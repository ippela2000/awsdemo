## Contributing to Nationwide cloud
* The following images show the step by step process of contributing to a repo [Nationwide/cloud-documentation](https://github.nwie.net/Nationwide/cloud-documentation).
* You need Git software to contribute.

### Clone the project on your local machine - you should only need to do this once!

#### Forking the master repo

* Before you can start making updates to the content you will need to fork the repo [Nationwide/cloud-documentation](https://github.nwie.net/Nationwide/cloud-documentation).
* Go to the main [repo]((https://github.nwie.net/Nationwide/cloud-documentation)) and click on the **Fork** icon
* Select your NWIE ID
* This creates a copy of the [Nationwide/cloud-documentation](https://github.nwie.net/Nationwide/cloud-documentation) under you id e.g. [kalurk2/cloud-documentation](https://github.nwie.net/kalurk2/cloud-documentation)
* Copy the url for your own repo
* Create a new directory **workspace** on your C: drive.  
    ```
        c:\workspace
    ```
    
#### Cloning your forked repo
    
* On the Windows Terminal change your directory to      
* Clone the repository using the **git clone** command in Windows Command Prompt 
    ```
       git clone <clone_link> <directory>
       
       e.g. git clone https://github.nwie.net/kalurk2/cloud-documentation.git kalurk2-cloud-docs
    ```


#### Create your own working copy of the code
* Complete these steps each time you want to make any content updates
* Open a terminal in the repository directory.
    ```
        C:\workspace\kalurk2-cloud-docs>
        
    ```
    
* Get the most current version of the code: Run the command on your terminal : 
    ```
        git pull origin master
    ```

* Create a new branch for your changes: The branch name should be indicative of the change you're making.
    ``` 
        git branch <branch_name>
        
        e.g. git branch kalurk2-contribution-guide
    ```
    
* Checkout the branch you just created: 
    ```
        git checkout <branch_name>.
    ```

* Push your new branch to GitHub: git push --set-upstream origin <branch_name>.
Git Push Branch

GitHub Branch Made

Make changes
Complete these steps for your branch when you make changes to files! Also, when working on a branch for extended periods of time, be sure to periodically update the master branch in case changes have been made by others with git pull origin master.

Open a terminal in the repository directory.
Make sure you are on your branch: Execute git checkout <branch_name>.
Make your changes: edit files, create files, delete files, etc.
After each categorical change commit:
git add <files you want to add> if you'd like to add specific files or git add -A to add all modified files.
git commit -m "Description of changes".
git push origin <branch_name>.
Adding Changes to Branch

Adding your changes to master
You should follow these steps when you're done working on a branch!

Open a terminal in the repository directory.
Make sure you are on the master branch: git checkout master.
Move over to your branch: git checkout <branch_name>.
Merge the master branch into your branch: git merge master.
These first few steps ensure that any updates to the master branch work with your changes.
If everything is working properly, push your branch to GitHub: git push origin <branch_name>.
Create a pull request on GitHub: Click the "Pull requests" tab towards the top of the page and then click "New pull request".
Choose the branch you want to create a Pull Request for (the branch you worked on, completed, and just pushed).
Provide a good description of what changes you made.
Submit your pull request.
Pull Request Init

Choose PR for Branch

PR Submit

Under "Reviewers" on the right side of the screen, add Ryan Mainwaring, mainwr1 to all PRs. In addition:
If your PR is regarding Cloud Data, also add Matt Haines, hainem1.
If your PR is regarding Cloud Infrastructure, add Taraneh Parvaresh, parvat1.
If your PR is regarding Cloud Security, add Michael Corlew, corlem1.
If your request is regarding Cloud Native Platform/Containers, add Vikas Chopra, choprav1
If your request is regarding Site Reliability Engineering, add the SRE team, @Nationwide/sre
They will triage your PR for review.