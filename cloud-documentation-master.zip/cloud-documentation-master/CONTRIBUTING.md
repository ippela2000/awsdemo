## About
Welcome to the Nationwide Cloud Documentation. The content on GoCloud is on Github [Nationwide/cloud-documentation](https://github.nwie.net/Nationwide/cloud-documentation) under the **content** folder.

## Table of contents
Read and follow the following documents before contributing to GoCloud. Links not in the **Required** category may be skipped.

### Required

- [Style Guide](https://istio.io/latest/about/contribute/style-guide/): A guide on how to make documentation clear and understandable for all users.
- [GoCloud Front Matter](https://github.nwie.net/Nationwide/cloud-documentation/blob/master/GOCLOUD_FRONT_MATTER.md): A GoCloud documentation specific guide for what front matter is and how to fill out the properties for it
- [Blog Front Matter](https://github.nwie.net/Nationwide/cloud-documentation/blob/master/BLOG_FRONT_MATTER.md): A GoCloud blog specific guide for what front matter is and how to fill out the properties for it
- [GitHub Process](https://github.nwie.net/Nationwide/cloud-documentation/blob/master/GITHUB.md): If you have not worked with GitHub before or need a refresher, read this.

### Optional
- [Markdown Cheat Sheet](https://www.markdownguide.org/cheat-sheet/): A concise guide of all the properties used in markdown
- [Markdown Tutorial](https://www.markdowntutorial.com/): A step by step tutorial on how to use mark down for beginners
