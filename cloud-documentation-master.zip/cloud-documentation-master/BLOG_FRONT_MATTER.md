## GoCloud blog

### Website section explanation
The homepage of the blog consists of all the blog posts currently available sorted by date, newest to oldest. On the right site of the homepage is a filter that sorts the blog post by category tag. These tags are created when the blog posts are created. All the tags are generated, without duplicates, and updated dynamically on the filter section of the homepage. When you check one (or more) of the filters, the homepage automatically shows the blog posts with those tags. When you click on a blog post, then you can see the full post, with an option to go back to the main screen.

### What is front matter? 
GoCloud blog website is built on a web framework called Hugo. The main structure of the blog post is markdown, but there are properties that the site uses to display other content (also called metadata). For example, the title property is used for the title section of the blog post listing page and the blog post itself and the menu property tells the site what section of GoCloud the document lives. More information on front matter can be found on Hugo's [website](https://gohugo.io/content-management/front-matter/).

### How to add a blog post
The [blog](https://github.nwie.net/Nationwide/cloud-documentation/tree/master/content/blog) is hosted on [GoCloud GitHub repository](https://github.nwie.net/Nationwide/cloud-documentation) so if you have contributed to GoCloud in the past, you will easily be able to contribute to the blog.

When creating a markdown-written blog post, you must include some properties at the top of the file. If this isn't followed, the pull request is rejected. Here is an example of the properties, anything in // is a comment/explanation of the property and does not need to be added.

```
---
title: "Introducing Site Reliability Engineering (SRE) at Nationwide!" //This is the title of the blog
menu: blog //This should not be changed, the website uses this to figure out what section of the site to put the file in
blogPost: true //conditional to denote blog posts from other posts
draft: false // Always false, otherwise you won't see the post
description: Introducing Site Reliability Engineering (SRE) at Nationwide! // Brief description of the blog post
tags: ["sre", "cloud"] // tags used to generate the filter section of the homepage
---
```

**Note:** menu, blogPost, and draft will always be the same value.

Once you add the properties above, wrapped in ---, your blog post is ready for release. Put in a Pull Request in github, and make sure you put the file in content/blog, otherwise the pr will be rejected. 

For support, email: CloudSuccessTeam@nationwide.com with APRMID: 8353