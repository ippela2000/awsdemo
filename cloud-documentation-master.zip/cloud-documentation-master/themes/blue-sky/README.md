# Hugo Blue Sky Theme
BlueSky Theme for Nationwide Cloud Documentation App

# Installation
- Use Homebrew or Chocolatey, depending on platform to install hugo core package
    - see [Hugo's Getting Started Gude](https://gohugo.io/getting-started/installing/)
- After Hugo is done installing, you will need to apply the theme to an existing hugo site or run `hugo new site SITENAMEHERE` with SITENAMEHERE being your sitename. This will initalize hugo and create the folder structure to apply the BlueSky theme.
- Once a Hugo site is ready to go. CD into the themes folder and clone the theme: https://github.nwie.net/orej2/hugo-bluesky.git
- Finally, to get the theme activated with our site, we open the `config.toml` file in our main Hugo site directory and add the following line `theme = "hugo-bluesky"`
- To run a local version of the site, run the following commands:
  - npm install
  - gulp
  - hugo server

# Styles
This project uses the latest version of the [Bolt design toolkit](https://prototype1.apps.nwie.net/). Web Components are loaded through the javascript loader in layouts/default/baseof.html. Typography is set sitewide via the bolt-typography class.

Site-specific styles are loaded though main.css, which is compiled from src/scss/main.scss. SCSS architecture follows [Hugo Giraudel's architecture guidelines](https://sass-guidelin.es/#architecture). Individual component-level and layout-level SCSS files should use '@import 'node_modules/@nationwide-bolt/tokens/dist/scss/_tokens.scss';' to make use of Bolt design tokens such as color names.

# Reference
As Hugo is still in active development, often the best way to find out how something is done is to see it in use. Most themes written with Hugo are available on GitHub, and allow you to see side by side the code and the site it generates. A few good resources:

- [Hugo Ananke Theme](https://themes.gohugo.io/gohugo-theme-ananke/)
- [istio.io](https://github.com/istio/istio.io)
