# CI-CD Processes

## Concourse
Concourse is used to build the `cloud-documentation` image and push to DTR.  Anytime a change is pushed to the master branch, concourse will automatically build a new image, tag it with the git commit ref AND the `latest` tag and push those to DTR.  Anyone can view the concourse Pipeline status by visiting the exposed pipeline here: https://concourse.nwie.net/teams/cloud-documentation/pipelines/pipeline

### Kube Secrets
Concourse requires kubernetes secrets in order to build and push the image to DTR; and to run the twistlock scanning.  They are stored in the secret `buildcreds` in the `concourse-cloud-documentation` namespace.

To make/update the secrets:
1. Create files `buildemail.txt`, `buildpassword.txt`, and `builduser.txt` in a directory that will **NOT** be committed to Github.  Each file should be one line, containing only the content of the filename
2. Run the following command to create the secret from the files:
```
kubectl create secret generic buildcreds --from-file=buildemail=./buildemail.txt --from-file=builduser=./builduser.txt --from-file=buildpassword=./buildpassword.txt
```

## Harness
Harness is the deployment part of `cloud-documentation`.  It is triggered to start whenever a new artifact (image) is pushed to DTR.  It will automatically deploy that new image to the test cluster and pause.  A manual approval is currently required to deplow those changes to production.  

### Harness Manual Approvals
To approve a production deployment:
1. Log on to [app.harness.io](https://app.harness.io)
2. Click on the flashing red bell in the upper-right corner
3. Click on Approvals Tab
4. All pending approvals for applications that you have access to will appear here

## Hugo Image
The `cloud-documentation` site is built off of the hugo framework.  Because there isn't a good publically available docker image for hugo, we maintain our own.  The Dockerfile for Hugo is in `ci-cd\docker\hugo\Dockerfile`

Currently, the Hugo image is manually built.  It must be built from the InfraSvcsProd AWS Account (CNP Jumpy Server) to prevent proxy issues when downloading dependencies.  Eventually, this should be moved to automatically build new images via concourse.

### Manually Building Hugo Image
1. From root of repository, run the following:

```bash
docker build -t dtr.aws.e1.nwie.net/cloud-documentation/hugo:v0.72.0-ubuntu-extended --build-arg hugoVersion=0.72.0 ./ci-cd/docker/hugo

# latest tag should match production
docker tag dtr.aws.e1.nwie.net/cloud-documentation/hugo:v0.72.0 dtr.aws.e1.nwie.net/cloud-documentation/hugo:latest
```

*Note: that the build arg `hugoVersion` is optional.  If specified, do not include the letter `v`.  If not specified, it will use the production value, which is set in the `Dockerfile`.*

