---
title: "Guaranteed Support"
menu: support
weight: 2
---

## Production incident support

* [ServiceNow Incident](https://nwproduction.service-now.com/incident.do?sys_id=-1&sysparm_query=active=true&sysparm_stack=incident_list.do?sysparm_query=active=true): For **Production** bugs, unavailable, or degraded cloud services.

  - Cloud/CNP: Assign the Incident to **CLOUD-SOLUTIONS**
  - Concourse: Assign the Incident to **NSC-WEB-CODE-MIGRATION**
  - Database : Assign the Incident in ServiceNow to the appropriate support team for database support. 


## Guaranteed support 
**Note:** _**This request is NOT for operational support of applications running in production**_
* [Request to engage a technology engineer](https://halo.nwie.net/#/support/guaranteed-support)  


    - This request **guarantees** a response from a Technology Engineer during core business hours (Monday - Friday, 9am - 5pm [EST]) **in 1 hour or less** to:  
        - Inform you that analysis of your request has begun  
        - Request any further information (if needed)  


    - This request type includes the following:
        1.  AWS
            - Troubleshooting : Troubleshooting AWS services  
            - General Consulting : Design Review/Architectural Guidance/Cost/Migrations  
              - Long running assistance  
              - Feature Request or Report a bug  
              - Enhancement for an existing pipeline product  
              - Identify a bug  

        2.  On-Prem Engineer Engagement
            - General Consulting
              - Troubleshooting
              - General questions or assistance
              - Long running, non-urgent assistance

            - Provisioning
              - Request for new service

