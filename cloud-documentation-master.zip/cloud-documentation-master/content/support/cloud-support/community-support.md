---
title: "Community Support"
menu: support
weight: 1
---


For general issues you can checkin the following before filing a ticket to the Cloud team.

1. [AnswerHub](https://nationwide.cloud.answerhub.com/index.html)
If you've got a quick question, the [Nationwide Cloud AnswerHub](https://nationwide.cloud.answerhub.com/index.html) is a good place to look for answers. Members of the various Cloud teams use AnswerHub to post answers to frequently asked questions, as well as answer questions from anyone who posts them. This is a "best effort" support approach from CDT and the various Cloud Solutions Teams.

2. [RocketChat](https://rocketchat.nwie.net/)
If you can't find the answer you're looking for on AnswerHub, the next step is to ask your question on one of the appropriate RocketChat channels.

The following links are to RocketChat channels that you may find valuable to join for questions and discussion:

[#AWS](https://rocketchat.nwie.net/channel/AWS) channel is available for questions and discussion. Support is primarily peer to peer, but Cloud Solutions and IDOC may provide basic support depending on availability.

[#AWS-NOTIFICATIONS](https://rocketchat.nwie.net/channel/AWS-NOTIFICATIONS)- Notifications on all AWS updates.  If you need questions answered about AWS, go to the main AWS channel, not here.

[#AWS-RELEASES](https://rocketchat.nwie.net/channel/AWS-RELEASES) - Notifications on releases from CDT team. If you need questions answered about AWS, go to the main AWS channel, not here.

[#aws-federator](https://rocketchat.nwie.net/channel/aws-federator) - Channel for aws-federator

[#gangplank](https://rocketchat.nwie.net/channel/gangplank) - Channel for Gangplank

[#harness](https://rocketchat.nwie.net/channel/harness) - Channel for Harness

[#cloud-data-services-ama](https://rocketchat.nwie.net/channel/cloud-data-services-ama) - Cloud Data Services

[#cloud-native-platform](https://rocketchat.nwie.net/channel/cloud-native-platform) - This is the main channel for issues related to Docker, Swarm, and Kubernetes, and the best way to reach the Cloud Platform team.

[#docker](https://rocketchat.nwie.net/channel/docker) - Anything Docker-related.

[#concourse-ci](https://rocketchat.nwie.net/channel/concourse-ci) - Channel for Concourse

[#site-reliability-engineering](https://rocketchat.nwie.net/channel/site-reliability-engineering) - Channel for SRE 

[#pcf-platform](https://rocketchat.nwie.net/channel/pcf-platform) - This channel is monitored by the Pivotal Cloud Foundry (PCF) team.

[#imedia-pcf](https://rocketchat.nwie.net/channel/imedia-pcf) - This is iMedia's channel, but it is also monitored by the PCF team.







#### Cloud Dojo
You can also email the following group: Cloud_Dojo_Hotline@nationwide.com with any Cloud or Dojo questions. This is a "best effort" support approach from CDT and the various Cloud Solutions Teams.

