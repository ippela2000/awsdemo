---
title: Postmortem Guide
menu: support
category: sre
weight: 6
---
## Postmortem 101

### What is a postmortem?

[A postmortem is a written record of an incident, its impact, the actions taken to mitigate or resolve it, the root cause(s), and the follow-up actions to prevent the incident from recurring.](https://landing.google.com/sre/sre-book/chapters/postmortem-culture/)

### Why should I write a postmortem?

The ultimate goal of writing a postmortem is to identify and prioritize action items that will help prevent, detect, or mitigate a repeat of the incident. Writing a postmortem helps everyone, from executives to engineers, understand:

- What happened, and when
- The impact, from a technical and business perspective
- Teams/people involved in responding to the incident
- Actions taken to mitigate the incident and the causes of the incident
- What went well, what went poorly, and actions items needed to prevent a recurrence 

### When should I write a postmortem?

>Common postmortem triggers include:
>
>- User-visible downtime or degradation beyond a certain threshold
>- Data loss of any kind
>- On-call engineer intervention (release rollback, rerouting of traffic, etc.)
>- A resolution time above some threshold
>- A monitoring failure (which usually implies manual incident discovery)

Source: https://landing.google.com/sre/sre-book/chapters/postmortem-culture/#googles-postmortem-philosophy

### How to be "blameless"

>Blameless postmortems are a tenet of SRE culture. For a postmortem to be truly blameless, it must focus on identifying the contributing causes of the incident without indicting any individual or team for bad or inappropriate behavior. A blamelessly written postmortem assumes that everyone involved in an incident had good intentions and did the right thing with the information they had. If a culture of finger pointing and shaming individuals or teams for doing the "wrong" thing prevails, people will not bring issues to light for fear of punishment.
>
>Blameless culture originated in the healthcare and avionics industries where mistakes can be fatal. These industries nurture an environment where every "mistake" is seen as an opportunity to strengthen the system. When postmortems shift from allocating blame to investigating the systematic reasons why an individual or team had incomplete or incorrect information, effective prevention plans can be put in place. You can’t "fix" people, but you can fix systems and processes to better support people making the right choices when designing and maintaining complex systems.
>
>When an outage does occur, a postmortem is not written as a formality to be forgotten. Instead the postmortem is seen by engineers as an opportunity not only to fix a weakness, but to make Google more resilient as a whole. While a blameless postmortem doesn’t simply vent frustration by pointing fingers, it should call out where and how services can be improved. Here are two examples:
>
>#### Pointing fingers
>"We need to rewrite the entire complicated backend system! It’s been breaking weekly for the last three quarters and I’m sure we’re all tired of fixing things onesy-twosy. Seriously, if I get paged one more time I’ll rewrite it myself…"
>
>#### Blameless
>"An action item to rewrite the entire backend system might actually prevent these annoying pages from continuing to happen, and the maintenance manual for this version is quite long and really difficult to be fully trained up on. I’m sure our future on-callers will thank us!"

Source: https://landing.google.com/sre/sre-book/chapters/postmortem-culture/#googles-postmortem-philosophy

## The postmortem process

### During the incident

During the incident, keep an [incident document](https://landing.google.com/sre/sre-book/chapters/incident-document/) with timelines, actions, TODOs, and other information that will help you create your postmortem. For a P0, Enterprise Command Center (ECC) Incident Management will create a document; otherwise SRE suggests using a OneNote notebook shared with others who are working on the incident with you.

### Writing the postmortem

You should begin the postmortem immediately after conclusion of the incident, or if the incident occurs off-hours, the next business day. Aim to complete the postmortem in two business days or less. SRE suggests using [this](https://raw.github.nwie.net/Nationwide/SRE/master/postmortemTemplate.md) template and storing your postmortem in your GitHub repository. (Integration w/ SNOW TBD)

For help writing your postmortem, check out some of our favorite examples:

1. [Cloudflare Global Ooutage, July 2nd, 2019](https://blog.cloudflare.com/details-of-the-cloudflare-outage-on-july-2-2019/)
2. [S3 Service Disruption in Northern Virginia, February 28th 2017](https://aws.amazon.com/message/41926/)
3. [iMedia MFA Issue P1, April 30th, 2020](https://github.nwie.net/Nationwide/imedia/issues/504)
4. [Google Example Postmortem Document](https://landing.google.com/sre/sre-book/chapters/postmortem/)

### Reviewing the action items

After completing the postmortem document, you should schedule a postmortem review with any relevant stakeholders, including your team, the APM(s) for the impacted applications, and any team with action items. The goal of this meeting is to prioritize and establish buy-in for completing the action items to prevent, detect, or mitigate future recurrences of the incident. We recommend [this](https://postmortems.pagerduty.com/meeting/) guide to help you conduct an effective postmortem meeting.

## When to use a RCA in addition to a postmortem

If the incident in question is a major incident, or if requested by a stakeholder (including you!), Problem Management will/may conduct a facilitated Root Cause Analysis. Bring your postmortem to the RCA - it will save time and provide valuable insights!

![Graphic of postmortem and RCA processes](/support/sre/images/postmortem_rca.png)
