---
title: Design Recommendations
menu: support
category: sre
weight: 3
---

Below is a generic list of design recommendations that have been gathered from Design Review engagements with different application teams.

A review specifically tailored to your application can be requested by opening up a Design Review [here](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-docs/design-recommendations/)

## Understand/Implement Monitoring and Logging for All Applications

**EC2**

Infrastructure performance monitoring with New Relic is configured by default on all EC2s. Application performance monitoring should be configured per application by the application team (New Relic is the enterprise standard).

By default, basic CloudWatch logs are emitted for EC2s. Advanced CloudWatch logging can be enabled and configured. CloudWatch logs go to Splunk Cloud.

**Kubernetes**

At this time, logs can be accessed using command line (kubectl), Docker Enterprise Universal Control Plane (UCP), or through Splunk Cloud. The Kubernetes platform will automatically capture a container’s standard output (stdout) and standard error (stderr) streams and send this information to Splunk Cloud (indexed under “cnp”). For an application that cannot log directly to Splunk or has additional logs files that need to be shipped, a sidecar container can be used to pull those logs.

New Relic, Kubewatch, Cloudability, Metrics Server and Kube-State-Metrics are added to each Kubernetes cluster and managed as a service by the Cloud Platform Team. Kubewatch is a Kubernetes event stream watcher. It watches configured events and publishes those events to a webhook or a chat service. Cloudability monitors and reports on cloud expense metrics. More information on installed services is available [here](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/cnp-features/).  More information about cluster logging is available [here](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/Logging/).

Application monitoring can be instrumented through your deployed application and/or the container it is running on. A library of standard base container image is documented within GitHub [here](https://github.nwie.net/Nationwide/docker-library), many of these images include an appropriate New Relic APM agent – simply complete the configuration and many default metrics will be available. More information about application logging/monitoring on the CNP platform is available [here](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/application-logging/).

The SRE Team recommends implementation of monitoring using Nationwide Enterprise Standard Tools, however, the SRE Team is generally tool agnostic and is willing to assist with implementation of monitoring using any tool(s) designed for such a purpose.

---

Additional information about logging in general is available [here](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/monitor-and-alert/).

## Understand/Implement Alerting for All Applications

Alerting should be configured through a tool that works for the application team, but Enterprise Standards include New Relic, CloudWatch (CloudWatch Alarms) and Splunk Cloud in conjunction with ServiceNow.

The SRE Team recommends implementation of alerting using Nationwide Enterprise Standard Tools, however, the SRE Team is generally tool agnostic and is willing to assist with implementation of monitoring using any tool(s) designed for such a purpose.

Additional information about alerting in general is available [here](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/monitor-and-alert/).

## SLIs and SLOs for All Applications

The establishment of SLIs (Service Level Indicators) and SLOs (Service Level Objectives) can only be completed after implementation of monitoring and alerting, and as such is not a concurrent task. SLIs are “carefully defined quantitative measure of some aspect of the level of service that is provided.” The SRE Team recommends implementation of SLIs regarding latency, error rate, throughput, and availability.

SLOs or Service Level Objectives are, “a target value or range of values for a service level that is measured by an SLI.” SLOs set expectations regarding how a given service will perform. Explicitly set and published SLOs will guide user and team expectations regarding a service.

The establishment of SLIs and SLOs can prove challenging. Engagement with the SRE team for this effort is strongly recommended.

## Recoverability

A mitigation strategy should be created and tested to ensure that these applications can auto-recover in the event of failure of the primary instance for any reason. Autoscaling may be an option to ensure recoverability if the application in question can support multiple running instances at a time.

## Blue/Green Deployments (EC2)

The implementation of a blue/green pipeline and deployment strategy will ensure the application team is able to release as needed. At present, any deployment using the Simple Pipeline will cause a lengthy outage in the environment being deployed to, including production.

## Dependency Mapping & Risk Mitigation

It is the recommendation of the SRE team that a documented list of dependencies and actions to be taken in the event of dependency failures be created. Beginning with the most common failures and adding to the list will help operations personnel to determine what actions can and should be taken during dependency failures.

Centralize this information in a run book:

Runbooks are documented procedures to achieve specific outcomes. Enable consistent and prompt responses to well-understood events by documenting procedures in runbooks. Implement runbooks as code and trigger the execution of runbooks in response to events where appropriate, to ensure consistency, speed responses, and reduce errors caused by manual processes.

## GameDay – HA/DR Testing

The SRE team recommends that “GameDays” be run where scenarios that require response are introduced and the team responds as if a genuine problem were occurring. This will hone the procedures and run book documentation while also training the team on an ongoing basis. With this effort, the team should automate their existing rollback strategy.
Centralize investigation strategies used to identify issues in a play book:
Playbooks are documented processes to investigate issues. Enable consistent and prompt responses to failure scenarios by documenting investigation processes in playbooks. Implement playbooks as code and trigger playbook execution in response to events where appropriate, to ensure consistency, speed responses, and reduce errors caused by manual processes.

## Fully automated installation of Applications

The application team has an “automated but manual” method available for deployment of applications on an EC2 instance. This method allows relatively untrained personnel to quickly deploy applications as required. The SRE team recommends, as time allows, fully automating the deployment of applications based on the existing method. With this work completed a fully automated pipeline run could be completed in response to specific alerts or triggers with no manual intervention.

## Build Once, Deploy Anywhere

In order to minimize potential sources of change/defects, the application team should strive for a solution that follows build once, deploy anywhere. Currently the team rebuilds their application in production and per environment for password changes. Solutions should be investigated to avoid this including utilizing AWS native services Secrets Manager or Parameter Store. This exists as a low priority due to the team’s desire to rewrite the applications.

In order to minimize potential sources of change/defects, the application team should strive for a solution that follows build once, deploy anywhere. Currently the team rebuilds their front and back end per environment for property file changes. Solutions should be investigated to avoid this.
Docker/Environment Variable Solution: https://medium.com/@OlegVaraksin/configure-angular-cli-build-for-different-stages-in-cloud-7c22410c724b
Supplemental Solutions: https://www.jvandemo.com/how-to-use-environment-variables-to-configure-your-angular-application-without-a-rebuild/

## Eliminate Shared Infrastructure

The team understands and has chosen to accept the risk associated with coupling 9 applications in a single pipeline and shared EC2 instances. The SRE team stands by this recommendation, but understands the priority is to rewrite the applications as opposed to addressing all design recommendations.
As discussed during the design review session, the use of a single EC2 instance (supporting 9 applications) in a single availability zone creates significant risk. These scenarios include, but are not limited to, underlying AWS hardware failures, AZ Network connectivity issues and deployments.


## Implement Quality Gates

Quality gates verify that the products we build perform as expected, follow best practices, and are secure. Within a CI/CD pipeline, certain actions should be automated to ensure a quality product is delivered to our end users. For example, during pull-request automation, unit tests can execute, static code analysis can perform code reviews and security checks, and feature tests can run against an ephemeral application environment. Then, as an artifact is deployed through environments, smoke tests or full test suites can provide further confidence of a reliable system.

## Automate Rollback

The application team has done well to embrace automated deployments through Helm and is aware of the rollback capabilities of Helm. To extend on this good work, we recommend fully automating the rollback procedure so minimal human interaction is required. A good first step toward this goal could be implementing a Concourse pipeline that executes the necessary commands to achieve the rollback.

## Database Backups

Using managed database snapshot and restore capabilities is a good start, but further actions could be taken to ensure reliable access to data. For example, with a multi-tenant database instance (multiple databases on the same database server) restoring from a snapshot will affect all applications utilizing the server. To mitigate this risk, it is suggested to leverage database specific tools to create light weight backups at appropriate times. This will likely require the assistance of the distributed database DBA team to acquire access to appropriate credentials to perform the necessary actions to backup and restore an individual database from the backup file.
Also, even though the risk is small it may be worthwhile to disconnect your applications from the database in a way that allows them to continue to operate, although at a degraded level while the database is unavailable. This can be achieved by creating an event stream for actions to modify the database and reading data through a well configured cache mechanism.

## Cost Optimization

NoSQL data storage should be investigated as a method of further cost optimizing these applications. Currently, two NoSQL Database Systems are awaiting TSB approval.
https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/0-Platform-Product-Services/
The current status of these offerings can be viewed here: https://github.nwie.net/search?q=org%3ANationwide+nosql&type=Issues
The team should feel free to contribute to these issues and list their use cases.

## User Authorization

Currently, Windows directory credentials and groups provide the necessary information for user authorization. While there is no API-enabled enterprise solution for this issue available at this time, there is an effort underway in collaboration between IRM and SDS to open up an API to IIQ which will likely fill this gap. If necessary, however, it is technically possible to implement a light-weight authorization service that can be managed by trusted users and consumed through Java APIs (see: https://github.nwie.net/Nationwide/whoville-auth for an example)

## Production Pipeline Deployments

The implementation of a production pipeline and deployment strategy will ensure the application team is able to release as needed. At present, no production pipeline exists so any changes would need to be implemented manually into production. By implementing a production pipeline deployment the application team can release with confidence whenever needed.

## Investigate Serverless

Analysis should be done to determine if you application may be a good candidate for serverless architecture (using AWS Lambda). A review of how consumers require access to SAMS data may show they have a tolerance for slow “cold starts” which would lead to a relatively easy re-write/re-platform for these services. Other options still exist to mitigate the “cold start” issue that serverless applications can experience. Benefits to this approach include automatic provisioning of compute power, automatic scaling to application demand, and pay only for what you use pricing (among other benefits).



