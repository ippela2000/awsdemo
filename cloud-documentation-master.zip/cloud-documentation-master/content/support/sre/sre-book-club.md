---
title: "SRE Book Club"
menu: support
category: sre
weight: 5
---

We recommend the below consolidated reading list as a good dive into SRE concepts. The chapters come from the [SRE Handbook](https://landing.google.com/sre/sre-book/toc/index.html) and the [SRE Workbook](https://landing.google.com/sre/workbook/toc/). Please browse the Table of Contents and be sure to include chapters that are relevant to your audience.

Study guides are provided below to help facilitate your self-run book club. We recommend allocating an hour per week for reading, plus an additional hour per week for discussion, based on the eleven week plan below.

|Session|Topic|Readings|Study Guide|
|---|---|---|---|
|1|Introduction|[Introduction](https://landing.google.com/sre/sre-book/chapters/introduction/), [How SRE Relates to DevOps](https://landing.google.com/sre/workbook/chapters/how-sre-relates/)|[Intro Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/intro-guide/)|
|2|Service Level Objectives Part 1|[Embracing Risk](https://landing.google.com/sre/sre-book/chapters/embracing-risk), [Service Level Objectives](https://landing.google.com/sre/sre-book/chapters/service-level-objectives)|[SLO Pt 1 Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/slo-guide-pt-1/)|
|3|Service Level Objectives Part 2|[Implementing SLOs](https://landing.google.com/sre/workbook/chapters/implementing-slos/), [Sample SLO Document](https://landing.google.com/sre/workbook/chapters/slo-document/)|[SLO Pt 2 Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/slo-guide-pt-2/)|
|4|Monitoring|[Monitoring Distributed Systems](https://landing.google.com/sre/sre-book/chapters/monitoring-distributed-systems), [Monitoring](https://landing.google.com/sre/workbook/chapters/monitoring)|[Monitoring Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/monitoring-guide/)|
|5|Alterting|[Practical Alerting](https://landing.google.com/sre/sre-book/chapters/practical-alerting), [Alerting on SLOs](https://landing.google.com/sre/workbook/chapters/alerting-on-slos)|[Alerting Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/alerting-guide/)|
|6|On-Call|[Being On-Call](https://landing.google.com/sre/sre-book/chapters/being-on-call), [On-Call](https://landing.google.com/sre/workbook/chapters/on-call)|[On Call Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/on-call-guide/)|
|7|Incidents|[Effective Troubleshooting](https://landing.google.com/sre/sre-book/chapters/effective-troubleshooting), [Emergency Response](https://landing.google.com/sre/sre-book/chapters/emergency-response), [Managing Incidents](https://landing.google.com/sre/sre-book/chapters/managing-incidents), [Incident Response](https://landing.google.com/sre/workbook/chapters/incident-response/)|[Incident Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/incident-guide/)|
|8|Postmortem Culture|[Postmortem Culture: Learning From Failure (Handbook)](https://landing.google.com/sre/sre-book/chapters/postmortem-culture), [Example Postmortem](https://landing.google.com/sre/sre-book/chapters/postmortem), [Postmortem Culture: Learning From Failure (Workbook)](https://landing.google.com/sre/workbook/chapters/postmortem-culture)|[Post Mortem Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/post-mortem-guide/)|
|9|Simplicity|[Simplicity (Handbook)](https://landing.google.com/sre/sre-book/chapters/simplicity), [Simplicity (Workbook)](https://landing.google.com/sre/workbook/chapters/simplicity)|[Simplicity Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/simplicity-guide/)|
|10|Toil|[Eliminating Toil (Handbook)](https://landing.google.com/sre/sre-book/chapters/eliminating-toil), [Eliminating Toil (Workbook)](https://landing.google.com/sre/workbook/chapters/eliminating-toil), [Canarying Releases](https://landing.google.com/sre/workbook/chapters/canarying-releases)|[Toil Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/toil-guide/)|
|11|Team & Collaboration|[Communication and Collaboration in SRE](https://landing.google.com/sre/sre-book/chapters/communication-and-collaboration), [Reaching Beyond Your Walls](https://landing.google.com/sre/workbook/chapters/reaching-beyond), [SRE Team Lifecycle](https://landing.google.com/sre/workbook/chapters/team-lifecycles)|[Team & Collaboration Guide](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/sre-book-club-docs/team-collaboration-guide/)|
