---
title: "SRE"
menu: support
category: sre
weight: 2
---

## What Is Site Reliability Engineering?
Site Reliability Engineering (SRE) was developed by Google in the early 2000s in response to the limitations of traditional production operations practices. By treating ["operations as if it's a software problem,"][1] Google has built reliable, performant, scalable systems that require minimal manual operations work, freeing operations and run resources to spend their time on understanding and preventing problems from happening, rather than reacting to them.

Site Reliability Engineering is often conceptualized in three ways:

1. [As a role][2]
2. [As a team][3] 
3. [As a mindset and set of practices][4]

Since the publication of [Site Reliability Engineering][5], SRE has become a common role in the technology industry. Nationwide's team was founded in mid-2018, and after several years assisting with cloud migration work, is now focused on performing SRE work. 

Site Reliability Engineering is also a mindset and a set of practices that can be used by any team to improve the reliability of their systems and reduce repetative, manual efforts to keep systems operating coined toil by the SRE community. A distilled set of key practices is available [here][6], with more details available in [Google's SRE books][7] and [RocketChat][8]

## What Do Site Reliability Engineers Do?
["In general, an SRE team is responsible for availability, latency, performance, efficiency, change management, monitoring, emergency response, and capacity planning."][9] SREs are experts in both software development and systems management, and are able to work across system, technology, and organizational boundaries to build reliable systems and debug complex problems.

In addition to hands-on problem solving, SREs will consult with teams who want help building and operating reliable systems, create tools and patterns to improve reliability, and eliminate or automate operational [toil][10].

Common reasons to engage Site Reliability Engineering are:

1. For design reviews and questions when designing new systems, to ensure reliability and supportability are built in from the beginning.
2. To facilitate the creation and implementation of [Service Level Indicators and Service Level Objectives][11]
3. To help improve monitoring and alerting, including reducing noisy alerts and implementing a strategy of [alerting on SLOs][12]
4. To facilitate the adoption of [postmortem culture][13] in a team or BSA
5. To engage SRE to operate services in production according to SRE practices
6. For assistance in identifying and automating [toil][10] or creating tooling

## How Can I Get Started With Site Reliability Engineering?
Ready for a different approach to building and running reliable systems? Ready to start making tomorrow better than today? There is no wrong way to get started, but here are a few ideas:
- Educate yourself further - The books cited above from Google are available for free, online. Check them out [here][7].
- Identify opportunities - SLOs, SLIs, and error budgets create a consistent, mathematical calculation of when to focus on new features vs reliability. Often however there is low hanging fruit we can identify even in advance of that equation. What's causing the most toil for your team?
- Want to talk about starting an engagement with the Nationwide team of SREs? Reach out to us SRE@Nationwide.com
- Last, but not least, follow this blog! We plan on posting all kinds of goodness here, from reusable solutions to ideas that offer inspiration. Stay tuned, there is more to come! 


[1]: https://landing.google.com/sre/
[2]: https://onyourside.sharepoint.com/:w:/r/sites/ITWE/LearningCircles/_layouts/15/doc2.aspx?sourcedoc=%7B4B8C4FBB-F85C-4A54-BB4D-7B1FD2B15B9E%7D&file=Consultant%20Site%20Reliability%20Engineer_Final.docx&action=default&mobileredirect=true&cid=d5043937-d3e8-49e9-ba99-5f0fc9cb3a05
[3]: https://callup.nwie.net/orgChart/U2FsdGVkX1+PhDzoUYR1hR5qZTjRpnzaBWxToNmmJ54=
[4]: https://landing.google.com/sre/workbook/chapters/how-sre-relates/
[5]: https://landing.google.com/sre/sre-book/toc/index.html
[6]: https://onyourside.sharepoint.com/sites/nwcloudnews/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2Fnwcloudnews%2FShared%20Documents%2FInformational%20Material%2FSRE%2EMaturity%2EModel%2Ev1%2Epdf&parent=%2Fsites%2Fnwcloudnews%2FShared%20Documents%2FInformational%20Material&p=true&originalPath=aHR0cHM6Ly9vbnlvdXJzaWRlLnNoYXJlcG9pbnQuY29tLzpiOi9zL253Y2xvdWRuZXdzL0VUS2Vnay15WGZSR3M4R0RFeVVxRDNZQnpkejcxeEluYWFzMlFzNG5ES1F0OXc_cnRpbWU9RG9Bbl9mMEgyRWc
[7]: https://landing.google.com/sre/books/
[8]: https://rocketchat.nwie.net/channel/site-reliability-engineering
[9]: https://landing.google.com/sre/interview/ben-treynor-sloss/
[10]: https://landing.google.com/sre/sre-book/chapters/eliminating-toil/
[11]: https://landing.google.com/sre/sre-book/chapters/service-level-objectives/
[12]: https://landing.google.com/sre/workbook/chapters/alerting-on-slos/
[13]: https://landing.google.com/sre/sre-book/chapters/postmortem-culture/


