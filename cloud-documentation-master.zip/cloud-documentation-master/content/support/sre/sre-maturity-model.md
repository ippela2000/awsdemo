---
title: SRE Maturity Model
menu: support
category: sre
weight: 4
---

## Put the user experience first with SLOs 

As a technology professional, you focus on ensuring the health of your systems – monitoring aspects like CPU/RAM, uptime, storage consumption, and more. But from the perspective of your users, these things are invisible – what matters is whether they can complete their intended tasks quickly and successfully using your service. 

But wait – what does “quickly” and “successfully” mean to your users? And how do you know what they are experiencing? 

**Service Level Indicators (SLIs)** are *measurements* of things users care about – like availability, latency, data freshness, etc. [SLIs help you understand key aspects of the user experience](https://landing.google.com/sre/sre-book/chapters/service-level-objectives/). 

**Service Level Objectives (SLOs)** are *targets* – such as 99% availability or 95% of requests returning in less than 200ms. SLOs are set by the product owner based on their understanding of your user’s expectations. They enable you to see if your services are meeting expectations, or you should invest in improvements . 

**Service Level Agreements (SLAs)** are *contracts with consequences*. For example, a service might promise 99.99% monthly availability, and to pay a penalty fee of $500 per customer if that target is not met. SLAs are not required to use SLOs, but can provide an extra layer of assurance, especially for external customers. 

### If you’re doing well 

1. [Your services have SLOs defined](https://landing.google.com/sre/workbook/chapters/slo-document/) and in common use within the team and outside stakeholders 
2. [You alert on SLOs](https://landing.google.com/sre/workbook/chapters/alerting-on-slos/), rather than system health metrics 
3. You pause feature releases when SLOs are not met and focus on reliability improvements 

### If you’re doing poorly 

1. You don’t have SLOs, or the SLOs you have are only used by operations teams 
2. Failing to achieve SLOs does not trigger a shift in prioritization from features to reliability 

## Use blameless postmortems to prevent recurring issues 

How do you respond when your systems inevitably fail? How do you prevent them from failing repeatedly in the same way? Blameless postmortems offer a solution. 

When you experience failures that meet [certain criteria](https://landing.google.com/sre/sre-book/chapters/postmortem-culture/), such as: 

- User-visible downtime or degradation beyond a certain threshold 
- Data loss of any kind 
- On-call engineer intervention (release rollback, rerouting of traffic, etc.) 
- A resolution time above some threshold 
- A monitoring failure (which usually implies manual incident discovery) 

You can use blameless postmortems to: 

1) identify the contributing causes of the issue 
2) identify actions to prevent the issue happening again.  

### If you’re doing well 

1. You’re creating postmortems for every eligible incident, beginning within 24 hours 
2. You prioritize postmortem action items and treat them the same as feature work 
3. Criteria for conducting a postmortem are well defined and publicized 
4. Teams share and learn from each other’s postmortems 

### If you’re doing poorly 

1. Many incidents have occurred with the same underlying causes 
2. You track and prioritize postmortem action items differently than feature work 
3. Teams focus on avoiding and deflecting blame after outages 

## Reduce blast radius with small and gradual releases 

No matter how well you test, releasing changes into production will always be risky. You can cut the risk and blast radius (impact) of changes by making your changes as small as possible and releasing them gradually, allowing you to see the impact of the change on a subset of your system and take corrective action if there are any issues. 

Three common tactics include: 

**[Blue Green](http://blog.itaysk.com/2017/11/20/deployment-strategies-defined)** deploys use two environments (traditionally “blue” and “green”) in an active/passive configuration. While the “blue” environment serves production traffic, “green” receives new changes. The environments are then swapped, sending production traffic to green and making blue the inactive environment. If you observe negative impacts from the changes, you can reverse the swap, and serve traffic out of the “blue” environment while troubleshooting occurs. 

**[Feature Flags](https://github.com/launchdarkly/featureflags/blob/master/1%20-%20Introduction.md)** wrap new features and allow you to enable or disable them on the fly. With feature flags, you can silently deploy features into production and release them later with the click of a button. If the feature doesn’t work as expected, you can disable it just as easily while working on a fix. 

More advanced implementations of feature flags can provide even more granular control over feature releases. You can make features available to available to different user groups based on persona, location, channel, or other groupings as desired. 

A **Canary release** validates changes by gradually releasing them to users, starting with a small group and incrementally reaching 100%. If you observe unexpected issues  at any increment, you can pause the canary or roll back to the previous increment until you're able to troubleshoot. Canary releases pair well with blue green deploys and feature flags. 

### If you’re doing well 

1. Anyone on the team can safely deploy changes on-demand 
2. You automatically detect and roll back bad changes within five minutes 

### If you’re doing poorly 

1. Releases are “all or nothing” 

## Design for failure with self-healing systems 

1. [All complex systems operate in a state of continuous partial failure.](https://www.researchgate.net/publication/228797158_How_complex_systems_fail) How should you respond to these failures? What steps can you take to minimize the impacts of failures when they do occur? 
2. By (re)designing your systems to self-heal, you can avoid user impact and operator intervention for many failure scenarios. For example, you can use [EC2](https://docs.aws.amazon.com/autoscaling/ec2/userguide/healthcheck.html) or [Kubernetes](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/) health checks and autoscaling features to replace unhealthy components of your service automatically, without user impact or manual operator intervention. 

### If you’re doing well 

1. You only [page humans](https://landing.google.com/sre/sre-book/chapters/monitoring-distributed-systems/) when they need to take immediate action to prevent or fix an incident, no more than twice per day 
2. You regularly run [chaos testing](https://github.nwie.net/Nationwide/ChaosWorkshop) against your production environment without user impact 
3. Your systems automatically detect and recover from routine failures 

### If you’re doing poorly 

1. The team suffers from pager fatigue 
2. Your system requires frequent manual interventions (e.g. restarting a server/service) 
3. The number of interventions required increases as the system scales to handle more load 
4. DR/resiliency activities require pre-planning, coordination, and manual execution 

## Spend time on work that matters by eliminating toil 

[“Toil is the kind of work tied to running a production service that tends to be manual, repetitive, automatable, tactical, devoid of enduring value, and that scales linearly as a service grows.”](https://landing.google.com/sre/sre-book/chapters/eliminating-toil/) By eliminating toil, you can free up time for valuable engineering work that produces permanent improvements to a product or service. 

### If you’re doing well 

1. Your team is spending no more than 50% (and preferably much less) of its time on toil 
2. The time and money invested in operating your services scales sub linearly with service growth 

### If you’re doing poorly 

1. Your team spends more than half of its time on toil, especially repetitive toil 
2. The time and money invested in operating your services scales linearly with service growth 
