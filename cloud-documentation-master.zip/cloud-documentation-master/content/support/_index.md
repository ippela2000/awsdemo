---
title: "Support"
description: "As Nationwide embarks on our journey to the cloud, there are changes in how applications are supported"
menu: main
weight: 4
---


## Overview

Application teams will be empowered and expected to take a greater role in designing and operating their application's infrastructure, while Cloud Solutions will provide a common platform and escalation support for issues experienced in the cloud.

![Support Structure](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/team-support.png)

## Application Team Responsibilities

Application teams will now be responsible for developing and supporting their own infrastructure. This includes:

### Infrastructure

- Configuring monitoring and alerting – base configuration will be provided by Cloud Solutions. (NCS-ESM-SYSTEMS-MANAGEMENT) will continue to be available for consulting.
- CI/CD Pipeline: Created by Cloud Solutions automation, these are owned and can be updated by teams to meet their needs.
- Currency: Applications will be required to redeploy through their CI/CD Pipeline on a monthly basis with updated AMIs. For applications which cannot use this method, traditional patching is available by exception.


### Incident Resolution

Application teams will have primary responsibility for responding to and resolving incidents for their infrastructure in the cloud.

* **P0 Incidents:** the ECC will coordinate the necessary teams to resolve the incident.

* **P1-P4 Incidents:** Application teams may use [self-service through community support](/support/cloud-support/community-support) options to resolve the incident. If this is insufficient, escalation to Cloud Solutions is available through [Guaranteed Support](/support/cloud-support/guaranteed-support)

* If you have an incident which requires database support, open an incident in ServiceNow to the appropriate support team

## Cloud Solutions | Cloud Delivery Team Responsibilities

Cloud Solutions will be responsible for items that are AWS Cloud related. This includes:

* Pipeline Factory: Generates new pipelines with template Cloudformation for application team consumption.
* Responders: Detect and correct security and compliance issues, automatically.
* Identify & Access Management: For platform and shared services; application teams manage IAM for their applications.
* Accounts: Creating and configuring account stacks prior to turning them over to BSAs.
* Cloud Solutions also provide support for the products they own and migration consulting support. Refer to the [Cloud Support](/support/cloud-support/) page for more details.

## Infrastructure & Operations Distributed Database Responsibilities

* The Distributed Database Team will continue to provide build and operational support for databases in the cloud as they do today for on-premise applications.
* To engage the team to support your migration, please enter a [ServiceNow Database Administration Request](https://nwproduction.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D258993eddb0d6f00c2937b27689619f4%26sysparm_link_parent%3Dcb8d9b290f1f7100a5eee478b1050e65%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_Service_Catalog).
* If you have an incident which requires database support, open an incident in ServiceNow to the appropriate support team

## Infrastructure & Operations Responsibilities

I&O will be responsible for continued support of on-premise applications and items that have been moved into the Cloud as needed. This includes:

- Data Center Access – regular access from data center to AWS Cloud
- Solutions Engineering – the Solution Engineering team will take on a consultancy role to provide “white glove” support to application teams as needed
- SMEs – provide subject matter expertise to specific products and services that are now AWS Cloud specific (i.e. Tomcat, Linux, etc.)
- VPC Networking Configuration – tasks such as VPC creation, subnet creation and modification, routing creation and modification, subnetting design and planning, and NAT gateway and Internet Gateway implementation decisions
- Incident Management – this process will not change; the team will continue to facilitate high priority tickets. The only difference will be the number of teams that are involved; it will flex as needed.
- Problem Management – will provide RCA following a major incident (i.e. P0)
- Patching – provide foundational pipelines for patching, etc.

## SRE Support

* SRE team provides consulting and operational services. Refer to the [SRE Service Catalog](/support/sre/service-catalog) for a list of service provided




