---
title: Storage
menu: docs
category: cnp
---

## Supported storage

The platform currently supports two different types of storage, Amazon Elastic File System (EFS) and Amazon Elastic Block Store (EBS). The storage class you use will vary depending on your needs.  

### Storage classes

To get a list of the currently supported storage classes, run `kubectl get storageclass`.

```shell
kubectl get storageclass
NAME              PROVISIONER              AGE
efs-gp (default)  aws-efs                  27m
gp2               kubernetes.io/aws-ebs    15d
io1               kubernetes.io/aws-ebs    15d
block             pure-provisioner         21h
network           nfs-client-provisioner   1d
nfs-client        nfs-client-provisioner   6d
pure              pure-provisioner         23h
pure-block        pure-provisioner         23h
```

### Network (EFS or NFS)

Network is a generic storage type that will vary depending on the cluster.
Clusters in AWS will be backed by EFS, while clusters in Nationwide's datacenters will be backed by NFS.
This allows you to specify the storage class of network, and have it just work, no matter where your cluster is running.

### Block (EBS or Pure)

Block is a generic block storage type that will vary depending on the clusters.
Clusters in AWS will be backed by EBS (gp2) while clusters in Nationwide's datacenters will be backed by PURE.
This allows you to specify the storage class of block, and have it just work, no matter where your cluster is running.

### NFS-Client (NFS)

NFS is used to provide a network filesystem inside Nationwide's datacenters.

NFS is just like EFS in AWS, except it does not grow forever.
If you need to use NFS for large amounts of data, please inform the Cloud Platform Team so we can make sure there is enough storage to back up your requests.

NFS is flexible as it allows multiple PODs to access the same PV.

### PURE (Block storage)

Pure is used to provide block storage inside Nationwide's datacenters. It is
just like EBS in AWS, and uses dedicated fiber channel for all requests.

### Elastic file system(EFS)

EFS is Amazon's version of NFS.

EFS is currently the most flexible storage offering, as it allows the storage
to be accessed across different Availability Zones and can be accessed by
more than one container at the same time.

### Elastic block store (EBS)

EBS should be used when you need a fast block storage solution for things
such as hosting a database where the data does not need to be shared with
other containers/PODs.

PODs that use EBS will not be able to move across multiple Availability
Zones and must stay in the zone where the storage was allocated. Kubernetes
will only schedule on servers in that zone for you once the storage has
been provisioned. Only a single container can access the storage at a time.

The cluster has been configured to support gp2 and io1 storage backend.
gp2 is a general purpose block storage backend, while io1 is a high IO
storage backend. Differences in them can be found [here](https://aws.amazon.com/ebs/features/).

### Elastic file system (EFS)

EFS is Amazon's version of NFS.

EFS is currently the most flexible storage offering, as it allows the storage
to be accessed across different Availability Zones and can be accessed by
more than one container at a the same time.

#### EFS persistent volume claim

Specify the correct storage class:

```yaml
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: storage-claim
spec:
  accessModes:
  - ReadWriteMany
  resources:
    requests:
      storage: 10Gi
  storageClassName: efs-gp
```

### Remote NAS storage

**Try to move your data to the cloud instead of pulling data from an on-prem NAS. The performance will not be good!**

If you MUST continue to use an old on-prem NAS mount for whatever reason, you'll need to make a firewall request to be able to mount the data to the kubernetes clusters. The following example is how you can mount that NFS share into a pod.

```yaml
kind: Pod
apiVersion: v1
metadata:
  name: nfs-in-a-pod
spec:
  containers:
    - name: app
      image: alpine
      volumeMounts:
        - name: nfs-volume
          mountPath: /var/nfs # Please change the destination you like the share to be mounted too
      command: ["/bin/sh"]
      args: ["-c", "sleep 500000"]
  volumes:
    - name: nfs-volume
      nfs:
        server: nfs.example.com # Please change this to your NFS server
        path: /share1 # Please change this to the relevant share
```
