---
title: Final Thoughts and Next Steps
category: cnp
weight: 13
---


- Play with the technology. Don't be afraid to start with a Hello World simple container and work from there. Below are some good tutorials from Rob Richardson and Michael Frayer.
- Read and review the documentation section of this site starting [here](/docs/cnp/).
- Contribute to others and the community.
- If you see anything incorrect or can be better stated in this training, feel free to drop and issue or pull request and update to this training. Pull requests are welcome. I'm not an expert!
- I'd recommend going through the Pluralsight Docker and Kubernetes training.
- Use the resources below. The cheat sheets are some of the better ones I've found so you can try those to start.
- Use the Rocket Chat channels for help. Either ask a question there or search the history for answers.
- Follow the experts and stay up on the technology. Kelsey Hightower, Joe Beda and Brendan Burns are good to follow on Twitter.
- Spend some time and explore the [Cloud Native Computing Foundations site](https://www.cncf.io/).

### Documentation

[Cloud Native Platform Docs](/docs/cnp/)

[Docker Docs](https://docs.docker.com/)

[Kubernetes.io](https://kubernetes.io/docs/home/)

### Helpful recommendations

#### kubectl autocompletion

Enabling autocompletion for kubectl commands can make your life much easier. It will autocomplete not only parameters and commands, but also pod and resources names. You can enable it in a bash shell or in git bash for Windows with these commands:

For current shell

```bash
source <(kubectl completion bash)
```

For persistent autocomplete

```bash
echo "source <(kubectl completion bash)" >> ~/.bashrc
```

  More info here: [kubectl autocompletion](https://kubernetes.io/docs/tasks/tools/install-kubectl/#optional-kubectl-configurations)

### Useful cheat sheets

[Docker Cheat Sheet](https://github.com/wsargent/docker-cheat-sheet)

[Kubernetes Cheat Sheet](https://github.com/dennyzhang/cheatsheet-kubernetes-A4)

### Tutorials

[Code Camp Kubernetes Workshop](https://github.nwie.net/Nationwide/kubernetes-workshop)- A tutorial from the SDS Code Camp, developed by Michael Frayer

[CodeMash Hands On Kubernetes Workshop](https://github.com/robrich/kubernetes-hands-on-workshop) - From 2019 CodeMash, a good Kubernetes hands on tutorial from Rob Richardson

[Hands On Docker Workshop](https://github.com/robrich/docker-hands-on-workshop) - Another good hands on tutorial for Docker from Rob Richardson

[Kubernetes the Hard Way](https://github.com/kelseyhightower/kubernetes-the-hard-way) - An in depth walk through that will have you build your own Kubernetes cluster from scratch (A GCP account is required)

[Cloud Native Computing Foundation Kubernetes Training](https://www.cncf.io/certification/training/) - Kubernetes training from the CNCF. There is a free beginner course and a Fundamentals and Developer course for $299.

[Scalable Microservices with Kubernetes](https://eu.udacity.com/course/scalable-microservices-with-kubernetes--ud615) - A free course from udacity with Mr. Kubernetes Kelsey Hightower that walks you through deploying a microservice into Kubernetes. A GCP account is also required here since the labs use it.

[Pluralsight Kubernetes](https://www.pluralsight.com/search?q=kubernetes) - Pluralsight has some good Kubernetes training so I would recommend checking that site as well

[Kubernetes.io Tutorials](https://kubernetes.io/docs/tutorials/) - Tutorials from the Kubernetes.io community. A Katacoda web shell is available if you don't have access to a Kubernetes cluster.

[Kubernetes.io Recommended Training](https://kubernetes.io/docs/tutorials/online-training/overview/) - Other recommended training from the Kubernetes.io community. Some have costs and some are free.

[Introduction to Concourse](https://pages.github.nwie.net/Nationwide/concourse-tutorial/) - Informative Concourse tutorial with some changes that make it specific to Nationwide.

### Examples

[Cloud Native Platform Examples](https://github.nwie.net/Nationwide/cnp-examples/)

[CNP Angular Reference Application](https://github.nwie.net/Nationwide/cnp-angular-example)

[Sample Flask Kubernetes App](https://github.nwie.net/Nationwide/sample-flask)

[Solution Marketplace Maintenance Container](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app)

### Certifications

These are a couple of certifications you can get from the Cloud Native Computing Foundations for Kubernetes:

[Certified Kubernetes Administrator](https://www.cncf.io/certification/cka/)

[Certified Kubernetes Application Developer](https://www.cncf.io/certification/ckad/)

### RocketChat help

[cloud-native-platform](https://rocketchat.nwie.net/channel/cloud-native-platform) - The official rocketchat channel for the Cloud Native Platform team

[docker](https://rocketchat.nwie.net/channel/docker) - A rocketchat channel for Docker help

[cka-group](https://rocketchat.nwie.net/channel/cka-group) - A channel that will help you with Certified Kubernetes Administrator questions

### Quick YouTube tutorials (Recommended if you’re not familiar with Docker or Kubernetes)

[The Container Operator's Manual](https://www.youtube.com/watch?v=sJx_emIiABk) - Recommended if you're new to containers or thinking about migrating your apps to them.

[Docker Video](https://www.youtube.com/watch?v=h0NCZbHjIpY)

[Kubernetes Video](https://www.youtube.com/watch?v=Mn6Jc0AOUTE)

### Future sections

- CI/CD Pipelines with Concourse
- Interacting with AWS Resources
- Deployment Strategies for Containers - Blue/Green and Canary
- Microservices with Containers
- Managing the Service Mesh with Istio
- Sidecars
