---
title: Pushing Docker Images
category: cnp
weight: 5
---

In this section we're going to go over how to push an image to a Docker registry.

## Creating a repository in DTR

At Nationwide, we use Docker Enterprise Edition, which comes with our own version of the Docker Hub that we call the Docker Trusted Registry (DTR). When you pull an image from a repository to use for anything, you should pull it from the DTR, as images on the DTR are approved for Nationwide. If you already belong to DTR, you should be able to find yourself when searching the list of users in the DTR.

Although there are currently multiple DTRs, in general, you should only need to use [dtr.aws.e1.nwie.net](https://dtr.aws.e1.nwie.net/).  You will need to log into DTR using your NWIE ID and password. If you cannot log in, please see the CNP [Get Access](/docs/cnp/getting-started-with-cnp/get-access/) page ("Developer Access to DTR".) When you push to dtr.aws.e1.nwie.net, the repo will automatically create itself with your image inside it.

**If you are pushing to dtr-prod or dtr-test, you will need to create the repo manually. The directions for this are below. If you are going to push to dtr.aws.e1 as outlined in this tutorial, you can safely ignore these directions.**

Once you have logged into dtr-prod/dtr-test, you will see a list of all repositories currently on the DTR. On the left-hand side, there will be a drop-down bar that says "Filter by", set to "All accounts". Click on the drop-down there and change it from "All Accounts" to your shortname, which should appear under User.

There should now be a green "New repository" button on the right-hand side of the screen, across from the filter. Press this button, enter your account name and name your repo (for this example, name your repo `smpmaint`), and then click "Save". Your repository should now exist - remember what you named it, as you will use it later in this tutorial.

## Preparing an image to push - tagging

Once you build an image, you will need to tag it with the relative registry info to push it. For example let's look at the **smpmaint** image we built in the **Building Docker Images** section. The image id from that example was **`830cac3d1b62`**.

![Image Push ID](/docs/cnp/tutorial/images/dockerbuild-smpmaint.jpg)

Let's tag it and push it to dtr.aws.e1.nwie.net. In our demonstration, we pushed to the marketplace repo, but since you are using your own personal repo, you might tag your image like this:

**`docker tag 830cac3d1b62 dtr.aws.e1.nwie.net/shortname/smpmaint:latest`**

![Docker Tag](/docs/cnp/tutorial/images/dockerimagetag.jpg)

We're now ready to push it to the registry.

## Pushing the image

**Note:** If you are using git-bash for this section of the tutorial, you will need to include `winpty` in front of the `docker login` command in order for it to work correctly.

First, log in at the command line to the proper registry. In this example dtr.aws.e1.nwie.net:

**`docker login dtr.aws.e1.nwie.net`**

If you do not specify where to log in and only type `docker login`, Docker will assume you mean to log into Docker Hub, not a Nationwide registry.

Then push the image with the **`docker push`** command. Once again, in our demonstration we pushed to the marketplace repo, but you should use the tag you made previously:

**`docker push dtr.aws.e1.nwie.net/shortname/smpmaint:latest`**

![Docker Push](/docs/cnp/tutorial/images/dockerpush.jpg)

## Validate the image push

1. Go to the DTR url in a browser, in this case [dtr.aws.e1](https://dtr.aws.e1.nwie.net/)
2. Next navigate to your profile and select repositories.
3. In the repositories, select your image and the images tag there for details.
4. You can select **View Details** for more detailed info about your image.

![Image Details in DTR](/docs/cnp/tutorial/images/dtr-repo.jpg)

**Next:** [Running Docker Containers](../06-running-docker-containers)
