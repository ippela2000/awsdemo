---
title: "Tutorial"
menu: docs
category: cnp
weight: 3
---

## Introduction

**Planning to attend a Cloud Migration Party? Please complete this tutorial BEFORE you attend, and have Docker and Kubernetes ready to go when you arrive!**

## A Practical Guide To Docker and Kubernetes

This site is designed to be a practical guide on not only how to build and deploy applications with Docker and Kubernetes, but how to do it at Nationwide. It is meant for developers and system engineers who are new to Docker and/or Kubernetes. This guide is designed to help get you started.

We'll go over some fundamental examples of running containers in Docker and Kubernetes on both your local system, and in the Nationwide Cloud Native Platform Kubernetes space. We'll use a few examples along the way to help guide you. At the bottom are some resources, cheat sheet and other training I would recommend, such as Rob Richardson's [Docker](https://github.com/robrich/docker-hands-on-workshop) and [Kubernetes](https://github.com/robrich/kubernetes-hands-on-workshop) guide as well as Michael Frayer's [Kubernetes CodeCamp](https://github.nwie.net/Nationwide/kubernetes-workshop) tutorial.

This guide is meant to be a living, breathing site so please feel free to submit pull request to update, add or delete any content. I am no expert at this so I welcome feedback.

The guide will use several Kubernetes examples but mainly these three:

[Python Sample Flask Demo](https://github.nwie.net/Nationwide/sample-flask)

[Solution Marketplace Nginx Maintenance Page](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app)

[Multi Pod Application](/docs/cnp/tutorial/12-multi-pod-example) using [NextCloud](https://nextcloud.com/)

Other examples from the Cloud Native Platform team can be found here:

[https://github.nwie.net/Nationwide/cnp-examples](https://github.nwie.net/Nationwide/cnp-examples) - A repository of many different example such as ingress, configmaps, logging sidecars, storage and many others

[https://github.nwie.net/Nationwide/cnp-angular-example](https://github.nwie.net/Nationwide/cnp-angular-example) - A CNP Angular reference app

Let's get started...

**Next:** [An Intro to Docker](01-intro-to-docker)
