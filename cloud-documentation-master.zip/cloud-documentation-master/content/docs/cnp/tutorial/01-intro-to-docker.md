---
category: "cnp"
description: "Get hands-on experience with Docker in this course from the CNP team, recommended for any team looking to migrate their application into a Docker container."
draft: false
difficulty: 1
title: "Intro to Docker"
hoursEstimate: 3
weight: 1
---

## What are containers

<cite>[From Docker][4]</cite>

>A container is a standard unit of software that packages up code and all its dependencies so the application runs quickly and reliably from one computing environment to another. A Docker container image is a lightweight, standalone, executable package of software that includes everything needed to run an application: code, runtime, system tools, system libraries and settings.

_"Containers are **processes** born from **tarballs** anchored to **namespaces** controlled by **cgroups**"_ -Alice Goldfuss, [The Container Operator's Manual](https://www.youtube.com/watch?v=sJx_emIiABk)

## What is Docker

<cite>[From Opensource.com][1]</cite>

> Docker is a tool designed to make it easier to create, deploy, and run applications by using containers. Containers allow a developer to package up an application with all of the parts it needs, such as libraries and other dependencies, and ship it all out as one package. By doing so, thanks to the container, the developer can rest assured that the application will run on any other Linux machine regardless of any customized settings that machine might have that could differ from the machine used for writing and testing the code.
>
> In a way, Docker is a bit like a virtual machine. But unlike a virtual machine, rather than creating a whole virtual operating system, Docker allows applications to use the same Linux kernel as the system that they're running on and only requires applications be shipped with things not already running on the host computer. This gives a significant performance boost and reduces the size of the application.

## Why Docker and containers

- Smaller, lightweight with just enough application libraries to run your app. They're also closer to the bare metal than a traditional VM.
- Faster deployment - Since they're lightweight they can be deployed much faster.
- Currency and vulnerability management - containers are much easier to maintain vs traditional servers. The images are source controllable code and can be redeployed much faster and easier. They're also stateless so can be deleted and recreated.
- Portable - They can be run anywhere with a Docker engine and the correct base kernel, Linux or Windows.
- Easier to share - Like code images can be shared via the Docker registry or Docker Hub.

## A Quick Docker architecture overview

The best place to review Docker architecture is in the [Docker documentation](https://docs.docker.com/engine/docker-overview/)

## Docker vs VM - What's the difference

Docker containers are similar to virtual machines in that they are another level of abstraction above the machine level, however containers are run on the Docker engine rather than a hypervisor. This allows the containers to be more light weight than virtual machines. They can start faster as well as consume less resources than a VM.

Containers are however weaker in security since they cannot provide the same level of isolation as a virtual machine can.

<cite>[From The Docker.com Blog][2]</cite>
![Docker vs VM](/docs/cnp/tutorial/images/dockerVsVms.jpg)

## Docker image vs container

A Docker image is the a file or the blueprint for a container. A container is the instantiation of the image into a running application.

## What's in a Docker image - Looking under the covers

A Docker image is usually made up of several "layers". You usually start with a base image such as one based on CentOS or Alpine, and then you add layers such as a yum or apt-get update. Or maybe a layer to add Nginx or Apache HTTPD server. Here's an example:

<cite>[From learnitguide.net][3]</cite>
![image layers](/docs/cnp/tutorial/images/dockerLayers.jpg)

## Finding and storing images

Docker images are stored in registries. Docker maintains a public Docker Hub with official or un-official images. Nationwide runs it's own private registry both on and off-prem. You can also run a registry on your own desktop.

## Where can I run my containers

Docker containers can be run in several places, anywhere a Docker engine can be run. They can run locally on your computer with Docker Desktop or they can be run on a server with a Docker Engine. They can be managed by orchestrators such as Docker Swarm or Kubernetes.

## Documentation

[Docker Docs](https://docs.docker.com/)

[The Container Operator's Manual](https://www.youtube.com/watch?v=sJx_emIiABk)

[1]: https://opensource.com/resources/what-docker
[2]: https://blog.docker.com/2016/04/containers-and-vms-together/
[3]: https://www.learnitguide.net/2018/06/docker-images-explained-with-examples.html
[4]: https://www.docker.com/resources/what-container

**Next:** [Installing Docker](../02-installing-docker)
