---
category: "cnp"
description: "Get hands-on experience with Kubernetes in this course from the CNP team, recommended for any team looking to migrate their application to one of the Kubernetes clusters."
draft: false
difficulty: 1
title: "Intro to Kubernetes"
hoursEstimate: 3
weight: 7
---


## What is Kubernetes

<cite>[From the Kubernetes Documentation][1]</cite>

> Kubernetes is a portable, extensible open-source platform for managing containerized workloads and services, that facilitates both declarative configuration and automation. It has a large, rapidly growing ecosystem. Kubernetes services, support, and tools are widely available.

[1]: https://kubernetes.io/docs/concepts/overview/what-is-kubernetes/

## Kubernetes architecture

<cite>[From learnitguide.net][1]</cite>
![Kubernetes Architecture](/docs/cnp/tutorial/images/kubearch.jpg)

### Kubernetes master

The central orchestrator and scheduler for Kubernetes. It is made up of the following components:

#### API server

API Server to the master. It will scale out as needed.

#### Scheduler

Selects where to run new pods.

#### Controller-Manager

<cite>[From the Kubernetes Documentation:][2]</cite>
>Component on the master that runs controllers.
Logically, each controller is a separate process, but to reduce complexity, they are all compiled into a single binary and run in a single process.
>
>These controllers include:
>
> - Node Controller: Responsible for noticing and responding when nodes go down.
> - Replication Controller: Responsible for maintaining the correct number of pods for every replication controller object in the system.
>- Endpoints Controller: Populates the Endpoints object (that is, joins Services & Pods).
>- Service Account & Token Controllers: Create default accounts and API access tokens for new namespaces.

#### etcd

Key-value store for all cluster data.

### Worker nodes

Kubernetes is made up of several worker nodes that the master uses to provide pods a place to run. Each worker node has the following:

#### kubelet

An agent that runs pods on the workers nodes.

#### Kube-proxy

A service that allows the nodes to maintain their networking.

#### Container runtime

The runtime for running containers, in our case Docker.

### kubectl

The main cli command for interacting with the Kubernetes master. This communicates to the master via the API. It "secretly" converts everything to json.

## Workloads

### Pods

Pods are a container or group of containers with shared storage resources and network. Usually a pod is comprised of a single container but sometimes they might contain more if they share a resource or if the have a "sidecar" container for something like Istio.

### ReplicaSets

ReplicaSets are a set of identical pods.

### Controllers

Controllers are comprised of many different components such as replica sets, deployments and jobs. For more info see the **Deeper Dive** section below.

### Services

Services allow you to specify a logical set of pods. For that logical set you can specify the network for the service such as loadbalancer, nodeport, clusterip or ingress controller.

### Ingress controllers

Ingress controllers allow you let an external network talk internally to your pods. Nationwide uses and nginx ingress controller that forwards DNS names to a wildcard domain. More info can be found [here](https://kubernetes.io/docs/concepts/services-networking/ingress/).

## Configmaps

Configmaps allow you to decouple and reuse configurations with multiple pods. Configmaps can be literal values, files or directories and are stored as key value pairs. For more information and examples, please see the following site:

[Kubernetes.io Configmaps](https://kubernetes.io/docs/tasks/configure-pod-container/configure-pod-configmap/)

## Secrets

Kubernetes secrets are similar to configmaps, except they are base64 encrypted. For more information and examples, please see the Kubernetes documentation below:

[Kubernetes.io Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)

## A deeper dive

I've touched on just a few core concepts and components of Kubernetes but there are many, many more, For more detailed information about Kubernetes and its core concepts, the Kubernetes documentation site is a good place to start.

[https://kubernetes.io/docs/concepts/](https://kubernetes.io/docs/concepts/)

## Documentation

[Kubernetes.io Docs](https://kubernetes.io/docs/home/)

[1]: https://www.learnitguide.net/2018/08/what-is-kubernetes-learn-kubernetes.html
[2]: https://kubernetes.io/docs/concepts/overview/components/

**Next:** [Installing Kubernetes](../08-installing-kubernetes)
