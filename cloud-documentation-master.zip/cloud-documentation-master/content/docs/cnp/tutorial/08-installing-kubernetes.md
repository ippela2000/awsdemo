---
title: Installing Kubernetes
category: cnp
weight: 8
---


## Enable Kubernetes

To install Kubernetes locally, we will use the Kubernetes cluster that is provided with Docker Desktop.

Let's first enable Kubernetes...

1. Open the **Docker Settings** and select **Kubernetes** in the left hand navigation.
2. Click **Enable Kubernetes**
3. Click **Apply**

![Docker Kubernetes](/docs/cnp/tutorial/images/enablekube.jpg)

This will now install Kubernetes and create a local cluster called **docker-desktop** or **docker-for-desktop**

## Configure Kubernetes locally

To use the local Kubernetes cluster you will need to create and set a local variable called **KUBECONFIG**

1. Open your local **Environment Variables**
2. Under the **User variables for...** section click **New...**
3. Create a new user variable called **KUBECONFIG** and set the variable value to your user profiles **.kube\config** file. For example mine is **C:\Users\herrioj\\.kube\config**

![KUBECONFIG](/docs/cnp/tutorial/images/kubeconfig.jpg)

This will let main Kubernetes command **kubectl** know what Kubernetes cluster you're using. If you use a different Kubernetes cluster, we'll override the KUBECONFIG variable to point it to say somewhere like Nationwide's AWS Kubernetes environment.

## Validating kubernetes

Let's validate Kubernetes is running properly. First lets start a command window and run the following command: **`kubectl version`**

![Kube version](/docs/cnp/tutorial/images/kubeversion.jpg)

Next let's view our environment and run this: **`kubectl config view`**

![Kube Config View](/docs/cnp/tutorial/images/kubeconfigview.jpg)

You should see a **docker-desktop** or **docker-for-desktop** cluster and context. Ignore the AWS contexts and clusters in the screen shot.

## Troubleshooting Docker Desktop Kubernetes

If you're not able to connect to your local Kubernetes cluster or when you check the Docker settings you see Kubernetes never completely starts, there is likely some issue going on, and most times it's iBoss proxy related. This seems to be more common on Windows machines. A good place to start would be to review your **Proxies** settings in your Docker settings but also the environment variables for your computer. If your local Docker Desktop Kubernetes instance won't start, please take a look at this iBoss Nest article and apply the settings in both **Docker/Kubernetes** and **Updating Environment Variables** sections. You may need to log off or reboot for the setting changes to work.

**[Nest Recommended iBoss Proxy Settings](https://nest.nwie.net/content/articles/iboss-proxy-settings.html)**

If your local Kubernetes cluster fails to start after applying the proxy settings for both the computer environment variables and in Docker settings, you could check with others in the #docker RocketChat channel.

**Next:** [Working with Kubernetes Locally](../09-working-with-kubernetes)
