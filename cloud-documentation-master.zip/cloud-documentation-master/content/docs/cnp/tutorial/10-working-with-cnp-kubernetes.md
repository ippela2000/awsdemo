---
title: Working With CNP Kubernetes
category: cnp
weight: 10
---



## Getting setup in CNP kubernetes

This section we'll go over how to request a namespace, repo and org in the Cloud Native Platform's AWS Kubernetes environment. We'll then go over how to deploy your application there and how you can manage it there.

### Getting access

To get access to the Nationwide's AWS Universal Control Plane and Docker Trusted Registry you will need to be added to the **nw-docker-users** group. More info [here](/docs/cnp/getting-started-with-cnp/get-access/).

### CaaS config GitHub repo

To get setup in the Cloud Native Platform Kubernetes namespace, you'll need to go to the following repository and pull request in a CaaS Config file. There are instructions on the main page readme.

[https://github.nwie.net/Nationwide/cnp-caas-config](https://github.nwie.net/Nationwide/cnp-caas-config)

The CaaS config lets you create a Kubernetes org, access to the AWS UCP, a DTR org in AWS as well as a Concourse CI instance. If you have question submit them to the CNP Rocket Chat channel #cloud-native-platform.

## Logging into the AWS universal control plane (UCP)

Once you have access and your organization setup, you should be able to log into either or both the AWS Universal Control Plane for test or prod. Links can be found in the link to the [get-access](/docs/cnp/getting-started-with-cnp/get-access/) CNP page or on the main page for this repo. For our example we'll use test.

Go to the [Test UCP](https://ucp-test.aws.e1.nwie.net) and login in with your normal Nationwide Sign-On credentials. **Note: Do not use your secondary id here**

![AWS UCP Front Page](/docs/cnp/tutorial/images/ucp-testfrontpage.jpg)

### Navigating the UCP

To view your Kubernetes namespace in the UCP app, on the left side expand the **Kubernetes** navigation and select **Namepaces**. Once in there select the line with your orgs namespace and select the **Set Context** button (yellow arrow below) and confirm. Now you will be able to view your workloads in the links below the Namespace section (red arrow below).

![UCP Namespace Example](/docs/cnp/tutorial/images/ucp-namespacejpg.jpg)

### More help on UCP

In the bottom left-hand corner of the UCP app there is a **Docs** link. That will take you to the Docker documentation on using the Universal Control Plane.

### Getting your private key and bundle

Now that you have access to the Universal Control Plane, you'll need to generate your public key and bundle to be able to connect your **kubectl** context to your AWS org and namespace.

Start by clicking on your id in the top left corner and select **My Profile**:

![My Profile](/docs/cnp/tutorial/images/ucp-profile.jpg)

In your profile select **Client Bundles** and select **Generate Client Bundle** from the drop down. This will generate a new key and bundle with certs and scripts that will allow you to connect you command line kubectl to the AWS Kubernetes cluster.

![UCP Bundle](/docs/cnp/tutorial/images/ucp-generatebundle.jpg)

You will get a zip download titled **ucp-bundle-youruserid.zip** that will contain scripts and certs

![Bundle Files](/docs/cnp/tutorial/images/ucp-bundlefiles.jpg)

Once you have the bundle downloaded and unzipped, open the command window and navigate to the directory with your bundle. You then can run either a env.sh, env.cmd or env.ps1 script to set your **KUBECONFIG** environment variable along with a few others. You only need to run one env script. The env.ps1 will not run by default, you'll need to open it and re-save since PowerShell will not allow unsigned scripts not created by the user to run.

Here is what the **env.sh** script looks like but the other scripts are essentially the same:

```bash
export DOCKER_TLS_VERIFY=1
export COMPOSE_TLS_VERSION=TLSv1_2
export DOCKER_CERT_PATH=$PWD
export DOCKER_HOST=tcp://ucp-test.aws.e1.nwie.net:443

if kubectl >/dev/null 2>&1; then
    unset KUBECONFIG
    kubectl config set-cluster ucp_ucp-test.aws.e1.nwie.net:6443_herrioj --server https://ucp-test.aws.e1.nwie.net:6443 --certificate-authority "$PWD/ca.pem" --embed-certs
    kubectl config set-credentials ucp_ucp-test.aws.e1.nwie.net:6443_herrioj --client-key "$PWD/key.pem" --client-certificate "$PWD/cert.pem" --embed-certs
    kubectl config set-context ucp_ucp-test.aws.e1.nwie.net:6443_herrioj --user ucp_ucp-test.aws.e1.nwie.net:6443_herrioj --cluster ucp_ucp-test.aws.e1.nwie.net:6443_herrioj
fi
export KUBECONFIG=$PWD/kube.yml
```

You can also copy the script contents out and run them in the command window. Or also update contents of the script such as the **PATH**. Here's an example of running it in the command line.  

![Set Env](/docs/cnp/tutorial/images/kube-setenv.jpg)

After running these commands, you will have updated your **KUBECONFIG** environment variable to the **kube.yml** in the directory you downloaded your content pack. The commands should also set your Kubernetes context and namespace.

We can verify with the following commands:

#### Check current context

```bash
kubectl config current-context
```

#### Check current context namespace

```bash
kubectl get sa default -o jsonpath='{.metadata.namespace}'
```

![Check Context and Namespace](/docs/cnp/tutorial/images/kube-checkcontext.jpg)

### Setting your Kubernetes context

This command will set your context:

**`kubectl config use-context <context-name>`**

In my example I want to use the ucp-test AWS namespace:

**`kubectl config use-context ucp_ucp-test.aws.e1.nwie.net:6443_herrioj`**

**Note:** If you are using Docker for Desktop with Kubernetes, you can also easily change contexts by right-clicking the Docker icon in your system tray, hovering over "Kubernetes", and selecting the context you want to use from the list that pops up.

### Setting your namespace to your organization

This command will change the namespace for your default context:

**`kubectl config set-context --current --namespace=default`**

In my case I want to use the **infra-devnull** namespace:

**`kubectl config set-context --current --namespace=infra-devnull`**

**Note:** If this command does not work for you, you are using an outdated version of kubectl. Please update to the most recent version.

## Working in AWS Kubernetes

Now that your namespace and context is set, you're now ready to work inside the Nationwide AWS Kubernetes space. You can use all the same commands and deployment files we used in the previous section, [Working With Kubernetes](/docs/cnp/tutorial/09-working-with-kubernetes/).

### Example - smpmaint Nginx

For this example we'll use the Nginx container example we've used in previous sections. Here's a link to that [directory](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app).

To start, assuming you've setup your **KUBECONFIG** variable, set your context and namespace using the directions on this page, you should be ready to deploy your pods and services to your namespace.

We'll start be going to the directory with our application's Kubernetes deployment file. The deployment file we'll be using is essentially the same one from the sample flask example. Click [here](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app/blob/master/deployment.yml) to view the deployment file we'll be using for the Nginx deployment.

Our deployment will create a service called **smpmaint-service** that will allow for an ingress called **smpmaint-ingress** to talk to our **smpmaint** pod. The ingress will allow for outside traffic to talk to our pod with the host name **smpmaint.apps-test.aws.e1.nwie.net**.

We'll first cd to the directory of the deployment yaml file, in my case **`C:\devl\smpmaint-container-example\`**.

To deploy our app, we use the same **`kubectl apply -f <deployment file>.yml`** we used before:

**`kubectl apply -f deployment.yml`**

And here's a screenshot:
![smpmaint deploy](/docs/cnp/tutorial/images/kube-smpmaintdeploy.jpg)

In the screen shot you should see the service, deployment and ingress were all created. In my case since I already had it deployed, everything is unchanged.

We can check our deployment by going to `http://smpmaint.apps-test.aws.e1.nwie.net`. If we go to that link, we can see the Solution Marketplace maintenance page is running:

![smpmaint in Kube](/docs/cnp/tutorial/images/smpmaint-website.jpg)

Everything looks good with this deployment but let's take a quick look at the workloads we just deployed using the kubectl command.

Checking the deployment:

**`kubectl get deployment smpmaint-deployment`**

Output:

```bash
NAME                  DESIRED   CURRENT   UP-TO-DATE   AVAILABLE   AGE
smpmaint-deployment   1         1         1            1           41m
```

Check the pod status (we'll use the label we assigned in the deployment.yml):

**`kubectl get pods -l app=smpmaint`**

Output:

```bash
NAME                                  READY     STATUS    RESTARTS   AGE
smpmaint-deployment-cb7bdcc67-phl7v   1/1       Running   0          41m
```

Let's get the pod name using jsonpath expressions and put it in the **`$pod_name`** variable (Note: this will not work in command prompt):

**`$pod_name = kubectl get pods -l app=smpmaint -o jsonpath="{.items[0].metadata.name}"`**
**`$pod_name`**

Output:

`smpmaint-deployment-cb7bdcc67-phl7v`

Then use that pod name to describe it as well as get the logs:

**`kubectl describe pod $pod_name`**

**`kubectl logs $pod_name`**

Let's check the ingress:

**`kubectl get ingress smpmaint-ingress`**

Output:

```bash
NAME               HOSTS                                ADDRESS   PORTS     AGE
smpmaint-ingress   smpmaint.apps-test.aws.e1.nwie.net             80, 443   44m
```

And lastly, let's check the service:

**`kubectl get service smpmaint-service`**

Output:

```bash
NAME               TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)    AGE
smpmaint-service   ClusterIP   10.96.143.246   <none>        8080/TCP   45m
```

## Using storage

For information on Storage, please reference the Cloud Native Platforms Storage documentation [here](/docs/cnp/storage/).

## CI/CD

Concourse is the preferred CI/CD for Kubernetes. For more information please refer to the Cloud Native Platform documentation on how to setup a Concourse instance [here](/docs/cnp/about-cnp/docker-builds/).

There is also a [Concourse tutorial GitHub pages](https://pages.github.nwie.net/Nationwide/concourse-tutorial/).

Send all tickets regarding Concourse support to NSC-WEB-CODE-MIGRATION.

**Next:** [Using Helm](../11-using-helm)
