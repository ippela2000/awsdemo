---
category: "cnp"
description: "Learn about Helm, a useful tool for deploying and managing your Kubernetes applications."
draft: false
difficulty: 2
title: "Using Helm"
hoursEstimate: 1
weight: 11
---



## What is Helm

Helm is essentially is a package manager for Kubernetes. It allows to create charts to package your Kubernetes application and abstract the complexity of Kubernetes configuration files.

Helm also has a repository for charts, similar to RedHat Satellite or Ubuntu Package repository. The Cloud Native Platform team maintains a repository of charts [here](https://github.nwie.net/Nationwide/cnp-charts).

<cite>[From helm.sh][1]</cite>

>Helm helps you manage Kubernetes applications — Helm Charts help you define, install, and upgrade even the most complex Kubernetes application.
>
>Charts are easy to create, version, share, and publish — so start using Helm and stop the copy-and-paste.

Helm allows you to simplify your Kubernetes YAML files by templatizing them and allow you to maintain your default resource configurations in a single values file. It also allows you to manage your dependencies better through the use of a requirements.yaml file or local charts directory.

<cite>[A Helm Chart Example From Medium][2]</cite>

![Helm Chart](/docs/cnp/tutorial/images/helm-example.jpg)

Here's a good intro into Helm from Digital Ocean:

[An Introduction to Helm, the Package Manager for Kubernetes](https://www.digitalocean.com/community/tutorials/an-introduction-to-helm-the-package-manager-for-kubernetes)

More Helm Documentation:

[Helm Documentation Site](https://helm.sh/)

[Helm GitHub Repository](https://github.com/helm/helm)

## Installing Helm

Instructions for installing Helm for Linux and Windows via Chocolatey can be found on the Helm Github site [here](https://helm.sh/docs/using_helm/#installing-helm)

For Windows 10, the best way I found to install Helm is to go to the [Helm GitHub release page](https://github.com/helm/helm/releases/latest) and find the **Latest V3 release**. If the latest release is a V2 release, just scroll down to find the latest V3 version.

Under the latest release section there is a section labeled **Installation and Upgrade**, in that section you can get a **Windows amd64 ZIP File**.

Download and unzip the Helm ZIP file to the location you want the Helm binaries. You will need to add the Helm folder location to your System Environment Path variable. This article has full instructions on installing Helm on Windows:

[Medium Article on installing Helm on Windows](https://medium.com/@JockDaRock/take-the-helm-with-kubernetes-on-windows-c2cd4373104b)

[Installing Helm 3](https://helm.sh/docs/intro/quickstart/)

### Verify Helm install

```bash
helm version
```

Which should output something similar to the following:

```bash
Client: &version.Version{SemVer:"v2.13.0", GitCommit:"79d07943b03aea2b76c12644b4b54733bc5958d6", GitTreeState:"clean"}
Server: &version.Version{SemVer:"v2.13.0", GitCommit:"79d07943b03aea2b76c12644b4b54733bc5958d6", GitTreeState:"clean"}
```

If you run into any issues, try the [FAQ](https://helm.sh/docs/faq/) at the Helm docs site.

Assuming now that Helm is installed, you are ready to start deploying applications to Kubernetes using Helm charts.

## Helm cheat sheet

Here is a useful cheat sheet for Helm: [https://github.com/RehanSaeed/Helm-Cheat-Sheet](https://github.com/RehanSaeed/Helm-Cheat-Sheet)

## Getting started with Helm

Now assuming you have Helm installed, you can now create your own charts. To start, `cd` to the directory you'd like to create your chart in, and run the `helm create` command with the name of your app's chart:

```bash
helm create <my app name>
```

To create the default chart templates:

```bash
helm create mynewchart
```

If we check that directory, we can see it has been populated with a Chart.yaml and values.yaml, as well as charts and templates directories:

```bash
$ cd mynewchart/
$ ls
Chart.yaml  charts/  templates/  values.yaml
```

Your next step should be going through the Helm guide on developing charts, which will explain the files and directories and how to use them to create a Helm deployment:

[Helm Developing Charts](https://helm.sh/docs/developing_charts/)

## Helm templating

The best place to start with explaining Helm templating is in the [Helm Documentation](https://helm.sh/docs/chart_template_guide/).

We'll walk through a couple of quick examples. When you run **`helm create <myapp>`** it will create the default templates in the templates/ directory. Here is small snippet from the deployment.yaml:

```bash
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ include "mynewchart.fullname" . }}
  labels:
    app.kubernetes.io/name: {{ include "mynewchart.name" . }}
    helm.sh/chart: {{ include "mynewchart.chart" . }}
    app.kubernetes.io/instance: {{ .Release.Name }}
    app.kubernetes.io/managed-by: {{ .Release.Service }}
spec:
  replicas: {{ .Values.replicaCount }}
```

In this snippet you can see multiple templated values, here's where those values are generated from:

**{{ include "mynewchart.fullname" . }}** - Generated from the Release.Name and defined by the functions/_helpers.tpl file. It will be the name given on the command line (if given) in addition to the chart name.

**{{ .Release.Name }}** - Generated from the Helm built-in Release object

**{{ .Release.Service }}** - Also generated from the Helm Release object. This value will most always be Tiller

**{{ .Values.replicaCount }}** - Generated from the values.yaml file

We can run Helm command to output the values without deploying the application. This is helpful when troubleshooting or when Tiller isn't working and you want to deploy the Helm generated manifest files via kubectl. This command will output the generated manifest:

`helm install --dry-run --debug --name=<myappname> ./<mychartdirectory>`

In the mynewchart case, this command:
`helm install --dry-run --debug --name=mynewchart ./mynewchart/`

When I compare the output from the template snippet above, you can see that the template variables are now populated:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mynewchart-chart
  labels:
    app.kubernetes.io/name: mynewchart
    helm.sh/chart: mynewchart-0.1.0
    app.kubernetes.io/instance: mynewchart
    app.kubernetes.io/managed-by: Tiller
spec:
  replicas: 1
```

As mentioned at the start of this section, please consult the [Helm Templating Guide](https://helm.sh/docs/chart_template_guide/) for more info.

## Helm dependencies

Helm charts allow you to install dependencies for your application, say a redis or postgresql database. You can link those dependencies in your Helm chart with the charts directory or the requirements.yaml file.

Once you've defined your dependencies, you can run the **`helm dependency update`** command to retrieve the dependency charts. The update command will retrieve the dependency archive files and store them in the charts directory. Here's an the full command:

```bash
helm dep up <myappchart>
```

## Deploying a Helm chart

Once you've setup and configured your Helm chart and updated any dependency, you should now be ready to deploy your application using the Helm install command:

```bash
helm install --name <myappname> <myappchartdirectory>
```

After you've deployed your application via Helm, you can run the **`helm list`** command to see all deployed Helm releases.

## Updating a Helm chart

When we make changes to the application, we can use the **`helm upgrade`** command to update the application. Let's say for instance you change the replicaCount for your application in the values.yaml file, you can push the changes with the command below. Also good practice is to also increment the version in the Chart.yaml appropriately.

```bash
helm upgrade <myappname> <myappchart>
```

## Deleting a Helm chart

Deleting an application and all of its resources is easy with Helm. Use the **`helm delete`**. Helm delete will delete the application and resources, however it will keep the chart name around in Helm so you can use the **`--purge`** parameter to remove all references to the app name from Helm.

```bash
helm delete <myappdeployment> --purge
```

## A quick Helm example

Let's create a chart for the application we've seen earlier in the tutorial, the Solution Marketplace maintenance app. Previously we walked through the Kubernetes mainfest deployment YAML file, the file is located [here](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app/blob/master/deployment.yml). We now want to turn that into a helm chart.

To start we create a Helm generic template for our app like we did earlier in this page:

```bash
helm create smpmaint-chart
```

We can cd into the directory and see our templates, value and chart files. For this example, we're going to update the service resource. This is what we're going to convert to a helm chart:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: smpmaint-service
  labels:
    app: smpmaint
spec:
  ports:
    - name: http
      port: 8080
  selector:
    app: smpmaint
```

To match that we'll update the service templates file in the root chart directory **./templates/service.yaml**. We'll update the default template to look like this:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: {{ include "smpmaint-chart.name" . }}
  labels:
    name: {{ include "smpmaint-chart.name" . }}
    helm.sh/chart: {{ include "smpmaint-chart.chart" . }}
    app.kubernetes.io/instance: {{ .Release.Name }}
    app.kubernetes.io/managed-by: {{ .Release.Service }}
spec:
  #type: {{ .Values.service.type }}
  ports:
    - port: {{ .Values.service.port }}
      #targetPort: http
      #protocol: TCP
      name: http
  selector:
    name: {{ include "smpmaint-chart.name" . }}
    app.kubernetes.io/instance: {{ .Release.Name }}
```

Above, you can see we commented out the lines with type, targetPort and protocol since we didn't need those. The rest of the template values we'll get from the values.yaml, Chart.yaml or the Release Helm object.

In the chart's root director, we'll update the **values.yaml** file to add the needed values such as **.Values.service.port**. Here's what we need to add:

```yaml
service:
  type: ClusterIP
  port: 8080
```

You can run the helm install debug command with dry run to output and verify the manifest YAML:

```bash
helm install --dry-run --debug --name=smpmaint ./smpmaint-chart/
```

The full Helm solution for the Solution Marketplace maintenance app, with ingress and deployment templates and values, can be found here: [Solution Marketplace Maintenance App Chart](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app/tree/master/smpmaint-chart)

## Helm documentation, repositories, examples and tutorials

Here are some guides, documentation and reference examples you can use to continue learning Helm:

### Documentation

[Helm Official Documentation](https://helm.sh/docs/)

[Helm Best Practices](https://helm.sh/docs/chart_best_practices/)

### Repositories

[Cloud Native Platform Helm Repository](https://github.nwie.net/Nationwide/cnp-charts)

[Helm Hub](https://hub.helm.sh/)

### Tutorials

[Kubernetes CodeCamp Workshop](https://github.nwie.net/Nationwide/kubernetes-workshop)

[Helm Intro from Digital Ocean](https://www.digitalocean.com/community/tutorials/an-introduction-to-helm-the-package-manager-for-kubernetes)

[Helm Tutorial on Github.com (start at part III)](https://github.com/muffin87/helm-tutorial)

[1]: https://helm.sh/
[2]: https://medium.com/tenable-techblog/how-tenable-uses-helm-to-template-a-microservice-stack-8c90ae445e48

**Next:** [Multi-Pod Example](../12-multi-pod-example)
