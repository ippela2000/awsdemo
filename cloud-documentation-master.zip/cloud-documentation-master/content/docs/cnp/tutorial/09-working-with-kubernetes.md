---
title: Working With Kubernetes
category: cnp
weight: 9
---

## Running containers locally with kubectl

Now that you have Kubernetes installed locally, you can use it to experiment and develop containers locally. Let's walk through it.

### Get context

The first thing I do, and this will be important as you start working with more clusters, is check my context to see where my **`kubectl`** command is pointed. This can be done with this command:

**`kubectl config current-context`**

![Kube Get Context](/docs/cnp/tutorial/images/kubegetcontext.jpg)

### View all available contexts

To view all available contexts you can use this command:

**`kubectl config view`**

To return just the names you can run this command:

**`kubectl config view -o jsonpath='{.contexts[*].name}'`**

### Setting a context

Should you need to set a context, you can do it with this command:

**`kubectl config use-context <context-name>`**

![Kube Set Context](/docs/cnp/tutorial/images/kubeusecontext.jpg)

### Deploy containers like Docker with kubectl

You can use the kubectl command like the docker command with a few subtle difference. We'll go through a few but this document has a good overview of how kubectl commands can map to docker commands: [https://kubernetes.io/docs/reference/kubectl/docker-cli-to-kubectl/](https://kubernetes.io/docs/reference/kubectl/docker-cli-to-kubectl/)

### Example - smpmaint Nginx

In this example, we'll use the Solution Marketplace maintenance Nginx app that we used in the Docker examples directory:

[Nginx Maintenance Page Example](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app)

We learned all about running containers with Docker but now we'll touch on how to run them in Kubernetes. We can deploy our images into Kubernetes with the kubectl command. The command is similar to the Docker command but a little different.

**`kubectl create deployment --image=dtr.aws.e1.nwie.net/infra-devnull/smpmaint:latest nginx-app`**

This command will deploy our smpmaint image from the AWS DTR to a deployment we'll call `nginx-app`  as a container into a pod, a pod being a container or multiple containers.

Next, we can expose the pod container's port 8080 to the Kubernetes cluster:

**`kubectl expose deployment nginx-app --port=8080`**

![Kube Run smpmaint](/docs/cnp/tutorial/images/kube-deploysmpmaint.jpg)

We can check our deployment to see if our image deployed as a container into a pod. We'll run this command to check:

**`kubectl get deployment nginx-app`**

![kube get deployment](/docs/cnp/tutorial/images/kubectl-deployment.jpg)

We can see it's running. Let's check the running pod. This command will show us all running pods. It's similar to docker ps:

**`kubectl get pods`**

![kubectl get pod](/docs/cnp/tutorial/images/kubectl-getpods.jpg)

We can see our nginx-app is running and has the pod name of **nginx-app-5fb4d74b47-nqfpr** which is assigned by the cluster. If you run this on your system you'll also see **nginx-app-** as well but with a different trailing guid.

You can see in the screen shot above that the pod it has a ready state of 1/1 and a status of Running. Pods can have several different phases, which are listed in the **STATUS**. In the screen shot above you can see the **app-server-86c87dd7c6-shlqb** pod has a status of **ImagePullBackOff** which means the pod has a problem with the image it's trying to deploy as a container.

Pods can have several different status such as running, stopped, failed, CrashLoopBackOff. I would recommend reading the Kubernetes documentation to learn more about the pod lifecycle here: [Pod Lifecycle](https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/)

In Docker when we run a container we can map the Docker internal port to a port on our OS. We could then go to a browser and [http://localhost:8080](http://localhost:8080) to see our webpage. In Kubernetes we have to go an extra step to expose our pod's internal port to our local system. To do that we can use **port forwarding**.

### Exposing ports and networks with services

The quickest way to expose the pod's port to our computer's network is with port forwarding. In this case we'll forward our nginx-app pod's port 8080 to our computer's port 8080. Here's the command:

**`kubectl port-forward <pod name> [Local Port]:[Remote Port]`**

In our example, we would use this command:

**`kubectl port-forward nginx-app-5fb4d74b47-nqfpr 8080:8080`**

![kubectl port fwd](/docs/cnp/tutorial/images/kubectl-portfwd.jpg)

Now if we go [http://localhost:8080](http://localhost:8080) we can see our site is running.

Yay! We're done. Not so fast. As soon as we kill or control-c our port forward command the port forwarding stops and we're unable to get to the site. We need something more persistent so we'll get into deploying pods and services with deployment files. First let's cleanup what we did. The easiest way is to delete the deployment:

### Deleting a deployment

We can delete our deployment with this simple command:

**`kubectl delete deployment nginx-app`**

If we check with **`kubectl get pods`** and **`kubectl get deployment nginx-app`** we can see our deployment and pods are gone.

![kubectl delete](/docs/cnp/tutorial/images/kubectl-delete.jpg)

## Using Kubernetes manifest YAML files

A better way to deploy application pods, services and other workloads to a Kubernetes cluster is with the use of Kubernetes manifest YAML files. Deployment files allow you to maintain pods, replica sets and services in the desired, declared state. Each deployment file has 4 main sections for each deployment type: apiVersion, Kind, metadata and spec. Kubernetes deployment files are written in yaml format. If you're new to YAML, here's a tutorial to help get you started: [YAML Tutorial](https://gettaurus.org/docs/YAMLTutorial/)

Here's a site I found useful in understanding deployment files: [https://devopscube.com/kubernetes-deployment-tutorial/](https://devopscube.com/kubernetes-deployment-tutorial/)

Here is the Kubernetes Deployment Documentation: [https://kubernetes.io/docs/concepts/workloads/controllers/deployment/](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)

### Example 1 - sample flask

In this example we'll deploy the sample Flask app we used in earlier examples. Let's break down the manifest file located [here](https://github.nwie.net/Nationwide/sample-flask/blob/master/kubernetes.yaml):

```yaml
---
apiVersion: v1
kind: Service
metadata:
  name: sample-flask-app-service
  labels:
    app: sample-flask
spec:
  ports:
    - name: http
      port: 5000
  selector:
    app: sample-flask

---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sample-flask-deployment
spec:
  selector:
    matchLabels:
      app: sample-flask
  #replicas: 2
  revisionHistoryLimit: 5
  template:
    metadata:
      labels:
        app: sample-flask
    spec:
      containers:
      - name: sample-flask
        image: dtr.aws.e1.nwie.net/sidelig/sample-flask:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 5000
        env:
        - name: SAMPLE_ENV_VAR
          value: "dummy_value"
        # HTTPD Checks
        livenessProbe:
          httpGet:
            path: /
            port: 5000
            #scheme: HTTPS
          initialDelaySeconds: 10
          periodSeconds: 15
          failureThreshold: 3
          successThreshold: 1
        readinessProbe:
          httpGet:
            path: /
            port: 5000
            #scheme: HTTPS
          initialDelaySeconds: 10
          periodSeconds: 15
          failureThreshold: 3
          successThreshold: 1


---
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: sample-flask-ingress
  annotations:
    ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
    nginx.ingress.kubernetes.io/secure-backends: "false"
    #kubernetes.io/ingress.allow-http: "true"
    ingress.kubernetes.io/affinity: "cookie"
    ingress.kubernetes.io/session-cookie-name: "STICKY"
    ingress.kubernetes.io/session-cookie-hash: "index"
    kubernetes.io/ingress.class: "default"
spec:
  tls:
  - hosts:
    - sample-flask.aws.e1.nwie.net
  rules:
  - host: sample-flask.aws.e1.nwie.net
    http:
      paths:
      - backend:
          serviceName: sample-flask-app-service
          servicePort: http

```

The deployment file for the sample flask app deploys several workloads into the cluster. Let's break each down.

#### sample-flask-app-service service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: sample-flask-app-service
  labels:
    app: sample-flask
spec:
  ports:
    - name: http
      port: 5000
  selector:
    app: sample-flask
```

The first section deploys a service called **sample-flask-app-service**. This service exposes the **sample-flask** app/pods and allows other pods or services to communicate to the **sample-flask**. The **spec** tells the service to communicate to the app via port 5000.

#### sample-flask-deployment deployment

This section defines the **sample-flask-deployment** deployment. You can see the name for the deployment defined in the metadata section. In the spec section you can see replicas has been commented out but if left uncommented it would deploy 2 pods that would be identical, with identical containers.

You can also see the container section defines what container you'd like to deploy along with the name and image location. You can see port 5000 is going to be exposed from the pod and two probes, liveness and readiness are setup to listen on that port for activity. The readiness probes will let Kubernetes know that the pod is ready to accept traffic.

This example doesn't contain any storage mounts but if you would like to attach storage to your pods, documentation can be found here: [Kubernetes Storage Documentation](https://kubernetes.io/docs/concepts/storage/volumes/)

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: sample-flask-deployment
spec:
  selector:
    matchLabels:
      app: sample-flask
  #replicas: 2
  revisionHistoryLimit: 5
  template:
    metadata:
      labels:
        app: sample-flask
    spec:
      containers:
      - name: sample-flask
        image: dtr.aws.e1.nwie.net/sidelig/sample-flask:latest
        imagePullPolicy: Always
        ports:
        - containerPort: 5000
        env:
        - name: SAMPLE_ENV_VAR
          value: "dummy_value"
        # HTTPD Checks
        livenessProbe:
          httpGet:
            path: /
            port: 5000
            #scheme: HTTPS
          initialDelaySeconds: 10
          periodSeconds: 15
          failureThreshold: 3
          successThreshold: 1
        readinessProbe:
          httpGet:
            path: /
            port: 5000
            #scheme: HTTPS
          initialDelaySeconds: 10
          periodSeconds: 15
          failureThreshold: 3
          successThreshold: 1
```

#### sample-flask-ingress ingress

This section defines an ingress controller that will allow external traffic to talk to services, in this case **sample-flask-app-service**. As with the other workloads defined, you can see the **Kind** is Ingress and metadata name is **sample-flask-ingress**. In the specs you can see the host is setup as **sample-flask.apps-test.aws.e1.nwie.net**. This is a wildcard domain that an Nginx server is listening on and routes traffic accordingly. More info on how ingress works in the Cloud Native Platform space can be found here: [Cloud Native Platform Ingress Documentation](/docs/cnp/ingress/ingress-default/)

**Note: Since we are running locally, odds are you're not running a local ingress controller like Nginx. So this won't work locally. In section 11 we'll demonstrate it working in an AWS Kubernetes cluster.**

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: sample-flask-ingress
  annotations:
    ingress.kubernetes.io/rewrite-target: /
    nginx.ingress.kubernetes.io/ssl-redirect: "false"
    nginx.ingress.kubernetes.io/secure-backends: "false"
    #kubernetes.io/ingress.allow-http: "true"
    ingress.kubernetes.io/affinity: "cookie"
    ingress.kubernetes.io/session-cookie-name: "STICKY"
    ingress.kubernetes.io/session-cookie-hash: "index"
    kubernetes.io/ingress.class: "default"
spec:
  tls:
  - hosts:
    - sample-flask.apps-test.aws.e1.nwie.net
  rules:
  - host: sample-flask.apps-test.aws.e1.nwie.net
    http:
      paths:
      - backend:
          serviceName: sample-flask-app-service
          servicePort: http
```

### Example 2 - Nginx maintenance page example

The deployment file for the smpmaint Nginx example is setup and structured the same way as the sample flask application so we won't go in detail on the deployment file. Here's the location of the deployment file which I've dowloaded locally to my **`C:\devl\smpmaint-container-example`** directory:

[Nginx Maintenance Page Deployment File Example](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app/blob/master/smpmaint-volume-example/deployment.yml)

### Applying and updating a deployment via the deployment file

Applying the deployment yaml file is pretty easy with this command. Run it from the directory of your deployment:

**`kubectl apply -f <deploymentfilename>.yaml`**

In the **Nginx smpmaint example**, I cd to the directory of my deployment.yml file and run the following command:

**`kubectl apply -f deployment.yml`**

![Deployment Example](/docs/cnp/tutorial/images/deploymentfileexample.jpg)

### Viewing the deployment details

You can view the deployment and services now to verify everything specified in the deployment file deployed properly.

#### Get all deployments

**`kubectl get deployment`**

In our example, we should see the smpmaint-deployment:

![Kube Get Deployment](/docs/cnp/tutorial/images/kube-getdeployment.jpg)

If we go to [http://localhost:8080/](http://localhost:8080/) we still don't see our application and that is because we don't have an ingress running. If you had one running you'd be able to see your site running on that link.

If you want to be able to see it running locally and don't want to install and ingress, you can use a **nodeport** service to make the pod available to outside the Kubernetes cluster. In our case we would remove (or leave, it doesn't matter) the ingress section from our deployment file and replace our smpmaint-service with the following config:

##### nodeport config

```yaml
apiVersion: v1
kind: Service
metadata:
  name: smpmaint-service
  labels:
    app: smpmaint
spec:
  selector:
    app: smpmaint
  type: NodePort
  ports:  
  - name: http
    port: 8080
    targetPort: 8080
    nodePort: 30036
    protocol: TCP
```

You can copy the contents of the **deployment.yml** and paste them into a file called **deployment-nodeport.yml**. Then replace the **Service** section with the **nodeport** config above. Then we can re-apply that config with the same command we used before with the new deployment file:

**`kubectl apply -f deployment-nodeport.yml`**

![Nodeport Deployment](/docs/cnp/tutorial/images/kubectl-deploynodeport.jpg)

You can see the deployment and ingress did not change but the service did. To access our app now we can use the **nodePort** port we specified in the deployment file. We should see the app now at [http://localhost:30036](http://localhost:30036)

![App on Nodeport](/docs/cnp/tutorial/images/kube-appOnNodeport.jpg)

If we want more insight into our deployment we can use these commands:

#### Describe a deployment in detail

**`kubectl describe deployment <deployment name>`**

#### View and describe ingress

```bash
kubectl get ingress
kubectl describe ingress <ingress name>
```

#### View and describe a service

```bash
kubectl get service
kubectl describe service <service name>
```

or

```bash
kubectl get svc
kubectl describe svc <service name>
```

### Deleting the deployment

To delete all workloads deployed in a deployment yaml file, run the following command:

**`kubectl delete -f <deployment file>.yaml`**

Here is the smpmaint example. We'll use the last deployment file with the nodeport to delete the workloads we created:

**`kubectl delete -f deployment-nodeport.yml`**

![Delete Deployment with File](/docs/cnp/tutorial/images/deploymentfiledeleteexample.jpg)

## Troubleshooting or looking for more info

For troubleshooting Kubernetes workloads, I would recommend starting with the Kubernetes documentation on debugging applications:

 [Troubleshooting Kubernetes Applications](https://kubernetes.io/docs/tasks/debug-application-cluster/debug-application/)

**Next:** [Working with Cloud Native Platform Kubernetes](../10-working-with-cnp-kubernetes)
