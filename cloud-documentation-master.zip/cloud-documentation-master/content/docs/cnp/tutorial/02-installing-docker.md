---
title: Installing and Configuring Docker
category: cnp
weight: 2
---

This section will give you the 411 on pulling and managing images. It will go over where to get images, which ones to use, and how you can manage them once you pull them down. Lastly, it will go over how to delete images.

## Installing Docker Desktop

Docker provides installation instructions online. This guide differs in the assumption that you are doing the installation on a corporate laptop connected to the corporate network.

Download the installation package, and install using the instructions provided on one of the following pages.  Note that you may need to sign up for a docker hub account on their website, and that this is separate from your NWIE credentials.

* [Docker Desktop for Windows](https://hub.docker.com/editions/community/docker-ce-desktop-windows)
* [Docker Desktop for Mac](https://hub.docker.com/editions/community/docker-ce-desktop-mac)

Note that if you are using windows, Docker will ask if you want to use Windows or linux containers.  You should choose linux containers regardless of your host OS.

## Updating Docker proxy settings

1. Right-click on the Docker icon in the tray and select **Settings**.

2. Under the **Proxies** menu, select **Manual proxy configuration** and update the HTTP/HTTPS proxy servers to `http://cloud-cluster122197-swg.ibosscloud.com:8009`

3. Additionally, update the **Bypass for these hosts and domains** with the same hosts as those in the `no_proxy` environment variable: `.nwie.net,localhost,kubernetes.docker.internal`

![Docker proxy settings](/docs/cnp/tutorial/images/docker-proxy-settings.png)

## Validating Docker install

Now that Docker has been installed and proxy settings have been updated, it's a good idea to validate Docker.

1. Open a command terminal (ie. PowerShell, CMD, Cmder, Git Bash, etc)
2. Run the following command: **`docker version`**

You should see something similar to this:

```bat
PS C:\Users\kemper5\Github\Nationwide\NW-Cloud-Docs> docker version
Client: Docker Engine - Community
 Version:           19.03.2
 API version:       1.40
 Go version:        go1.12.8
 Git commit:        6a30dfc
 Built:             Thu Aug 29 05:26:49 2019
 OS/Arch:           windows/amd64
 Experimental:      false

Server: Docker Engine - Community
 Engine:
  Version:          19.03.2
  API version:      1.40 (minimum version 1.12)
  Go version:       go1.12.8
  Git commit:       6a30dfc
  Built:            Thu Aug 29 05:32:21 2019
  OS/Arch:          linux/amd64
  Experimental:     false
 containerd:
  Version:          v1.2.6
  GitCommit:        894b81a4b802e4eb2a91d1ce216b8817763c29fb
 runc:
  Version:          1.0.0-rc8
  GitCommit:        425e105d5a03fabd737a126ad93d62a9eeede87f
 docker-init:
  Version:          0.18.0
  GitCommit:        fec3683
```

Next let's pull and run the **Hello-World** image from the Docker Hub. Run the command **`docker run hello-world:latest`**

```cmd
PS C:\Users\kemper5\Github\Nationwide\NW-Cloud-Docs> docker run hello-world:latest
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
1b930d010525: Pull complete
Digest: sha256:b8ba256769a0ac28dd126d584e0a2011cd2877f3f76e093a7ae560f2a5301c00
Status: Downloaded newer image for hello-world:latest

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
```

If the Docker was installed and configured correctly, you should see the above. It has successfully pulled and ran the latest Hello-World image down from the Docker Hub Trusted Registry. We'll break down what this command did later on.

If you ran into issues running either command, please validate the settings in the previous sections. You can also start fresh without re-installing Docker by going to **Docker Settings -> Reset** and selecting **Reset to factory defaults...**.You will need to reconfigure your proxy settings if you do a full reset.

**Next:** [Pulling Docker Images](../03-pulling-docker-images)
