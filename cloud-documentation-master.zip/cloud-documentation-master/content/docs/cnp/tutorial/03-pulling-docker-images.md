---
title: Pulling Docker Images
category: cnp
weight: 3
---

The next several sections will give you the foundation to start managing your own images.

## Where can I pull images

There are several places to find a Docker image. The best place to start is the local Nationwide Docker Trusted Registry. I recommend building images from the production DTRs. The location of Nationwide's Private Docker Trusted Registries can be found on the [**Get Access**](/docs/cnp/getting-started-with-cnp/get-access) page.

## Access to the Nationwide DTRs

To be able to log in to Nationwide's four DTRs and view images, you will need to submit a ServiceNow request to ID Admin and have yourself added to the **nw-docker-users** NWIE group. In order to get team access to dtr.aws.e1.nwie.net, you will need to submit a pull request to the caas-config pipeline. Directions on how to do both of these things can be found in the the [**Get Access**](/docs/cnp/getting-started-with-cnp/get-access) page.

Access to the three DTRs hosted on-prem are still managed via an e-mail process.  To set up a Docker repo, send the Cloud Platform team an email along with an appropriate AD group name as well as a name for the repo. The email address is cloud-platform@nationwide.com

For more information on the on-prem DTRs or the latest instructions, please visit the Cloud Native Platform's Docker site here: [https://pages.github.nwie.net/nationwide/docker/](https://pages.github.nwie.net/nationwide/docker/)

## Which images should I use

The Cloud Native Platform team maintains a list of official base images. If you need to build your own image, start with these:

[https://pages.github.nwie.net/Nationwide/docker/image-standards](https://pages.github.nwie.net/Nationwide/docker/image-standards)

Another good place to view some:

[https://dtr.aws.e1.nwie.net/orgs/library/repos](https://dtr.aws.e1.nwie.net/orgs/library/repos)

## What about Windows containers and images

Support for Windows containers will be coming in 2020. For more information visit thw [CNP Windows Container Support page](https://cnp.nwie.net/docs/cnp/windows/)

## Pulling from Docker Hub

Sometimes, especially for proof of concept, you'll want to pull some image from the Docker Hub. Here are some best practices when pulling images from Docker Hub:

- **Official Images** - Stick to images that are Docker Certified, from a verified publisher or are an official image published by Docker.
- **TSB Rules Apply** - Same with any software we run at Nationwide, make sure at TSB exception or standard exists. If it doesn't, make sure to file for one.
- **The Fine Print** - Please review the licensing for the image you pull from the Docker Hub. Some images have some legal fine print to give Nationwide some headaches.
- **Check with the Experts** - If you have any doubt, check with your architect or the Cloud Native Platform team.

## Let's get hands on

Ok let's start pulling some images. In the Docker Install section we pulled a simple Hello World image. Now we'll pull down something more useful with the latest Nationwide official CentOS image. It may at first tell you that it is unable to find image, but it will download soon.

### Pulling an image

Let's get started by pulling the latest **centos** image from the **library** repo in the **dtr.aws.e1.nwie.net** registry

**`docker pull dtr.aws.e1.nwie.net/library/centos:latest`**

![Pull CentOS](/docs/cnp/tutorial/images/dockerpullcentos.jpg)

In the image above, we pulled the CentOS image from the linuxengineering team's repo in the dtr-test registry, but you should see similar results. Important to note, you can specify an earlier CentOS image to pull, just replace latest with the version number you'd like to pull.

## A deeper look at an image

There are a few ways to get a deeper look into an image. Let's go through a few:

### View an image

Let's take a closer look at the image you just pulled:

**`docker images dtr.aws.e1.nwie.net/library/centos`**

We can see some details of when it was created, its size and its image ID. Sometimes it's easier to use the image ID than its name. The image name we've been using is just a tag associated with the image.

When we take a look at our demo image with the `docker images` command, we can see the IMAGE ID **11008842a4eb**:

![Docker Images](/docs/cnp/tutorial/images/dockerimagesexample.jpg)

### Docker image history

Docker image history will show you all the layers that went into. In our demo, we used the image ID **11008842a4eb**. When you try it, you should use the image ID that you saw when you used the `docker images` command above:

**`docker history (image ID)`**

![History](/docs/cnp/tutorial/images/dockerhistory.jpg)

This command gives you each layer that has been added to the image, when it was added and it's size. As you can see the Created By section has been truncated. If you'd like to see the whole comment run the history command with the **`--no-trunc`** flag.

### Docker image inspect

Ok, we get it, you want more detail so luckily we have another command:

**`docker image inspect (image ID)`**

This command will give you all the details for the image such as who created it, all the image layer hashes, architecture, etc.

### View all images

To view all images run this command:

**`docker image ls`**

This will list all images. If you are logged into a DTR, you are going to get a lot of images in return.

### View all image IDs

A quick and useful command to pull all image IDs is using the -q flag.

**`docker images -q`**

## Deleting an image

Sometimes we'll want to do some house cleaning and get rid of some images. In this example we'll remove the **Hello-World** image we used to validate your install earlier:

**`docker rmi hello-world`**

![Docker Delete](/docs/cnp/tutorial/images/dockerdelete.jpg)

If the image is associated with a container, you may need to delete the container first or you can also specify the **`-f`** flag to force the issue.

### Pruning images and containers

Docker has a command you can run to clean up your system. It will cleanup all unused images, containers, networks, volumes, etc.

**`docker system prune`**

You can add the **`-a`** flag to that command to also remove any stopped containers.

## Get a good cheat sheet... and Google

These are just a few useful commands but I recommend finding a good [cheat sheet](https://www.docker.com/sites/default/files/d8/2019-09/docker-cheat-sheet.pdf). There are many more useful commands out there for Docker images, these are just the basics.

**Next:** [Building Docker Images](../04-building-docker-images)
