---
title: Running Docker Containers
category: cnp
weight: 6
---

In this section we'll go over a couple of ways to run your containers, locally and via a Docker stack. These containers can also be run in Kubernetes, which is covered in a separate course.

## Running containers locally

The **`docker run`** command is a quick way to run your container locally. You can specify the map your containers port to a port on your OS with the **`-p`**. For running the container in the background in a “detached” mode use **`-d=true`** or just **`-d`** option. Here's an example of running the smpmaint container in detached mode and mapping the internal port 8080 to the OS port 8080.

**`docker run -d -p 8080:8080 dtr.aws.e1.nwie.net/shortname/smpmaint:latest`**

When running that command we should now be able to go to [http://localhost:8080](http://localhost:8080) to see our maintenance page.

You can have a container delete itself after it's stopped by added the **`--rm`**

For example this will delete the smpmaint container after it stops:

**`docker run --rm -p 8080:8080 dtr.aws.e1.nwie.net/shortname/smpmaint:latest`**

### Naming a container

You can name a container when running with the **`--name <name>`** parameter. For instance we can name the maintenance container the same name as the image with this command:

**`docker run -d -p 8080:8080 --name smpmaint dtr.aws.e1.nwie.net/shortname/smpmaint:latest`**

This will make it easier to interact with the container later since you won't have to lookup the container id.

## View container info

Your container is running and now you want more info, here are a few different commands to help you.

### View all containers

The **`docker ps -a`** command will show all running and stopped containers.

### View running containers

The **`docker ps`** command will show you all running containers. You can get the container id for all containers with this command.

### View stopped containers

The **`docker ps --filter "status=exited"`** or **`docker ps -f "status=exited"`** command will show all the stopped Docker containers.

### Container ID

**Important to note:** The container id is NOT the same as the image id.

### View even more container info

You want more, you got it with **`docker inspect <container id>`** command. It will give you detailed info about the container.

## Stopping and removing containers

You can stop a container and remove it with the following commands.

### Stopping a running container

To stop a container you will first need to get the container id. This can be done with the **`docker ps`** command. You can the run this command to stop the container:

**```docker stop <container id>```**

For example: **`docker stop 6892a350c10c`**

If you named your container with the **`--name`** parameter then you can use the name to stop it. For example if we named our container **smpmaint** we could run this:

**`docker stop smpmaint`**

### Removing a container

To remove a container you will first need to get the container id. This can be done with the **`docker ps`** command. You can the run this command to remove the container:

**```docker rm <container id>```**

For example: **`docker rm 6892a350c10c`**

If you named your container with the **`--name`** parameter then you can use the name to stop it. For example if we named our container **smpmaint** we could run this:

**`docker rm smpmaint`**

If a container fails to delete you can force remove it with the **`-f`** option

## Helpful commands for troubleshooting

Ok, let's say we have some problems, here are some useful commands and tricks to figure out what's going on.

### Gettings Logs

The **`docker logs <container id>`** command will give you the logs being output from a container.

### Shell into the container

Sometimes you want to shell into a container to look around and maybe run a command or two. The **`docker exec -it <container id> bash`** command will let you do that. Once you run that command you should get a command prompt inside the shell. Remember these containers are Linux based but very stripped down so not all commands will work. To get out of shell mode, use ctrl + P + Q.

## Running containers with mounted volumes

You can also mount a local folder or directory into your container with the -v command.  For example in Windows I would mount my current directory to /opt with this command:

**`docker run -v ${PWD}:/opt my-container`**

For a better example, go to the maintenance page volume example [here](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app/tree/master/smpmaint-volume-example).

If you are understandably confused about what mounting is, here is the docker doc page for it.
[Docker Storage](https://docs.docker.com/storage/)

## Documentation

For more documentation on Docker commands, see the site below

[Docker Commands](https://docs.docker.com/engine/reference/commandline/docker/)

**Next:** [Intro to Kubernetes](../07-intro-to-kubernetes)
