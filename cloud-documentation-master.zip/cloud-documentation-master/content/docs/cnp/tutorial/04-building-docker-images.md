---
title: Building Docker Images
category: cnp
weight: 4
---

## Building an image

Building an image is made easy with the use of a Dockerfile. Dockerfile's almost always start with a base image to build on. The best advice to building an image from scratch is **don't!** Always start with a base image.

## The Dockerfile

The Dockerfile is a set of instructions to build an image and what commands to execute when the image is run as a container.

## Important Dockerfile commands

### FROM

This tells the Dockerfile which base image to use and which registry to get it from.

### CMD

Default set of instructions for the container to run when executed. This can be overridden by the user.

### COPY

Copies files from source to a specified directory in the container. **`COPY * /opt/mydir`** will copy everything in my current working directory into the containers **`/opt/mydir`** directory.

### ADD

Similar to COPY but ADD will also allow your source to be a URL. It wil also unpacked recoginzed archived formats like a tarball or zip file.

### RUN

Will allow you to run commands to create a new layer and thus a new image. An example would be running the yum command to install a new feature such as python.

### EXPOSE

Tells Docker which port your container is using.

### ENTRYPOINT

This command tells the container what to execute once the container is run.

### LABEL

Metadata information about the container.

## Example - smpmaint Nginx

In this example, we'll use the Dockerfile in this Github directory:

[Nginx Maintenance Page Example](https://github.nwie.net/Nationwide/solution-marketplace-maintenance-app)

The **Dockerfile** in the example directory pulls the latest CentOS image from the library repo in DTR.aws.e1. It then sets a label and informs the Docker engine that it's listening on port 8080. When the container is launched, it will run the nginx command if the user doesn't provide any. It layers in the nginx install and then adds several files to the image.

```Dockerfile
FROM dtr.aws.e1.nwie.net/library/centos:latest

LABEL maintainer="NGI.Cloud.Support@nationwide.com"

EXPOSE 8080
CMD nginx

RUN set -x \
    && yum -y install nginx \
    && yum clean all \
    && rm -rf /var/cache/yum \
    && ln -s /dev/stdout /var/log/nginx/access.log \
    && ln -s /dev/stderr /var/log/nginx/error.log

ADD nginx.conf /etc/nginx
ADD maintenance.html /usr/share/nginx/html
#ADD maintenance-config.js /usr/share/nginx/html
```

If we clone that directory locally (you can use git clone, or alternatively fork the repo and download it) and cd to the local location, we can run the following command to build the image:

**`docker build .`**

![SMP Maint Build](/docs/cnp/tutorial/images/dockerbuild-smpmaint.jpg)

In the output you can see the different layers it has added to the image, stating with the pull of the CentOS image from the DTR. You can see near the end of the output this line which gives the image id:

**`Successfully built 830cac3d1b62`**

## Example - sample flask

In this example, we'll use the Dockerfile in this Github directory:

[Python Sample Flask Demo](https://github.nwie.net/Nationwide/sample-flask)

The Dockerfile in this example also pulls the latest centos image from Linux Engineering. It informs the Docker engine that the container is listening on port 5000 and set the default command to run on container launch as gunicorn wsgi web server. It creates a couple layers by pip installing some python packages. It also copies in some files to run a sample app into the **`/opt/sample-flask`** directory.

```Dockerfile
FROM dtr.aws.e1.nwie.net/library/centos:latest

LABEL maintainer="JavaHosting <JavaHostCore@nationwide.com>"
EXPOSE 5000
CMD gunicorn wsgi:app -b 0.0.0.0:5000 --workers 10 --threads 10 --chdir /opt/sample-flask

RUN mkdir /opt/sample-flask \
    && printf '[global]\ntrusted-host = repo.nwie.net\nindex = http://repo.nwie.net/nexus/repository/pypi/pypi\nindex-url = http://repo.nwie.net/nexus/repository/pypi/simple' > /etc/pip.conf \
    && yum install python2-pip python-virtualenv -y \
    && yum clean all \
    && rm -rf /var/cache/yum

COPY * /opt/sample-flask/
RUN pip install -r /opt/sample-flask/requirements.txt
```

If we clone that directory locally (once again either through git clone, or forking and downloading the repo) and cd to the local location, we can run the following command to build the image:

**`docker build .`**

![SMP Maint Build](/docs/cnp/tutorial/images/dockerbuild-flask.jpg)

From the output, you can see there is a lot more going on in the build output. This Dockerfile is installing several Python pip packages that will install when the image builds. Again at the end you can see the image id:

**`Successfully built 3aec403299bb`**

In the next section we'll use these image ids to deploy them into running containers. Here are some additional Docker image build reference documents.

## Reference

For more info on the Dockerfile, best practices and a cheat sheet, please see the links below:

[Docker Dockerfile Docs](https://docs.docker.com/engine/reference/builder/)

[Dockerfile Best Practices](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/)

[Dockerfile Cheatsheet](https://kapeli.com/cheat_sheets/Dockerfile.docset/Contents/Resources/Documents/index)

**Next:** [Pushing Docker Images](../05-pushing-docker-images)
