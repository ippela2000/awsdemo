---
category: "cnp"
description: "Learn how to deploy a multi-pod application in Kubernetes with this tutorial."
draft: false
difficulty: 2
title: "Multi-Pod Example"
hoursEstimate: 2
weight: 12
---

## NextCloud example

This example will show how to use the following Kubernetes constructs: pods, ingress, persistent volume claims and secrets.  To show these in action the example will implement the [NextCloud](https://nextcloud.com/) software in AWS.  By the end of this example you will have an application which is accessible from a URL of your choice and accesses a private data tier stored in a MySQL database.

## A word of caution

NextCloud is a private cloud software implementation which can be used at home or in businesses who choose to use it.  This software is not TSB approved so it is not to be used at Nationwide except as an example.  After you finish this tutorial, you should delete your instance.  This saves money as well as keeping your team compliant with Nationwide standards.  The choice of NextCloud happened to coincide with something the author was working on at home but it ties together ideas previously covered in the [Intro to Kubernetes](/docs/cnp/tutorial/07-intro-to-kubernetes) tutorial.

## Before you begin

You will need to set your context to point to your team's CNP space. See [the Kubernetes course](/docs/cnp/tutorial/07-intro-to-kubernetes) for more details.

You can use the [yaml files](https://github.nwie.net/Nationwide/cnp-examples/tree/master/multi-pod-example) in the [cnp-examples](https://github.nwie.net/Nationwide/cnp-examples) repo to follow along with this example.

You can do all of this locally but to do so you will need to change the yaml files and create equivalencies to resources in the CNP environment.  This is covered as an appendix to this example.

This tutorial uses Kubernetes labels to identify resources.  All resources have a label of app=next-cloud.  There are other labels in the resources to limit a view like class=app or class=db

To see resources defined in this example you can use the command `kubectl get RESOURCETYPE -l app=next-cloud`.  RESOURCETYPE can be `pods` to see pods created, `services` to see services created, `secrets` to see secrets created, `ingress` to see ingress points created or `pvc` to see storage created.  To see properties of the resources use the command `kubectl describe RESOURCETYPE -l app=next-cloud`.  Adding in `-l class=db` shows the database specific resources.  Adding in `-l class=app` shows the app server specific resources.    To see the logs output by a pod for troubleshooting use the command `kubectl logs PODNAME`, `kubectl logs -l app=next-cloud -l class=app` or `kubectl logs -l app=next-cloud -l class=db`.

For example, to describe the database pod created later you would use `kubectl describe pods -l app=next-cloud -l class=db`.  To see all pods use `kubectl get pods`.

Only one person at a time can do this in a CNP namespace unless you change the names of the objects created in the example.

## The secrets

This application uses a database to store metadata about the files being stored in the personal cloud along with data for other plug-ins.  MySQL needs to have some private information to start up that will be shared across multiple pods.  To accomplish this a secret is needed.

Please see the file `next-cloud-secrets.yml`.  The file contains comments detailing what is in the file.  Create the secrets by executing the command `kubectl -f next-cloud-secrets.yml apply`.  After you have created the secretes, take a moment to run the get secrets command (`kubectl get secrets -l app=next-cloud`) and describe the secrets you just created (`kubectl describe secrets -l app=next-cloud`)

You can delete the secrets later with `kubectl delete secret -l app=next-cloud`.  This will delete all the secrets contained in the file.  

## Database service

The MySQL database pod and service is defined in `next-cloud-db.yml`.  MySQL listens on port 3305.  For other pods in the cluster to access this pod a service is also needed.  This file creates the next-cloud-db pod as well as a next-cloud-db service to expose the pod to the rest of the namespace.  Applications will be able to access this service with the next-cloud-db:3305 just like a server name/port combination when running outside of Kubernetes except this doesn't need a domain extension like .nwie.net.

The yaml tree inside spec/template/spec/containers/env defines environment variables that are used inside the pod.  The environment variables in this example get their values from the secrets created in the previous section.  These create the default user/passwords and an initial database.  See `next-cloud-secrets.yml` for the key/value pairs.

To create these resources, use a command similar to the one used for the [secrets](#The-Secrets).  This is left to the user to figure out.  After creating the resources, describe them to see their information.

## The application

The NextCloud web application pod and service is defined in `next-cloud-application.yml`.  This pod shares three of the secrets that the [database service](#Database-Service) uses.  It also defines in its environment variables where the database is located.  This is done with the database service name and the port on which the database service is listening.  The result of applyting this file is the creation of the next-cloud-app service and pod that listens on port 80.  

To create these resources, use a command similar to the one used for the [database service](#Database-Service).  This is left to the user to figure out.  After creating the resources, describe them to see their information.

## The ingress

Ingress is what allows the outside world to consume a service in the Kubernetes cluster.  The ingress for this application is defined in `next-cloud-ingress.yml`.  This resource allows you to use HTTP to access the NextCloud service which was created in the previous section.  Please note, to keep the instance from conflicting with others, please change the USERNAME in spec/rules/host inside the file.  After creating this resource you should be able to point a web browser to `http://next-cloud-USERNAME.apps-test.aws.e1.nwie.net` (where USERNAME is substituted with your username) and see the NextCloud intro screen.

To create the resource, use a command similar to the one used for the [database service](#Database-Service).  This is left to the user to figure out.  After creating the resource, describe it to see it's information.

Open a web browser and navigate to your URL.  At this point you should see ![next cloud startup screen](/docs/cnp/tutorial/images/next-cloud-startup.png)

Create an admin account with username/password admin/admin (yes it's weak but it's only an example).  You'll then be presented with ![next cloud intro screen](/docs/cnp/tutorial/images/next-cloud-intro.png)

## Persistence

Cool, we have a web app.  Lets experiment.  First get the name of the POD hosting the database using `kubectl get pods -l app=next-cloud -l class=db`.  This uses labels to select the pods to show.  This will return something like

```bash
NAME                             READY     STATUS    RESTARTS   AGE
next-cloud-db-547659f489-rp8d4   1/1       Running   0          25m
```

Using `kubectl exec -it next-cloud-db-547659f489-rp8d4 bash` gets a bash shell running in the container inside the pod.  Inside the pod a `ps -ef` yields

```bash
root@next-cloud-db-547659f489-rp8d4:/# ps -ef
UID        PID  PPID  C STIME TTY          TIME CMD
mysql        1     0  0 15:51 ?        00:00:06 mysqld --transaction-isolation=READ-COMMITTED --binlog-format=ROW --mroot       204     0  0 16:18 pts/0    00:00:00 bash
root       213   204  0 16:19 pts/0    00:00:00 ps -ef
```

Running `kill 1` should kill the database.  Kubernetes will restart the pod for us since the database server failed.  Go back to your website and refresh.

```txt
Internal Server Error

The server encountered an internal error and was unable to complete your request.
Please contact the server administrator if this error reappears multiple times, please include the technical details below in your report.
More details can be found in the server log.
```

Uh oh.  Maybe restarting the web app will help.  Do this with the following commands to scale down the web app and then scaling it back up.

```bash
>kubectl scale deployment next-cloud-app --replicas=0
deployment.extensions "next-cloud-app" scaled

>kubectl get pods -l app=next-cloud
NAME                             READY     STATUS    RESTARTS   AGE
next-cloud-db-54b99d899b-vcxsm   1/1       Running   1          50m

>kubectl scale deployment next-cloud-app --replicas=1
deployment.extensions "next-cloud-app" scaled

>kubectl get pods -l app=next-cloud
NAME                              READY     STATUS    RESTARTS   AGE
next-cloud-app-797ddb9ddf-8psg9   1/1       Running   0          24s
next-cloud-db-54b99d899b-vcxsm    1/1       Running   1          51m
```

Refreshing the website yields this ![next cloud startup screen](/docs/cnp/tutorial/images/next-cloud-startup.png)

Uh oh!  What happened?  The pods for the database and web app were recreated back to their default state when they were restarted.  This includes what is in the file system.  To persist between restarts we're going to need storage that does not go away between restarts.

Kubernetes handles persistent storage using persistent volumes and persistent volume claims within a pod. Creating and managing persistent volumes are out of scope here.  What you need to know is that there are persistent volumes created for you in the CNP cluster.  Inside the Universal Control Plain/Kubernetes/Storage or by using `kubectl get storageclass` you'll find the classes of storage available to you.   At the time of this writing there were three available in the cluster.

```bash
λ kubectl get storageclass
NAME               PROVISIONER             AGE
efs-gp (default)   aws-efs                 26d
gp2                kubernetes.io/aws-ebs   123d
io1                kubernetes.io/aws-ebs   123d
```

Information on the storage classes avilable in the CNP clusters can be found in the [CNP Storage Documentation](/docs/cnp/storage/).  The CNP team mapped the gp2 and io1 directly to the AWS gp2 and io1 storage types.  Info on AWS gp2 and io1 can be found at [Amazon EBS Volume Types](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/EBSVolumeTypes.html).  Io1 is the fastest AWS storage and recommended for databases so we'll choose this.  It, however, limits the accessing PODs to one zone and is the most expensive of the options here.

For these to work, we're going to need to add PersistentVolumeClaim objects.  First, delete the database and web app using `kubectl -f FILENAME delete`.  Now create the PersistentVolumeClaim objects using the files `next-cloud-pvc-db.yml` and `next-cloud-pvc-app.yml`.  The claims will be named `next-cloud-pvc-db` and `next-cloud-pvc-app`.  You can verify the claims have been created in UCP.  If they are not bound then something went wrong and you'll need to troubleshoot.![Persistent Volume Claim in UCP-Test](/docs/cnp/tutorial/images/pvc-in-ucp.png)

Now that there exists persistent storage for the app and database it can be consumed.  Start the db and application using the files `next-cloud-db-pvc.yml` and `next-cloud-application-pvc.yml`.  When you examine these files you should see mounts defined that reference the persistent volume claim.  For example, the next-cloud-db-pvc.yml file contains the additional yaml

```yaml
        volumeMounts:
        - name: mysql-persistent-storage
          mountPath: /var/lib/mysql
      volumes:
      - name: mysql-persistent-storage
        persistentVolumeClaim:
          claimName: next-cloud-pvc-db
```

to mount the persistent volume into `/var/lib/mysql` so that MySQL can store data in it.  When you describe your running database pod you will ses an entry in the mounts section showing it pointing to the persistent volume.

```txt
    Mounts:
      /var/lib/mysql from mysql-persistent-storage (rw)
      /var/run/secrets/kubernetes.io/serviceaccount from default-token-74xh9 (ro)
```

Now set your cloud up as before.  After setting it up, bounce the database.

```bash
kubectl scale deployment next-cloud-db --replicas=0
deployment.extensions "next-cloud-db" scaled

kubectl scale deployment next-cloud-db --replicas=1
deployment.extensions "next-cloud-db" scaled
```

Access the site after the next-cloud-db pod has been started.  There is now a working website that survives a restart of one of more pods.

## Secure HTTP

The CNP site has documentation on how to use HTTPS instead of HTTP.  You can find it [here](/docs/cnp/ingress/ingress-default)

## Cleanup

So that you incur the least amount of cost to Nationwide, you should now clean up.

```bash
kubectl delete deployment,pvc,secret,ingress,service -l app=next-cloud
```

Should you want to start it all back up with persistent storage, a shortcut is to use

```bash
kubectl -f next-cloud-ingress.yml -f next-cloud-pvc-db.yml -f next-cloud-pvc-app.yml -f next-cloud-secrets.yml -f next-cloud-application-pvc.yml -f next-cloud-db-pvc.yml apply
```

You can see everything using

```bash
kubectl get pods,service,deployment,ingress,pvc,secrets -l app=next-cloud
```

## Appendix A - local execution

Persistent Volumes don't need to be configured locally on Kubernetes.  A hostPath volume can be used instead.  In these snippets, change USERNAME to your username to resolve to you Windows home directory.  The home C:\Users directory needs to be accessible to Docker for Windows.

Change the volumes in next-cloud-application-pvc.yml from

```yaml
      volumes:
        - name: app-persistent-storage
          persistentVolumeClaim:
            claimName: next-cloud-pvc-app

```

to

```yaml
      volumes:
        - name: app-persistent-storage
          hostPath:
            path: /c/Users/USERNAME/nextcloud/app
            type: Directory

```

Change the volumes in next-cloud-db-pvc.yml from

```yaml
      volumes:
      - name: mysql-persistent-storage
        persistentVolumeClaim:
          claimName: next-cloud-pvc-db
```

to

```yaml
      volumes:
        - name: mysql-persistent-storage
          hostPath:
            path: /c/Users/USERNAME/nextcloud/db
            type: Directory
```

Install nginx ingress locally using `helm install stable/nginx-ingress`.
Change the ingress file to

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  annotations:
    kubernetes.io/ingress.class: nginx
  name: next-cloud-ingress
  labels:
    ingress: next-cloud-ingress
spec:
  rules:
    - host: nextcloud.local
      http:
        paths:
          - backend:
              serviceName: next-cloud-app
              servicePort: http
            path: /
```

Add a line to `C:\Windows\System32\drivers\etc\hosts` to resolve the hostname.

```txt
127.0.0.1 nextcloud.local
```

**Next:** [Final Thoughts and Next Steps](../13-final-thoughts)
