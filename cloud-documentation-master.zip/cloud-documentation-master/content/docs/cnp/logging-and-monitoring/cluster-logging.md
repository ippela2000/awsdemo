---
title: Cluster Logging
menu: docs
category: cnp
---

### Overview

Logs can be accessed using Kubectl, or through Splunk Cloud.

#### Accessing logs on Splunk Cloud

The platform will automatically capture a container's stdout and stderr and send it to [Splunk Cloud](https://nationwide.splunkcloud.com/en-US/app/search), to the *cnp* index.
The following labels will also be sent, and can be use to filter logs.

* io.kubernetes.pod.namespace
* io.kubernetes.pod.name
* io.kubernetes.container.name
* io.kubernetes.pod.uid
* com.docker.ucp.access.label
* com.docker.swarm.service.name
* com.docker.stack.namespace

Also, the following environmental variables will be sent:

* ENVIRONMENT

##### Getting access

Some teams have been already added to Splunk Cloud, and migrations continue. So, access to Splunk Cloud should work for most, but if your account is not able to logon, then send a request to ESM to be added. Details are documented [here](https://onyourside.sharepoint.com/sites/dwbi/splunk/SitePages/Access%20Splunk.aspx).

##### Additional logs

If an application creates additional logs files, then sidecar container with the Splunk log forwarded can be used to retrieve them.

(Work in progress.)
