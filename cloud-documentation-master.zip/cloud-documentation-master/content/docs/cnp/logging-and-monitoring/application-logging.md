---
title: Application Logging and Monitoring
menu: docs
category: cnp
---

### Overview

The platform will automatically gather SystemOut and SystemErr of a container,but does access other log files.
For an application that can not log directly to Splunk, or has additional logs files that need to be shipped, we can use a [sidecar](https://docs.microsoft.com/en-us/azure/architecture/patterns/sidecar) container to pull those logs.

### Prerequisite

You will need to obtain a Splunk Cloud HEC token. Go [here](https://onyourside.sharepoint.com/sites/dwbi/splunk/SitePages/Home.aspx) to start this process.  

### How to

Below are two example files to use as a template for your application.
The first file shows a **deployment** with the logging sidecar. At the bottom of the file, 2 volumes are created.
The volume named **log** will be shared between the application container, **tomcat** and the log reader, **logger**.
This volume will be mounted, in the **tomcat** container, to where logs are normally written, `/usr/local/tomcat/logs`, in this case.
In the **logger** container, however, it will be mounted to the directory `/log`.
For your application, mount this volume in the appropriate place, but I recommend not changing the mount path of the log reading container.
This will allow simpler and reusable configuration files.

The next file is a **configMap** which has two configuration files in it.
The HEC token goes at the end the first file `fluent.conf`, and may need to be updated if all the log files do not end in `.log`
The second file in the **configMap**, `parsers.conf` can be updated to help improve the formatting of your log files.

Additional [documentation](https://docs.fluentbit.io/manual/) on fluent bit.  

### Monitoring

Application monitoring is done on a case-by-case basis and application monitoring needs vary greatly. To request monitoring of POD or endpoint health, enter the pertinent details in [this request](https://nwproduction.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D5bb47e4a0fe692402407abf8b1050e94%26sysparm_link_parent%3Dcb8d9b290f1f7100a5eee478b1050e65%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default%26sysparm_view%3Dtext_search).  

-------------------------------------------

#### Example deployment.yaml

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: logging-example
spec:
  selector:
    matchLabels:
      app: logging-example
  replicas: 3
  template:
    metadata:
      labels:
        app: logging-example
    spec:
      automountServiceAccountToken: yes
      containers:
      # Example application container.
      - name: tomcat
        image: tomcat:latest
        volumeMounts:
        - name: log
          mountPath: /usr/local/tomcat/logs
      # Logging sidecar.
      - name: logger
        env:
          - name: NODE_NAME
            valueFrom:
              fieldRef:
                fieldPath: spec.nodeName
          - name: POD_NAME
            valueFrom:
              fieldRef:
                fieldPath: metadata.name
          - name: POD_NAMESPACE
            valueFrom:
              fieldRef:
                fieldPath: metadata.namespace
          - name: POD_UID
            valueFrom:
              fieldRef:
                fieldPath: metadata.uid
        image: fluent/fluent-bit:1.0.4
        # Above image is not bundled with sh,bash etc, for troubleshooting add -debug to the image name,
        # for eg. fluent/fluent-bit:1.0.4-debug  
        command: ["/fluent-bit/bin/fluent-bit"]
        args:
        - --config=/fluentd/etc/fluent.conf
        - --parser=/fluentd/etc/parsers.conf
        volumeMounts:
        - name: log
          mountPath: /log
        - name: config-volume
          mountPath: /fluentd/etc
      # Create a volume to share between containers for writing and reading logs.
      volumes:
      - name: log
        emptyDir: {}
      # fluent bit config files.
      - name: config-volume
        configMap:
          name: bit-config

```

#### Example config-bit.yaml

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: bit-config
data:
  # Update this file with your HEC token and any additional logs.
  fluent.conf: |
    [SERVICE]
        Flush        5
        Log_level    info
        HTTP_Server  on
        HTTP_Port    2020

    [INPUT]
        Name         tail
        Path         /log/*.log
        Parser       apache
        Exclude_Path *.gz,*.zip
        DB           /log/logs.db
        Path_Key     file
        Key          line
        Tag          kube.${POD_NAME}.${POD_NAMESPACE}.${HOSTNAME}

    [FILTER]
        Name         kubernetes
        Match        kube.*
        Kube_URL     https://kubernetes.default.svc.cluster.local:443
        tls.verify   off
        Regex_Parser kube-sidecar
        Annotations  Off

    [OUTPUT]
        Name         splunk
        Match        *
        Host         http-inputs-nationwide.splunkcloud.com
        Port         443
        TLS          On
        TLS.Verify   Off
        Splunk_Token XXX-YYYY-ZZZZ
        Message_Key  fbit
  # You may have to update this file with new log formats.
  parsers.conf: |
    [PARSER]
        Name   apache
        Format regex
        Regex  ^(?<host>[^ ]*) [^ ]* (?<user>[^ ]*) \[(?<time>[^\]]*)\] "(?<method>\S+)(?: +(?<path>[^\"]*?)(?: +\S*)?)?" (?<code>[^ ]*) (?<size>[^ ]*)(?: "(?<referer>[^\"]*)" "(?<agent>[^\"]*)")?$
        Time_Key time
        Time_Format %d/%b/%Y:%H:%M:%S %z

    [PARSER]
        Name   apache2
        Format regex
        Regex  ^(?<host>[^ ]*) [^ ]* (?<user>[^ ]*) \[(?<time>[^\]]*)\] "(?<method>\S+)(?: +(?<path>[^ ]*) +\S*)?" (?<code>[^ ]*) (?<size>[^ ]*)(?: "(?<referer>[^\"]*)" "(?<agent>.*)")?$
        Time_Key time
        Time_Format %d/%b/%Y:%H:%M:%S %z

    [PARSER]
        Name   apache_error
        Format regex
        Regex  ^\[[^ ]* (?<time>[^\]]*)\] \[(?<level>[^\]]*)\](?: \[pid (?<pid>[^\]]*)\])?( \[client (?<client>[^\]]*)\])? (?<message>.*)$

    [PARSER]
        Name   nginx
        Format regex
        Regex ^(?<remote>[^ ]*) (?<host>[^ ]*) (?<user>[^ ]*) \[(?<time>[^\]]*)\] "(?<method>\S+)(?: +(?<path>[^\"]*?)(?: +\S*)?)?" (?<code>[^ ]*) (?<size>[^ ]*)(?: "(?<referer>[^\"]*)" "(?<agent>[^\"]*)")?$
        Time_Key time
        Time_Format %d/%b/%Y:%H:%M:%S %z

    [PARSER]
        Name   json
        Format json
        Time_Key time
        Time_Format %d/%b/%Y:%H:%M:%S %z

    [PARSER]
        Name         docker
        Format       json
        Time_Key     time
        Time_Format  %Y-%m-%dT%H:%M:%S.%L
        Time_Keep    On
        # Command      |  Decoder | Field | Optional Action
        # =============|==================|=================
        Decode_Field_As   escaped    log
        Decode_Field_As   escaped    stream

    [PARSER]
        Name        docker-daemon
        Format      regex
        Regex       time="(?<time>[^ ]*)" level=(?<level>[^ ]*) msg="(?<msg>[^ ].*)"
        Time_Key    time
        Time_Format %Y-%m-%dT%H:%M:%S.%L
        Time_Keep   On

    [PARSER]
        Name        syslog-rfc5424
        Format      regex
        Regex       ^\<(?<pri>[0-9]{1,5})\>1 (?<time>[^ ]+) (?<host>[^ ]+) (?<ident>[^ ]+) (?<pid>[-0-9]+) (?<msgid>[^ ]+) (?<extradata>(\[(.*)\]|-)) (?<message>.+)$
        Time_Key    time
        Time_Format %Y-%m-%dT%H:%M:%S.%L
        Time_Keep   On

    [PARSER]
        Name        syslog-rfc3164-local
        Format      regex
        Regex       ^\<(?<pri>[0-9]+)\>(?<time>[^ ]* {1,2}[^ ]* [^ ]*) (?<ident>[a-zA-Z0-9_\/\.\-]*)(?:\[(?<pid>[0-9]+)\])?(?:[^\:]*\:)? *(?<message>.*)$
        Time_Key    time
        Time_Format %b %d %H:%M:%S
        Time_Keep   On

    [PARSER]
        Name        syslog-rfc3164
        Format      regex
        Regex       /^\<(?<pri>[0-9]+)\>(?<time>[^ ]* {1,2}[^ ]* [^ ]*) (?<host>[^ ]*) (?<ident>[a-zA-Z0-9_\/\.\-]*)(?:\[(?<pid>[0-9]+)\])?(?:[^\:]*\:)? *(?<message>.*)$/
        Time_Key    time
        Time_Format %b %d %H:%M:%S
        Time_Format %Y-%m-%dT%H:%M:%S.%L
        Time_Keep   On

    [PARSER]
        Name    mongodb
        Format  regex
        Regex   ^(?<time>[^ ]*)\s+(?<severity>\w)\s+(?<component>[^ ]+)\s+\[(?<context>[^\]]+)]\s+(?<message>.*?) *(?<ms>(\d+))?(:?ms)?$
        Time_Format %Y-%m-%dT%H:%M:%S.%L
        Time_Keep   On
        Time_Key time

    [PARSER]
        # http://rubular.com/r/tjUt3Awgg4
        Name cri
        Format regex
        Regex ^(?<time>[^ ]+) (?<stream>stdout|stderr) (?<logtag>[^ ]*) (?<message>.*)$
        Time_Key    time
        Time_Format %Y-%m-%dT%H:%M:%S.%L%z

    [PARSER]
        Name    kube-custom
        Format  regex
        Regex   (?<tag>[^.]+)?\.?(?<pod_name>[a-z0-9](?:[-a-z0-9]*[a-z0-9])?(?:\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*)_(?<namespace_name>[^_]+)_(?<container_name>.+)-(?<docker_id>[a-z0-9]{64})\.log$

    [PARSER]
        Name    kube-sidecar
        Format  regex
        Regex   (?<tag>[^.]+)\.(?<pod_name>[^.]+)\.(?<namespace_name>[^.]+)\.(?<container_name>[^.]+)$


    [PARSER]
        Format regex
        Name java_multiline
        Regex (?<time>\d{1,2}-.+-\d{4}\s\d{1,2}:\d{1,2}:\d{1,2}.\d{1,3})
        Time_Format %d-%b-%Y %H:%M:%S.%L
        Time_Keep true
        Time_Key time

```

#### New Relic

In addition to the methods mentioned above, you can also monitor your Kubernetes pods in other ways through New Relic. For example, if you're interested in seeing the overall health of a cluster, the [New Relic Kubernetes Infrastructure](https://infrastructure.newrelic.com/accounts/1092591/kubernetes?cluster=test) page is a good place to look. This Infrastructure view provides a quick summary of the cluster, and displays the top "problem" nodes. From this view, you can also look to see individual CPU and memory usage of pods.

Teams can also utilize New Relic's alerting features to create alerts and ServiceNow tickets for when their pods meet certain criteria. In order to do this, you must have access to create/edit alerts in New Relic - to get this, open a ServiceNow request to the `NSC-ESM-SYSTEMS-MANAGEMENT` group, and include in your request the IDs of the users who need the access.

The New Relic team can assist with helping first-time users set up their alert policy, but here's a little extra help for setting up alert conditions themselves, specific to Kubernetes:

- While in your team's Alert Policy, click the Add a Condition button.
- Select the Infrastructure alert type, and then select Kubernetes.
- **IMPORTANT:** Use the Narrow Down Entities section to narrow down your alert to the specific cluster, namespace, and deployment you want to monitor. If you do not do this, you will receive alerts for everything that meets the alert criteria, instead of for your specific application.

Once these steps are complete, you can define the thresholds for what will trigger your alert and send your team an e-mail or ticket. Consider setting up alerts similar to what can currently be seen in the [Kubernetes Default Alert Policy](https://alerts.newrelic.com/accounts/1092591/policies/453681), which is not active, but contains several examples of Kubernetes alerts.
