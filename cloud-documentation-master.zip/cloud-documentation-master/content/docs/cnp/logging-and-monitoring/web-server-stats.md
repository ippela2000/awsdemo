---
title: Web Server Stats
menu: docs
category: cnp
---

Apache HTTPD and Nginx have status pages that can be used to track
their connection stats. New Relic running inside the kubernetes
cluster is capable of scraping the status page and storing that data.
In order for New Relic to know it needs to monitor the pod
a special annotation needs to be added to the pod and the web
server needs to be configured to expose the status page
in the way New Relic expects.

## New Relic

The Apache New Relic data can be accessed [here](https://infrastructure.newrelic.com/accounts/1092591/integrations/onHostIntegrations/accounts/4/apache/dashboard).

The NGINX New Relic data can be accessed [here](https://infrastructure.newrelic.com/accounts/1092591/integrations/onHostIntegrations/accounts/2/nginx/dashboard).

## Pod annotation

One of the following annotations needs to be added
any pods that you want to have New Relic scrape the
server status page. Use the correct the annotation
based on which web server you are using.

The port number in the annotation is the port that the webserver is
listening on.  Ports 443 and 8443 will use https (tls/ssl).

Apache HTTPD

```yaml
newrelic.com/apache-httpd-80-status: "true"
newrelic.com/apache-httpd-443-status: "true"
newrelic.com/apache-httpd-8080-status: "true"
newrelic.com/apache-httpd-8443-status: "true"
```

NGINX

```yaml
newrelic.com/nginx-80-status: "true"
newrelic.com/nginx-443-status: "true"
newrelic.com/nginx-8080-status: "true"
newrelic.com/nginx-8443-status: "true"
```

## PING support

If your application is using PING New Relic will be unable to
access the stats.  This is because PING needs a valid Hostname
and New Relic does not allow us to set one currently.  A feature
request has been opened with New Relic to be able to pass in
http headers to solve this issue.

As a work around you can add a 2nd httpd container to your pod
that listens on a different port and proxies requests to
`http://locahost/nr-server-status`.  This will cause PING to see
the hostname localhost on which it can then allow without
authentication.

## Example configurations

The web server needs to be configured to expose the status page on one
of the predefined ports. That stats should be exposed under /nr-server-status.
The status page should also only allow certain IPs to access it as this data
should never be exposed to the Internet or end users. The IPs of each AWS
VPC should be used to limit access to the status pages.
The examples are for a pod running in the **test** cluster
running in AWS us-east-1.

Please refer to [Firewall Page](../../security/firewalls/) for a list
of all IP ranges for each cluster.

The WAF in AWS also blocks access to /nr-server-status so end users
should not be able to access the page.

### Apache HTTPD

```apache
<Location "/nr-server-status">
    SetHandler server-status

    # Allow localhost and Test us-east-1
    Require ip 172.0.0.1
    Require ip 10.165.52.0/22
    Require ip 10.165.56.0/22
    Require ip 10.165.60.0/22
</Location>
```

### NGINX

```nginx
location = /nr-server-status {
    stub_status;

    # Allow localhost and Test us-east-1
    allow 127.0.0.1;
    allow 10.165.52.0/22;
    allow 10.165.56.0/22;
    allow 10.165.60.0/22;
    deny  all;
}
```
