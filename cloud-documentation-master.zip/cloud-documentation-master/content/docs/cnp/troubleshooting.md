---
title: Troubleshooting
menu: docs
category: cnp
---

## Troubleshooting

This page addresses a number of common issues experienced by Kubernetes users and goes through how to identify and solve them.

### Diagnosing common problems

When there's something wrong with your pod, the first step is to take a look at its current state and see if anything stands out. The following are basic troubleshooting steps to help narrow down the cause of pod issues:

1. `kubectl describe pod <podname>` - This will get a description of the pod, including its setup, the last time Kubernetes restarted each container and why, and any recent pod events.

2. `kubectl logs <podname>` - Get the logs from the application inside the pod (you may need to specify a container name). You may not see anything if the application is not logging. All `stdout` and `stderr` logs are automatically sent to the `cnp` index in Splunk, so if the pod is no longer available, you can search Splunk for its logs instead.

3. `kubectl get events` - Get the events (activity relating to pods, deployments, etc.) for your namespace.

4. `kubectl top pod <podname>` - Get the current CPU and memory usage of your pod. If the CPU/memory usage looks abnormal for your application, there's possibly an application problem that needs investigating.

5. `kubectl describe node <nodename>` - Find information about the node itself using the name from the `Node:` field in your pod's description. Events on the node may indicate an issue. If you notice strange behavior with a node, go to the `#cloud-native-platform` channel in RocketChat and let the Cloud Platform team know. Include the name of the node, your namespace and pod name, and what issue you are investigating.

If you often have trouble finding the cause of issues with your pod, it can help if the application is set up to report event logs or last exit reason.

### Troubleshooting specific issues

The following are more detailed descriptions of issues and directions on how to troubleshoot them.

#### ALB not registering

If your ALB Ingress is not registering your DNS name, check the following:

- Read over the [ALB Ingress documentation](../ingress/ingress-alb/) and make sure your ALB has all of the proper annotations present.
- If it has the proper annotations, ensure that all of them, including your certificate ARN, are correct.
- Ensure that your ALB's `backend` is using the correct `serviceName` and `servicePort`.
- The ALB controller does not report misconfigurations to the Ingress object via events; it only logs them to its `stdout`, which can make it difficult to track down issues. However, the ALB controller sends all of its logs to Splunk. You can search Splunk using the following query, using the name of your namespace or ingress:

`index=cnp "attrs.io.kubernetes.pod.namespace"="ingress" "attrs.io.kubernetes.container.name"="aws-alb-ingress-controller" <name>`

- When using the above query, keep in mind that the data is coming from all Kubernetes clusters.

#### Pod not starting/stuck in pending

Follow the "diagnosing common problems" steps above to see if anything stands out as obvious. Below are examples of common causes for a pod not starting and how to troubleshoot:

**ImagePullBackOff status.** Kubernetes cannot find, doesn't have permission to pull, or can’t connect to the image registry. Make sure that the image name in your pod’s YAML is correct, repository is not private, and registry (DTR, Docker Hub, etc.) is available.

**The pod triggered a scale-up.** The pod is too big to fit on any node in the cluster, so the cluster is adding a new node to accommodate the pod. The issue will resolve in in 5-10 minutes after the cluster adds a new node.

**The pod did not trigger a scale-up (wouldn't fit if a new node is added).** There are multiple possible causes for this:

1. The pod is being blocked by Twistlock due to a vulnerability in the image. Run `kubectl describe pod <podname>` on your pod, and check the pod's events and see if there is a message from Twistlock. You can find more information in the [image vulnerability scanning documentation](../security/image-vulnerability-scanning/).

2. You might have reached your namespace's limits on number of pods, CPU/memory requests or limits, or etc. Check your namespace's limits (`kubectl describe namespace <namespacename>`) and either remove unneeded resources to create room, or increase your limits by updating your organization's file in the [cnp-caas-config repo](https://github.nwie.net/Nationwide/cnp-caas-config).

#### Pod restarting

Follow the "diagnosing common problems" steps above to see if anything stands out as obvious. Below are examples of common causes for pod restarts and how to troubleshoot:

**A container on the pod has "OOMKilled" listed as the reason for the last termination.** The container went over its memory limit and was restarted by the node it is running on. Look into causes for unusually high memory usage from the application's side, or raise your container's memory limit if this is normal memory usage for the application.

**The pod's liveness probe is failing.** When a liveness probe fails, it will restart the pod. Make sure that the liveness probe is trying to reach the correct port to communicate with your application and that your application is able to respond properly. If the liveness probe is failing before your pod is ready to respond, increase the `initialDelaySeconds` to tell the liveness probe how long to wait before performing the first probe.

**The application is configured incorrectly.** Check the logs from your pod - you may be able to find a cause for the application itself crashing due to application errors. These are cases in which the application developer will need to investigate and resolve the problem.

#### Pod stuck in "Terminating" status for a long time

**If your pod is stuck with a "Terminating" status, do NOT force delete it. Force deleting the pod will remove it from your view, but leaves resources running on the node.**

- There is possibly an issue with the node your pod is on. Go to the `#cloud-native-platform` channel in RocketChat and bring the issue to the attention of the Cloud Platform team, including the names of the cluster, namespace and pod.

### When in doubt

...follow through this handy Kubernetes troubleshooting flowchart, which goes over many potential causes for your issue. (You can right-click the image and open it in a new tab to view a bigger version.)

If all else fails, reach out to the Cloud Platform team in the `#cloud-native-platform` channel on Rocketchat. Provide your namespace, the cluster you are working in, the names of the resources (pod, ingress, etc.) involved with the issue, and details on what the issue is.

![Kubernetes troubleshooting flowchart](/docs/cnp/images/kubeflowchart.png)
