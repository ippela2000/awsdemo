---
title: FAQ
menu: docs
category: cnp
weight: 4
---

## Frequently asked questions

* **Q: How do I obtain a namespace?**

* **A:** Visit the [cnp-caas-config](https://github.nwie.net/Nationwide/cnp-caas-config) repo, and fork it (press Fork in the upper right-hand corner, next to Star). Using the `caas.template.yaml` file in the repo, fill out the information you need. If you are unsure on what information to fill in, you can look in the configs folder to see examples from other requests. If you need Concourse C/I, you will also need to fill out the `caas.concourse.template.yaml` file. Rename the file(s) to fit your org, `org.yaml` (and `concourse-org.yaml` if needed), and copy them into the configs directory in the repo. Once you have completed this, submit a pull request. Unless your pull request contains formatting issues, it is automatically accepted. A pipeline will then process the configuration files, get your namespace added, and grant you access to your requested clusters. The pipeline takes about a half hour to run.

* **Q: I need to update my namespace information (increase quota, etc). How can I do this?**

* **A:** Follow similar steps to above. Update your `org.yaml` (and `concourse-org.yaml`) files as needed through a pull request, and the pipeline will update them.

* **Q: I am receiving e-mails from the Cloud Platform team. Where does this contact information come from?**

* **A:** The e-mail contact information, which is used for notifications relating to your resources, is pulled from the **ResourceOwner** and **ContactGroup** on a deployment. These labels are automatically applied to pods within a namespace based off of the info provided in your caas-config file. If a specific deployment within the namespace needs to have different contact info, you can override the namespace's labels by adding **ResourceOwner** and **ContactGroup** labels on your deployment with the desired contact information.

* **Q: I am trying to use Docker Desktop, but am encountering an error connecting.**

* **A:** Check your proxy settings and try setting and unsetting the proxy environment variables, `http_proxy` and `https_proxy` (both should be set to `http://cloud-cluster122197-swg.ibosscloud.com:8009`). You may also need to set the `no_proxy` environment variable to `nwie.net,localhost`.

* **Q: Can I use a Windows node?**

* **A:** Support for Windows nodes is not currently offered. Work on this feature requires the next release of the platform.

* **Q: I am seeing issues with my resources and need help troubleshooting.**

* **A:** Check out our [troubleshooting page](../../troubleshooting/) for information on how to investigate and troubleshoot common issues.

Question not answered here? Need further help? Reach out to our [RocketChat](https://rocketchat.nwie.net/channel/cloud-native-platform) channel, #cloud-native-platform, where the Cloud Platform team is regularly available to help. **For Docker Desktop issues, reach out to the #docker channel instead.**
