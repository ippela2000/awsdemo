---
title: "Getting Started with CNP"
menu: docs
category: cnp
weight: 1
---

## Overview

This section has the details on what you will need to get started in the Cloud Native Platform at Nationwide.

1. Getting Access
2. Tools
3. FAQ

**[Questions? Visit our RocketChat channel!](https://rocketchat.nwie.net/channel/cloud-native-platform)**

**[Next - Getting Access](/docs/cnp/getting-started-with-cnp/get-access)**
