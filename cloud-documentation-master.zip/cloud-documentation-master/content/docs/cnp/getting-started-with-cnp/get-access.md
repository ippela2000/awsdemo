---
title: Getting Access
menu: docs
category: cnp
weight: 1
---

### Developer access

There is one common group for all Docker Enterprise users. You will need to request that your NWIE ID is added to the group **nw-docker-users** through IIQ. Membership in this group will give access to both Universal Control Plane (UCP) and the image registry (DTR) in test and production. This group has nothing to do with Docker Desktop.

In order to make your request, visit [IIQ](https://iiq.nwie.net/) at this link.

- Click on the three dots/lines on the upper left-hand side of the page.
- Select **"Manage Access"**, then **"Manage user access"**.
- Select the user who needs access. If it's yourself, you should automatically appear on the page. If it's someone else, you will need to search for them and select them.
- Click on **"Manage Access"** in the middle (next to **"Select Users"**, which should currently be highlighted).
- In the **"Search Access"** box, type **nw-docker-users** and search. When it appears, click the check mark.
- Click on **"Review"** on the right (next to **"Manage Access"**). Make sure that you have requested for the correct user to access the correct group.
- Click the blue **Submit** button at the bottom of the page.

Once the account is made you'll be able to log in to UCP, get a cert bundle and start deploying applications. Follow this [link](https://docs.docker.com/ee/ucp/user-access/cli/) for instructions on downloading and using the bundle.

### Team access

Team access is managed with LDAP groups. Create a new group for your team or use an existing one. (UCD Codemove groups are fairly common). The group will allow multiple users to view and manipulate containers for a given namespace. Think of it like a tag for resources your team cares about. You will need to know the full LDAP Common name for your LDAP group.  An example is **CN=nw-docker-users,OU=NSC Managed,OU=Global,OU=Groups,DC=nwie,DC=net** for the nw-docker-users group. You can look up the common name using [Apache Directory Studio](https://directory.apache.org/studio/) using hostname adldap.nwie.net, port 3268, & authentication with `cn=<username>,OU=NSC Managed,OU=Accounts,DC=nwie,DC=net`, replacing `<username>` with your NWIE ID.

Go to the [cnp-caas-config](https://github.nwie.net/Nationwide/cnp-caas-config) GitHub repo and follow the instructions in the README.md file to create your team's namespace and submit a PULL request. A concourse file is also needed to enable the use of Concourse continuous integration. See the README.md file for more information. As part of this process, you will pick which clusters you want access to.

### Cluster list

[1]: https://ucp-dev.aws.e1.nwie.net   "dev"
[2]: https://ucp-test.aws.e1.nwie.net  "test"
[3]: https://ucp.aws.e1.nwie.net       "prod"
[4]: https://ucp-tools.aws.e1.nwie.net "tools"
[5]: https://ucp-test02.nwie.net       "test02"
[6]: https://ucp-prod02.nwie.net       "prod02"
[7]: https://ucp-test03.aws.e2.nwie.net       "test03"
[100]: https://dtr.aws.e1.nwie.net     "dtr"

| CLUSTER | UCP                             | DTR                        | Notes             |
| ------- | ------------------------------- | -------------------------- | ----------------- |
| dev     | [ucp-dev.aws.e1.nwie.net][1]    | [dtr.aws.e1.nwie.net][100] | AWS, Kube 1.14    |
| test    | [ucp-test.aws.e1.nwie.net][2]   | [dtr.aws.e1.nwie.net][100] | AWS, Kube 1.14  |
| prod    | [ucp.aws.e1.nwie.net][3]        | [dtr.aws.e1.nwie.net][100] | AWS, Kube 1.14 |
| tools   | [ucp-tools.aws.e1.nwie.net][4]  | [dtr.aws.e1.nwie.net][100] | AWS, Kube 1.14  |
| test02  | [ucp-test02.nwie.net][5]        | [dtr-prod.nwie.net][100]   | NW, Kube 1.14, ON PREM  |
| prod02  | [ucp-prod02.nwie.net][6]        | [dtr-prod.nwie.net][100]   | NW, Kube 1.14, ON PREM |
| test03  | [ucp-test03.aws.e2.nwie.net][7] | [dtr.aws.e1.nwie.net][100] | AWS OH, Kube 1.17 |
| prod03  | [ucp-prod03.aws.e2.nwie.net][7] | [dtr.aws.e1.nwie.net][100] | AWS OH, Kube 1.17 |

- AWS is hosted at AWS us-east-1
- AWS OH is hosted at AWS us-east-2
- NW is hosted at a Nationwide datacenter
- The tools cluster is currently only used for Concourse, app teams are not allowed to run applications there

You should target the AWS clusters unless you have to stay inside a Nationwide
datacenter.  The NW clusters have limited resources and do not grow to meet
demand like the clusters in AWS.
