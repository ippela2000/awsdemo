---
title: Application On-boarding
menu: docs
category: cnp
weight: 2
---
This document focuses on the application concerns for on-boarding an application to the Nationwide Cloud Native Platform.

## Initial application assessment

We intend to use the following questions to gain an understanding of the application being migrated to the Cloud Native Platform.

### Application

1. Do you have access to the source code and can build the application locally? If yes, what is the source repo name?
1. Is there supporting documentation and diagrams for this application that can be shared? Please share if available.
1. What is the business importance of this application? i.e. tier1, tier2, tier3
1. How is logging currently handled? Does it log to the filesystem or stdout?
1. Which other components does the application interface with?
1. Does the application use in-memory session state? If not, where is session state stored?
1. Is the application currently load balanced? If so, how many upstream nodes?
1. Does the application use persistent storage?
1. Does the application have automated tests associated with it?
1. Which versions of Java and Springboot does the application use?

### Operational

1. Is the application externally accessible?
1. How is the application currently deployed today?
1. How is service failure handled today?
1. How is the application monitored today?
1. What type of hardware does the application currently run on?
1. How many users access the application and what is the current load profile?
1. Is the application currently highly available?
1. Which environments does this application get currently promoted through as part of the SDLC?
1. Are there performance tests associated with this application?

### Security

1. Does your app touch PII/PIFI?
1. Are all of your integration endpoints HTTPS or otherwise encrypted in transit?
1. How does your app handle authentication?
1. What services does your app integrate with? For each, what is the network location? What sort of data is exchanged? How does the external service handle authentication?

## Local development environment setup

1. Install Docker for Mac or Docker for Windows depending on your OS.
1. Steps for NTLM setup

TODO: Complete this section with Nationwide

## Containerizing the application locally

Now that the development environment is setup, we will walk through running the application in a container locally.

First, take note of the following with the current application.

1. Java version
1. Springboot version

The Websphere Liberty image has several tags associated with it, depending on the Java and Springboot versions.

* javaee8, latest
* microProfile
* springBoot2
* kernel
* beta
* springBoot1
* webProfile7
* javaee7

If the application is using Springboot, then the Springboot version for that will need to match with the image tag. Otherwise, select the image tag that matches your Java version.

### Build the artifact locally

1. Build the deployment artifact on your local machine so that it will produce an *EAR/WAR/JAR* file. For Java projects this will most likely be done with Maven, Gradle, or Ant.

**Example:**

Below is an example using a sample application found on Github.

1. Clone this repo: `https://github.com/WASdev/sample.servlet.jdbc`

1. Build the project locally with *mvn clean package*

1. This will build and place the artifacts in the *./target* directory

1. Since this project uses the Liberty *webProfile7* we'll go ahead and use that as the base image.

Below is an example Dockerfile that will containerize the application. The Dockerfile should be placed in the root of the application directory.

```Dockerfile
FROM websphere-liberty:webProfile7

ENV LICENSE accept
ENV DERBY_MD5 aade6f4eaa2504fc04dc561fc3e7c374
ENV DERBY_VERSION 10.13.1.1

RUN wget -q http://mirror.olnevhost.net/pub/apache//db/derby/db-derby-$DERBY_VERSION/db-derby-$DERBY_VERSION-bin.tar.gz -O /tmp/db-derby-$DERBY_VERSION-bin.tar.gz && \
    cd /tmp && \
    echo $DERBY_MD5 db-derby-$DERBY_VERSION-bin.tar.gz | md5sum -c && \
    tar zxf db-derby-$DERBY_VERSION-bin.tar.gz && \
    mv db-derby-$DERBY_VERSION-bin/lib/derby.jar /opt/ibm/wlp/usr/shared/resources/derby-$DERBY_VERSION.jar && \
    rm -rf /tmp/*
COPY target/liberty/wlp/usr/servers/defaultServer/server.xml /config/server.xml
COPY target/liberty/wlp/usr/servers/defaultServer/bootstrap.properties /config/bootstrap.properties
COPY target/*.war /config/apps/JDBCApp.war
```

There are some things to note in the above Dockerfile.

1. The *FROM* line needs to match your applications profile, in this case it's *webProfile7* as noted in the *pom.xml* file.

1. This application uses the Derby embedded database, so the *RUN* line grabs the library for that and checks the *md5* hash as it downloads. It then cleans up the temporary files to save space on the corresponding image layer.

1. The appropiate config files are added to the image. Notably the *server.xml* and the *bootstrap.properties* files. **Note:** The *server.xml* config file needs `host="*"` for this application to work properly in a containerized environment. The sample repo cloned as-is does not have this in the *server.xml* file.

1. The final line adds the WAR file to the image. Typically the application code should reside in the final layer since this is what would change the most often. This will allow for image caching to work properly. More details can be found [here](https://docs.docker.com/develop/develop-images/dockerfile_best-practices/#leverage-build-cache).

To build the application we use the *docker build* command.

1. This will build the image and tag it as a *0.1* release. *docker build -t dtr.nwie.net/example/liberty-test:0.1*
1. After the image is build, run the image with this command: *docker --rm -p 80:9080 dtr.nwie.net/example/liberty-test:0.1*
1. If you're running Docker for Desktop, the application can be viewed from `http://localhost/JDBCApp`
1. Ctrl-c to stop the running container

#### Multi-stage build

Expanding on the previous example, it's possible to build the application and then package the deployment artifact in a single step.

```Dockerfile
FROM maven:3.5-jdk-8-alpine AS build
COPY src /usr/src/app/src
COPY pom.xml /usr/src/app
RUN mvn -f /usr/src/app/pom.xml clean package


FROM websphere-liberty:webProfile7

ENV LICENSE accept
ENV DERBY_MD5 aade6f4eaa2504fc04dc561fc3e7c374
ENV DERBY_VERSION 10.13.1.1

RUN wget -q http://mirror.olnevhost.net/pub/apache//db/derby/db-derby-$DERBY_VERSION/db-derby-$DERBY_VERSION-bin.tar.gz -O /tmp/db-derby-$DERBY_VERSION-bin.tar.gz && \
    cd /tmp && \
    echo $DERBY_MD5 db-derby-$DERBY_VERSION-bin.tar.gz | md5sum -c && \
    tar zxf db-derby-$DERBY_VERSION-bin.tar.gz && \
    mv db-derby-$DERBY_VERSION-bin/lib/derby.jar /opt/ibm/wlp/usr/shared/resources/derby-$DERBY_VERSION.jar && \
    rm -rf /tmp/*
COPY --from=build /usr/src/app/target/liberty/wlp/usr/servers/defaultServer/server.xml /config/server.xml
COPY --from=build /usr/src/app/target/liberty/wlp/usr/servers/defaultServer/bootstrap.properties /config/bootstrap.properties
COPY --from=build /usr/src/app/target/*.war /config/apps/JDBCApp.war
```

The above example is similar to the previous one but building the application artifact is entirely handled by the Docker image build process.

1. The *FROM* line needs the appropriate maven version (both maven and the JDK) as well as the *AS build* for a multi-stage build.
1. Copy the source code and the *pom.xml* into the maven container.
1. Build the project using maven inside of the container
1. The final image then grabs the necessary files out of the first build step and then places them into the final image.

This image can be build the same way as the previous example, with a *docker build* command such as: *docker build -t dtr.nwie.net/example/liberty-test:0.1*

Multi-stage builds simplify the workflow and it allows for the CI system to build using a standard image. This allows for image building to be built using a consistent environment from dev to CI.

### IDE integration

TODO

## Integrating the application with concourse CI

Concourse steps specific to Nationwide

## Deploying the application

Sample helm chart
Explanation of resource constraints

## Monitoring the application

TODO: Steps for dynamically monitoring the application
