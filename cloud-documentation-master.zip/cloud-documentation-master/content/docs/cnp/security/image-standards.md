---
title: Image Standards
menu: docs
category: cnp
---

## Base images

### Nationwide base images

These are base images that Nationwide maintains. A list of all images can be
found in [DTR](https://dtr.aws.e1.nwie.net/orgs/library/repos).  Details
can also be seen in the [docker-library](https://github.nwie.net/Nationwide/docker-library)
repo in github.

All of these images are based on upstream images and have been customized to make
working within Nationwide easier. Below is a list of some of the base images to use.
Browse the docker-library in github and DTR for a complete list.

| Image                                   | Description  |
| --------------------------------------- | --------------------------- |
| dtr.aws.e1.nwie.net/library/centos      | Community-driven, RedHat-based operating system |
| dtr.aws.e1.nwie.net/library/httpd       | The Apache HTTP Server Project |
| dtr.aws.e1.nwie.net/library/ping        | Ping-Enabled Apache HTTP Server |
| dtr.aws.e1.nwie.net/library/tomcat      | Open source implementation of the Java Servlet and JavaServer Pages technologies |
| dtr.aws.e1.nwie.net/library/openjdk     | Open-source implementation of the Java Platform, Standard Edition |

### Upstream base images

These are base images that have been approved for use at Nationwide.  These images can
be found in the TSB by searching for products by the "Docker Inc" Vendor. All of these images
are also [Docker Official Images](https://docs.docker.com/docker-hub/official_images/).

| Image       | Description  |
| ----------- | --------------------------- |
| alpine      | A tiny Linux distribution built around musl libc and BusyBox |
| centos      | An open source Redhat Linux clone |
| debian      | Linux distribution that's composed entirely of free and open-source software |
| ubuntu      | Ubuntu is a Debian-based Linux operating system based on free software |
| httpd       | The Apache HTTP Server Project |
| nginx       | Modern web server and reverse proxy |
| redis       | An open source key-value store that functions as a data structure server |
| sonarqube   | An open source platform for continuous inspection of code quality |
| node        | JavaScript-based platform for server-side and networking applications |
| ruby        | Dynamic, reflective, object-oriented, general-purpose, open-source programming language |
| python      | An interpreted, interactive, object-oriented, open-source programming language |
| openjdk     | An open-source implementation of the Java Platform, Standard Edition |
| golang      | A general purpose, higher-level, imperative programming language |
| gradle      | A build tool with a focus on build automation and support for multi-language development |
| maven       | Apache Maven is a software project management and comprehension tool |

### Installing software

When installing software via a package manager, be sure to clean up the
cache on the same *RUN* line to reduce image size. Every distribution
will handle this slightly differently.  Examples for the three common
use cases are below.

#### Installing software via yum (Redhat/CentOS)

```Dockerfile
FROM dtr.aws.e1.nwie.net/library/centos

# install curl
RUN yum install -y curl; yum clean all; rm -rf /var/cache/yum
```

#### Installing software via apt (Debian/Ubuntu)

```Dockerfile
FROM ubuntu

# install curl
RUN apt-get update; apt-get install -y curl ; apt-get clean
```

#### Installing software via apk (Alpine)

```Dockerfile
FROM alpine

# install curl
RUN apk add curl
```

## Image labels

Many tools need some information about a container image, or about the consumer's use of that container image. Metadata built into container images can enable even more powerful container management tooling.

By agreeing on a conventional set of labels, everyone can use tools from different vendors without the need to add vendor-specific labels to all their images, especially where those labels carry the same information or serve the the same purpose. Duplication leads to the risk of error.

Examples of the kind of information commonly found in image labels today are:

* What source code a container was built from

* Version number

* Information on how to run the code within the container

* Where to find additional information about the container

* Who to contact if this container causes issues in production

* Test status of this container

In some cases the information is immutable for the container image, and can (and even should) be defined at build time - for example the version number and source code. Building this additional information into the container image acts like a ‘shipping manifest’ to describe the contents of the container image.

In other cases, it is only possible or desirable to define labels after the container is built - for example, labels indicating whether the container has been tested, or who the current support engineer for a deployed container is. We describe this as ‘run time’ information, though in some cases (like test status) it is useful even when a container is not currently running.

Many tools and orchestration systems already support the use of container labels or annotations. This convention defines the semantics of a set of basic labels so that ecosystem tools can have a shared understanding of them. The intention is for this convention to be fully compatible with existing container runtime specifications and implementations.

Here are a small number of examples illustrating cases where it’s useful for different tool vendors to support the same label semantics:

* A continuous integration tool automatically adds labels for source code and version number during the build process. An orchestration system’s UI could use the same labels to show which versions of code are running, and a logging tool could automatically add versioning information to its output. If the tools use the conventional label definition, the user doesn’t need to do anything to see information about the version of code that is running.

* Monitoring / alarm / container security tools can use conventional labels for identifying who to contact in the event of a critical error being generated from within a given container.

* Visualization and monitoring tools can use container metadata to display useful information in human-readable form, such as what code is running within a deployment, and how the containers are related. If different tools use a schema convention, users don’t need to add different labels whenever they want to experiment with a new tool, or if they want to use multiple tools in parallel.

### Rules

* Annotations MUST be a key-value map where both the key and value MUST be strings.
* While the value MUST be present, it MAY be an empty string.
* Keys MUST be unique within this map, and best practice is to namespace the keys.
* Keys SHOULD be named using a reverse domain notation - e.g. `com.example.myKey`.
* If there are no annotations, then this property MUST either be absent or be an empty map.
* Consumers MUST NOT generate an error if they encounter an unknown annotation key.

### Pre-defined image labels

The CNCF has pre-defined image labels defined on their [website](https://github.com/opencontainers/image-spec/blob/master/annotations.md).

### Nationwide required labels

* **com.nationwide.image.ContactGroup** The contact group for the image - xyzabc@nationwide.com
  * Character set of the value SHOULD conform to alphanum of [A-Za-z0-9]@nationwide.com
* **com.nationwide.image.ResourceOwner** The resource owner of the image - xyzabc
  * Character set of the value SHOULD conform to alphanum of a-z0-9
* **com.nationwide.image.TicketGroup** The contact groups ServiceNow queue - XYZABC-SOLUTIONS
  * Character set of the value SHOULD conform to alphanum of A-Za-z0-9 and separator set of `-`  

### Nationwide optional labels

* **com.nationwide.image.ARPMID** The APRM ID of your application. This would only be used on application images.
  * Character set of the value SHOULD conform to numeric of `0-9`
* **com.nationwide.image.DisbursementCode** The disbursement code of your application. This would only be used on application images.
  * Character set of the value SHOULD conform to numeric of `0-9`. This should be `9` digits long.

### Nationwide example

```text
LABEL maintainer="Nationwide CSE <xyzabc@nationwide.com>" \
    org.opencontainers.image.title="Awesome CSE Application" \
    org.opencontainers.image.description="CSE Application to monitor Security Hub Data" \
    org.opencontainers.image.authors="Nationwide CSE <xyzabc@nationwide.com>" \
    org.opencontainers.image.vendor="Nationwide Security Project" \
    org.opencontainers.image.documentation="https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/" \
    org.opencontainers.image.version="1.1.1" \
    org.opencontainers.image.url="https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/" \
    org.opencontainers.image.source="https://github.nwie.net/Nationwide/NW-Cloud-Docs.git" \
    org.opencontainers.image.revision=$VCS_REF \
    org.opencontainers.image.created=$BUILD_DATE

    # Nationwide Optional Labels
    com.nationwide.image.APRMID="1234"
    com.nationwide.image.DisbursementCode="123456001"

    # Nationwide Required Labels
    com.nationwide.image.ContactGroup="someone@nationwide.com"
    com.nationwide.image.ResourceOwner="xyzabc"
    com.nationwide.image.TicketGroup="XYZABC-SOLUTIONS"

```
