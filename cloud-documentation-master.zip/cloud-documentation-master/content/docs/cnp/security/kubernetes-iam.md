---
title: Kubernetes IAM
menu: docs
category: cnp
---

## Kube2IAM setup and usage

Permits IAM role usage to a kubernetes pod.
[Kubernetes Annotation Doc](https://github.com/jtblin/kube2iam#kubernetes-annotation)
[Kube2Iam Manual](https://gist.github.com/snoby/77a49b6b79d0dd2ad9afbbf533588f54)

- **Dev Role Trust ARN: arn:aws:iam::010896039642:role/kubernetes-worker**
- **Test Role Trust ARN: arn:aws:iam::405507766639:role/kubernetes-worker**
- **Prod Role Trust ARN: arn:aws:iam::271942324821:role/kubernetes-worker**

## Use case - S3 bucket access from a pod

Kube2IAM allows a pod to assume an IAM role to grant secure access to native AWS resources. Let's say you wrote an application and wanted to use the AWS SDK to write to a bucket. Since you are not allowed to create access keys and secrets for granting access, we need to use IAM roles. The following steps are required to grant access to pods via IAM roles.

- Create the encryption keys, bucket and roles
- Grant a trust relationship on the role (Allow the K8 cluster to assume the role)
- Annotate the pods with the ARN of the to be assumed.

## Make AWS resources

Create an S3 bucket in an account and create a policy and role that can read it.

```json
    { // dop-kube2iam-s3
    "Version": "2012-10-17",
    "Statement": [
        {
        "Sid": "AllowListObjects",
        "Effect": "Allow",
        "Action": [
            "s3:ListBucket"
        ],
        "Resource": "arn:aws:s3:::dop-bucket-perms-test"
        },
        {
        "Sid": "AllowObjectsCRUD",
        "Effect": "Allow",
        "Action": [
            "s3:DeleteObject",
            "s3:GetObject",
            "s3:PutObject"
        ],
        "Resource": "arn:aws:s3:::dop-bucket-perms-test/*"
        }
    ]
    }
```

Add a trust on the IAM role so the kube workers can assume this permission

```json
 {
    "Version": "2012-10-17",
    "Statement": [
     {
      "Effect": "Allow",
      "Principal": {
        "AWS": "arn:aws:iam::405507766639:role/kubernetes-worker"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
```

Add the role to the pod with an annotation

```yaml
    apiVersion: v1
    kind: Pod
    metadata:
    name: awscli
    labels:
        name: awscli
    annotations:
        iam.amazonaws.com/role: arn:aws:iam::010896039642:role/dop-kube2iam-role
    spec:
    containers:
    - image: dtr-test.nwie.net/linuxengineering/centos
        command:
        - "AWS_DEFAULT_REGION=us-east-1"
        - "/home/aws/aws/env/bin/aws"
        - "s3"
        - "ls"
        - "dop-bucket-perms-test"
        name: awscli
```

## Great success
