---
title: Certificates
menu: docs
category: cnp
---

Certificates are managed by [cert-manager](https://github.com/jetstack/cert-manager)
inside the Kubernetes cluster. Cert-manager will take care of creating and renewing
SSL certs.

For details on upgrading from older versions of the cert-manager CRD
please read the Migration section at the bottom of the page.

## Note

We are currently in the process of migrating to a newer version of cert-manager.
This document has been updated for the newest version of cert-manager in use.
Please refer to the migration section at the bottom of the page for what
changes are required.

| Cluster | Status              |
|---------| --------------------|
| dev     | Migrated 5-14-2020  |
| test    | Migration Date: 6-17-2020 |
| test02  | Migration Date: 6-17-2020 |
| prod    | Migration Date: 7-1-2020 |
| prod02  | Migration Date: 7-1-2020 |
| tools   | Migration Date: 7-1-2020 |

`kubectl get certificates` will also only return the legacy certs. Use the
full api name to see newer certs.

* `kubectl get certificates.certmanager.k8s.io` - legency
* `kubectl get certificates.cert-manager.io` - new

## Issuers

Two issuers have been setup for every one to use.
The *nwie* issuer can be used to sign SSL certs with a Nationwide CA.
The *self-signed* issuer will give you a self signed cert. These should
not be used unless the application only talks to itself.

```shell
kubectl get commandissuer
NAME   AGE
nwie   15d

```

```shell
kubectl get clusterissuers.cert-manager.io
NAME          READY   AGE
self-signed   True    68m
```

## Ingress certs

If you are using the *default* ingress provided by the cloud-platform, you can
order a NWIE signed cert by adding the **kubernetes.io/tls-acme: "true"** annotation and a **secretName** to have a SSL cert generated and renewed as needed.
More details on this can be found on the [ingress](/docs/cnp/ingress/ingress-default/) page.

## Certificates

The certificate API can be used to create and view certs just like any other
kubernetes resource.

```shell
kubectl get certificates.cert-manager.io
NAME         READY     SECRET       AGE
my-app-tls   True      my-app-tls   25m
```

### NWIE signed cert

Example cert that will be valid for my-app.nwie.net and my-alias.nwie.net domains.
This will use the CommandIssuer to get a NWIE signed cert.

```yaml
apiVersion: cert-manager.io/v1alpha2
kind: Certificate
metadata:
  name: my-app-tls
spec:
  secretName: my-app-tls
  issuerRef:
    name: nwie
    kind: CommandIssuer
    group: keyfactor.com
  commonName: my-app.nwie.net
  dnsNames:
  - my-alias.nwie.net
```

The nwie CommandIssuer will currently only sign certs for the following domains.

* nwie.net

#### Certificate metadata

The Nationwide CA requires that certain metadata be added to all
certificates it signs. In order to pass this data on to the
certificate signer the metadata needs to be added as an annotation
on the Certificate. The `keyfactor.com/metadata` annotation contains
a comma separated list of key=value pairs that will be passed to
the signer.

The current list of values that should be provided are blow. These options will be looked up from the Namespace if not provided.

```yaml
APRMID: Application ID
Application_Owner_Group_email: email group
Application_Name: Application Name
```

The signer requires these options, and are injected by a kubernetes mutating webhook.

```yaml
Application_Location: Kubernetes
Nationwide_Environment: Prod or Non-Prod
Kube_Namespace: Namespace the cert exists in
```

Application_Location should always be Kubernetes and Nationwide_Environment should be either Prod or Non-Prod.
Adding in extra options outside of what is listed will currently cause the signer
to reject the request.

Example Annotation

```yaml
  metadata:
    annotations:
      keyfactor.com/metadata: Application_Owner_Group_email=cloudplatform@nationwide.com,APRMID=1245,Nationwide_Environment=Non-Prod,Application_Name=Docker-EE,Application_Location=Kubernetes,Kube_Namespace=my-namespace
```

If this Annotation does not exist a default one will be applied by a mutating webhook.

### Self-signed cert

Example cert for that will be valid for internal-service.srv and internal-service domains.
This will use the ClusterIssuer to get a self signed cert.

```yaml
apiVersion: cert-manager.io/v1alpha2
kind: Certificate
metadata:
  name: my-app-tls
spec:
  secretName: my-app-tls
  issuerRef:
    name: self-signed
    kind: ClusterIssuer
  commonName: internal-service.srv
  dnsNames:
  - internal-service
```

### Certificate data

Certs are stored in a secret once created.

```shell
kubectl get secrets
NAME                  TYPE                                  DATA      AGE
my-app-tls            kubernetes.io/tls                     3         36s
```

These secrets can be mounted inside a container and used by processes
such as apache, nginx, and tomcat.

## Securing container traffic with HTTPS

PODs should use TLS for all incoming traffic.  Kubernetes is able to order certificates however
you still need to wire your web/application server to use them. Below are examples
on how to enable TLS for a couple of different setups.

### Create certificate

```yaml
apiVersion: cert-manager.io/v1alpha2
kind: Certificate
metadata:
  name: my-app-tls
spec:
  secretName: my-app-tls
  issuerRef:
    name: nwie
    kind: CommandIssuer
    group: keyfactor.com
  commonName: my-app.nwie.net
  dnsNames:
  - my-alias.nwie.net
```

### Add certificate to container

The certificate is stored in a kubernetes secret which can be mounted inside
the container as a volume.  This will involve defining a volume called certs
from the certificate secret and then mounting that volume inside the container.

This deployment example will have these three files mounted inside the container for
use in the later steps.

* /certs/ca.crt - Certificate Authority CA Chain in PEM format
* /certs/tls.crt - Cert in PEM format
* /certs/tls.key - Private Key in PEM format

```yaml
...
        # mount the certs volume under /certs
        volumeMounts:
        - mountPath: /certs
          name: certs
          readOnly: true
...
      # Map the my-app-tls secret to a volume called certs
      volumes:
      - name: certs
        secret:
          defaultMode: 420
          secretName: my-app-tls
...
```

### Configure web/application server

Below are examples on how to configure different setups to use
the certificates mounted under /certs to enable HTTPS listeners.
These are examples so your setup may be different depending on the images
you are using and the current secure configuration standards.

#### Apache HTTPD

This example is known to work with the dtr.aws.e1.nwie.net/library/httpd:debian-ff image.
The config snipit below can be placed in the /usr/local/apache2/conf.d/ directory or loaded
into the main httpd.conf file.

```apache
# Enable mod_ssl
LoadModule ssl_module modules/mod_ssl.so

# Listen on 443 (standard https port)
Listen 443

# Configure TLS
SSLCipherSuite HIGH:MEDIUM:!MD5:!RC4:!3DES
SSLProtocol all -SSLv3 -TLSv1 -TLSv1.1
SSLProxyProtocol all -SSLv3

# Configure a TLS virtual host
<VirtualHost _default_:443>
  SSLEngine on
  SSLCertificateFile "/certs/tls.crt"
  SSLCertificateKeyFile "/certs/tls.key"
  SSLCertificateChainFile "/certs/ca.crt"
</VirtualHost>
```

#### NGINX

This example has been tested on the official nginx image hosted in docker hub.
The config snipit below can be placed in the /usr/nginx/conf.d directory or loaded
into the main nginx.conf file.

```nginx
server {
  # Listen on 443 (standard https port)
  # http2 and ssl option turn on TLS for this port
  listen         443 ssl http2 default_server;

  # Load Cert files
  ssl_certificate      /certs/tls.crt;
  ssl_certificate_key  /certs/tls.key;

  # Configure TLS
  ssl_session_cache    shared:SSL:1m;
  ssl_session_timeout  5m;
  ssl-ciphers ALL:!aNULL:!EXPORT56:RC4+RSA:+HIGH:+MEDIUM:+LOW:+SSLv2:+EXP
  ssl_prefer_server_ciphers   on;
  ssl_protocols       TLSv1.2 TLSv1.3;
}
```

#### Tomcat

This example is known to work with the dtr.aws.e1.nwie.net/library/tomcat image.
The config snipit below can be added to the /usr/local/tomcat/conf/server.xml.

```xml
    <Connector
        port="8443"
        connectionTimeout="20000"
        maxHttpHeaderSize="100"
        minSpareThreads="10"
        enableLookups="false"
        disableUploadTimeout="true"
        acceptCount="100"
        scheme="https"
        secure="true"
        URIEncoding="UTF-8"
        protocol="org.apache.coyote.http11.Http11Nio2Protocol"
        maxThreads="150"
        SSLEnabled="true" >
        <SSLHostConfig
            certificateVerification="false"
            protocols="TLSv1.2" >
            <Certificate
                certificateKeyFile="/certs/tls.key"
                certificateFile="/certs/tls.crt"
                type="RSA" />
        </SSLHostConfig>
    </Connector>

```

## Migration

The Cloud Native Platform is in the progress of upgrading to a newer version
of cert-manager which has changed it's API endpoint and will require
changes for users who interact directly with Certificate objects. If
you only interact with cert-manager by adding the **kubernetes.io/tls-acme: "true"**
annotation to Ingress objects no action is needed to continue to
get new certificates and have existing ones automatically renew.
All existing Ingress certificates will be migrated for you.

Both the legacy and the new cert-manager will be enabled in the clusters
to allow users to migrate.  If a namespace contains any certs that
need migrated the namespace owners will be contacted once
cert-manager has been updated in that cluster.  After
all users have migrated off the legacy certificates they
will be disabled.

### API group and version change

For all Certificate objects you will need to replace
certmanager.k8s.io/v1alpha1 with cert-manager.io/v1alpha2.

The nwie signer also requires a change.  Cert-manager 0.11 introduced
the concept of external issues which we are utilizing now. Because of
this change the issuerRef needs to be updated.  The *kind* needs to be
changed to *CommandIssuer* and the *group* of *keyfactor.com* needs added.

```yaml
  # Needs to be updated from
  issuerRef:
    name: nwie
    kind: ClusterIssuer

  # To
  issuerRef:
    name: nwie
    kind: CommandIssuer
    group: keyfactor.com
```

### Helm

If you have a helm chart that creates certificates you can
use the `.Capabilities.APIVersions.Has` feature to detect
what version of the API is installed in a cluster.
This way the same chart will continue to work in clusters with
the old and new versions of cert-manager.

Here is an example way to detect the api version.

The mychart.certManagerApiVersion or the _helper.tlp,
or another tlp file.

```go-text-template
{{/*
Detect the version of cert manager crd that is installed
Fall back to the latest version
*/}}
{{- define "mychart.certManagerApiVersion" -}}
{{- if (.Capabilities.APIVersions.Has "cert-manager.io/v1alpha3") -}}
cert-manager.io/v1alpha3
{{- else if (.Capabilities.APIVersions.Has "cert-manager.io/v1alpha2") -}}
cert-manager.io/v1alpha2
{{- else if (.Capabilities.APIVersions.Has "certmanager.k8s.io/v1alpha1") -}}
certmanager.k8s.io/v1alpha1
{{- else  -}}
{{- fail "cert-manager CRD does not appear to be installed" }}
{{- end -}}
{{- end -}}
```

Update your apiVersion to use the returned value from certManagerApiVersion.

```go-text-template
{{- if .Values.certificate.enabled }}
{{- $fullName := include "mychart.fullname" . -}}
apiVersion:  {{ include "mychart.certManagerApiVersion" . }}
kind: Certificate
metadata:
  name: {{ $fullName }}
  labels:
    app.kubernetes.io/name: {{ include "mychart.name" . }}
    helm.sh/chart: {{ include "mychart.chart" . }}
    app.kubernetes.io/instance: {{ .Release.Name }}
    app.kubernetes.io/managed-by: {{ .Release.Service }}
spec:
  secretName: {{ .Values.certificate.secretName | default (printf "%s-tls" ($fullName)) }}
  issuerRef:
    name: {{ .Values.certificate.issuer.name }}
    kind: {{ .Values.certificate.issuer.kind }}
  dnsNames:
{{- range .Values.ingress.hosts }}
  - {{ . | quote }}
{{- end }}
{{- end }}
```

**NOTE:** This example does not take into account the changing kind and
requirement for a group to be added under the issuerRef.
