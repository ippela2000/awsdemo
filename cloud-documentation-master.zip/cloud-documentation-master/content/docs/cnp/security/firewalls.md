---
title: Firewalls
menu: docs
category: cnp
---

## Firewall requests

Firewall requests for the Kubernetes clusters need to be made on [https://firewall.nwie.net](https://firewall.nwie.net). The request type is a "Run Resource" request. Fill out the five fields at the top of the form. Use the example templates below as the description for the request. Fill in the bolded parameters with the cluster name, outside URL and ports.

## Example firewall request for AWS clusters

Please update the Palo Alto group "docker_domains" to allow **Kubernetes Cluster Name** access to **Outside URL** on port **some port(s)**.

## Example firewall request for on-prem clusters

Please update the Palo Alto group "custom_docker_domains" to allow **Kubernetes Cluster Name** access to **Outside URL** on port **some port(s)**.

## Cluster IP ranges

Found below are the destination subnets for any FW requests that may be needed. Make sure you request subnet-based rules since your application can, and will, move between hosts in any given environment.

## AWS clusters

| Environment | Region | Zone A | Zone B | Zone C |
|---|---|---|---|---|
| Development | us-east-1 | 10.166.52.0/22 | 10.166.56.0/22 | 10.166.60.0/22 |
| Development | us-east-2 | 10.242.52.0/22 | 10.242.56.0/22 | 10.242.60.0/22 |
|     Test    | us-east-1 | 10.165.52.0/22 | 10.165.56.0/22 | 10.165.60.0/22 |
|     Test    | us-east-2 | 10.241.52.0/22 | 10.241.56.0/22 | 10.241.60.0/22 |
|     Prod    | us-east-1 | 10.164.52.0/22 | 10.164.56.0/22 | 10.164.60.0/22 |
|     Prod    | us-east-2 | 10.240.52.0/22 | 10.240.56.0/22 | 10.240.60.0/22 |
|     Tools   | us-east-1 | 10.164.4.0/22  | 10.164.8.0/22  | 10.164.12.0/22 |

## On-prem Kubernetes clusters

- **Test-02** 10.22.37.0/24
- **Prod-02** 10.93.170.0/24

### Firewall ingress diagram

The following diagram depicts ingress routing from the Internet. The CDT (Cloud Delivery Team) is responsible for the processes related to ingress to the Platform from the Internet.

![ARCI](/docs/cnp/images/CNP-ArchitectureDiagrams-InternetFirewalls.png)

Known restrictions:

1. WAF (Web Application Firewall) policies are automatically applied to Internet-facing ALBs (Application Load Balancers) by event responders maintained by the CDT.
2. All inbound Internet traffic must be HTTP/HTTPS, meaning ports 80 and 443.
