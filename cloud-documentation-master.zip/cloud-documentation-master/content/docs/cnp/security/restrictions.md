---
title: Restrictions in Kubernetes
menu: docs
category: cnp
---

### Resource restrictions

The Cloud Platform team enforces certain restrictions on resources requested in our on-premises Kubernetes environments, in order to ensure that the resources are within our limitations and follow required guidelines.

These restrictions are as follows:

* Pods may not set their CPU request to **more than 7 cores**.
* Pods may not set their memory request to **more than 60GB**.

These numbers (7 cores, 60GB) were determined by the team to be the highest amount of resources a pod could request without interfering with the worker nodes that pods run on. Without these restrictions, pods requesting more than this many resources would either never schedule or potentially cause a node to crash.

### Ingress restrictions

Additionally, ingress objects **may not share a host with another ingress** in a different namespace. However, sharing of host in the same namespace is allowed as long as the paths are different. In order to prevent collision, below are the list of scenarios that will be rejected.

**Scenario 1:**
Ingress objects in the same namespace cannot share same path but can share same host

|namespace|ingress|host           |path    |
|---------|-------|---------------|--------|
|  foo    | foo   | foo.nwie.net  | /baz   |
|  foo    | bar   | foo.nwie.net  | /baz   |

**Scenario 2:**
Ingress objects in different namespaces cannot share same host

|namespace|ingress|host           |
|---------|-------|---------------|
|  foo    | foo   | foo.nwie.net  |
|  bar    | bar   | foo.nwie.net  |

### PodDisruptionBudget restrictions

Deployments, Statefulsets and PodDisruptionBudget objects will be blocked from getting deployed if the replicas on either Deployments or Statefulset matches the minAvailable in the PodDisruptionBudget. Other scenarios are if minAvailable in PodDisruptionBudget is set to 100% or maxUnavailable is set to 0%. If you have a business case where this policy needs exemption please reach out to us at cloud-platform@nationwide.com or on rocketchat  channel #cloud-native-platform.

### Label restrictions

There are also labeling restrictions which require that **resources must have `DisbursementCode`, `ContactGroup`, and `ResourceOwner` tags**. These are necessary in order for us to know who to charge for the resource and who to contact about the resource if needed. If you create a resource without these labels, our Admission Controller will automatically copy the labels from your namespace to your resource.

The `APRMID` label is currently not enforced, but **it is required** in order to give the applications running in your namespace more visibility. It also allows Cloudability to gather data about your applications, so that you can view cost information on a per-app basis.

* If you are only running a single application in a namespace, you can apply the `APRMID` label to the namespace, and resources created within the namespace will automatically have the label copied to them.
* If you have applications which do not have their own APRMID, but are instead supporting another application, you can use the APRMID of the application they are supporting.

### emptyDir volume restrictions

There are restrictions on how much disk an emptyDir volume can request, volumes requesting more than 5Gi of space will be blocked from deployment, this is to ensure pods don't consume entire diskspace available on a kubernetes worker node. A 3Gi default sizeLimit is assigned to volumes that do not have a sizeLimit defined. Also note that when a volume consumes its allocated disk space kubernetes will evict that pod. Hence, evaluate persistant storage needs of your workload and acquire EBS or NFS volumes in cases where more than 5Gi of space is needed.

### Security restrictions

These restrictions are as follows:

* Images should **NOT** have passwords in them. If they do, they **could** be blocked by our container security tool.
* Images should **NOT** have **patchable critical vulnerabilities over 60 days old**. If they do, they **will** be blocked by our container security tool for deployment.

The Nationwide SLA for high, medium, and low vulnerabilities is 120 days for both OS, middleware, and application packages. After you build your images, you can [scan](/docs/cnp/security/image-vulnerability-scanning/) them with Twistlock to verify you no longer have any critical vulnerabilities. If you are unable to patch these vulnerabilities due to application restrictions you will need to open a Fulcrum exception with your IRM front office.
