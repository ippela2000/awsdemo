---
title: "About CNP"
menu: docs
category: cnp
weight: 2
---

### Overview

The Cloud Native Platform is an installation of the Kubernetes container orchestrator that empowers its users to deploy applications, create storage, configure load balancing, and much more.

### Main features

| Feature | Description | Details | External Doc |
| ------- | ----------- | ------- | ------------ |
| Namespaces | Namespaces divide cluster resources between multiple users. | | [Link](https://kubernetes.io/docs/concepts/overview/working-with-objects/namespaces/)|
| Pods | A pod is a group of one or more containers.| |[Link](https://kubernetes.io/docs/concepts/workloads/pods/pod/)|
| ReplicaSets | A ReplicationSet ensures that a specified number of pods are running at any one time.| |[Link](https://kubernetes.io/docs/concepts/workloads/controllers/replicaset/)|
| Deployments | Create and manage the updating of a ReplicaSet.| |[Link](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/) |
| Stateful Sets |Manages the deployment and scaling of a set of Pods , and provides guarantees about the ordering and uniqueness of these Pods.| |[Link](https://kubernetes.io/docs/concepts/workloads/controllers/statefulset/)|
| Logging | | [Link](/docs/cnp/logging-and-monitoring/cluster-logging)| |
| Storage | |[Link](/docs/cnp/storage/) | |
| Ingress | Configure external access to the services in a cluster, typically HTTP. A default ingress is created in every cluster. |[Link](/docs/cnp/ingress/ingress-alb/)|[Link](https://kubernetes.io/docs/concepts/services-networking/ingress/) |
| Services | A network load balancer available internally to the cluster, or also externally. | | [Link](https://kubernetes.io/docs/concepts/services-networking/service/) |
| Configmaps | ConfigMaps allow you to decouple configuration items from an image to keep applications portable. | | |
| Secrets | Secrets are intended to hold sensitive information, such as passwords, OAuth tokens, and ssh keys | |[Link](https://kubernetes.io/docs/concepts/configuration/secret/)|
| Network Policy | A network policy is a specification of how groups of pods are allowed to communicate with each other and other network endpoints. | |[Link](https://kubernetes.io/docs/concepts/services-networking/network-policies/) |
| Cronjobs | A Cron Job creates Jobs on a time-based schedule. | |[Link](https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/) |
| TTL | Limit the lifetime of resource objects that have finished execution. | |[Link](https://kubernetes.io/docs/concepts/workloads/controllers/ttlafterfinished/) |
| Quotas | A resource quota provides constraints that limit aggregate resource consumption per namespace. Useful in preventing unlimited spending. | |[Link](https://kubernetes.io/docs/concepts/policy/resource-quotas/)|

### Nationwide platform services

Components that are added onto  Kubernetes to make the platform more useable.

| Feature | Description | Docs |
| ------- | ----------- | ------------ |
| NW Roles | Standard Roles for Nationwide users to make sure they only have access to their namespaces | |
| Storage | Provide standard block and network storage | [Docs](https://github.nwie.net/Nationwide/k8s-admission-controllers) |
| Service Validation | Webhook that sets defaults for Service of type LoadBalancer |[Link](https://github.nwie.net/Nationwide/k8s-admission-controllers)|
| Ingress Validation | Webhook that sets defaults for Ingresses of type alb |[Link](https://github.nwie.net/Nationwide/k8s-admission-controllers)|
| Pod Validation | Webhook that copy labels from namespaces to pod |[Link](https://github.nwie.net/Nationwide/k8s-admission-controllers)|
| Open Policy Agent | Make sure Ingress objects do not use existing DNS names |[Link](https://www.openpolicyagent.org/)|
| Kube2IAM | Allow PODs to assume AWS IAM roles |[Docs](/docs/cnp/security/kubernetes-iam/)|
| Kube Watch | Send Kube events to splunk |[Link](https://github.com/bitnami-labs/kubewatch)|
| EFS provisioner | Provide EFS persistent volumes in AWS |[Docs](/docs/cnp/storage/), [Link](https://github.com/kubernetes-incubator/external-storage/tree/master/aws/efs)|
| NFS provisioner | Provide NFS persistent volumes on prem |[Docs](/docs/cnp/storage/) [Link](https://github.com/helm/charts/tree/master/stable/nfs-client-provisioner)|
| Kube state metrics | Generates metrics for kube objects |[Link](https://github.com/kubernetes/kube-state-metrics)|
| Metrics server | Cluster-wide aggregator of resource usage data |[Link](https://github.com/kubernetes-sigs/metrics-server)|
| New Relic | Send Kubernetes data to newrelic |[Link](https://infrastructure.newrelic.com/accounts/1092591/kubernetes)|
| Cluster Autoscaler | Dynamically add/remove nodes to the clusters in AWS based on demand |[Link](https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler)|
| Cert Manager | Sign Certificates using Nationwide's internal CA | [Code](https://github.nwie.net/Nationwide/cert-manager), [Link](https://github.com/jetstack/cert-manager/)|
| Nginx Ingress | Send Kubernetes data to newrelic |[Docs](/docs/cnp/ingress/ingress-default/), [Link](https://kubernetes.github.io/ingress-nginx/)|
| ALB Ingress | Send Kubernetes data to newrelic |[Docs](/docs/cnp/ingress/ingress-alb/), [Link](https://kubernetes-sigs.github.io/aws-alb-ingress-controller/)|
| External DNS | Register DNS names in Route53 and Infoblox |[Link](https://github.com/kubernetes-sigs/external-dns)|
| Prometheus | Time series data of Kubernetes metics |[Link](https://prometheus.io/)|
| Grafana | Display Prometheus data |[Link](https://grafana.com/)|
| Node Labeler | Add AWS labels to nodes in Kubernetes |[Link](https://github.nwie.net/Nationwide/k8s-node-labeler)|
| Vertical Pod Autoscaler | Automatically set requests and limits |[Link](https://github.com/kubernetes/autoscaler/tree/master/vertical-pod-autoscaler)|
| Goldilocks | See Vertical Pod Autoscaler suggestions for |[Link](https://github.com/FairwindsOps/goldilocks)|
| Twistlock Defender  | Keep the container environment secure and safe | |
| Node Problem Detector | Detect node errors and report them back to kubernetes |[Link](https://github.com/kubernetes/node-problem-detector)|
| Kube Downscaler | Scale down deployments on a time schedule |[Docs](/docs/cnp/architecture/deployment-scaling/), [Link](https://github.com/hjacobs/kube-downscaler)|
| Pod Scaledown | Notify users of Pod issues and scaledown deployments that have been failing  |[Code](https://github.nwie.net/Nationwide/pod-scaledown)|
| Pure Storage | Access pure block storage on prem | |

### Important links

[Examples](https://github.nwie.net/Nationwide/cnp-examples)
