---
title: Docker Builds (In Cluster)
menu: docs
category: cnp
---

## About

Docker builds using Docker are not allowed in the clusters as it requires privileged container access, which is turned off for users.

### Concourse

> "Built on the simple mechanics of resources, tasks, and jobs, Concourse presents a general approach to automation that makes it great for CI/CD"

Concourse CI is the preferred tool for teams building and deploying their container workloads to the Cloud Native Platform. Concourse maintains a core design philosophy in which all tooling needed in your CI/CD pipeline is sourced in via containers. This alleviates many of the operational challenges of operating plugin based platforms like Jenkins which invariably became "pet" servers over time when infrastructure as code principles are not applied. When everything in your pipeline is an execution of a versioned container, the entire product pipeline becomes predictable and repeatable.

A single *preview* instance of Concourse is hosted for all of Nationwide and runs in a separate Tools Kubernetes cluster where privileged container mode is enabled. Privileged mode is what enables you to build Docker Images from other containers (or Concourse in this instance) in your code pipeline (using the [docker-image-resource](https://github.com/concourse/docker-image-resource) resource type). Allowing this "privileged mode" capability only in the Tools cluster is a security measure to protect the Application clusters from potential vulnerabilities.

### Concourse onboarding

When onboarding to the Cloud Native Platform, an additional Kubernetes namespace needs to be created to enable the use of secrets for credentials in pipelines. Ensure that when you onboarded to the platform you followed the convention to create a *concourse-{team}.yaml* file per the [cnp-caas-config README.md](https://github.nwie.net/Nationwide/cnp-caas-config/blob/master/README.md) in your pull request. For more information on this topic, see [Credentials in Pipelines](#Credentials-in-Pipelines).

#### Concourse UI

[The Concourse UI](https://concourse.nwie.net/) is where you can view the status and logs of your pipelines. You can also pause/unpause a pipeline or manually invoke them, but that is the extent of the input you have to your pipeline from the UI. All other changes to the pipeline are done in code, and applied via the fly command line tool.

Access in Concourse is given at a [Team](https://concourse-ci.org/auth.html) level. A Concourse Team is a conceptual bucket where you can add, modify, run and delete pipelines. There can be many Teams in a Concourse instance, and you can have access to multiple.

Authorization to a Concourse Team is determined through a one-to-one mapping to a GitHub Team. Under the covers it is using GitHub's OAuth capabilities, and the end result is that you can self-manage access to your Concourse Team by adding or removing individuals to a GitHub Team (a self-service capability in Nationwide).

Gaining access to a Concourse Team can then be done in one of the following ways:

1. **Accessing an existing Concourse Team**  
Ask the team that uses that Concourse Team to be added to the backing GitHub Team that controls authorization access to that Concourse Team
2. **Creating a new Concourse Team**  
If you do not yet have a GitHub Team that contains members who you would like access to your Concourse Team, create one first at [Nationwide Teams](https://github.nwie.net/orgs/Nationwide/teams).  
Once created, follow the directions on the [Concourse Team Config](https://github.nwie.net/Nationwide/concourse-team-config) repository to submit a request.

### Example pipelines

A sample Concourse Pipeline deploying a Spring Boot with a Blue/Green deploy step can be seen in [this repository](https://github.nwie.net/Nationwide/k8s-demo-contacts) under the *ci* directory:

### Credentials in pipelines

Credentials are sometimes needed for taking certain actions in pipelines. Kubernetes Secrets can be used to securely store the credentials and to make them available to pipelines.

Here's an example of a pipeline resource referencing secret sds-tech-consulting-generic-id-creds:  

```yaml
- name: release-candidate-docker-repository
  type: docker-image
  source:
    repository: dtr.aws.e1.nwie.net/sds/textbook-exchange
    tag: release-candidate
    insecure_registries:
    - "dtr.aws.e1.nwie.net"
    username: ((sds-tech-consulting-generic-id-creds.username))
    password: ((sds-tech-consulting-generic-id-creds.password))
```

In order for Concourse to be able to access secrets, they must be created in the namespace: concourse-(team namespace) on the tools cluster where Concourse runs.

See the [Kubernetes Documentation on Secrets](https://kubernetes.io/docs/concepts/configuration/secret/) for information about secrets.

### Concourse learning material

- [NW Concourse Tutorial](https://pages.github.nwie.net/Nationwide/concourse-tutorial/)
- [Concourse Website](https://concourse-ci.org/)
- [Concourse Tutorial](https://concoursetutorial.com/)

## Kaniko

Kaniko is a Google project that supports building images in Kubernetes without being a privileged container. It processes a Dockerfile just like the *docker build* command. It can be used from Jenkins with the kubernetes plugin.

### Jenkins examples

The Jenkins Kubernetes plugin has some examples on using kaniko [here](https://github.com/jenkinsci/kubernetes-plugin/tree/master/examples).

Here is is an example of a simple Jenkinsfile based on one of the above examples and pointed to DTR.

```groovy
/**
 * This pipeline will build and deploy a Docker image with Kaniko
 * https://github.com/GoogleContainerTools/kaniko
 * without needing a Docker host
 *
 * You need to create a jenkins-docker-cfg secret with your docker config
 * as described in
 * https://kubernetes.io/docs/tasks/configure-pod-container/pull-image-private-registry/#create-a-secret-in-the-cluster-that-holds-your-authorization-token
 *
 * ie.
 * kubectl create secret docker-registry dtr-creds --docker-server=https://dtr.aws.e1.nwie.net/v2/ --docker-username=sidelig --docker-password=fakePassword --docker-email=john@nationwide.com

 * Or use your existing config.json
 * kubectl create secret generic dtr-creds --from-file config.json

 */

pipeline {
  agent {
    kubernetes {
      //cloud 'kubernetes'
      label 'kaniko'
      yaml """
kind: Pod
metadata:
  name: kaniko
spec:
  containers:
  - name: kaniko
    image: gcr.io/kaniko-project/executor:debug-1ffae47fdd91d38006c1d28e14e66869742cbdba
    imagePullPolicy: Always
    command:
    - /busybox/cat
    tty: true
    volumeMounts:
      - name: jenkins-docker-cfg
        mountPath: /root

  volumes:
  - name: jenkins-docker-cfg
    projected:
      sources:
      - secret:
          name: dtr-creds
          items:
            # Use for docker-registry secret
            - key: .dockerconfigjson
              path: .docker/config.json
            # Use for generic file secret
            #- key: config.json
            #  path: .docker/config.json

"""
    }
  }
  stages {
    stage('Build with Kaniko') {
      environment {
        PATH = "/busybox:/kaniko:$PATH"
      }
      steps {
        container(name: 'kaniko', shell: '/busybox/sh') {
            sh '''#!/busybox/sh
            /kaniko/executor -f `pwd`/Dockerfile -c `pwd` --skip-tls-verify --skip-tls-verify-pull  --destination=dtr.aws.e1.nwie.net/sidelig/sample-flask:latest
            '''
        }
      }
    }
  }
}
```

If using *kubectl create secret docker-registry* to setup your DTR credentials, it stores your password in the secret and will need to be updated when passwords change. Use a generic ID for this, as anyone else with access to the namespace can retrieve the secret.

k8s command to create `docker-registry` as a secret in the namespace, which will be used by Kaniko

```shell
kubectl create secret docker-registry --dry-run=true regcred \
  --docker-server=dtr.aws.e1.nwie.net \
  --docker-username=cisbuild \
  --docker-password=Password1 \
  --docker-email=cisbuild@nationwide.com -o yaml | kubectl apply -f - -n cls-cis
```

If using *kubectl create secret generic dtr-creds* to upload an existing docker config.json, make sure it contains your identity like the one below. Docker on OSX by default will actually store this stuff in a vault, which is then consulted on the fly and not the file itself.

```json
{
    "auths": {
            "dtr.aws.e1.nwie.net": {
                    "auth": "***MASKED***,
                    "identitytoken": "***MASKED***"
            },
            "dtr.nwie.net": {
                    "auth": "***MASKED***",
                    "identitytoken": "***MASKED***"
            }
    },
    "HttpHeaders": {
            "User-Agent": "Docker-Client/18.03.1-ce (linux)"
    }
}
```

## JPIPE

Jpipe is an opinionated Jenkins pipeline utilities, stages, and pipelines created by a team. It has support for kaniko and more details can be found [here](https://github.nwie.net/Nationwide/jpipe/tree/k8s#kaniko).
