---
title: Tools
menu: docs
category: cnp
weight: 3
---

There are many tools that can be used to help make working with
kubernetes more enjoyable. This page will try to document some of the ones that
we have found useful.

## Manage context (Working with lots of clusters)

### Docker CE

Docker CE provides a drop down to change your contexts with a click of the button.

For OSX, place all of your UCP bundles in sub directories under ~/.docker. For example,
create ~/.docker/ucp.aws.e1.nwie.net and unzip your bundle into it.

Launch Docker from Applications. Once it is running you can click on Moby the Whale
and select your kube context from the Kubernetes Menu.

### Kubernetes tools

[kubernetes-tools](https://github.com/shawnxlw/kubernetes-tools) works for zsh and bash shells
to provide you with tools to quickly change contexts from a shell. It supports
bash completion, too.

kctx is the tool to list and change your context.

kns is the tool to list and change your namespace.

It also provides a handful of scripts for listing pods and other actions.

### Kube CTX

[kubectx](https://github.com/ahmetb/kubectx) works for zsh and bash shells
to provided you with a with tools to quickly change contexts from a shell. It supports
bash completion, too.

It can also provide you with menus to select from instead of having to type out names
or use tab completion. This is enabled by installing the fzf package, which is documented
on their site.

kubectx and kubernetes-tools are both tools that try to solve the same problem, so
use which ever one you like more.

## Shell integration

### Kube-PS1

[kube-ps1](https://github.com/jonmosco/kube-ps1) is a bash and zsh prompt
integration that shows your current Kube context and namespace.

## Software

Below are some software packages that are helpful.

### Helm

[helm](https://helm.sh/) is the package manager for Kubernetes that allows
you to put a template engine in front of kube yaml files.

### Helmsman

[helmsman](https://github.com/Praqma/helmsman/) is a desired state tool for managing helm deployments into a cluster. It can take care of installing Tiller and managing charts. If you have many helm charts that need to be installed into the cluster and managed, this tool can do it all with a single command.

**[Next - FAQ](/docs/cnp/getting-started-with-cnp/faq)**
