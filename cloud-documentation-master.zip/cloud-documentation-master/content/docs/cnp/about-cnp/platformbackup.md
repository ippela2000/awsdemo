---
title: Cloud Platform Backup
menu: docs
category: cnp
---


## Overview

This document describes how the platform is backed up and more importantly what the current limitations are.

![Backup](/docs/cnp/images/cnp-backup.png)

## Backup

The parts of the platform that are being backed up are the image registry, UCP configuration, and the state of Docker Swarm.

The backup the image registry, DTR, will allow us to restore its configuration and the metadata of images it contains.
This configuration includes organization, team and user accounts, access permissions, image names and tags, and the repository structure.
The images themselves are not backed up, but are kept on redundant storage. This means a restore of DTR will lose any data about images between the time of the backup and the time of the restoration.

The backup of UCP will capture the user accounts and permissions, the configuration of the system, and Kubernetes objects. This does not capture any filesystem data that is on a host or a PVC. Performing a retore of UCP will return the entire system to its previous state, so doing this would only be done in an extreme emergency. It is assumed that applications can be recreated and deployed by the development teams.

Backing up the Docker Swarm data is necessary for the restoration of the system. There are not any user items using Swarm.

## Future

- Improve data backup and give control of creating and restoring snapshots to users.
- Replicate image registry to every datacenter, transparently.
- Allow restore of single application or components.

## Further reading

- [UCP Backup](https://docs.docker.com/ee/admin/backup/back-up-ucp/)
- [DTR Backup](https://docs.docker.com/ee/admin/backup/back-up-dtr/)
