---
title: Installed Tools
menu: docs
category: cnp
---

## Software added to all CNP clusters

Here is a list of software that is added to each Kubernetes cluster and managed as a service by the Cloud Platform Team.

* Cluster Default Ingress Controller: This is the default ingress controller that can be used by teams running applications in the Kubernetes clusters. The software is managed by the Kubernetes project. Additional information can be found at [https://kubernetes.github.io/ingress-nginx/](https://kubernetes.github.io/ingress-nginx/)
* Tiller: Tiller is the server side of Helm, the package manager for Kubernetes. Tiller is installed both cluster-wide for operator use and can be installed in in team namespaces for development team use. With Helm 3, Tiller is no longer necessary, so application teams may find success in utilizing Helm for deployments without the addition of Tiller. More information about Helm and Tiller can be found at [https://helm.sh/](https://helm.sh/).
* Kubewatch: Kubewatch is a Kubernetes event stream watcher. It watches configured events and publishes those events to a webhook or a chat service. For more information go to [https://github.com/bitnami-labs/kubewatch](https://github.com/bitnami-labs/kubewatch).
* New Relic agent: The New Relic monitoring agent for Kubernetes. Additional information can be found here [https://docs.newrelic.com/docs/integrations/host-integrations/host-integrations-list/kubernetes-monitoring-integration](https://docs.newrelic.com/docs/integrations/host-integrations/host-integrations-list/kubernetes-monitoring-integration).
* Cluster Autoscaler: Cluster Autoscaler adds or removes worker nodes in a cluster depending on resource consumption. Additional information is available at [https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler](https://github.com/kubernetes/autoscaler/tree/master/cluster-autoscaler)
* Cloudability agent: The Cloudability monitoring agent for Kubernetes. Cloudability monitors and reports on cloud expense metrics. More information on Kubernetes integration can be found here [https://support.cloudability.com/hc/en-us/sections/360000720694-Containers](https://support.cloudability.com/hc/en-us/sections/360000720694-Containers)
* Metrics Server: [https://github.com/kubernetes-sigs/metrics-server](https://github.com/kubernetes-sigs/metrics-server)
* Kube-State-Metrics: [https://github.com/kubernetes/kube-state-metrics](https://github.com/kubernetes/kube-state-metrics)
* EFS Provisioner: [https://github.com/kubernetes-incubator/external-storage/tree/master/aws/efs](https://github.com/kubernetes-incubator/external-storage/tree/master/aws/efs)
* Backup: Control Plane and Registry backup. See [https://docs.docker.com/ee/admin/backup/](https://docs.docker.com/ee/admin/backup/) for details.
