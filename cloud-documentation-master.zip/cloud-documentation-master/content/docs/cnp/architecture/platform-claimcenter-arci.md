---
title: Cloud Platform / ClaimCenter ARCI
menu: docs
category: cnp
---

This document presents an ARCI matrix (Accountable, Responsible, Consulted, Informed) for IT components that make up the Cloud Native Platform supporting ClaimCenter. All activities listed below are specific to ClaimCenter use of the Docker Dedicated product. When we refer to a node specific activity, we are referring to a _"Docker Dedicated"_ node used by ClaimCenter. At a high level, the Cloud Platform Team is responsible for the platform and the Claims support teams are responsible for the application containers running on the platform.

The activities listed are expected to occur during normal "day-2-day" operation of ClaimCenter running on the Cloud Native Platform.

|           Activity                                       | CPT | CCInfra | CCRR     | CCRelease    | CCDev | ECC | LNXENG | CCArch |
|---------------------------------------------------------:|:---:|:-------:|:--------:|:------------:|:-----:|:---:|:------:|:------:|
| ClaimCenter Monitoring/Alerting Profile                  |     | A,R     | A,R      |              | C     |     |        |        |
| ClaimCenter Incident Response                            |     | I,C     | A,R      |              | I     | I,C |        |        |
| Docker Trusted Registry Incident Response                | A,R |         |          |              |       |     |        |        |
| ClaimCenter Docker Image Build                           |     | A,R     | I        | I,C          | I,C   |     |        | I,C    |
| ClaimCenter Docker Image Currency                        |     | A,R     | I        | I,C          | C     |     |        |        |
| Docker-Compose File Creation                             |     | A,R     | I        |              | I,C   |     |        | I,C    |
| Docker-Compose File Maintenance                          |     | A,R     | I        | I,C          | C     |     |        | C      |
| ClaimCenter Dockerfile Best Practice                     |     | I,C     | I,C      |              | A,R   |     |        | C      |
| ClaimCenter App Topology                                 |     | I       |          |              |       |     |        | A,R    |
| ClaimCenter App Deploy/Rollback/Redeploy                 |     | I,C     | I,C      | A,R          | I     |     |        |        |
| ClaimCenter DNS Name Registration                        |     | A,R     | I,C      |              | I,C   |     |        | I,C    |
| Traefik Start/Stop/Restart                               |     | A,R     | I,C      | I,C          |       |     |        |        |
| Traefik Deployment                                       | I,C | A,R     | I        |              |       |     |        |        |
| Traefik Image Currency                                   | A,R | I,C     | I,C      | I,C          |       |     |        |        |
| ClaimCenter Dedicated Docker Engine Capacity Planning    | A,R | I,C     |          |              |       |     | I,C    | I,C    |
| Add/Remove ClaimCenter Dedicated Docker Node to Cluster  | A,R | I,C     | I        |              |       |     |        | I      |
| Restart ClaimCenter Dedicated Docker Engine              | A,R | I,C     |          |              |       |     |        |        |
| Docker Swarm/Kubernetes Monitoring/Alerting Profile      | A,R | I       |          |              |       | I   |        |        |
| Docker Swarm/Kubernetes Incident Response                | A,R | I       |          |              |       | I,C |        |        |
| Docker Swarm/Kubernetes Maintenance                      | A,R | I,C     | I,C      |              |       |     |        |        |
| Docker Org/Team Create/Update/Delete                     | A,R | I       |          |              |       |     |        |        |
| Docker Collection Create/Update/Delete                   | A,R | I       |          |              |       |     |        |        |
| Docker Grant Create/Update/Delete                        | A,R | I       |          |              |       |     |        |        |
| Docker Swarm/Kubernetes Capacity Planning                | A,R | I       |          |              |       |     |        |        |
| Docker Trusted Registry Monitoring Profile               | A,R |         |          |              |       |     |        |        |
| Docker Trusted Registry Capacity Planning                | A,R |         |          |              |       |     |        |        |
| Linux Base-Image Build                                   |     |         |          |              |       |     | A,R    |        |
| Linux Base-Image Currency                                |     |         |          |              |       |     | A,R    |        |

## Legend

### Roles

* __CPT__ - Cloud Platform Team
* __CCInfra__ - ClaimCenter Infrastructure Team
* __CCRR__ - ClaimCenter Rapid Response Team
* __CCRelease__ - ClaimCenter Release Management Team
* __CCDev__ - ClaimCenter Application Development Tech Leads
* __ECC__ - Enterprise Command Center
* __LNXENG__ - Linux Engineering
* __CCArch__ - ClaimCenter Architecture

### Responsibility assignments

* __A__ - _Accountable_ - There can be only one accountable role in an ARCI matrix. The accountable team may delegate responsibility for completing the activity to another team. The accountable team ensures an activity occurs and ensures the quality is sufficient for the activity when the activity is delegated.
* __R__ - _Responsible_ - The team(s) that actually do the activity.
* __C__ - _Consulted_ - Teams are consulted for both process and technical reasons depending on the activity.
* __I__ - _Informed_ - Inform includes e-mail event notifications or automated "webhook" events.
