---
title: Deployment Scaling
menu: docs
category: cnp
---

## Horizontal Pod Autoscaler (HPA)

The Horizontal Pod Autoscaler automatically scales the number of pods
in a replication controller, deployment, replica set or stateful set
based on observed CPU utilization.

See the [Kubernetes docs](https://kubernetes.io/docs/tasks/run-application/horizontal-pod-autoscale/) for more details.

## Scale down controller

The kube-downscaler is designed to turn off your application when it is not needed.
This can be used to turn off your application at night and/or weekends to
reduce your charges. This controller and the HPA can conflict as they both
manage the replica count on a deployment. If the scaledown controller
sets the replicas to 0 at night, the HPA will ingore the deployment.
However, if scaledown controller sets the replicas to 1 pod at night, the HPA
will continue to manage the deployment.

The schedule is controlled by annotations on the deployment and stateful set.
`downscaler/downtime` and `downscaler/uptime` are the two primary configuration
annotations. Use `downscaler/uptime` to specify the days and times that the deployment
should be running. Use `downscaler/downtime` to specify the days/times the
deployment should not be running. If both annotations are on the deployment,
`downscaler/downtime` will be used.

`downscaler/downtime-replicas` can also be used to scale down to X replicas during
the downtime period. Use this if you want to scale down to, say, 1 pod at night, and
then scale back to 4 during the day. The HPA may be a better solution than
using this feature. Also, this setting cannot be used if an HPA is also
managing the deployment.

The downtime and uptime annotations can be a comma separated list, and should
follow this format: `<WEEKDAY-FROM>-<WEEKDAY-TO-INCLUSIVE> <HH>:<MM>-<HH>:<MM> <TIMEZONE>`.

The timezone value can be any [Olson timezone](https://en.wikipedia.org/wiki/Tz_database),
e.g. "US/Eastern", "PST" or "UTC". When specifying the time, do not use 00:00 to represent
midnight; use 24:00. A time range cannot span more than one day, so specify multiple
ranges if you need need to span more than one day.

Example that will run the deployment from 8am to 6pm during the week:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  annotations:
    downscaler/uptime: Mon-Fri 08:00-18:00 America/New_York
```

Example that will scale the deployment down to 1 pod at night and
on weekends. This uses the downtime annotation instead of the uptime:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  annotations:
    downscaler/downtime: Sat-Sun 00:00-24:00 America/New_York,Fri-Fri 17:00-24:00 America/New_York
    downscaler/downtime-replicas: "1"
```

### Namespace scale down

The scale down controller is able to scale down all deployments in a namespace.
However, there is currently no way for end users to add the downscaler
annotations to a namespace. If you are interested in having all deployments
in namespace scale down, please contact the
[cloud-platform](mailto:cloud-platform@nationwide.com) team with what schedule
you would like, and we can add the annotation to your namespace. You will need to
provide the cluster(s), namespace and schedule you want enabled. You can check
the annoations on the namespace by doing `kubectl describe namespace NAMESPACE`.

If using the namespace scaledown option, you can override the namespace settings
by adding one of the downscaler schedule annotations to the deployment or
`downscaler/exclude: "true"` to exclude the deployemnt.
