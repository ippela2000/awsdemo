---
title: "Architecture"
menu: docs
category: cnp
linkDisabled: true
---