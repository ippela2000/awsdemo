---
title: Application Resiliency
menu: docs
category: cnp
---
This document explains multiple tools and methods an application team can use to ensure that their app is highly available in the Cloud Native Platform.

## Setting requests and limits

[Kubernetes Doc - Managing Compute Resources for Containers](https://kubernetes.io/docs/concepts/configuration/manage-compute-resources-container/)

Properly setting resource requests and limits for CPU and Memory for your pods will allow Kubernetes to correctly schedule your pods on a node that has enough resources to service your pod. Setting a request lower than what you reasonably expect your pod to use may result in Kubernetes scheduling that pod on a node that doesn't have enough resources to serve you.

See the billing documentation for more information about [rightsizing your application](/docs/cnp/billing/#rightsizing-your-application)

## ReplicaSets and deployment objects

[Kubernetes Doc - ReplicaSet](https://kubernetes.io/docs/concepts/workloads/controllers/replicaset/)
[Kubernetes Doc - Deployments](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/)

By running more than one copy of your application, if one of the pods becomes unstable or goes down, the other copies of the application can continue serving requests until the faulty pod is restarted. It is generally recommended to run 3 copies of your pod for high availability, and you can do so like this example in your deployment yaml:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: nginx-deployment
  labels:
    app: nginx
spec:
  replicas: 3
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1.7.9
        ports:
        - containerPort: 80
```

Deployments will create and manage ReplicaSets for you automatically, so there is no need to define the ReplicaSet separately. If you don't specify how many replicas you want, the default is 1.

**NOTE:** By running more copies of your application, it will require more CPU/Memory, which will result in a higher run cost. See the [cost estimator](/docs/cnp/billing/#cost-estimator) to estimate what your application will cost based on number of Replicas, Requests, and Limits that you set.

## Container probes

[Kubernetes Doc - Pod Lifecycle -> Container Probes](https://kubernetes.io/docs/concepts/workloads/pods/pod-lifecycle/#container-probes)

A probe is an object that can check to see if your application is ready to accept traffic (Readiness Probe), and running correctly (Liveness Probe). If a container is not ready, it will not accept traffic. If a container is not alive, it will be terminated and restarted.

### Readiness probe

[Kubernetes Doc - Define readiness probes](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/#define-readiness-probes)

Kubernetes uses Readiness Probes to know when a pod is ready to start accepting traffic. A pod is considered ready when all of its containers are ready. This is primarily used to prevent a pod from having traffic routed to it before it is fully started. When a pod is not ready, it is removed from Service load balancers.

### Liveness probe

[Kubernetes Doc - Define a liveness Command](https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/#define-a-liveness-command)

The kubelet uses Liveness Probes to know when to restart a Container. For example, Liveness Probes could catch a deadlock (an application is running, but unable to make progress). Restarting a container in such a state can help to make the application more available despite bugs.

Set the proper initialDelaySeconds parameter to give your app some time to initialize (especially for Java Apps) if they are slow to start their HTTP endpoints.

## Pod disruption budget

[Kubernetes Doc - Specifying a Disruption Budget for your Application
](https://kubernetes.io/docs/tasks/run-application/configure-pdb/)

Pod Disruption Budgets limit the number of concurrent disruptions that your application experiences, allowing for higher availability while permitting the cluster administrator to manage the clusters nodes.

You will set minAvailable OR maxUnavailable to specify how many copies at a minimum should always be running, or at most, how many copies can be down at a given time.

### minAvailable example

```yaml
apiVersion: policy/v1beta1
kind: PodDisruptionBudget
metadata:
  name: zk-pdb
spec:
  minAvailable: 2
  selector:
    matchLabels:
      app: zookeeper
```

**NOTE:** If you use minAvailable, do **NOT** set minAvailable equal to your deployment's replicas, as this means that your application cannot tolerate ANY pod disruptions. Cluster administrators routinely need to take nodes offline for maintainance, and if your application can not tolerate any disruptions, then it prevents the node from coming offline. This will result in your pod being forcibly killed instead of gracefully moved to another node.

### maxUnavailable example

```yaml
apiVersion: policy/v1beta1
kind: PodDisruptionBudget
metadata:
  name: zk-pdb
spec:
  maxUnavailable: 1
  selector:
    matchLabels:
      app: zookeeper
```

**NOTE:** You will need to specify the app label as specified in your deployment. This is how Kubernetes will know what app to apply the Pod Disruption Budget to.

## Kubernetes cluster high availability

The Kubernetes clusters run across three Availability zones. Each zone has at least one Kubernetes master node running in it, so that the loss of a single zone will not affect Kubernetes' ability to schedule work loads. If an availability zone is lost, the Kubernetes cluster will start up nodes in the other zones and work loads will be moved to the other zones if possible. This process can take anywhere from 5-10 minutes per node, so using anti-affinity rules helps limit the possibility of a zone/node outage causing an application to be 100% down.

### Node affinity and antiAffinity

[Kubernetes Doc - Assigning Pods to Nodes](https://kubernetes.io/docs/concepts/configuration/assign-pod-node/)

Worker nodes are spread out across three availability zones (a, b, and c). You can specify that replicas are spread across all three of these zones using node AntiAffinity rules so  that your application will continue to run in the other zones if one is lost. AntiAffinity rules can also be specified to not run replicas on the same node in the cluster.

**Example:**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: web-server
spec:
  selector:
    matchLabels:
      app: web-store
  replicas: 3
  template:
    metadata:
      labels:
        app: web-store
    spec:
      affinity:
        # Try to schedule pods in different availability zones
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchExpressions:
                - key: app
                  operator: In
                  values:
                  - web-store
              topologyKey: "failure-domain.beta.kubernetes.io/zone"
          # Never schedule pods on the same node
          requiredDuringSchedulingIgnoredDuringExecution:
          - labelSelector:
              matchExpressions:
              - key: app
                operator: In
                values:
                - web-store
            topologyKey: "kubernetes.io/hostname"
      containers:
      - name: web-app
        image: nginx:1.12-alpine
```

**NOTE:** If podAntiAffinity and Replicasets are used in conjunction with one another, and if a zone becomes unavailable, then the podAntiAffinity rules will not be possible if you use `requiredDuringSchedulingIgnoredDuringExecution`. By using `preferredDuringSchedulingIgnoredDuringExecution`, your pods will be scheduled in different zones as long as its possible to do so. Using `requiredDuringSchedulingIgnoredDuringExecution` with **failure-domain.beta.kubernetes.io/zone** also limits you to no more than three pods at a time since there are currently only three availability zones which is why `preferredDuringSchedulingIgnoredDuringExecution` is recommended.

**NOTE** If an availability zone is lost the kubernetes cluster will spin up nodes in the other zones and work loads be moved to the other zones if possible.  This process can take anywhere from 5-10 minuets per node so using the anti-affinity rules helps limit the possibility of a zone/node outage causing an application be 100% down.

### Verify availability zones

Here is a small script that will lookup the availability zones the pods are currently running in.

```shell
SELECTOR="web-store"
NODES=`kubectl get pods -l $SELECTOR -o go-template --template '{{range .items }}{{ printf "%s\n" .spec.nodeName}}{{ end }}'`

for NODE in $NODES; do
    kubectl get node $NODE -o go-template --template '{{ index .metadata.labels "failure-domain.beta.kubernetes.io/zone" | printf "%s\n"  }}'
done
```
