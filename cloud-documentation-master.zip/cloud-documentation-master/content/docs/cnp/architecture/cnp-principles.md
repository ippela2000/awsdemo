---
title: Architectural Principles 
menu: docs
category: cnp
---

## Guiding principles

This document is not set in stone. It represents our understanding at
a point in time. It is intended to record what we believe to be best
practices related to operating a container service.

## Goals

The goal of this project is to build an application container service
on "Docker Datacenter". In the broadest sense there are two
communities that will interact with the service offering. The service
operators (a.k.a. admins) and the service consumers
(a.k.a. application teams). The inner-workings of the service offering
should be hidden from service consumers. For example, service
operators should be able to add and remove docker hosts without
service consumers being aware. With that said, the service consumers
should not expect to build into application container dependencies on specific
host machines or groups of host machines.

### Expectations of service operators

- All administrative tasks required to maintain the service MUST
      be automated.
- All automated administrative tasks must be checked into a
      standard source control system.
- All automated administrative tasks MUST scheduled to run as
      one-off container processes themselves. Granted, can suffer from
      a chicken-and-the-egg problem depending on your PoV.
- The docker hosts must be provisioned using standard server
      provisioning automation (probably Ansible and IT Simplification
      workflows). Provisioning should include the installation of the
      Docker host, configuring the engine, and adding the engine to
      the Swarm.
- Service operators will provide a collection of containers that
      service consumers can use to build applications. For example,
      the minimum list of supplied containers will include:

  - RHEL7
  - Java 1.7 JRE
  - Python
    - Django
    - Flask
  - Ruby
  - WebSphere Liberty
  - WebSphere Full Profile
  - Node.JS
  - MongoDB

### Expectations of service consumers

- Images for application components MUST be version controlled with a Dockerfile in the root folder of the project.

## Do's and don'ts

- Do version control a Dockerfile for every image you create.

- Don't muck around with the host.
  Application containers should not be used to alter the host
  configuration. For example, an application container should not
  alter /etc/hosts on the host OS or alter system network routing.
  
- Don't run application containers with --privileged=true. Application
  containers generally should not need special access to the
  underlying host. However, containers used to run administrative
  tasks on the host engines may need such access.
  
- Not everyone should be in the "docker" group.
  You should consider users in the docker group as users with elevated
  privileges. Similar to but not quite root. Only put operators of the
  container service in the docker group.
  