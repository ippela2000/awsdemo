---
title: Platform Architecture
menu: docs
category: cnp
---
This document describes the architecture of the Nationwide CNP (Cloud Native Platform).

## Cloud native platform architecture

The CNP is an implementation of [Nationwide Cloud Native Platform - Reference Architecture](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-arch/ra-cnp.html). The specified architecture is intended to be a hosting platform for several types of application architectures. That includes cloud native applications, [cloud hosted packed applications](https://pages.github.nwie.net/Nationwide/Packaged-Applications/ra/gw-cloud-ref-architecture.html), and traditional application architectures. The core of the CNP is a container runtime engine and a container orchestration/scheduler engine. The [Principles](/docs/cnp/architecture/cnp-principles) document has the guiding principles for this implementation. The container runtime in this implementation of the CNP-RA is Docker (the OSS project). Container orchestration and scheduling is Kubernetes. Both components are part of the Docker EE distribution. **AD-###** documents the architectural decisions related to sourcing the container runtime, orchestration, and scheduling.

The Nationwide CPT (Cloud Platform Team) uses [DCI (Docker Certified Infrastructure) for Amazon](https://success.docker.com/api/articles/certified-infrastructures-aws/pdf). DCI is Docker's prescriptive approach to deploying Docker Enterprise Edition on a range of infrastructure choices. DCI for AWS provides best practices and automation for deploying Docker EE environments in AWS. The automation has been modified to comply with the guidelines and constraints of Nationwide's AWS implementation.

DCI for AWS uses [Terraform](https://www.terraform.io/) and [Ansible](https://www.ansible.com/) to create a highly available Docker EE cluster via Infrastructure as Code in a repeatable fashion. Terraform uses the AWS API to create infrastructure resources in AWS (i.e. EC2, security groups, DNS Names). Ansible is used for the final steps of the configuration. Ansible playbooks install the necessary software and configure EC2 instances. All artifacts use Nationwide's GitHub repository for version control.

Below is a high level diagram of the architecture design.

![High Level Architecture](/docs/cnp/images/docker_ee_aws.png)

## Cluster manager nodes

Cluster manager nodes host the cluster control plane. That includes the Kubernetes master node processes, Swarm master node processes, the UCP (Universal Control Plane) processes, and the ectd processes. UCP is a Web GUI for interacting with the cluster. Ectd is a key-value database that stores cluster configuration data. An odd number of masters is  required, in a 3-manager or 5-manager configuration. (1 master and 2 replicas, or 1 master and 5 replicas.) Each master node is placed in a unique AZ (Availability Zone).

## Worker nodes

Cluster worker nodes host application containers. The worker nodes run the kubelet, kube-proxy, and ucp-agent processes, which are responsible for managing scheduled containers and container resources (i.e. volumes). A minimum set of 3 worker nodes are initially deployed in a CNP cluster. The initial number is arbitrarily chosen to support initial cluster workload. The number of worker nodes varies over time, and is automatically increased or decreased based on workload. Worker nodes are distributed across multiple AZs to improve availability. Initially, all worker nodes are sized identically.

## Container registry managers (Docker Trusted Registry)

DTR (Docker Trusted Registry) provides the following services to the platform:

* Container image storage
* Container image life cycle management
* Container image vulnerability scanning
* Container image environment promotion
* Container image signing

A minimum of 3 DTR nodes are required. The 3 nodes are distributed across 3 AZs to address availability concerns. In AWS, DTR is configured to use S3 to store container image layers. By design, DTR is tightly coupled with the UCP processes in a cluster. There is a 1-to-1 relationship between DTR and UCP in a single cluster. A [separate document](https://docs.mirantis.com/docker-enterprise/v3.0/dockeree-products/dtr/dtr-architecture.html) addresses DTR architecture and image life-cycle.

## Load balancers

Load balancers are a collection of AWS Classic ELBs (Elastic Load Balancers). Three sets of **AWS Classic ELBs** are deployed supporting three fundamental platform functions:

1. Load balancing UCP - Supporting a web GUI for the platform runtime and orchestration. The load balancers listen on port 443. The backend instances are the 3 or 5 nodes that host the cluster managers and the ucp-controller process.
2. Load balancing DTR - Supporting a web GUI for the image registry. The load balancers listen on 443. They route to the 3 DTR instances that contain the dtr-nginx process.
3. Load balancing HTTP/HTTPS applications running on the platform. The load balancers listen on 443. They route requests to the three instances of the kubernetes NGINX ingress controller.

These three sets support the basic functionality of the platform cluster. Additional application-specific load balancers will be added when needed to meet application requirements.

## Disaster recovery

In the AWS environments, backups of Swarm and UCP are taken once a week on Sundays, as well as before cluster upgrades are performed. In the event that something catastrophic occurs, the Cloud Platform team will restore the cluster using one of these backups.

In the on-prem environments, production will only exist in Data Center North. There will be no DR in Data Center East, as investment is being made to build a Kubernetes environment in the AWS Ohio Region when available (tentative 4th quarter 2020). Resiliency is in place, but the event of a full Data Center North loss where all workloads must be recovered in Data Center East is not accounted for. If disaster recovery is a requirement for your application, you will need to delay your container deployment until you can pivot to AWS Ohio or AWS VA.

Refer to this [knowledgebase article](https://success.docker.com/article/backup-restore-best-practices) for detailed information on performing cluster backups.

## Loss of quorum

In the event that quorum is lost, such as when (N-1)/2 manager nodes are lost, the Cloud Platform team will perform the following steps:

1. Ensure that at least one manager node is still available
2. Build a new manager node (or multiple if needed) using the AWS console
3. Ensure that the new manager node joins the cluster and is recognized as a manager

## Loss of all manager nodes

In the unlikely event that all manager nodes in a cluster are lost, the Cloud Platform team will perform the following steps:

1. Build new cluster using automation tooling
2. Restore UCP and DTR backups
3. Run all CI jobs to re-deploy applications to the cluster

## Cluster upgrades

The Cloud Platform team performs cluster updates once a month, and performs upgrades to the Docker Engine, UCP, and DTR when applicable. The team performs upgrades in lower environments first in order to take note of any issues encountered.

The workflow for cluster upgrades is as follows:

1. Upgrade UCP managers one by one. Both engine and OS when applicable.
2. Upgrade DTR managers one by one. Both engine and OS when applicable.
3. Upgrade UCP workers. The new AMI is added to the template used to create worker nodes. Each worker node is drained, and cluster scaling automation creates new workers using the new AMI.

Refer to this [knowledgebase article](https://success.docker.com/article/upgrade-an-entire-cluster-with-centos-docker-engine-ucp-and-dtr) for detailed steps on how a cluster upgrade works.

Below is a diagram that illustrates the upgrade workflow.

![Docker Upgrades](/docs/cnp/images/docker-upgrades.png)

## Cluster scaling

A cluster component called the aws-cluster-autoscaler is running in each AWS cluster. When the aws-cluster-autoscaler detects that more nodes are needed, it automatically increases the size of the autoscaling group (ASG) in AWS. The aws-cluster-autoscaler periodically checks the usage of each node, marks nodes with low usage for removal, and scales the cluster accordingly. The AWS clusters frequently change size based on usage through this component.

This scaling behavior does not occur in the on-prem clusters, which have a fixed number of nodes and do not automatically increase or decrease in size.

## Logging

All standard output/standard error logs from containers, as well as logs from the nodes, are sent to [Spunk Cloud](https://nationwide.splunkcloud.com/en-US/app/launcher/home).

## Monitoring

A set of tools are used to collect platform metrics and monitor the various layers of the platform. They include:

* [Prometheus](https://prometheus.io/) : Prometheus is an open source pull-based monitoring system that is included in as part of the Docker EE system. It is used to collect metrics on each node in the platform.
* [Kubernetes metrics-server](https://kubernetes.io/docs/tasks/debug-application-cluster/core-metrics-pipeline/) : The Kubernetes Metrics-Server is included as a standard add-on to Kubernetes. Metrics-Server is a cluster-wide aggregator of resource usage data.
* [New Relic](https://newrelic.com/) : New Relic is the standard monitoring tool at Nationwide. New Relic is the central point for viewing, analyzing, and alerting data collected in the platform. It provides system and application monitoring and system analytics. This document addresses platform monitoring. Application monitoring is addressed in the application on-boarding document.

Monitoring is addressed at each layer of the [Cloud Native Platform reference architecture](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-arch/ra-cnp.html): Cloud, Runtime, Orchestration and Management, Application Definition and Development, and Image Management.

### Cloud

The Cloud layer includes all underlying cloud infrastructure on which the platform relies. For example, in AWS, that includes EC2 instances, Elastic Load Balancers, and Route53 DNS. The following includes the minimum set of metrics that are monitored for the EC2 nodes that make up the platform:

* Uptime
* CPU Utilization
* Memory Utilization
* Storage Utilization
* Cloud Provider Notifications

The following includes the minimum set of metrics that are monitored for the elastic load balancers that make up the platform:

* **UCP:** https://ucp.nwie.com/_ping _returns:_ `OK`

* **DTR:** https://dtr.nwie.com/health _returns:_ `{"Error":"","Healthy":true}`

### Runtime

The Runtime layer includes the Docker engine and associated plugins and drivers, including virtual networking and virtual storage. The following includes the minimum set of runtime metrics that are monitored:

* Containers: name, tag, ID, creator, APRM ID, # running, # stopped, age, restarts/time interval, memory & CPU consumption
* Images: name, tag, ID, maintainer, APRM ID, size, age, number/host+cluster
* Volumes: name, ID, size, creator, APRM ID, in-use, age
* Networks: name, ID, creator, APRM ID, in-use, age

### Orchestration and management

The Orchestration and Management layer includes the Kubernetes cluster components. The following includes the minimum set of runtime metrics that are monitored:

* Nodes: Number/cluster, State, resources (cpu, memory, disk, special hardware)
* ApiServer: status
* Controller Manager: status
* Cloud Controller Manager: status
* Scheduler: status
* Kubelet: status
* Kube-Proxy: status
* Namespaces: number per cluster, names, disbursement code, number of objects deployed, resources consumed (cpu memory)
* Pods: number/namespace, total number, team/owner, status, number of containers
* Services: number/namespace, total number, team/owner, status, number of containers
* Deployments: number/namespace, total number, team/owner, status, number of containers
* CPU: Aggregate per cluster
* Memory: Aggregate per cluster

### Cluster managers

The Cloud Platform team currently monitors the number of manager nodes in each cluster through New Relic Synthetic Alerts. The Synthetic Alerts contact UCP in each cluster every 5 minutes, and ensure that the results return that each manager node is both _ready_ and _reachable_. If a manager node violates either of these conditions, the Cloud Platform team receives an alert.

### Application definition and development

The Application Definition and Development layer includes CI/CD tools like [Concourse](https://concourse-ci.org/), [Jenkins](https://jenkins.io/), and [Harness](https://harness.io/), [Tiller](https://www.helm.sh/) (server-side of helm), and [Kubernetes Service-Catalog](https://kubernetes.io/docs/concepts/extend-kubernetes/service-catalog/). The following includes the minimum set of runtime metrics that are monitored:

* Concourse: application status, CPU consumed, Memory consumed
* Tiller: Status per namespace
* Service-Catalog: Status per cluster

### Image management

The Image Management layer includes the registry implementations that are operated to support container image discovery and deployment. Nationwide has standardized on the use of DTR ( [Docker Trusted Registry](https://docs.docker.com/ee/dtr/) ) from the Docker EE product set. The following includes the minimum set of runtime metrics that are monitored:

* DTR: status per registry, storage/registry & /image layer, number of image repositories, number of layers stored, layer reuse percentage
