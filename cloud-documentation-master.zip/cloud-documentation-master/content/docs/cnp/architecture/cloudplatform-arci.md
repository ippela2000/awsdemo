---
title: Cloud Platform ARCI
menu: docs
category: cnp
---

Accountability and responsibility for IT components that make up the Cloud Native Platform running in AWS are organized according to logical layers. The Cloud Platform Team is responsible for the platform itself. The Cloud Infrastructure Team is responsible for the infrastructure underlying the platform. The diagram below is a logical depiction of the  [Cloud Native Platform Reference Architecture](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-arch/ra-cnp.html). It is color-coded to indicate responsibilities for each team.

![ARCI](/docs/cnp/images/CNP-ArchitectureDiagrams-blockARCI.png)

The following table outlines the roles and responsibilities of the **CIT**
(Cloud Infrastructure Team), **CPT** (Cloud Platform Team), Application Teams,
Nationwide's Network team, and **IRM** (Information Risk Management).

The table lists some of the common activities that are expected to
occur during "day-to-day" operation of a Cloud Platform. Notice that in
all cases, IRM is Informed and/or Consulted. For activities that occur
frequently, IRM is informed and consulted on the practices and
standards used to execute the activity. Informed and Consulted can be a
person to person interaction, or it could be a process updating the
running state of resources in a cluster. For example, it is not
expected that application teams will personally contact the CPT when
creating an EFS mount. However, the CPT will be able to report on the EFS mounts
that have been created and are used by application through use of the the platform administration tools.

|           Activity               | CIT | CPT | App Team | Network Team | IRM |
|---------------------------------:|:---:|:---:|:--------:|:------------:|:---:|
| AMI Creation                     | A,R | I,C |          |              | I,C |
| AMI Distribution                 | A,R | I,C |          |              | I,C |
| EC2 Instance Creation            |     | A,R |          |              | I,C |
| EC2 Instance Currency            |     | A,R |          |              | I,C |
| EC2 Instance Administration      |     | A,R |          |              | I,C |
| Platform EBS Volume Creation     |     | A,R |          |              | I,C |
| EFS Filesystem Creation          |     | I,C | A,R      |              | I,C |
| Platform EBS Backup/Restore      |     | A,R |          |              | I,C |
| EFS Backup/Restore               |     |     | A,R      |              | I,C |
| VPC Creation                     | A,R |     |          |              | I,C |
| Inbound Internet Access          | A,R |     |          |              | I,C |
| Outbound Internet Access         | A,R |     |          |              | I,C |
| Subnet Creation                  | A,R |     |          |              | I,C |
| VPC address assignment           | A,R |     |          |              | I,C |
| Subnet address assignment        | A,R |     |          |              | I,C |
| Account Peering                  | A,R |     |          |              | I,C |
| NW Network Connectivity          |   R |     |          | A,R          | I,C |
| DNS 2LD management               |     |     |          | A.R          | I,C |
| DNS Subdomain Delegation         |     |     |          | A,R          | I,C |
| Platform Virtual Net IPAM        |     | A,R |          |              | I,C |
| Platform Virtual Net Creation    |     | A,R |          |              | I,C |
| Cloud Account Admin              | A,R |     |          |              | I,C |
| Cloud User Admin                 | A,R |     |          |              | I,C |
| Cloud Directory Admin            | A,R |     |          |              | I,C |
| WAF Admin                        | A,R |     |          |              | I,C |
| TLS Cert Management              |     | A,R |          |              | I,C |
| Kubernetes Management            |     | A,R |          |              | I,C |
| Cluster Creation                 |     | A,R |          |              | I,C |
| Cluster Capacity Management      |     | A,R |          |              | I,C |
| Cluster RBAC Management          |     | A,R |          |              | I,C |
| ClusterRole Create/Update/Delete |     | A,R |          |              | I,C |
| Org/Team Create/Update/Delete    |     | A,R |          |              | I,C |
| Collection Create/Update/Delete  |     | A,R |          |              | I,C |
| Grant Create/Update/Delete       |     | A,R |          |              | I,C |
| Platform Currency                |     | A,R |          |              | I,C |
| Platform Monitoring/Alerting     |     | A,R |          |              | I,C |
| Platform Outage Response         |     | A,R |          |              | I,C |
| Image Registry Management        |     | A,R |          |              | I,C |
| Cluster Services Management      |     | A,R |          |              | I,C |
