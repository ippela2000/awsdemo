---
title: Kubernetes Labeling
menu: docs
category: cnp
---

Some of this document is borrowed from the [Kubernetes Label Docs](https://kubernetes.io/docs/concepts/overview/working-with-objects/labels/) web site.

## Labels

_Labels_ are key/value pairs that are attached to objects, such as pods. Labels are intended to be used to specify identifying attributes of objects that are meaningful and relevant to users, but do not directly imply semantics to the core system. Labels can be used to organize and to select subsets of objects. Labels can be attached to objects at creation time and subsequently added and modified at any time. Each object can have a set of key/value labels defined. Each Key must be unique for a given object.

Labels will be:

```json
"metadata": {
  "labels": {
    "key1" : "value1",
    "key2" : "value2"
  }
```

## Motivation

Labels enable users to map their own organizational structures onto system objects in a loosely coupled fashion, without requiring clients to store these mappings.

Service deployments and batch processing pipelines are often multi-dimensional entities (e.g., multiple partitions or deployments, multiple release tracks, multiple tiers, multiple micro-services per tier). Management often requires cross-cutting operations, which breaks encapsulation of strictly hierarchical representations, especially rigid hierarchies determined by the infrastructure rather than by users.

Nationwide recently purchased a [security tool](https://www.twistlock.com) that allows us to scan running containers for vulnerabilities, mis-configured dockerfiles, and [container compliance rules](https://www.cisecurity.org/benchmark/docker/). Twistlock has the ability to read Kubernetes labels, and send alerts directly to the `ResourceOwner` via email.

Example pod labels:

* `"release" : "stable", "release" : "canary"`
* `"environment" : "dev", "environment" : "qa", "environment" : "production"`
* `"tier" : "frontend", "tier" : "backend", "tier" : "cache"`
* `"partition" : "customerA", "partition" : "customerB"`
* `"track" : "daily", "track" : "weekly"`

These are just examples of commonly used labels; you are free to develop your own conventions. Keep in mind that label Key must be unique for a given object.

## Required Nationwide pod labels

* `"APRMName" : "AwesomeApp"`
* `"APRMID" : "9874"`
* `"DisbursementCode" : "123456001"`
* `"ResourceOwner" : "loeffls1"`
* `"ContactGroup" : "cas"`

**Note that these labels are case sensitive!**

These labels should be on all of your **pods**.  If all pods in a namespace are running for the same app, you can specify these labels for your namespace in [cnp-caas-config](https://github.nwie.net/Nationwide/cnp-caas-config).  Then, all pods in that namespace will automatically inherit those labels from the namespace.

If your pods are being managed by a deployment, then you should apply the labels to the spec.template section of the deployment.  All pods created by the deployment will automatically inherit the labels specified in the template section of your deployment yaml.

See example below:

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: demo
spec:
  selector:
    matchLabels:
      app: demo
  replicas: 3
  template:
    metadata:
      labels:
        ARPMName: # Friendly Application Name from APRM
        APRMID: # Application ARPMID goes here, do this for all your kube objects!!
        DisbursementCode: "<9 digits>" # (Required) Billable Disbursement Code. Leave quotes as kube needs to treat this as a string
        ResourceOwner: <nwie id>   # (Required)
        ContactGroup: <email>      # (Required) Email group to contact, minus @nationwide.com
    spec:
      containers:
      - name: demo
        image: ehazlett/docker-demo:latest
        ports:
        - containerPort: 8080
```

## Syntax and character set

_Labels_ are key/value pairs. Valid label keys have two segments: an optional prefix and name, separated by a slash (`/`). The name segment is required and must be 63 characters or less, beginning and ending with an alphanumeric character (`[a-z0-9A-Z]`) with dashes (`-`), underscores (`_`), dots (`.`), and alphanumerics between. The prefix is optional. If specified, the prefix must be a DNS subdomain: a series of DNS labels separated by dots (`.`), not longer than 253 characters in total, followed by a slash (`/`).

If the prefix is omitted, the label Key is presumed to be private to the user. Automated system components (e.g. `kube-scheduler`, `kube-controller-manager`, `kube-apiserver`, `kubectl`, or other third-party automation) which add labels to end-user objects must specify a prefix.

The `kubernetes.io/` and `k8s.io/` prefixes are reserved for Kubernetes core components.

Valid label values must be 63 characters or less and must be empty or begin and end with an alphanumeric character (`[a-z0-9A-Z]`) with dashes (`-`), underscores (`_`), dots (`.`), and alphanumerics between.

Here is a configuration file for a Pod that has the required Nationwide labels:

```yaml
apiVersion: v1
kind: Pod
metadata:
  name: my-app
  labels:
    ARPMName: # Friendly Application Name from APRM
    APRMID: # Application ARPMID goes here, do this for all your kube objects!!
    DisbursementCode: "<9 digits>" # (Required) Billable Disbursement Code. Leave quotes as kube needs to treat this as a string
    ResourceOwner: <nwie id>   # (Required)
    ContactGroup: <email>      # (Required) Email group to contact, minus @nationwide.com
spec:
  nodeSelector:
    com.docker.ucp.collection.shared: "true"
  containers:
  - name: web
    image: nginx
    resources:
      limits:
        cpu: 100m
        memory: 64Mi
      requests:
        cpu: 100m
        memory: 64Mi
    ports:
    - containerPort: 80
      name: http
  restartPolicy: Never
```

## Email notifications

To control who receives notifications for issues with a pod, add an annotation of `nationwide.com/email` to the deployment or pod.  More information can be found on the [pod-scaledown](https://github.nwie.net/Nationwide/pod-scaledown#email-contacts) documentation.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: demo
  annotations:
    nationwide.com/email: "user1@nationwide.com"
```
