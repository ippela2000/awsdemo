---
title: DNS Resolution
menu: docs
category: cnp
---

The following diagram depicts a few of the details related to DNS name resolution as it relates to the Cloud Platform running in Amazon AWS.

![ARCI](/docs/cnp/images/CNP-ArchitectureDiagrams-DNSResolution.png)

A couple of points worth restating.

1. All of Nationwide's [DNS](https://www.digitalocean.com/community/tutorials/an-introduction-to-dns-terminology-components-and-concepts) Zones hosted in AWS Route 53 are [private zones](https://docs.aws.amazon.com/Route53/latest/DeveloperGuide/hosted-zones-private.html). Private zones are private to the AWS account where it is hosted. Private zones are not accessible outside of the account without adding something special. In our case, an [InfoBlox](https://www.infoblox.com/) appliance runs in the same account where we host the private zones. Nationwide's private zones are hosted in the InfraSvcProd account. The InfoBlox appliance running in the account acts as a forwarder to Route53 and a  “universal resolver” for all EC2 instances across all Nationwide accounts.

2. Resolution for all DNS resources under the ".aws.e1.nwie.net" branch of the nwie.net DNS tree are forwarded to InfoBlox in the InfraSvcProd AWS account. Programmatic updates to resources in that branch require assuming an administrative role that has privileges to write to Route53 in that branch.
