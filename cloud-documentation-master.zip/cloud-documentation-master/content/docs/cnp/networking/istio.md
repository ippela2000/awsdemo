---
title: Istio Service Mesh
menu: docs
category: cnp
---

## Istio is only available in the Kubernetes **Dev** environment

This feature is being examined for broader use in our environments. Please contact the cloud-platform in RocketChat team about your use cases for the Istio service mesh!

## Opting into Istio

Automatic sidecar injection is enabled in the dev environment. This is done by adding a label to a namespace.

```shell
# an admin needs to run this for now. email cloud-platform@nationwide.com or ask in RocketChat #cloud-native-platform
kubectl label namespace <namespace-to-enable> istio-injection=enabled
```

## Istio supporting tools

We have installed the tooling packaged with the istio distribution. These are installed at a global level for now. The url list is below.

- [Istio Grafana](https://istio-grafana.apps-dev.aws.e1.nwie.net) - no auth
- [Istio Prometheus](https://istio-prometheus.apps-dev.aws.e1.nwie.net) - no auth
- [Istio Kiali](https://istio-kiali.apps-dev.aws.e1.nwie.net) - admin/admin

## Common ingress gateway

There is a common ingress gateway installed installed in the 'istio-system' namespace for playing around. Chances are, you'll want your own gateway in your namespace so others don't clobber your routing rules.
