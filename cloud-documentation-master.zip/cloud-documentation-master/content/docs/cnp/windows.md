---
title: Windows
menu: docs
category: cnp
---

Windows container support may come to the Cloud Native Platform in the future, but is not currently available.

**The CNP team has turned off the Windows POC environment. Follow [issue 374](https://github.nwie.net/Nationwide/cloud-native-platform/issues/374) for details on when an offical beta enviroment will be ready as we get closer to having Windows support ready for general availability.**

Details on what the POC environment was like while it was running can be found below.

[Windows limitations](https://kubernetes.io/docs/setup/production-environment/windows/intro-windows-in-kubernetes/#limitations)

## Access

If you are interested in getting access to the POC cluster, please send an email
to [cloud-platform](mailto:cloud-platform@nationwide.com) and ask for access.
Include a namespace name and AD/LDAP group to grant access to it.

## Feature status

Since this is a proof of concept, there are many features of the standard
CNP clusters that are either not set up or not supported on Windows yet.
There are some features we do not plan on enabling in the POC.

This table will try to capture some of the more common Kubernetes/CNP
features and their known state. Please let us know if there is a feature
you need.

| Feature                        | Status  | Notes |
|--------------------------------|-----------|-------|
| CAAS Config Self Registration  | Not Setup | Do not plan on adding to POC cluster, email us for access |
| Ingress Default                | Working   |  |
| Wildcard DNS for Ingress       | Not Setup | Use DNS Registration Instead for now |
| Ingress ALB (External Apps)    | Not Setup | Do not plan on adding to POC cluster |
| Certificate Signing            | Working   |  |
| DNS registration (Ingress Objects) | Working | cp.nwie.net and apps.nwie.net are setup |
| DNS registration (Service Objects) | Working | cp.nwie.net and apps.nwie.net are setup |
| AWS ELB                        | Working |  |
| EBS Storage                    |  |  |
| EFS Storage                    |  | Not sure if EFS is event supported on Windows |
| SMB Storage                    |  |  |
| Twistlock (security)           |  |  |
| New Relic                      |  |  |
| Splunk Logging                 |  |  |
| AWS IAM                        |  |  |
| Open Policy Controller          | Setup |  |
| AWS Node Labeler               |  |  |
| NW Admission Controller        | Setup |  |
| Cluster Auto Scaling           |  | The cluster has 3 worker nodes right now.  An ASG can be added if needed. |
| Istio                          |  | Do not plan on adding to the POC cluster |
| Helm Support                   |  | Tiller needs to run on a Linux node. Version 3 is in beta now. |

## Building images

Windows containers need to be built with a Sever 2019 base image. This is because
server 2019 1809 is the current target.

## Support

Use RocketChat for support during this POC.  A
[kubernetes-windows](https://rocketchat.nwie.net/channel/kubernetes-windows)
channel has been created to keep things focused on this POC. Once things
get closer to the final release of Windows suppport for the Cloud Native
Platform all support will move back to the normal channels. Questions
can also be emailed to [cloud-platform](mailto:cloud-platform@nationwide.com).

Please do not open ServiceNow tickets for the POC.

## Usage

### Kubeconfig

You will need to download the Kubeconfig yaml file to your laptop in order to access
the cluster via kubectl.

The POC env is currently based on a product called Rancher, which uses a different setup
compared to Docker's UCP. Rancher can be accessed at
[https://rancher-poc.cp.nwie.net](https://rancher-poc.cp.nwie.net). Use your
Nationwide email as your username and Nationwide Password to log in. You
have to have access to an existing namespace in order to log in.

The Kubeconfig file can be found by logging into Rancher
and accessing the *windows-poc* cluster under the Global menu. Click on Cluster in the
menu once you have selected the windows-poc from the cluster list. From there, you can
click on Kubeconfig File in the upper right to download your file. You can even launch
a shell with access to kubectl in it. However, any files created in this shell will be
cleared when closed.

The Kubeconfig yaml will need to be consumed by either placing it in $HOME/.kube/config
or pointing to it with an env var KUBECONFIG.  The [Kubernetes docs](https://kubernetes.io/docs/concepts/configuration/organize-cluster-access-kubeconfig/) has details on how to merge your Kubeconfig files.

### Ingress

The *default* ingress controller is running in the cluster. Follow the docs on
[Ingress Routing](/docs/cnp/ingress/ingress-default). The POC cluster does not have a wildcard DNS or cert setup, so make
sure your DNS names are under cp.nwie.net or apps.nwie.net and they will be registered
in DNS on the fly. Also, add a `kubernetes.io/tls-acme: "true"` annotation to setup
an SSL cert.
