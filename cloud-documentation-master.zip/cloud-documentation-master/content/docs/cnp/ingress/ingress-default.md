---
title: Ingress Routing
menu: docs
category: cnp
---

Ingress is the traffic and data that the firewall allows to come into Nationwide (Egress, likewise, is traffic that goes out of Nationwide). For more general information about its role in Kubernetes, see [this.](https://kubernetes.io/docs/concepts/services-networking/ingress/)

## Internal applications

The platform provides an ingress controller that is capable of routing HTTP
requests to your PODs. The ingress controller is configured to handle all
DNS names under a wildcard DNS name __*.apps-CLUSTER.aws.e1.nwie.net__.
A table of the current wildcard DNS names can be found below for each
cluster.

Using the wildcard DNS names should be avoided now that the clusters are
able to register DNS names on the fly. Please consult the DNS Table
below to see which domains we can register in. If access is needed
to another domain please inquire about it.

## Wildcard DNS table

| CLUSTER | Wildcard DNS                    | ingress.class   | Notes             |
| ------- | ------------------------------- | --------------- | ----------------- |
| dev     | *.apps-dev.aws.e1.nwie.net      | default         |                   |
| test    | *.apps-test.aws.e1.nwie.net     | default         |                   |
| prod    | *.apps.aws.e1.nwie.net          | default         |                   |
| tools   | *.tools.aws.e1.nwie.net         | default         | Not for running apps |

## DNS table

Clusters are also able to register DNS names on the fly for Ingress.
If the DNS name requested matches one of the DNS domains Kubernetes
manages and the DNS name is available it will be registered on the fly.
The DNS Domains available for each cluster to use are documented below.

| CLUSTER | DNS Domain(s)                   | ingress.class   | Notes             |
| ------- | ------------------------------- | --------------- | ----------------- |
| dev     | cp.nwie.net, apps.nwie.net, aws.e1.nwie.net | default         |                   |
| test    | cp.nwie.net, apps.nwie.net, aws.e1.nwie.net | default         |                   |
| test03  | cp.nwie.net, apps.nwie.net, aws.e2.nwie.net | default         |                   |
| prod    | cp.nwie.net, apps.nwie.net, aws.e1.nwie.net | default         |                   |
| tools   | cp.nwie.net, apps.nwie.net, aws.e1.nwie.net | default         | Not for running apps |
| test02  | cp.nwie.net, apps.nwie.net                  | default         |                   |
| prod02  | cp.nwie.net, apps.nwie.net                  | default         |                   |

* Support for nwie.net will hopefully be possible in the future.

## Ingress controller

In order for the Ingress controller to know about your Service, you need to create an *Ingress* object which will contain the DNS name you want to use and a special annotation.  The annotation **kubernetes.io/ingress.class** must be set to *default* for default nginx-ingress to pick it up.

## Example ingress

Basics example that handles only http traffic (Don't use http only)

```yaml
apiVersion: networking.k8s.io/v1beta1
kind: Ingress
metadata:
  name: sample-app
  annotations:
    kubernetes.io/ingress.class: default
spec:
  rules:
  - host: sample.apps-test.aws.e1.nwie.net
    http:
      paths:
      - backend:
          # Reference your Service by name
          serviceName: sample-app-service
          # Reference your Service Port by either name or number
          servicePort: http
          #servicePort: 8080
```

Basic example that handles http and https requests. http will be redirect to https by default.

```yaml
apiVersion: networking.k8s.io/v1beta1
kind: Ingress
metadata:
  name: sample-app
  annotations:
    kubernetes.io/ingress.class: default
spec:
  tls:
  - hosts:
    - sample.apps-test.aws.e1.nwie.net
  rules:
  - host: sample.apps-test.aws.e1.nwie.net
    http:
      paths:
      - backend:
          # Reference your Service by name
          serviceName: sample-app-service
          servicePort: http
```

## SSL certs

The default ingress controller uses a nwie.net signed cert.
__*.nwie.net__ and __*.apps-CLUSTER.e1.aws.nwie.net__ names should just work.
However you should should use auto generated SSL certs by as documented
below.

### Auto generated SSL certs

The kubernetes cluster is capable of signing SSL certs with a nwie.net CA.
This will cause any Ingress with the **kubernetes.io/tls-acme: "true"**
annotations and a *secretName* to have a SSL cert generated and renewed
as needed.  The kubernetes cert manager will create a SSL secret in
*secretName* so you do not need to manage it.

```yaml
apiVersion: networking.k8s.io/v1beta1
kind: Ingress
metadata:
  name: sample-app
  annotations:
    kubernetes.io/ingress.class: default
    kubernetes.io/tls-acme: "true"
spec:
  tls:
  - hosts:
    - sample.apps-test.aws.e1.nwie.net
    secretName: sample-app-ssl-cert
  rules:
  - host: sample.apps-test.aws.e1.nwie.net
    http:
      paths:
      - backend:
          # Reference your Service by name
          serviceName: sample-app-service
          servicePort: http
```

#### Custom SSL certs

You can provide your own SSL cert by adding the *secretName* option the the spec.tls which will point to secret in the same namespace as your Ingress.

```yaml
spec:
  # Support https using  custom cert
  tls:
  - hosts:
    - sample.apps-test.aws.e1.nwie.net
    secretName: custom-ssl-cert
```

To create the secret if you have your SSL cert and key in pem format you can use this command to create the secret.

```shell
kubectl create secret tls custom-ssl-cert --cert=cert.pem --key=key.pem
```

### Customizing ingress

The Ingress can be customized by adding annotations. These annotations are documented [here](https://github.com/kubernetes/ingress-nginx/blob/master/docs/user-guide/nginx-configuration/annotations.md).

Common annotations

| Annotations                                     | Value             | Description                     |
| ----------------------------------------------- | ----------------- | ------------------------------- |
| nginx.ingress.kubernetes.io/force-ssl-redirect  | "true" or "false" | Redirect http to https          |
| nginx.ingress.kubernetes.io/backend-protocol    | "HTTP" or "HTTPS" | Set to HTTPS to use https       |
| nginx.ingress.kubernetes.io/affinity            | "cookie"          | Enabled sticky sessions         |
| nginx.ingress.kubernetes.io/session-cookie-name | ""                | Cookie to track sticky sessions |
| nginx.ingress.kubernetes.io/proxy-read-timeout  | "60"              | Seconds to wait for pod reponse |
| nginx.ingress.kubernetes.io/proxy-body-size     | "2m"              | Adjust the client_max_body_size setting if you are getting a 413 error code from NGINX |

### Error codes

The Ingress Controller is configured to provide friendly error pages for the following http error codes.

* 502: Error talking to the POD.
* 503: The Ingress controller does not know which service to route the request too.  Double check your DNS name and the **kubernetes.io/ingress.class: default** annotation.
* 504: You POD did not respond in the allocated time. Check the app logs and see why. If your requests normally take more than 60 seconds look into the  **nginx.ingress.kubernetes.io/proxy-read-timeout** annotation.

There is currently no way to turn these off as these can only be configured globally.

### Network policy

If using network policies you can add a namespaceSelector to match the CNP ingress namespace to allow traffic from the ingress controller to the pods in your namespace.  Look for a label called *ingress* and a value of *default*.

```yaml
apiVersion: networking.k8s.io/v1beta1
kind: NetworkPolicy
metadata:
  name: example-ingress-net-policy
spec:
  ingress:
  - from:
    # Allow ingress controller to talk to your pods
    - namespaceSelector:
        matchLabels:
          ingress: cloud-platform
  policyTypes:
  - Ingress

```

## Custom DNS names

Currently if you want a custom something.nwie.net DNS name you will need to
create a CNAME request to the DNS team and have them manually setup a
record that maps something.nwie.net to the DNS name of the ingress load
balancer. This currently needs to be done via a Service Now Request.

*NOTE:* Don't forget to add your something.nwie.net DNS names to your Ingress host list as this example shows.

```yaml
apiVersion: networking.k8s.io/v1beta1
kind: Ingress
metadata:
  annotations:
    kubernetes.io/ingress.class: default
  name: pls-simple
  labels:  
    aprmId: "1234"
    environment: test
    disbursementCode: "123456001"
spec:
  tls:
  - hosts:
    - something.apps-test.aws.e1.nwie.net
    - something.nwie.net
  rules:
  - host: something.apps-test.aws.e1.nwie.net
    http:
      paths:
      - backend:
          serviceName: myservice
          servicePort: 8080
        path: /
  - host: something.nwie.net
    http:
      paths:
      - backend:
          serviceName: myservice
          servicePort: 8080
        path: /
```

### ServiceNow request

Login to service now by browsing to [https://nwproduction.service-now.com](https://nwproduction.service-now.com). DNS requests can be found under the Service Catalog by selecting Catalog.
![service now catalog](/docs/cnp/images/sn-catalog-menu.png)

If you do not see "Add - New Alias" or "Modify - Move Alias to Different Host Name" in choices after selecting Catalog search for "cname" in the search menu.
![service now search](/docs/cnp/images/sn-catalog-search.png)

Select "Modify - Move Alias to Different Host Name" if you are moving an existing DNS name for an application to the Kubernetes Ingress.  "Add - New Alias" if this is a completely new DNS name that does not currently resolve.

### Add - new alias

* Alias: The left most part of your DNS name you want to register.
* Host IP Address: Enter 0.0.0.0 as CNAMES do not need an IP
* Environment:
* Domain Names: The right part of the DNS name.  *nwie.net* is most common values for this.
* Change Number: Your RFC number for a production change. (Not needed for Test)
* Effective Date: Date you want the change to happen.  Leave blank for ASAP.
* Additional Information: Enter a note here about setting this up as a CNAME and not an Alias.  *Please setup "DNS Name" as a CNAME to "Ingress DNS Name".* "DNS Name" should be your something.nwie.net DNS name and "Ingress DNS Name" should be the DNS something.apps.aws.e1.nwie.net name.

Here is an example for an external DNS names.
![new external cname](/docs/cnp/images/sn-new-external-cname.png)

Finally, add the item to your cart and finish the checkout process.

### Modify - Move alias to different host name

* Current Alias: The left most part of your DNS name you want to move.
* Current Domain Name: The right most part of your DNS name you want to move.
* Current IP Address: Enter 0.0.0.0 as CNAMES do not need an IP
* New IP Addresses: Enter 0.0.0.0 as CNAMES do not need an IP
* Environment:
* Change Number: Your RFC number for a production change. (Not needed for Test)
* Additional Information: Enter a note here about setting this up as a CNAME and not an Alias.  *Please setup "DNS Name" as a CNAME to "Ingress DNS Name".* "DNS Name" should be your something.nwie.net DNS name and "Ingress DNS Name" should be the DNS something.apps.aws.e1.nwie.net name.

Here is an example for an external DNS names.
![move external cname](/docs/cnp/images/sn-move-external-cname.png)

Finally add the item to your cart and finish the checkout process.

### Delete - Alias from IP address

* Alias: The left most part of your DNS name you want to remove.
* Domain Name: The right most part of your DNS name you want to remove.
* IP Address: Enter 0.0.0.0 as CNAMES do not need an IP
* Reason for Change: Provide a brief explanation.
* Environment: Select, as appropriate. Prod and Test requests can't be grouped.
* Change Number: Your RFC number for a production change. (Not needed for Test)
* Number of Objects Affected: 1 per alias being removed. Make sure you note additional aliases in the additional info section if multiples are being removed.
* Additional Information: Enter a note here about setting this up as a CNAME and not an Alias.  *Please setup "DNS Name" as a CNAME to "Ingress DNS Name".* "DNS Name" should be your something.nwie.net DNS name and "Ingress DNS Name" should be the DNS something.apps.aws.e1.nwie.net name.

Finally add the item to your cart and finish the checkout process.

## External applications

External applications will need to expose their services via an AWS Load Balancer.
More on this is documented [here](/docs/cnp/ingress/ingress-alb).
