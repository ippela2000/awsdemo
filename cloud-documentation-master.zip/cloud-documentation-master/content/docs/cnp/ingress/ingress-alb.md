---
title: Ingress ALB
menu: docs
category: cnp
---

## About

In order to meet security requirements for Internet accessible web applications at AWS, an Application Load Balancer ([ALB](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/application-load-balancer-getting-started.html)) with a Web Application Firewall ([WAF](https://aws.amazon.com/waf/getting-started/)) must be used. An ingress controller that creates and configures ALBs has been installed in the cluster.
More detailed documentation on the controller is [here](https://kubernetes-sigs.github.io/aws-alb-ingress-controller/).
There currently no solution for Internet accessible non-web applications. Please let us know if this is needed.

### Ingress controller

To use the ALB Ingress Controller, create an Ingress object with the annotation **kubernetes.io/ingress.class** set to **alb**. A full example is shown below.
The **service** that will be load balanced needs to be configured to expose a NodePort.
Finally, if the ALB will be listening on port 443, the required certificates must be in Amazon Certificate Manager (ACM). How to accomplish the is detailed below.

## Required annotations

There are a few required annotations for the ALB controller. (See [this document](https://kubernetes-sigs.github.io/aws-alb-ingress-controller/guide/ingress/annotation/) for a better understanding.)

The annotation **kubernetes.io/ingress.class** must be set to **alb**.

```yaml
kubernetes.io/ingress.class: alb
```

The annotation **alb.ingress.kubernetes.io/listen-ports** specifies the ports that ALB used to listen on. For example,

```yaml
alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
```

The annotation **alb.ingress.kubernetes.io/scheme**  specifies whether your LoadBalancer will be internet facing. See Load balancer scheme in the [AWS documentation](http://docs.aws.amazon.com/elasticloadbalancing/latest/userguide/how-elastic-load-balancing-works.html#load-balancer-scheme) for more details. Its default is to create ALBs in the internal zone. For example,

```yaml
alb.ingress.kubernetes.io/scheme: internet-facing
```

The annotation **alb.ingress.kubernetes.io/security-groups** needs to be set to cluster specific security group. The correct **alb.ingress.kubernetes.io/security-groups** will be added based on which cluster you are running in if left off.

| Cluster | Security Group |
|---------|----------------|
| dev     | dev_alb_sg     |
| test    | test_alb_sg    |
| test03  | test03_alb_sg  |
| prod    | prod_alb_sg    |
|---------|----------------|

For example,

```yaml
alb.ingress.kubernetes.io/security-groups: test_alb_sg
```

The annotation **alb.ingress.kubernetes.io/ssl-policy** needs to be set. The later date that the ssl-policy is, the more secure it is. Please refer to [this document](https://docs.aws.amazon.com/elasticloadbalancing/latest/application//create-https-listener.html#describe-ssl-policies) for more information. For example,

```yaml
alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-FS-2018-06
```

The **alb.ingress.kubernetes.io/tags** should be set to a comma separated list with `DisbursementCode`, `ResourceOwner` and `APRMID`. The `DisbursementCode` and `ResourceOwner` will be read from your namespace labels if not set. For example,

```yaml
alb.ingress.kubernetes.io/tags: "DisbursementCode=123456001,ResourceOwner=example,APRMID=1234"
```

The annotation **alb.ingress.kubernetes.io/waf-acl-id** needs to be set to cluster specific **WAF**. The correct **alb.ingress.kubernetes.io/waf-acl-id** will be added based on which cluster you are running in if left off.

| Cluster | WAF ACL ID |
|---------|------------|
| dev     | e04ae4d0-79a0-4bb3-8505-8e28601271e6 |
| test    | 3300039d-63e1-4ae4-a29a-9c25317bd8dd |
| test03  | 154dafdf-98c5-4c25-8c3e-888274d4e6bc |
| prod    | 5d87c213-a534-4ad6-b42c-d5d5e2c1a033 |
|---------|------------|

For example, for kubernetes test cluster,

```yaml
alb.ingress.kubernetes.io/waf-acl-id: 3300039d-63e1-4ae4-a29a-9c25317bd8dd
```

The annotation **alb.ingress.kubernetes.io/certificate-arn** needs to be set after your certificate is installed by the **Cloud Platform Team**. (Please read the `Certificates` section for details). For example,

```yaml
alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:us-east-1:012345678901:certificate/abcdefgh-ijkl-mnop-qrst-uvwxyz123456
```

The annotation **aalb.ingress.kubernetes.io/backend-protocol** needs to be set to HTTPS as Nationwide has a requirement to encrypt all traffic. Ingresses without this setting will be rejected by an admission controller. The `Certificates` documentation has examples on how to inject an SSL certificate into your container to enable SSL by default. For example,

```yaml
alb.ingress.kubernetes.io/backend-protocol: HTTPS
```

Additional available annotations are documented in the `Customizing Ingress` section.

### Example ingress

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  name: demo-app
  annotations:
    kubernetes.io/ingress.class: alb
    ## Default is listen on only port 80.
    ## when you initially apply the ingress you can only have '[{"HTTP": 80}]' if you want it to create an amazonaws.com url
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP": 80}, {"HTTPS": 443}]'
    ## Default is to create ALBs in the internal zone.
    ## alb.ingress.kubernetes.io/scheme: internet-facing
    ## The security-groups setting is required. test_alb_sg, prod_alb_sg
    ## alb.ingress.kubernetes.io/security-groups: test_alb_sg
    ## Set TLS policy. Docs: https://docs.aws.amazon.com/elasticloadbalancing/latest/application/create-https-listener.html#describe-ssl-policies
    alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-FS-2018-06
    alb.ingress.kubernetes.io/tags: "DisbursementCode=123456001,ResourceOwner=example,APRMID=1234"
    ## The waf-acl-id annotation is required
    ## Dev: e04ae4d0-79a0-4bb3-8505-8e28601271e6
    ## Test: 3300039d-63e1-4ae4-a29a-9c25317bd8dd
    ## Prod: 5d87c213-a534-4ad6-b42c-d5d5e2c1a033
    ## alb.ingress.kubernetes.io/waf-acl-id: SEE TABLE ABOVE
    ## Certificate ARN is needed when autodiscovery does not work.
    #alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:us-east-1:012345678901:certificate/abcdefgh-ijkl-mnop-qrst-uvwxyz123456
    ## Enable HTTPS to the backend POD so traffic is encrypted everywhere
    alb.ingress.kubernetes.io/backend-protocol: HTTPS
    # alb.ingress.kubernetes.io/healthcheck-protocol: HTTPS

spec:
  tls:
  - hosts:
    - "example.nationwide.com"
    - "example.awspubliccloud.nationwide.com"
  rules:
  - host: "example.nationwide.com"
    http:
      paths:
      - backend:
          serviceName: demo-app
          servicePort: 8443
  - host: "example.awspubliccloud.nationwide.com"
    http:
      paths:
      - backend:
          serviceName: demo-app
          servicePort: 8433
```

### Example service

Your type need to be `NodePort` and not `ClusterIP` for the ALB to be able to route traffic to it.

```yaml
apiVersion: v1
kind: Service
metadata:
  name: demo-app
  labels:
    app: demo-app
spec:
  ports:
    - name: https
      port: 8443
  selector:
    app: demo-app
  type: NodePort
```

### Customizing ingress

The Ingress can be customized by adding annotations. These annotations are documented [here](https://kubernetes-sigs.github.io/aws-alb-ingress-controller/guide/ingress/annotation/).

Common annotations

| Annotations                                     | Value             | Description                     |
| ----------------------------------------------- | ----------------- | ------------------------------- |
| alb.ingress.kubernetes.io/actions.ssl-redirect  | {"Type": "redirect", "RedirectConfig": { "Protocol": "HTTPS", "Port": "443", "StatusCode": "HTTP_301"}} | Redirect http to https |
| alb.ingress.kubernetes.io/healthcheck-path      | /                 | ALB health check path           |

### DNS names

Kubernetes is able to register DNS names under awspubliccloud.nationwide.com.
If your application should be reachable at example.nationwide.com you will also
want to configure example.awspubliccloud.nationwide.com. This way
kubernetes can configure the DNS entry to point to the random
ALB AWS DNS name. A DNS request via Service Now will need to be done
in order to have example.nationwide.com point to example.awspubliccloud.nationwide.com
via a CNAME.  This way if the AWS ALB is ever deleted and then recreated
kubernetes can manage the DNS names for you with zero human interaction
to update example.nationwide.com.

## Certificates

Currently, the **Cloud Platform** team will manually add the appropriate certificates to **ACM** in our accounts (cloud platform team account, such as kubernetes test cluster account or prod account), by request. If the **ARN** for the certificate is needed for your application, we can provide it. The workflow is described below.

* When you need a certificate for a public facing site, submit a [ServiceNow request](https://nwproduction.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3Df666b2e70f17ce00085d6509b1050e68%26sysparm_link_parent%3Dcb8d9b290f1f7100a5eee478b1050e65%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default%26sysparm_view%3Dtext_search) for a new or existing certificate. See [SSL Public Certificates](/docs/aws/cryptography/howto-publiccert/) for more information. Include the following information in the request:
  * Provide the domain name (DNS) that you need a certifcate for. For example, `example.nationwide.com`.
  * Request a `.pem` file in the return email.

* Once you get `.pem` file from [**IAM-Support-Identity** team](https://whoville.apps.aws.e1.nwie.net/workforce/teams/2201819278036960660/people), you will attach the `.pem` file(s) and email **Cloud Platform** team at `cloud-platform@nationwide.com`. (Do not send more information than that, someone will message you separately for the password they might need.)

* After the **Cloud Platform** team installed your `.pem` file successfully, they will notify you and provide you the `ARN` which you will use it to set your annotation **alb.ingress.kubernetes.io/certificate-arn** in your ingress file. For example,

```yaml
alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:us-east-1:012345678901:certificate/abcdefgh-ijkl-mnop-qrst-uvwxyz123456
```

## Sticky sessions

In order to configure sticky sessions for an ALB three things need to be taken into account.
The ALB needs to have sticky sessions enabled, the service needs to route to correct
pod and you need to make sure there is also only a single pod per node for the application.

Your application should still be configured with session backend however that is outside
the scope of Kubernetes and this documentation.

### Sticky sessions ALB

To enable sticky sessions on the ALB add the **alb.ingress.kubernetes.io/target-group-attributes** annotation
with the **stickiness.enabled** option set to true. The **stickiness.lb_cookie.duration_seconds**
option should also be specified to configure the lifetime of the cookie used to track stickiness.
The **lb_cookie.duration_seconds** setting should match your session timeout in the application.

```yaml
apiVersion: extensions/v1beta1
kind: Ingress
metadata:
  annotations:
    alb.ingress.kubernetes.io/target-group-attributes: stickiness.enabled=true,stickiness.lb_cookie.duration_seconds=360
...
```

The AWSALB cookie used to track stickiness will have it's value
updated with every request. This is by design because of how it
is encrypted and does not mean the stickiness is not working.

### Sticky sessions service

Enabling stickly sessions on the ALB will cause it to always route traffic to the same node in the cluster.
However the ALB is pointed to a Kubernetes Service of type NodePort which is a layer 4
loadbalancer and by default will loadbalance to the application pods which causes the
sticky session from the ALB to be invalidated.  Kubernetes services do support
layer 4 stickiness however it is based on client IPs which in this case is the
ALB so that can not be used.  However if the Service's **externalTrafficPolicy**
is set to **Local** the Service will only run on the nodes the pod is running
on and route traffic to the local pod by default.  So as long as there is only
one pod for that application on the node sticky sessions from the ALB will
be honored.

Example Service

```yaml
apiVersion: v1
kind: Service
metadata:
  name: demo-app
  labels:
    app: demo-app
spec:
  externalTrafficPolicy: Local
  ports:
    - name: http
      port: 8080
  selector:
    app: demo-app
  type: NodePort
```

When switching over to a Local externalTrafficPolicy make sure you tune your
ALB health checks. Pods can move around if something happens with a node
and you don't want the ALB to take too long to see where the pod is running.

### Sticky sessions pod antiAffinity

Here is an example Pod AntiAffinity rule which will not
schedule more than one pod on a node for an application.

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: demo-app
spec:
  selector:
    matchLabels:
      app: demo-app
  replicas: 3
  template:
    metadata:
      labels:
        app: demo-app
    spec:
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchExpressions:
                - key: app
                  operator: In
                  values:
                  - demo-app
              topologyKey: kubernetes.io/hostname
...
```

## DNS setup

This is the last step for your ALB ingress setup. After you deployed your app to kubernetes cluster, running `kubectl describe ingress <name>` on the ingress will give you the AWS DNS name assigned to the load balancers, shown on the `Address` line. This is the name that would be used in a **ServiceNow Request** (See **Service Now Request** section) to the DNS team to set an alias from the Nationwide name to your load balancer.

Example output from running `kubectl describe ingress albdemo`

```shell
Name:             albdemo
Namespace:        xaxxon
Address:          12345678-xaxxon-albdemo-abcd-1234567890.us-east-1.elb.amazonaws.com
```

### ServiceNow request

* Login to **Service Now** by browsing to [https://nwproduction.service-now.com](https://nwproduction.service-now.com). `DNS` requests can be found under the Service Catalog by selecting Catalog.
![service now catalog](/docs/cnp/images/sn-catalog-menu.png)

* If you do not see "Add - New Alias" or "Modify - Move Alias to Different Host Name" in choices after selecting Catalog search for "cname" in the search menu.
![service now search](/docs/cnp/images/sn-catalog-search.png)

* Select "Add - New Alias" if this is a completely new DNS name that does not currently resolve.

* Select "Modify - Move Alias to Different Host Name" if you are moving an existing DNS name for an application to the Kubernetes Ingress.

### Add - new alias

* Alias: The DNS name you want to register. For example, `example.nationwide.com`
* Host IP Address: Enter 0.0.0.0 as CNAMES do not need an IP.
* Environment: `Test` or `Prod`
* Domain Names: The DNS name you want to register. For example, `example.nationwide.com`
* Change Number: Your RFC number for a Production change. (Not needed for Test)
* Effective Date: Date you want the change to happen.  Leave blank for ASAP.
* Additional Information: Enter a note here about adding a new Alias to a CNAME.

 For example,

`Please add Alias "example.nationwide.com" to CNAME "example.awspubliccloud.nationwide.com"`

Finally add the item to your cart and finish the checkout process.

### Modify - Move alias to different host name

Refer to the [Ingress Routing page](../ingress-default/).

## Troubleshooting

Refer to the [Troubleshooting page](../../troubleshooting).
