---
title: Load Balancers
menu: docs
category: cnp
---

## AWS load balancers

A single Load Balancer costs ~$18/month (minimum) (data charges are a bonus)!

* $0.025 per Classic Load Balancer-hour (or partial hour)
* $0.008 per GB of data processed by a Classic Load Balancer

Our platform can provision AWS Load Balancers to expose your pods. [This document](https://kubernetes.io/docs/concepts/cluster-administration/cloud-providers/#load-balancers) describes the capability and annotations required to expose a service. While the documentation describes options to use NLB's, the feature is in alpha and does not work properly in our multizone environment. Stick with TCP,SSL (Layer 4) and HTTP(S) (Layer 7) Classic ELB's at this time.

### External load balancers (The default)

Service of type LoadBalancer are exposed to the Internet by default. To prevent
applications from exposing data to the internet by accident an admission
controller has been installed to reject Internet Load Balancers.

Currently all external applications should configure an
[ALB Ingress](/docs/cnp/ingress/ingress-alb/)
instead of using an ELB.  The ALB Ingress controller will create
an AWS Application Load Balancer with a security WAF attached to it.
The ALB can only handle HTTP and HTTPS traffic. If you need to expose
some other type of traffic to the internet you will need to follow
an exception policy.

TODO: Document policy. Send email to [cloud-platform](mailto:cloud-platform@nationwide.com) for now.
NOTE: The rules for external load balancers are not set in stone.  Please
ask questions in the #cloud-native-platform Rocket Chat channel or email
[cloud-platform](mailto:cloud-platform@nationwide.com).

### Required specs

AWS Load Balancers will create a security group that controls access to the
ELB.  Kubernetes uses the spec.loadBalancerSourceRanges when building the
security group. Please specify the source range for users who will need
access to the ELB.

**10.0.0.0/8** will cover most internal IPs at Nationwide.

```yaml
apiVersion: v1
kind: Service
metadata:
  name: myapp
spec:
  ports:
    - port: 8765
      targetPort: 9376
  selector:
    app: example
  type: LoadBalancer
  loadBalancerSourceRanges:
  - 10.0.0.0/8
```

**0.0.0.0/0** Is only valid for Internet facing ELBs.

### Required annotations

Services of type LoadBalancer are required to have a few annotations on them.

**service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags** is
required to be on all Load Balancers.  It should be a comma separated list
with DisbursementCode, ResourceOwner and APRMID.

```yaml
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags: "DisbursementCode=123456001,ResourceOwner=example,APRMID=1234"
```

The DisbursementCode and ResourceOwner tags will be read from your namespace labels
and added to the **service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags**
tag if they are missing from the request.

### Load balancers vs. ingress routing

The primary motivation for using a load balancer is to segment high volume applications from each other. It is unrealistic to have a single load balancer handle all traffic for a large enough application. Ingress routing is a great alternative but it only handles HTTP based traffic. Use a load balancer if you need to expose something like a database connection for external applications to consume or if you have high performance requirements. There's no magic threshold for using one over the other. Test your applications performance and decide what best suites your needs.

Why use ingress then? LB's are cool right? The ingress option is cheap, easy and works for most web based use cases. It is highly recommended to use ingress routing for dev/test workloads where applicable. Ingress routing is also available in the production cluster and can be used for production applications depending on your availability requirements. Ingress routing will scale as the cluster scales because its created by a DaemonSet on all nodes of the cluster acting as a reverse proxy to your pods. [Checkout the Ingress docs to learn more](/docs/cnp/ingress/ingress-default/)

### ELB classic example

```yaml
apiVersion: v1
kind: Service
metadata:
  name: rocketchat-lb
  namespace: dpt
  labels:
    app: rocketchat
    aprmid: 7338
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-ssl-cert: "arn:aws:acm:us-east-1:405507766639:certificate/16dd04c5-2974-4d04-a3d6-5ce9254e1e89"
    service.beta.kubernetes.io/aws-load-balancer-ssl-ports: "443"
    service.beta.kubernetes.io/aws-load-balancer-ssl-negotiation-policy: "ELBSecurityPolicy-TLS-1-2-2017-01"
    service.beta.kubernetes.io/aws-load-balancer-backend-protocol: tcp
    service.beta.kubernetes.io/aws-load-balancer-cross-zone-load-balancing-enabled: "true"
    service.beta.kubernetes.io/aws-load-balancer-internal: "0.0.0.0/0"
    # Extra AWS tags added to the Load Balancer, DO NOT FORGET!
    service.beta.kubernetes.io/aws-load-balancer-additional-resource-tags: "DisbursementCode=123456001,ResourceOwner=example,APRMID=1234"
    service.beta.kubernetes.io/aws-load-balancer-access-log-enabled: "true"
    service.beta.kubernetes.io/aws-load-balancer-access-log-emit-interval: 5
    service.beta.kubernetes.io/aws-load-balancer-access-log-s3-bucket-name: cnp-rocketchat-elb-logs
    service.beta.kubernetes.io/aws-load-balancer-access-log-s3-bucket-prefix: logs/test
spec:
  type: LoadBalancer
  # uncomment if you want to restrict the access to allowed IPs
  #  loadBalancerSourceRanges:
  #  - x.x.x.x/32
  ports:
  - port: 443
    targetPort: 3000
    protocol: TCP
  selector:
    role: rc-web # Selector for the RocketChat web instances
  loadBalancerSourceRanges:
  - 10.0.0.0/8
```

## DNS

The ability to register DNS names under aws.e1.nwie.net is enabled for internal load balancers. It is as simple as adding an annotation to your Service.

```yaml
  annotations:
    external-dns.alpha.kubernetes.io/hostname: sample-lb.aws.e1.nwie.net,sample-lb2.aws.e1.nwie.net
    external-dns.alpha.kubernetes.io/ttl: "10"
```

* **external-dns.alpha.kubernetes.io/hostname** annotation takes a comma separated list of DNS names to register.  The DNS names must be under the .aws.e1.nwie.net, cp.nwie.net or apps.nwie.net Domain.
* **external-dns.alpha.kubernetes.io/ttl** annotation lets you to customize the DNS records Time to Live.

### DNS notes

The extneral DNS provisioner will not touch records created outside of it's cluster.  If you register bob.aws.e1.nwie.net in the test cluster and in the prod cluster the first cluster to create it will control the record till it is deleted by that cluster.
