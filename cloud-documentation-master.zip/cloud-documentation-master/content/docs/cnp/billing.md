---
title: Billing
menu: docs
category: cnp
---

## Cloudability

You can use Cloudability to track charges in the platform.

Make a ServiceNow request to the Cloud Optimization Services team to get access to see container cost allocations in our Kubernetes clusters.
[This doc describes how to get access to Cloudability.](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/_layouts/15/doc2.aspx?sourcedoc=%7BF6BB7AFB-0FCD-4A5E-883C-771736772B35%7D&file=Submit%20Ticket%20to%20Cloud%20Optimization%20Services%20using%20SNOW.docx&action=default&mobileredirect=true&cid=c60ffb26-ffba-4842-8b33-47a6f5b52dc9)

## Disbursement codes

You must specify disbursement code when you onboard to the cluster.  Cloudability will use that code to provide a chargeback to your BSA. If you want to create multiple namespaces for access control and cost accounting, that's a valid pattern too. You will specify the disbursement code as a label on the namespace, and you can look it up with a `kubectl get namespace NAME -o yaml`. If you need to change your disbursement code, update the value in your team's [cnp-caas-config](https://github.nwie.net/Nationwide/cnp-caas-config) file.

### Override disbursement codes

If you need to specify a different disbursement code instead of the default on the namespace, you can add a `DisbursementCode` label to your pod
and Cloudability will use that code for billing instead of the namespace one.

## APRMID

If you want to track costs at the application level, you will need to also add a `APRMID` label to your pods. This will allow you to filter your charges beyond the disbursement code level. **The production Kubernetes cluster requires the APRMID label.**

## Cost estimator

This tool will try to help you estimate how much it will cost to run a container. Your Kubernetes requests determines your minimum bill. This is because requests reserve an amount of CPU/memory that no one else can use, so you will receive a bill for it even if you do not use it. Limits affect your max bill, as they control the highest amount of resources your container will use.

These are estimates and will not reflect your bill exactly. This is because Cloudability also includes network and storage costs, which make up 15% of the Cloudability weight for your bill. Cloudability also includes total idle spend, which we can not estimate. We are also working on tuning the formula to more closely match Cloudability.

<table id="resource_table">
  <thead>
      <tr>
      <th></th>
      <th colspan="2">Requests</th>
      <th colspan="2">Limits</th>
    </tr>
    <tr>
      <th>Replicas</th>
      <th>CPU</th>
      <th>Memory</th>
      <th>CPU</th>
      <th>Memory</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align: center">
        <select id="replicas" name="replicas" required="true" onchange="update_costs()">
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="4">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
            <option value="9">9</option>
            <option value="10">10</option>
            <option value="11">11</option>
            <option value="12">12</option>
            <option value="13">13</option>
            <option value="14">14</option>
            <option value="15">15</option>
        </select>
      </td>
      <td style="text-align: center">
        <select id="cpu_request" name="cpu_request" required="true" onchange="update_costs()">
            <option value=".01">10m</option>
            <option value=".1">100m (.1 cpu)</option>
            <option value=".2">200m (.2 cpu)</option>
            <option value=".3">300m (.3 cpu)</option>
            <option value=".4">400m (.4 cpu)</option>
            <option value=".5">500m (.5 cpu)</option>
            <option value=".6">600m (.6 cpu)</option>
            <option value=".7">700m (.7 cpu)</option>
            <option value=".8">800m (.8 cpu)</option>
            <option value=".9">900m (.9 cpu)</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="3">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
        </select>
      </td>
      <td style="text-align: center">
        <select id="memory_request" name="memory_request" required="true" onchange="update_costs()">
            <option value="128">128M</option>
            <option value="256">256M</option>
            <option value="512">512M</option>
            <option value="768">768M</option>
            <option value="1024">1G</option>
            <option value="1536">1.5G</option>
            <option value="2048">2G</option>
            <option value="2560">2.5G</option>
            <option value="3072">3G</option>
            <option value="4096">4G</option>
            <option value="5120">5G</option>
            <option value="6144">6G</option>
            <option value="8192">8G</option>
            <option value="10240">10G</option>
            <option value="20480">20G</option>
            <option value="30720">30G</option>
            <option value="40960">40G</option>
        </select>
      </td>
      <td style="text-align: center">
        <select id="cpu_limit" name="cpu_limit" required="true" onchange="update_costs()">
           <option value=".01">10m</option>
            <option value=".1">100m (.1 cpu)</option>
            <option value=".2">200m (.2 cpu)</option>
            <option value=".3">300m (.3 cpu)</option>
            <option value=".4">400m (.4 cpu)</option>
            <option value=".5">500m (.5 cpu)</option>
            <option value=".6">600m (.6 cpu)</option>
            <option value=".7">700m (.7 cpu)</option>
            <option value=".8">800m (.8 cpu)</option>
            <option value=".9">900m (.9 cpu)</option>
            <option value="1">1</option>
            <option value="2">2</option>
            <option value="3">3</option>
            <option value="3">4</option>
            <option value="5">5</option>
            <option value="6">6</option>
            <option value="7">7</option>
            <option value="8">8</option>
        </select>
      </td>
      <td style="text-align: center">
        <select id="memory_limit" name="memory_limit" required="true" onchange="update_costs()">
            <option value="128">128M</option>
            <option value="256">256M</option>
            <option value="512">512M</option>
            <option value="768">768M</option>
            <option value="1024">1G</option>
            <option value="1536">1.5G</option>
            <option value="2048">2G</option>
            <option value="2560">2.5G</option>
            <option value="3072">3G</option>
            <option value="4096">4G</option>
            <option value="5120">5G</option>
            <option value="6144">6G</option>
            <option value="8192">8G</option>
            <option value="10240">10G</option>
            <option value="20480">20G</option>
            <option value="30720">30G</option>
            <option value="40960">40G</option>
        </select>
      </td>
    </tr>
  </tbody>
</table>


<table id="cost_table">
  <thead>
    <tr>
      <th colspan="2">Hourly</th>
      <th colspan="2">Daily</th>
      <th colspan="2">Monthly</th>
    </tr>
    <tr>
      <th>Min Cost</th>
      <th>Max Cost</th>
      <th>Min Cost</th>
      <th>Max Cost</th>
      <th>Min Cost</th>
      <th>Max Cost</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td style="text-align: center">0</td>
      <td style="text-align: center">0</td>
      <td style="text-align: center">0</td>
      <td style="text-align: center">0</td>
      <td style="text-align: center">0</td>
      <td style="text-align: center">0</td>
    </tr>
  </tbody>
</table>

<script>

function update_costs(){
    console.log("Entering update_costs");

    // Hardcode values for r5 instances till we need to support more than one type
    // .504 is base cost
    // .4032 is %20 off base cost for reserved instance costs
    var r5Cost = .4032
    var r5Cpus = 8
    var r5Memory = 64681

    // Put in html items we need real values from
    var costTable = document.getElementById('cost_table');
    var replicasSelect = document.getElementById("replicas");
    var cpuRequestSelect = document.getElementById("cpu_request");
    var memoryRequestSelect = document.getElementById("memory_request");
    var cpuLimitSelect = document.getElementById("cpu_limit");
    var memoryLimitSelect = document.getElementById("memory_limit");

    // console.log(replicasSelect);
    // console.log(cpuRequestSelect);
    // console.log(memoryRequestSelect);
    // console.log(cpuLimitSelect);
    // console.log(memoryLimitSelect);

    // Get all current drop down values
    var replicas = replicasSelect.options[replicasSelect.selectedIndex].value;
    var cpuRequest = cpuRequestSelect.options[cpuRequestSelect.selectedIndex].value;
    var memoryRequest = memoryRequestSelect.options[memoryRequestSelect.selectedIndex].value;
    var cpuLimit = cpuLimitSelect.options[cpuLimitSelect.selectedIndex].value;
    var memoryLimit = memoryLimitSelect.options[memoryLimitSelect.selectedIndex].value;

    console.log("replicas=" + replicas);
    console.log("cpuRequest=" + cpuRequest);
    console.log("memoryRequest=" + memoryRequest);
    console.log("cpuLimit=" + cpuLimit);
    console.log("memoryLimit=" + memoryLimit);

    // If if requests are greater than limits update limit drop downs
    if (parseFloat(cpuRequest) > parseFloat(cpuLimit)) {
        console.log("Overriding CPU limit to " + cpuRequest);
        cpuLimitSelect.value = cpuRequest;
        update_costs();
        return;
    }

   if (parseFloat(memoryRequest) > parseFloat(memoryLimit)) {
        console.log("Overriding memory limit to " + memoryRequest);
        memoryLimitSelect.value = memoryRequest;
        update_costs();
        return;
    }

    // Calculate costs
    // CPU is 15% of the costs and memory is 70%
    // This is close to how cloudability does it but not the same as they
    // look at storage and network which no one will know we give more
    // weight to memory in this formula.  We will ignore storage and
    // network
    minCostPerHour = (( r5Cost * .15) * ( cpuRequest/r5Cpus ) + ( r5Cost * .7) * ( memoryRequest/r5Memory )  ) * replicas
    maxCostPerHour = (( r5Cost * .15) * ( cpuLimit/r5Cpus ) + ( r5Cost * .7) * ( memoryLimit/r5Memory )  ) * replicas

    minCostPerDay = minCostPerHour * 24
    maxCostPerDay = maxCostPerHour * 24
    minCostPerMonth = minCostPerDay * 30
    maxCostPerMonth = maxCostPerDay * 30

    costTable.rows[2].cells[0].innerHTML = "$" + minCostPerHour.toFixed(2);
    costTable.rows[2].cells[1].innerHTML = "$" + maxCostPerHour.toFixed(2);
    costTable.rows[2].cells[2].innerHTML = "$" + minCostPerDay.toFixed(2);
    costTable.rows[2].cells[3].innerHTML = "$" + maxCostPerDay.toFixed(2);
    costTable.rows[2].cells[4].innerHTML = "$" + minCostPerMonth.toFixed(2);
    costTable.rows[2].cells[5].innerHTML = "$" + maxCostPerMonth.toFixed(2);

}

window.onload = update_costs;
</script>

## Right-sizing your application

### Understanding Requests/Limits

[Kubernetes Doc - Managing Compute Resources for Containers](https://kubernetes.io/docs/concepts/configuration/manage-compute-resources-container/)

For each container, you can specify Requests and Limits for CPU and Memory.

**Requests** - how much CPU/Memory Kubernetes reserves on the node for the container. No other process can use this reserved CPU/Memory.

If a container exceeds its memory request, Kubernetes may evict the pod if the node runs out of memory.

**Limits** - hard quotas that your container cannot exceed. If a container exceeds its memory limit, Kubernetes will OOM Restart the pod, which may cause an application disruption.

The system enforces the CPU quota at the scheduler level, so the process gets throttled at the CPU limit. Kubernetes will not kill the pod for excessive CPU usage, but will throttle the pod at its CPU limit.

Setting a proper resource request will guarantee that your application has the resources it needs to run.  Set the request too high, and you will pay for wasted resources that are sitting idle.

### Default Requests/Limits

If you do not specify resource requests or limits, default requests/limits will apply.  You can see what your defaults are by making sure that you are in your namespace, and then running:

```bash
kubectl get limitrange -o yaml
```

## Rightsizing Tools

You can use the following tools to help understand what resources your pods are using.  After understanding what they are using under average load, you can more appropriately tune your containers' requests/limits appropriately.

### New Relic

[Cluster Explorer](https://infrastructure.newrelic.com/accounts/1092591/kubernetes?cluster=prod)  

1. Filter on Cluster, Namespace,and Deployment  
![Cluster Explorer ScreenCap](/docs/cnp/images/new-relic-cluster-explorer.png)

2. Pods will show up as hexagons on the wheel.  Click on one of the pods to view details.
![Cluster Explorer ScreenCap](/docs/cnp/images/new-relic-cluster-explorer-podDetail.png)  
**Blue Line** - Shows current usage over time  
**Yellow Line** - Shows Request setting  
**Red Line** - Shows Limit setting  

The average usage and request lines should be very close, and the limit should be set somewhat higher, allowing your application to use more resources for a short period of time if needed.

[Kubernetes Dashboard](https://infrastructure.newrelic.com/accounts/1092591/integrations/onHostIntegrations/accounts/5/kubernetes/dashboard)  
You can get more historical data from the kubernetes dashboard.  You can filter by cluster and many other keys at the top of the page.

### Grafana

Grafana for All Kubernetes Clusters - [https://dash.cp.nwie.net](https://dash.cp.nwie.net)

Grafana is a graphing tool allows you to see detailed usage information about your pods/deployments over time.  Within each of these of these dashboards, you can filter on cluster and namespace to view your deployments.

* [Kubernetes / Compute Resources / Cluster](https://dash.cp.nwie.net/d/efa86fd1d0c121a26444b636a3f509a8/kubernetes-compute-resources-cluster)
* [Kubernetes / Compute Resources / Namespace (Pods)](https://dash.cp.nwie.net/d/85a562078cdf77779eaa1add43ccec1e/kubernetes-compute-resources-namespace-pods)
* [Kubernetes / Compute Resources / Namespace (Workloads)](https://dash.cp.nwie.net/d/a87fb0d919ec0ea5f6543124e16c42a5/kubernetes-compute-resources-namespace-workloads)
* [Kubernetes / Compute Resources / Pod](https://dash.cp.nwie.net/d/6581e46e4e5c7ba40a07646395ef7b23/kubernetes-compute-resources-pod)
* [Kubernetes / Compute Resources / Workload](https://dash.cp.nwie.net/d/a164a7f0339f99e89cea5cb47e9be617/kubernetes-compute-resources-workload)

### Goldilocks

If your pod is currently taking traffic and is running at a normal capacity, Goldilocks can recommend requests/limits for you to set.  It looks at current usage to provide a recommendation for requests/limits.

| Cluster | Goldilocks Address |
|---|---|
| Dev AWS | [https://goldilocks.apps-dev.aws.e1.nwie.net/](https://goldilocks.apps-dev.aws.e1.nwie.net/) |
| Test AWS | [https://goldilocks.apps-test.aws.e1.nwie.net/](https://goldilocks.apps-test.aws.e1.nwie.net/) |
| Prod AWS | [https://goldilocks.apps.aws.e1.nwie.net/](https://goldilocks.apps.aws.e1.nwie.net/) |

When viewing a deployment, there are two sets of numbers, Guaranteed and Burstable:

* **Guaranteed** — means Kubernetes will schedule the application on a node where the resources are available.
* **Burstable** — means Kubernetes will guarantee the application a minimum level of resources but will give more if and when available.
