---
title: "Getting Started"
description: "New to your cloud journey? Start off on the right foot by viewing our getting started guide to get set up with access, tutorials, and more!"
weight: 1
draft: false
menu: docs
---


Hello!

We're thrilled that you're considering moving to the cloud.

Below is a guide to the different sections on GoCloud to help your development and implementation work in the Cloud.

* [Getting-Started-With-AWS](/docs/aws/getting-started-with-aws/) you will find how-to and other documentation which will help as you migrate you your application  to help you understand cost.

* [Getting-Started-With-CNP](/docs/cnp/getting-started-with-cnp) contains documentation on how to get access to, and begin working with, the Cloud Native Platform at Nationwide.

* [Getting-Started-With-DevOps](https://devops-portal-ui.apps.aws.e1.nwie.net/) has the DevOps field guide which has the details on how to get access and use the DevOps tools at Nationwide.

* [Getting-Started-with-Application-Migration](/solutions/migration/self-service-diagnostics)

* [Learning](/learning/) contains role-based learning modules to help you learn the basics of cloud or further refine your skillset and expertise.

* [Approved Products Platforms and Services](/docs/aws/products/) has a comprehensive list of all the products in AWS that are currently approved for use in Nationwide.

* [Docs-AWS](/docs/aws) you will find how-to/technical documentation with details on how to use the different AWS services at Nationwide.

* [Docs-CNP](/docs/cnp) you will find how-to/technical documentation and tutorails on implementing Containers at Nationwide.

* [Solutions](/solutions/) has resources to help you start and accelerate your cloud migration, architectural statement of direction and patterns for new cloud development.

* [Support](/support/) contains links to our news channels, release notes, community resources, and avenues for support and help.


Good luck in your cloud journey! 
