---
title: Personal Access Tokens for Code Pipeline
menu: docs
category: general
---

To get Github personal access tokens from a repository for Code Pipeline:

1. Go to github.nwie.net and be logged in.
2. Click  on the icon on the far right of the black bar accross the top of the screen (your profile avatar).
3. In the drop down that appears click on "Settings".
4. On this page click "Developer Settings", the bottom option on the left side of the screen.
5. On this page click "Personal Access Tokens", the bottom option on the left side of the screen.
6. Click "Generate New Token" in the upper right corner of the page.
7. Enter your Github credentials on this page.
8. Enter a brief description of the token's purpose in the description box at the top of the page.
9. Check off the options for **"repo"** and **"admin:repo_hook"**.
10. Click "Generate Token" at the bottom of the page.
11. Copy your new personal access token.

## MAKE SURE THIS TOKEN IS SAVED SOMEWHERE SECURE, YOU WILL NOT BE ABLE TO SEE IT AGAIN.
