---
title: Troubleshooting apps in AWS
permalink: /docs/aws-docs/aws-troubleshooting/
---

More details coming soon on where to check each of these items.

Things to check in AWS:
 - Are the instances turned on in AWS?
 - Did someone redeploy the application and not include DNS name information? Application infrastructure and instance ID's change with deployments and autoscaling groups.
 - Are the security groups correct on all of your instances?
 -  What kind of errors are the application showing? Database connectivity issues, 500 errors, 400 errors, etc.
 - Is the application having issues talking with a database on*prem? If so Networking should be involved to check Firewalls on*prem to make sure connections are open.
 - Is the same issue happening in Dev/Test?
 - When was the last code release/deployment?
 - When was the last time the pipeline ran to deploy to the environments?
 - Check Splunk for AWS logs, and New Relic APM and Infra for any data that could point to what is happening.
 - Are the instance sizes correct? Does New Relic show high CPU/Memory? Do the instance sizes need increased? Should these servers be in an auto scaling group to fix this issue?
 - Have you tried redeploying your application to all environments? If an update was recently pushed have you tried reversing the change in github and redeploying your application?
Did the application autoscale and connection information change?

