---
title: CloudWatch to ServiceNow tickets
draft: false
menu: docs
---
 

### CloudWatch Alarms

CloudWatch alarms can be created to trigger based on metrics in your AWS account. Example alarms could trigger off of a Lambda function failure or EC2 instance high CPU utilization.
CloudWatch alarms can be configured to send alerts to email, text and AWS SNS topics.
[More information of CloudWatch alarms here](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/AlarmThatSendsEmail.html)

### How to integrate CloudWatch Alarms with ServiceNow

1. Create a CloudWatch alarm for an event that you want to open an incident ticket for
2. The contents of the alarm description determine how the incident ticket is created. Alarm descriptions should be formatted as follows:
	* [ServiceNow Configuration Item Name],[Event Severity],[Ticket Severity],[Assignment Group]
	* Example description: ZoomWebServer,WARNING,P4,NSC-ESM-EVENT-MANAGEMENT
3. Have your CloudWatch alarm send a message to SNS topic "CWAlarmServiceNow". Messages will be pulled out of the topic and incidents will be opened in ServiceNow based on the information supplied in the alarm description.
4. BE CAREFULL! This service does not do any throttling of requests. If you set your CloudWatch Alarm metric to be too easily triggered, you may generate hundreds of incidents for your team. 


NOTE: this service is still in Beta, the information it automatically fills out in the ServiceNow ticket is minimal. If you would like to request any new features or report bugs, please add a ticket [here](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new/choose).




