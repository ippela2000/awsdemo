---
title: Monitoring and Alerting
draft: false
menu: docs
---

#  Overview
This initial AWS monitoring and alerting catalog provides broad guidance for enabling monitoring and alerting capabilities throughout Nationwide’s AWS ecosystem. The services are designed to provide: 

- Always on foundational monitoring for critical AWS metrics and events
- Flexible application and infrastructure monitoring enabled at deploy time for BSA's and Application teams
- *A Shift of accountability and responsibility for alert creation and management to the BSA/App teams, with patterns and best practices to jump-start enablement*
- Metrics, logs, and traces that  span end-users, applications, and underlying infrastructure including native AWS services and network transits
- Flexibility to enhance or extend capabilities within the constructs of Nationwide’s cloud governance policies

Table one outlines the initial, foundational monitoring capabilities. The  links provide additional guidance on implementation and optimization.

## Monitoring Capabilities

| Capability                                          | Tool                                                         | Key Services                                                 | Default State (on/off) | Additional Info  |
| --------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ | ----------------------- | ---------------- |
| AWS (native) Service Metrics & Events                     | Cloudwatch                                                   |* AWS service monitoring, alerting (e.g. Cloudwatch Alarms, SNS)<br>* Latency sensitive monitors/alerts High resolution metrics<br>* Forwards metrics to integrated tools (e.g. [New Relic](https://onyourside.sharepoint.com/sites/ESMSystemsMonitoring/SitePages/New%20Relic%20Infrastructure%20Basics.aspx?csf=1&e=sFY2zF "New Relic Infrastructure"))| Basic metrics only, advanced must be enabled & configured  | [Cloudwatch](https://aws.amazon.com/cloudwatch/ "Cloudwatch Info") |
| Application Performance Management (APM)            | New Relic (APM, Browser, Insights)                           |* User Experience Monitoring<br>* Application Performance Monitoring (e.g. middleware/JVM)<br>* Transaction Tracing & error trapping<br>* Correlation across end user, app, and infrastructure metrics | On                      | [Additional Info](https://onyourside.sharepoint.com/:w:/r/sites/newrelic/_layouts/15/Doc.aspx?sourcedoc=%7BA0975310-6B95-484F-8FEF-36B7558D2F2F%7D&file=New%20Relic%20-%20APM%20for%20AWS.docx&action=default&mobileredirect=true "New Relic APM Info") |
| Infrastructure Performance Management (IPM)         | New Relic (Infrastructure)                                   |* OS process and resource monitoring<br>* AWS service metrics     | On                      | [Additional Info](https://onyourside.sharepoint.com/sites/ESMSystemsMonitoring/SitePages/New%20Relic%20Infrastructure%20Basics.aspx?csf=1&e=sFY2zF "New Relic Infrastructure Info")  |
| Log Management & Analytics                          | Splunk Cloud                                                 |* Log collection, retention, search, analyze, monitor<br>* Security incident and event monitoring (SIEM) | On, except for app logs |  [Additional Info](https://onyourside.sharepoint.com/sites/dwbi/splunk "Splunk Info")   |
| Network Performance Management & Diagnostics (NPMD)                | CA Performance Center                                        |* AWS subnet availability & latency (from NW)<br>* DNS & Palo Alto  events & performance<br>* DirectConnect/circuit availability, capacity, and consumption| On                      | Link coming |
| Capacity & Expense Management (CSEM)                | Cloudability                            |* Budgets, Forecasting, & Optimization<br>* Cost comparison and estimation                        | On                      |[Additional Info](/docs/aws/cost/)  |
| RDS| New Relic Infrastructure (AWS RDS Integration)|* Consumption, tracing, performance analysis, etc| On (experimental)                      | [Additional Info](https://onyourside.sharepoint.com/sites/ESMSystemsMonitoring/SitePages/New%20Relic%20Infrastructure%20Basics.aspx?csf=1&e=sFY2zF "New Relic Infrastructure Info")  |
| Oracle Availability & Performance Monitoring | Solarwinds Database Performance Analyzer (DPA) <br>Oracle Enterprise Manager (OEM)|* DPA: Query/transaction performance analysis <br>* OEM: DB availability, currency, configuration| On (for Oracle Pets)                      | Link coming |


*Table 1- Monitoring Catalog*

## Creating Incidents from AWS Alerts

 ServiceNow incident creation can occur in several ways depending on where the alert is generated. Refer to table two below for guidance.

| Capability                                          | Description                                                         | Additional Info| 
| --------------------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ |
| Application Direct                    | Application calls incident API directly                       |[Incident API](https://pages.github.nwie.net/nationwide/enterprise-events-oas/OAS-EnterpriseEventsV1.html "NW Event Management API Info")|
| Cloudwatch Alarms            | Application team configures an alert trigger based on a cloudwatch event or threshold (e.g. CPU threshold, Lambda function fail, etc)                         |[Cloudwatch Alarm](/docs/general/monitoring-alterting/howto_cloudwatch-to-snow/)|
|3rd Party Tool      | 3rd party tool (e.g. New Relic, Splunk, etc) provides pre-configured integration and interface  | Refer to table 1 for guidance by capability/tool     |

*Table 2- AWS Alert & Incident Mechanisms*

Note, the API's integrations referenced in table two actually pass alerts to and thru the enterprise event management platform which provides an opportunity to aggregate, deduplicate, analyze events in near real time, as well as buffer/protect SNOW from event floods.  
Additionally, most monitoring tools provide notification capabilities for generating informational alerts directly to people (e.g. email) and to Nationwide tooling (e.g. RocketChat via webhook), etc. These are beneficial to promote operational awareness but are not to be used in lieu of incident management processes.
