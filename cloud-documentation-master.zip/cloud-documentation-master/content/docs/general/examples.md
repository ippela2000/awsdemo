
---
title: Examples of Implementations
menu: docs
category: general
---

## Overview 

This page has examples of Repositories/instructions of some commonly used AWS Services and Applications

## General
 * [Cloud Solutions AWS Cloudformation examples](https://github.nwie.net/Nationwide/AWS-CloudFormation) 
    
    This has examples of the different Cloudformation of the most commonly used services at nationwide. 
    If you are looking for a CF for an AWS Service that is not listed here, refer to [AWS-sample-templates](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/sample-templates-services-us-west-2.html) 
    
## Storage
 * [S3 example](https://github.nwie.net/kalurk2/s3-example)
 * [FSX Windows example](https://github.nwie.net/Nationwide/sample-fsx-windows)
 * [Example repo used for S3 bucket provisioned for Artifactory](https://github.nwie.net/Nationwide/Artifactory-S3)

## Compute
 * [AWS Instance Scheduler example](https://github.nwie.net/reedg11/aws_scheduler-example)
 * [ALB/ASG Repo example](https://github.nwie.net/Nationwide/LoadBal-ASG-Win)
 * [Simple Windows EC2 with additional D drive example](https://github.nwie.net/Nationwide/simple-win-ec2)

## Application
 * [Linux Tomcat server with Maven install example](https://github.nwie.net/Nationwide/SampleTomcatMaven)
 * [Linux server Node.js example](https://github.nwie.net/Nationwide/SamplePipelineApp)
 * [Javascript sign AWS API request example](https://github.nwie.net/mcbrim4/aws-signature-javascript-test)

## Data
 * [DynamoDB example](https://github.nwie.net/Nationwide/DynamoDB-Example)
 
## Containers
 * [Tomcat Application (NTDQA) implemented in Nationwide Cloud Native Platform](http://github.nwie.net/Nationwide/ntdqa)
 
## Networking & Content Delivery
  ### CloudFront
   * PLDS-SRE App
        - [CloudFront](https://github.nwie.net/Nationwide/PLDS-SRE-AWS-IAC)
        - [Lambda](https://github.nwie.net/Nationwide/PLDS-Servicing-Lambdas)
   * DGS-Sales App
        - [CloudFront](https://github.nwie.net/Nationwide/dgs-sales-life-ui-refresh/tree/develop)
  






