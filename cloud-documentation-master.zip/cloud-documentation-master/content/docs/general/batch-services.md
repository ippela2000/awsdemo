---
title: Workload Automation and Batch Support
menu: docs
category: general
---

### Workload Automation

* CA Workload Automation ESP Edition for job scheduling, event processing, and calendaring job control functions
* Based on on-premise Workload Automation scheduling solution expanded to AWS infrastructure using ESP agents for both Windows and Linux platforms

### Workload Automation Support Requirements

* Support from the Batch 24/7 (B247) team requires the following:
* ServiceNow incidents must be created (can be done using the Netcool API) to alert team of an issue. 
* Runbook documentation detailing actions to be taken must be created. The B247 team has staff available to assist with document creation.
* The B247 team needs access to production infrastructure relating to the workload automation jobs being supported.

### Workload Automation ESP Agent Use Patterns

* Deployment patterns using CA Workload Automation ESP Edition may be found [here](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/workload-management-esp-edition.pdf?csf=1&e=SeucIm)

### Batch Engineering Services

* Deployment patterns continue to be developed for batch and workload automation functions including local scheduling, container and streaming technologies.
* The Workload Automation Engineering Services team invites consultation requests. Please review our [team site]
(https://onyourside.sharepoint.com/sites/BatchApplicationandDataCenterSupport/SitePages/Home.aspx?web=1)

