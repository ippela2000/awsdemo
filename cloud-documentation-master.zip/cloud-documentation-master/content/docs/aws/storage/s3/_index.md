---
category: aws
draft: false
title: "S3"
menu: docs
---
# Amazon S3
Amazon Simple Storage Service (S3) is scalable, high-speed, object-based cloud storage service. S3 is often used for online backup and archiving of data on AWS. The data is stored in buckets as objects. For more information go here [Amazon S3](https://aws.amazon.com/s3/).

Need help accessing your data in S3?
Here are some helpful links:
* [S3 to Athena to Tableau](https://onyourside.sharepoint.com/:w:/r/sites/edo/applications/create_connector/_layouts/15/Doc.aspx?sourcedoc=%7BFF749127-389D-4BB4-9310-449263DDE403%7D&file=Tableau%20S3%20Connection%20Document.docx&action=default&mobileredirect=true)
* [S3 to PowerCenter](https://nest.nwie.net/content/articles/data-informatica-powercenter-s3-connectivity.html)
* [S3 to Paxata](https://onyourside.sharepoint.com/:w:/r/sites/edo/applications/create_connector/_layouts/15/Doc.aspx?sourcedoc=%7B77B96031-1E60-4FDB-9AF4-9FE4B03E4F16%7D&file=S3%20Connector%20How-To.docx&action=default&mobileredirect=true)
* S3 to SPSS (*Coming soon*)
* [S3 to DataBricks](https://onyourside.sharepoint.com/:w:/r/sites/DatabricksatNationwide/_layouts/15/Doc.aspx?sourcedoc=%7B6E90E789-66AA-458F-82C9-9D66226575C8%7D&file=Databricks_AWS-S3_Connection_Testing.docx&action=default&mobileredirect=true&cid=dcefd083-a606-4071-88d4-f75c79a75d0b)
