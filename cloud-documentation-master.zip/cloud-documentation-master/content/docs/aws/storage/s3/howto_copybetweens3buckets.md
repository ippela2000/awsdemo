---
title: Copy files between S3 buckets in different accounts
menu: docs
category: aws
---

#### Copy files between S3 buckets in different accounts with custom KMS encryption with AWS CLI ####

  *  When copying files between S3 buckets the roles have to be properly set for all the resources being used
		*  Source KMS Custom Key
		*  Destination KMS Custom Key
		*  Source S3 bucket
		*  Target S3 bucket
		*  EC2 instance making the transfer

  *  EC2 Policy - The EC2 instance making the transfer should have access to everything since it is the one performing the transfer
		*  Source KMS Custom Key
		*  Destination KMS Custom Key
		*  Source S3 bucket
		*  Target S3 bucket

	e.g:

	     {
            "Effect": "Allow",
            "Action": [
                "kms:*"
            ],
            "Resource": [
                "arn:aws:kms:us-east-1:542948635112:key/1e9c819f-8706-4d01-b33b-27fb88b1f64b",
                "arn:aws:kms:us-east-1:786994105833:key/9019a1e6-20ce-4762-9fa1-98a17c243418"
            ]
        },
		{
            "Effect": "Allow",
            "Action": [
                "s3:Put*",
                "s3:Get*"
            ],
            "Resource": [
                "arn:aws:s3:::targetbucket",
                "arn:aws:s3:::targetbucket/*",
                "arn:aws:s3:::sourcebucket",
                "arn:aws:s3:::sourcebucket/*"
            ]
        },


  * KMS Policy - Both the source and target KMS keys should allow the EC2 instance to access the key.

    e.g.

        {
            "Sid": "Allow use of the key",
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::542948635112:role/EC2rolename"
                ]
            },
            "Action": [
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*",
                "kms:DescribeKey"
            ],
            "Resource": "arn:aws:kms:us-east-1:542948635112:key/1e9c819f-8706-4d01-b33b-27fb88b1f64b"
        }

  * S3 policy - Both the Source and Target S3 policy should allow the EC2 access

    e.g.

	    {
            "Sid": "AllowEc2AccesstoBucket",
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::542948635112:role/EC2rolename"
                ]
            },
            "Action": [
                "s3:Get*",
                "s3:Put*"
            ],
            "Resource": "arn:aws:s3:::sourcebucket/*"
        },
        {
            "Sid": "AllowEc2AccesstoBucketContents",
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::542948635112:role/EC2rolename"
                ]
            },
            "Action": "s3:ListBucket",
            "Resource": "arn:aws:s3:::sourcebucket"
        },


  * Once the polices are set correctly in all the roles, run the CLI command to transfer files between the buckets from the EC2 instance.

	   ``` aws s3 cp s3://sourcebucket/example.yaml s3://targetbucket/example.yaml --acl bucket-owner-full-control ```

  * The flag ``` --acl bucket-owner-full-control ``` gives the target bucket full access to the object that was copied. Since ACL functionality is old, there could potentially be a new option for this in the future.

