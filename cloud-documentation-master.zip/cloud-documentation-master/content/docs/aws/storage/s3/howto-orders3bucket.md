---
title: S3 Bucket Vending Machine
menu: docs
category: aws
---

## What is this product?

This product allows you to order a single S3 bucket into an account. The advantage is you do not need to order a whole
CodePipeline or learn CloudFormation to create a bucket. The disadvantage is this offers you less control over the
configuration of the bucket.

## **Ordering An S3 Bucket**

- Go to the AWS Service Catalog in your Tools{BSA} account and choose the S3-Bucket product. Enter your provisioned product name and continue.
  - From here a Developer or User can order an S3 bucket and have it built in your account.
  - NOTE: If you need multiple environments you will need to deploy multiple S3 service requests. Under the ENVIRONMENT parameter be sure to select DEV.
- The build process takes approximately 2 minutes

## **S3 Requirements**

- You must follow AWS bucket naming conventions [here](https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html)
- Tagging: Check [Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement)
- No publicly accessible S3 is allowed without an exception.
- You must provide an IAM role(s) for Get Access and for Put Access to the bucket (This can be the same role).

## **Parameter input help**

#### On Product list - Product details - Launch product : Product Version
  - <ins>Provisioned product:</ins> enter text that contains your bucket name - i.e. mybucket1

#### On Product list - Product details - Launch product : Parameters
Bucket Information - what bucket to create and where
  - <ins>Bucket Name</ins> The [DNS Compliant](https://docs.aws.amazon.com/AmazonS3/latest/dev/BucketRestrictions.html) bucket name.
  - <ins>Environment:</ins> Select the AWS environment you where want the S3 deployed (Dev/Test/Prod).

Access Information - who has access to get from and put to the bucket and who can modify the bucket
  - <ins>Role(s) for Get Access:</ins> What IAM role will have Get Access to the bucket. Please put the full ARN (arn:aws:iam::999999999999:role/ROLENAME). You can put multiple roles here separated by commas. Example: CustomAdmin or ReadOnly roles
  - <ins>Role(s) for Put Access:</ins> What IAM role will have Put Access to the bucket. Please put the full ARN (arn:aws:iam::999999999999:role/ROLENAME). You can put multiple roles here separated by commas. Example: CustomAdmin or Federated App Team roles
  - <ins>(OPTIONAL) Team Name:</ins> The name of your [federated team role](/docs/aws/getting-started-with-aws/howto_federatedappteamroles/). This will add the Team tag to your bucket so you can modify the bucket configuration.

Required Tags
  - <ins>Resource Owner:</ins> enter in a valid NWIE ID.  i.e.  smita16  *DO NOT ENTER IN AN EMAIL ADDRESS.*
  - <ins>Disbursement Code:</ins> enter in your valid nine digit disbursement code.
  - <ins>ARPM ID:</ins> enter in your valid four digit APRM ID code.
  - <ins>Data Classification:</ins> select a data classification from the drop-down list. (Select Sensitive if it has PII, PCI, etc)

## **AWS S3 Documentation**

- [Working with S3 Buckets](https://docs.aws.amazon.com/AmazonS3/latest/dev/UsingBucket.html)

## **Need A Feature?**

Please submit a feature request [here](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md) and assign the Cloud Infrastructure Engineering team.

