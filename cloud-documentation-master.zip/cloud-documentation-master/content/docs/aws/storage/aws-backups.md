---
category: aws
draft: false
title: "AWS Backups"
menu: docs
---
### AWS Backups

[AWS Backup](https://docs.aws.amazon.com/aws-backup/latest/devguide/whatisbackup.html) is a fully managed backup service that makes it easy to centralize and automate the backup of data across AWS services in the cloud and on premises


**[This document](/docs/aws/storage/Nationwide.Data.Protection.Requirements.pdf) provides an overview of the requirements for Nationwide’s data backups in AWS.**

