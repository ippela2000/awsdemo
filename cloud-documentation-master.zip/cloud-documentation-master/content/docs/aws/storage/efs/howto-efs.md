---
title: AWS Elastic File System (EFS)
menu: docs
category: aws
---

## AWS EFS Documentation <br />
* [AWS EFS Documentation](https://docs.aws.amazon.com/efs/latest/ug/how-it-works.html)<br />

----

## EFS is available in the following accounts
* All Dev, Test, and Prod accounts for non-PII data

----

## EFS Exception Process
EFS is permitted for use in all accounts, but cannot be used to store PII data without an exception.
If you need to use EFS with PII data, you must first go through an exception request found here: [exception request](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=exception_request.md) to the CDT. This request will tag both the CDT and IRM who will work with this request. This GitHub card will track when the EFS service will be available for your use. <br />

----
## EFS Usage in Cloudformation
To use EFS in Test and Prod please add the following CloudFormation scipt to your pipeline

```YAML
---
AWSTemplateFormatVersion: '2010-09-09'
Description: Create a EFS. Built from a Production Pipeline.

Parameters:
  # Used by All
  pEnvironment:
    Type: String
  pProductName:
    Type: String
  # tags
  pDisbursementCode:
    Description: Customer Disbursement Code
    Type: String
  pResourceOwner:
    Description: Your NWIE Short Name
  pAPRMID:
    Description: APRM ID
    Type: String
  pResourceOwner:
    Description: Your NWIE Short Name
    Type: String
  pDataClassification:
    Description: Public_Data, Internal_Use_Only, PCI or Confidential
    Type: String

Resources:
  rElasticFileSystem:
    Type: 'AWS::EFS::FileSystem'
    Properties:
      Encrypted: true
      #if you have a pipeline key refer to kms alias, if not use the kms arn
      KmsKeyId: !ImportValue #YOUR KMSALIAS or KMSARN
      FileSystemTags:
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: DataClassification
        Value: !Ref pDataClassification
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pProductName
      - Key: Environment
        Value: !Ref pEnvironment
    #Uncomment the properties below as needed
    #PerformanceMode: String
    #ProvisionedThroughputInMibps: Double
    #ThroughputMode: String

  rElasticFileSystemSG:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: Enable ports for ELB so users can access to application.
      VpcId: !ImportValue oVPCID
      SecurityGroupIngress:
      - IpProtocol: tcp
        FromPort: '0'
        ToPort: '65535'
        SourceSecurityGroupId:
          Fn::ImportValue: #YOURSECURITYGROUP

  rMountTargetSubnetA:
    Type: "AWS::EFS::MountTarget"
    Properties:
      FileSystemId: !Ref rElasticFileSystem
      SubnetId:
        !ImportValue oPrivateSubnetA
      SecurityGroups:
        - !Ref rElasticFileSystemSG

  rMountTargetSubnetB:
    Type: "AWS::EFS::MountTarget"
    Properties:
      FileSystemId: !Ref rElasticFileSystem
      SubnetId:
        !ImportValue oPrivateSubnetB
      SecurityGroups:
        - !Ref rElasticFileSystemSG

  rMountTargetSubnetC:
    Type: "AWS::EFS::MountTarget"
    Properties:
      FileSystemId: !Ref rElasticFileSystem
      SubnetId:
        !ImportValue oPrivateSubnetC
      SecurityGroups:
        - !Ref rElasticFileSystemSG

  # Optional inclusion of .aws.e1.nwie.net DNS record for cross-account access by name
  rEfsARecord:
    Type: Custom::ExecuteCustomResource
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:us-east-1:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: A
      RecordName: !Ref pRecordName # should not have .aws.e1.nwie.net on it, just the name
      RecordValue:
        - !GetAtt rMountTargetSubnetA.IpAddress
        - !GetAtt rMountTargetSubnetB.IpAddress
        - !GetAtt rMountTargetSubnetC.IpAddress
```

Also please add the following to the bottom of your EC2 cloudformation: <br />
```YAML
  UserData:
      Fn::Base64:
        Fn::Join:
        - sudo mount -t efs -o tls
	- !Ref rElasticFileSystem
	- :/ /mnt/efs
```

## EFS Usage in Console
### Configure File System Access<br />

**VPC**<br />
Select the VPC associated with the account, should only be one available.<br />
<img src="/docs/aws/images/efs1.png"><br />
**Create Mount Target**<br />
Select the appropriate subnets and security groups associated to the VPC and click next.<br />
<img src="/docs/aws/images/efs2.png"><br />

### Configure optional settings

**Add tags** <br />
For a list of all necessary tags, please reference the S3 and EFS tagging column in the AWS Tagging Strategy chart found [here](https://pages.github.nwie.net/Nationwide/Next-Gen-Infra/pages/4-tags/). <br />
<img src="/docs/aws/images/efs3.png"> <br />

**Choose performance mode**<br />
Choose per discretion. <br />

**Choose throughput mode**<br />
Choose per discretion. <br />

**Enable Encryption**<br />
Mandatory to check this or it will be shutdown. <br />

**Enable lifecycle management** <br />
Choose per discretion. <br />

<img src="/docs/aws/images/efs4.png"> <br />

Click 'Next Step' <br />

### Review and create <br />
Review all of the following settings and then 'Create File System' <br />

----

## EFS Encrypting in Transit<br />

**AWS EFS Encryption Documentation** <br />
* [Encryption-in-Tranist](https://docs.aws.amazon.com/efs/latest/ug/encryption.html#encryption-in-transit) <br />

**Our Recommendations** <br />
Encryption of data in transit is enabled by connecting to Amazon EFS using TLS. We recommend using the mount helper because it's the simplest option. <br />

The EFS Mount Helper is in the amazon-efs-utils tools package. In order to install that package please follow the following link:
[amazon-efs-utils](https://docs.aws.amazon.com/efs/latest/ug/using-amazon-efs-utils.html#efs-mount-helper) and scroll down to **Installing the amazon-efs-utils Package on Amazon Linux** and follow the steps to run the code in your linux console: <br />
`sudo yum install -y amazon-efs-utils`<br />


### How to <br />
Enabling encryption of data in transit for your Amazon EFS file system is done by enabling Transport Layer Security (TLS) when you mount your file system using the Amazon EFS mount helper. For more information, see [Mounting with the EFS Mount Helper](https://docs.aws.amazon.com/efs/latest/ug/mounting-fs.html#mounting-fs-mount-helper).

When encryption of data in transit is declared as a mount option for your Amazon EFS file system, the mount helper initializes a client stunnel process. Stunnel is an open source multipurpose network relay. The client stunnel process listens on a local port for inbound traffic, and the mount helper redirects NFS client traffic to this local port. The mount helper uses a Transport Layer Security (TLS) version 1.2 to communicate with your file system.<br />

**Mounting your Amazon EFS file system with the mount helper with encryption of data in transit enabled**
1. Access the terminal for your instance through Secure Shell (SSH), and log in with the appropriate user name. For more information on how to do this, see [Connecting to Your Linux Instance Using SSH](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AccessingInstancesLinux.html) in the Amazon EC2 User Guide for Linux Instances.<br />

2. Run the following command to mount your file system. <br />
  fs-12345678 is your file system ID, you can get that file system's ID from the console or programmatically through the Amazon EFS API.<br />
 `sudo mount -t efs  -o tls fs-12345678:/ /mnt/efs` <br />

**Mounting your Amazon EFS file system persistently**
1. Access the terminal for your instance through Secure Shell (SSH), and log in with the appropriate user name. For more information on how to do this, see [Connecting to Your Linux Instance Using SSH](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/AccessingInstancesLinux.html) in the Amazon EC2 User Guide for Linux Instances.<br />

2. Run the following command to mount your file system. <br />
  fs-12345678 is your file system ID, you can get that file system's ID from the console or programmatically through the Amazon EFS API.<br />
 `sudo echo "fs-12345678:/ /mnt/efs efs tls,_netdev 0 0" >> /etc/fstab #for persistent` <br />


## EFS Friendly Name for Cross-Account Reference

* [You can't use DNS name resolution for EFS mount points in another VPC](https://docs.aws.amazon.com/efs/latest/ug/manage-fs-access-vpc-peering.html). 
* To mount your EFS file system, use the IP address of the mount points in the corresponding Availability Zone. 
* To get multi-AZ functionality you should use Amazon Route53. 
* In Route 53, you can resolve the EFS mount target IP addresses from another VPC by creating a private hosted zone and resource record set.
* Refer to the [Friendly DNS Names](/docs/aws/network-content-delivery/route53/howto_dns/#efs-friendly-name-for-cross-account-reference) on how to implement
