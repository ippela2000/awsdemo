---
title: Storage Gateway - How To
menu: docs
category: aws
---

## Requesting Storage Gateway

## Informational
- Please note that after deployment, the various CDT teams **DO NOT SUPPORT** this product
- CDT only guarantees a successful deployment of this product, there is **NO OPERATIONAL SUPPORT** from the CDT

The storage gateway implementation is no longer locked behind a request process, or CDT maintained.

To create a storage gateway in your account, you now need to log into your BSA Tools account or InfraSvcsProd(legacy) and order a storage gateway instance from Service Catalog.
Each Storage Gateway Instance product ordered from service catalog is for an instance in a single account. If you want a unique storage gateway in each of the accounts in your BU stack, you will need to order 3 separate products (Dev/Test/Prod).
Note that each storage gateway instance can have up to 10 file shares, so you can save cost by reusing an existing storage gateway over creating a new one if possible.
Locate the Other-StorageGatewayInstance product in Service Catalog and populate the requested fields:

- **pEnvironment** : The environment of your BU (which specific account) to create a storage gateway instance in.
- **pBusinessUnit** : Drop-down list of available BU accounts to deploy into
- **pUniqueName** : Any unique name to differentiate your storage gateway instance from others in the account. Can be your team name, app name, etc.
- **pDisbursementCode** : Your BU's disbursement code, used in the tags on the instance for billing
- **pResourceOwner** : Your NWIE ID, used in the tags on the instance for tracability


## Creating File Shares

#### Important Notes
- When creating a file share, you need to import the ARN of the storage gateway that you want to deploy the file share into. When ordering the
storage gateway in service catalog you are asked for pUniqueName, the name of the storage gateway will become {pUniqueName}-{Account} (EX: UniqueValue-DevCDT01). The snippets bellow for creating the file share need to be modified to replace !!!CHANGEME!!! with the name of the storage gateway you are deploying into (such as UniqueValue-DevCDT01)
- The role passed into the custom resource Role field must have `storagegateway.amazonaws.com` in it's assume role policy (see the example CFN)
- The file share may not be fully available immediately when the custom resource completes. Please allow up to 10 minutes after deployment for the file share to become fully available if you are unable to connect to it immediately.
- If ValidUserList and InvalidUserList are left out of an SMB share, any user who successfully authenticates with Active Directly will have access to the share.
- The custom resource passes the Parameters section direction to the relevant boto3 call, so any parameter defined in the boto3 docs for create_smb_file_share or create_nfs_file_share are supported.
- The following parameters cannot be changed after creation: "GatewayARN", "Role", "Authentication", "LocationARN"

#### Custom Resource Details
- Adding a file share to the storage gateway instance in your account is done through a custom resource in in cloudformation
- The following snippet can be included anywhere in your existing iac/ cloudformation files
- Example Usage NFS:
    {% raw %}
    ```
    rCustomResourceNFS:
        Type: Custom::CreateSGFileShare
        Properties:
          ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
          CustomResourceName: create-file-share
          Account: !Sub "${AWS::AccountId}"
          FileShareType: NFS
          Parameters:
            GatewayARN: !ImportValue !!!CHANGEME!!!  # Replace !!!CHANGEME!!! with the name of your storage gateway
            KMSEncrypted: True
            KMSKey: !Ref rProductKmsKeyParam
            Role: !GetAtt rProductRole.Arn
            LocationARN: !GetAtt rProductBucket.Arn
            ClientList:
                - "10.0.0.0/8"
                - "192.168.158.5"
            ReadOnly: False
    ```
    {% endraw %}

- Example Usage SMB:
    {% raw %}
    ```
    rCustomResourceSMB:
        Type: Custom::CreateSGFileShare
        Properties:
          ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
          CustomResourceName: create-file-share
          Account: !Sub "${AWS::AccountId}"
          FileShareType: SMB
          Parameters:
            GatewayARN: !ImportValue !!!CHANGEME!!!  # Replace !!!CHANGEME!!! with the name of your storage gateway
            KMSEncrypted: True
            KMSKey: !Ref rProductKmsKeyParam
            Role: !GetAtt rProductRole.Arn
            LocationARN: !GetAtt rProductBucket.Arn
            ReadOnly: False
            Authentication: "ActiveDirectory"
            ValidUserList:
                - "user1"
                - "@ADGroup"
            InvalidUserList:
                - "user2"
                - "@ADGroup2"
    ```
    {% endraw %}

- NFS Input Details:
  - **Account**: The value from the example should not be changed, this will populate the account number of the account that the cloudformation is being executed in.
  - **FileShareType**: Valid values are SMB and NFS, defines the type of file share to create. You cannot have both NFS and SMB file shares to the same bucket, only 1 or the other.
  - **GatewayARN**: The value from the example should not be changed, this will import the ARN of the storage gateway in the account that the cloudformation is being executed in.
  - **KMSEncrypted**: Sets whether storage gateway will encrypt objects it stores in your S3 bucket, this should always be True
  - **KMSKey**: The ARN of the KMS key that storage gateway will use to encrypt objects. The IAM role passed into the Role option needs to have access to use this key.
  - **Role**: The role that storage gateway will assume and use when interacting with your bucket. **This role MUST have `storagegateway.amazonaws.com` included in its assume role policy.**
  - **LocationARN**: The ARN of the s3 bucket that the file share will be mapped to. The bucket's policy must allow the role passed in the Role parameter to read/write to it.
  - **ReadOnly**: Defines whether the share should be writable or not. Setting this value to True will prevent files from being uploaded and will provide a ReadOnly view into the S3 bucket defined.
  - **ClientList**: A list of IP Addresses or Subnets that are allowed to connect to the share. NFS with Storage Gateway does not support any authentication mechanisms and access is controlled purely by IP address. Subnets should be in CIDR notation ("10.163.10.0/24")

- SMB Input Details:
  - **Account**: The value from the example should not be changed, this will populate the account number of the account that the cloudformation is being executed in.
  - **FileShareType**: Valid values are SMB and NFS, defines the type of file share to create. You cannot have both NFS and SMB file shares to the same bucket, only 1 or the other.
  - **GatewayARN**: The value from the example should not be changed, this will import the ARN of the storage gateway in the account that the cloudformation is being executed in.
  - **KMSEncrypted**: Sets whether storage gateway will encrypt objects it stores in your S3 bucket, this should always be True
  - **KMSKey**: The ARN of the KMS key that storage gateway will use to encrypt objects. The IAM role passed into the Role option needs to have access to use this key.
  - **Role**: The role that storage gateway will assume and use when interacting with your bucket. **This role MUST have `storagegateway.amazonaws.com` included in its assume role policy.**
  - **LocationARN**: The ARN of the s3 bucket that the file share will be mapped to. The bucket's policy must allow the role passed in the Role parameter to read/write to it.
  - **ReadOnly**: Defines whether the share should be writable or not. Setting this value to True will prevent files from being uploaded and will provide a ReadOnly view into the S3 bucket defined.
  - **Authentication**: Valid values are ActiveDirectory and GuestAccess. This should always be ActiveDirectory as the storage gateway will be preconfigured with ActiveDirectory integration and the Guest password is the same accross all file shares. If Guest is needed for some reason, reach out to the CDT through GitHub to request the guest SMB password.
  - **ValidUserList**: List of users and/or groups that should have access to this share. Add "@" to the front of the item to identify groups. (This value is not required)
  - **InvalidUserList**: List of users and/or groups that should not have access to this share. Add "@" to the front of the item to identify groups. (This value is note required)


#### Connecting to File Share
**NFS**:
  - On Linux: mount -t nfs -o nolock,hard [host]:/[bucketname] [MountPath]
  - On Windows: mount -o nolock -o mtype=hard [host]:/[bucketname] [WindowsDriveLetter]:
  - On macOS: mount_nfs -o vers=3,nolock,hard -v [host]:/[bucketname] [MountPath]

**SMB**:
  - On Microsoft Windows: net use [WindowsDriveLetter]: \\[host]\[bucketname]
  - On Linux and macOS: mount -t cifs -o user=[Username] //[host]/[bucketname] [MountPath]

Option Explanations:
  - **host:** A DNS name is creted for the storage gateway to make connection easier. Connect to storagegateway-<ACCOUNTNAME>.aws.e1.nwie.net (IE: storagegateway-io02.aws.e1.nwie.net)
  - **bucketname:** The actual share within the server is the name of the bucket that you mapped with the LocationARN field above.
  - **MountPath:** Full path to where you want the share mounted (IE: /mnt/mybucket)
  - **WindowsDriveLetter:** Windows drive letter to mount the share to

Example:
```
Account: DevIO02
BucketName: test-bucket-123

NFS
On Linux: mount -t nfs -o nolock,hard storagegateway-devio02.aws.e1.nwie.net:/test-bucket-123 /mnt/test-bucket-123
On Windows: mount -o nolock -o mtype=hard storagegateway-devio02.aws.e1.nwie.net:/test-bucket-123 T:
On macOS: mount_nfs -o vers=3,nolock,hard -v storagegateway-devio02.aws.e1.nwie.net:/test-bucket-123 /mnt/test-bucket-123

SMB:
On Microsoft Windows: net use T: \\storagegateway-devio02.aws.e1.nwie.net\test-bucket-123
On Linux and macOS: mount -t cifs -o user=myaduser1 //storagegateway-devio02.aws.e1.nwie.net/test-bucket-123 /mnt/test-bucket-123
```


#### Full Example CloudFormation Template
The following template is a full working example that creates an S3 bucket, KMS key, role, and SMB file share allowing a specific group access.
This is just an example of a full template, you should not need to add anything to your template, just add the sections around the role permission to your existing files:

```
AWSTemplateFormatVersion: '2010-09-09'
Description: Creates Bucket, Role, Key, and SG File Share

Parameters:
  pProductName:
    Description: Name of the instance
    Type: String
  pProductNameLower:
    Description: Name of the product, lower-case for bucket name
    Type: String
  pADGroup:
    Description: Active Directoy group to allow access to file share
    Type: String
  pEnvironment:
    Description: Environment Name
    Type: String
  pDisbursementCode:
    Description: Customer Disbursement Code
    Type: String
  pResourceOwner:
    Description: Your NWIE Short Name
    Type: String
  pAPRMID:
    Description: APRM ID
    Type: String
  pDataClassification:
    Description: Public_Data, Internal_Use_Only, PCI or Confidential
    Type: String
    Default: Internal_Use_Only


Resources:
  rProductRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub "${pProductName}-${pEnvironment}-${AWS::Region}"
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
        - Effect: Allow
          Principal:
            Service:
              - ec2.amazonaws.com
              - storagegateway.amazonaws.com
          Action:
            - sts:AssumeRole
      Path: "/"
      Policies:
      - PolicyName: !Sub "${pProductName}-${pEnvironment}-${AWS::Region}"
        PolicyDocument:
          Version: '2012-10-17'
          Statement:
          - Action:
              - 'ssm:DescribeParameters'
              - 'ec2:DescribeTags'
            Resource: '*'
            Effect: Allow
          - Action:
              - 'ssm:GetParameters'
            Resource: '*'
            Effect: Allow
          - Action:
              - 'logs:CreateLogGroup'
              - 'logs:CreateLogStream'
              - 'logs:PutLogEvents'
              - 'logs:DescribeLogStreams'
            Resource:
              - !Sub "arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:${pProductName}"
              - !Sub "arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:${pProductName}*"
            Effect: Allow
          - Action:
              - 's3:ListBucket'
              - 's3:GetBucketLocation'
              - 's3:GetBucketAcl'
              - 's3:GetObject'
              - 's3:GetObjectAcl'
            Resource: '*'
            Effect: Allow
          - Action:
              - 'kms:Decrypt'
            Resource: '*'
            Effect: Allow

  rProductBucket:
    Type: "AWS::S3::Bucket"
    Properties:
      BucketName: !Sub "${pProductNameLower}-productbucket-${AWS::Region}-${AWS::AccountId}"
      VersioningConfiguration:
        Status: Enabled
      Tags:
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: DataClassification
        Value: !Ref pDataClassification
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pProductName
      - Key: Environment
        Value: !Ref pEnvironment

  rProductBucketPolicy:
    Type: "AWS::S3::BucketPolicy"
    Properties:
      Bucket: !Ref rProductBucket
      PolicyDocument:
        Version: '2012-10-17'
        Id: SSEAndSSLPolicy
        Statement:
        - Sid: DenyUnEncryptedObjectUploads
          Effect: Deny
          Principal: '*'
          Action: s3:PutObject
          Resource: !Sub "arn:aws:s3:::${rProductBucket}/*"
          Condition:
            StringNotEquals:
              s3:x-amz-server-side-encryption: aws:kms
        - Sid: DenyInsecureConnections
          Effect: Deny
          Principal: '*'
          Action: s3:*
          Resource: !Sub "arn:aws:s3:::${rProductBucket}/*"
          Condition:
            Bool:
              aws:SecureTransport: 'false'
        - Sid: ''
          Effect: Allow
          Principal:
            AWS:
              - !GetAtt rProductRole.Arn
              - !Sub "arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole"
          Action:
            - s3:Get*
            - s3:Put*
          Resource: !Sub "arn:aws:s3:::${rProductBucket}/*"
        - Sid: ''
          Effect: Allow
          Principal:
            AWS:
              - !GetAtt rProductRole.Arn
              - !Sub "arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole"
          Action: s3:ListBucket
          Resource: !Sub "arn:aws:s3:::${rProductBucket}"

  rProductKmsKeyParam:
    Type: AWS::KMS::Key
    Properties:
      Description: !Sub "Built for ${pProductName} to encrypt and decrypt parameters from ssm"
      Enabled: true
      EnableKeyRotation: false
      KeyPolicy:
        Version: '2012-10-17'
        Id: key-default-1
        Statement:
          - Sid: Enable IAM User Permissions
            Effect: Allow
            Principal:
              AWS:
                - !Sub "arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole"
            Action: kms:*
            Resource: '*'
          - Sid: Allow access for Key Administrators
            Effect: Allow
            Principal:
              AWS:
                - !Sub "arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole"
                - !GetAtt rProductRole.Arn
            Action:
              - kms:Create*
              - kms:Describe*
              - kms:Enable*
              - kms:List*
              - kms:Put*
              - kms:Update*
              - kms:Revoke*
              - kms:Disable*
              - kms:Get*
              - kms:Delete*
              - kms:TagResource
              - kms:UntagResource
              - kms:ScheduleKeyDeletion
              - kms:CancelKeyDeletion
            Resource: '*'
          - Sid: allow instant profile key access
            Effect: Allow
            Principal:
              AWS:
                - !GetAtt rProductRole.Arn
            Action:
              - kms:Encrypt
              - kms:Decrypt
              - kms:ReEncrypt*
              - kms:GenerateDataKey*
              - kms:DescribeKey
            Resource: '*'
          - Sid: Allow attachment of persistent resources
            Effect: Allow
            Principal:
              AWS:
                - !GetAtt rProductRole.Arn
            Action:
              - kms:CreateGrant
              - kms:ListGrants
              - kms:RevokeGrant
            Resource: '*'
            Condition:
              Bool:
                kms:GrantIsForAWSResource: true

  rProductKmsKeyAlias:
    Type: AWS::KMS::Alias
    Properties:
      AliasName: !Sub "alias/${pProductName}-${pEnvironment}"
      TargetKeyId: !Ref rProductKmsKeyParam

  # NFS example...
  # rCustomResourceNFS:
  #   Type: Custom::CreateSGFileShare
  #   Properties:
  #     ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
  #     CustomResourceName: create-file-share
  #     Account: !Sub "${AWS::AccountId}"
  #     FileShareType: NFS
  #     Parameters:
  #       GatewayARN: !ImportValue !!!CHANGEME!!!  # Replace !!!CHANGEME!!! with the name of your storage gateway
  #       KMSEncrypted: True
  #       KMSKey: !Ref rProductKmsKeyParam
  #       Role: !GetAtt rProductRole.Arn
  #       LocationARN: !GetAtt rProductBucket.Arn
  #       ClientList:
  #         - "10.0.0.0/8"
  #         - "192.168.158.5"
  #       ReadOnly: False

  rCustomResourceSMB:
    Type: Custom::CreateSGFileShare
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: create-file-share
      Account: !Sub "${AWS::AccountId}"
      FileShareType: SMB
      Parameters:
        GatewayARN: !ImportValue !!!CHANGEME!!!  # Replace !!!CHANGEME!!! with the name of your storage gateway
        KMSEncrypted: True
        KMSKey: !Ref rProductKmsKeyParam
        Role: !GetAtt rProductRole.Arn
        LocationARN: !GetAtt rProductBucket.Arn
        ReadOnly: False
        Authentication: "ActiveDirectory"
        ValidUserList:
          - !Sub "@${pADGroup}"
```

#### Debugging Failures
The create-file-share lambda is centralized into the InfraSvcsProd account. To see its logs, you will need to have access to InfraSvcsProd CloudWatch. The log group for the lambda is `/aws/lambda/create-file-share` in the region that the action stack was created in.
