---
title: How to AWS Snowball Device
menu: docs
category: aws
---
## AWS Snowball Device

AWS Snowball is a service for transferring large amounts of data into and out of AWS.  The Snowball device is shipped through a regional carrier. Each Snowball is protected by AWS Key Management Service (AWS KMS).  In the US regions, Snowballs come in two sizes: 50 TB and 80 TB.


### Prerequisites

Before transferring data into Amazon S3 using Snowball, you should do the following:
* Create an AWS account and an administrator user in AWS Identity and Access Management (IAM). For more information, see Creating an IAM User for Snowball.
  * [How To Create Local Users](/docs/aws/iam/howto-localusers/)
* Create a S3 Bucket.
* For importing data, confirm that the files and folders to transfer are named according to the Object Key Naming Guidelines for Amazon S3. Any files or folders with names that don't meet these guidelines won't be imported into Amazon S3.
* For exporting data, understand what data will be exported when you create your job. For more information, see Using Export Ranges.
* For files with a colon (:) in the file name, change the file names in Amazon S3 before you create the export job to get these files. Files with a colon in the file name fail export to Microsoft Windows Server.

### Connecting the Snowball Device in the Data Center

Prior to ordering the Snowball device you will need a Run Services Engagement to determine the placement and connectivity of your device in the data center.
* Depending on where your source data is located, a network resource will provide the required network switch connectivity information.  You will need network port, static IP and default gateway.
* A Linux and/or Windows server administrator will be required to provide you a server to connect the Snowball device.  They will also be required to assist you in installing the Snowball Client software.
* Data Center facilities will be required to pull your cables and connect/disconnect the Snowball device.  Note, approved Service Now RFCs and Service Requests are required for these activities.


### Create an Export Job

Initiate an Import job on the AWS Snowball Management Console.  Amazon will ship the Snowball device to the address you specify.  Typically, it would be either the address of North Data Center or the East Data Center.  The shipment of the snowball device normally takes between 1-3 days to arrive at the data center.  Amazon will provide a Job Manifest file and a Manifest Unlock Code.  These two items will be needed to run the Snowball Client.
* From the AWS console, select the Snowball Service.
* From the Snowball Job dashboard, select Create Job.
* Select Import Into Amazon S3 and then select Next.
* Enter the Shipping Address and select Shipping Speed then select Next.
* Give your job a name and then select capacity.  Note, the devices requires some overhead space.  If you have 50TB of data, select the 80TB capacity Snowball.
* Select the S3 bucket or buckets you want the data copied to.  You can only select S3 buckets which are associated to the account you are using to order the Snowball device.
* When you select Next, you will be provided with your job details summary.

### Download the Snowball Client
* The Snowball client is a standalone terminal application that you run on your local workstation to do your data transfer.  It provides all the functionality you need to transfer data, including handling errors and writing logs to your local workstation for troubleshooting and auditing.
* You can obtain the correct version for you transfer here: https://aws.amazon.com/snowball/resources/
* It’s best to use MobaXterm to download the Snowball Client.  WinSCP gave errors.  The manifest file and the access code that is provide by Amazon when the Import Job was created on the Management Console, will be needed to perform the Snowball Start.  You can retrieve these two items from the Snowball Job Dashboard.

### Transfer of Data to Snowball
* During data transfer, at least one folder appears at the root level of the Snowball. This folder and any others at this level have the same names as the Amazon S3 buckets that you chose when this job was created. You can't write data to the root level of the Snowball. All data must be written into one of the bucket folders or into their subfolders.
* You can work with files or folders with spaces in their names, like my photo.jpg or My Documents. However, make sure that you handle the spaces properly in the client commands. For more information, see the following examples:

Linux and Mac version of the client – snowball ls s3://mybucket/My\ Folder/my\ photo.jpg

Windows version of the client – snowball ls "s3://mybucket/My Documents/my photo.jpg"
* A full list of Snowball Client commands can be found here: https://docs.aws.amazon.com/snowball/latest/ug/using-client-commands.html

### Disconnecting and Returning the Snowball Device
* Review the Log files (when the copy to snowball completes the end of the log file shows the number of files transferred, the speed which they were transferred, how many bytes and how long it took to transfer).  If you do not see this at the end of the log file, then it’s still running unless you see errors.
* The location where the snowball client creates the log files is /root/.aws/snowball/logs regardless if you generated your own log files.
* Create a Service Now RFC to uninstall Snowball Client and Ship back to Amazon.  Data Center facilities will load it onto the Dock for UPS to pick up.  UPS is NOT on a given schedule.  If UPS has to make a delivery to the North Data Center, then they will be given the Snowball Device to ship back to Amazon.
* Amazon will notify you when the device has been received and when your data transfer is complete.
