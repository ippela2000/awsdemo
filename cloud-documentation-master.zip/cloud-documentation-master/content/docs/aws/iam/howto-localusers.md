---
title: Request Local Account w/ Persistent Access Keys
menu: docs
category: aws
---

1. Account Owners should use AWS Federated Authentication with Active Directory Federation Services for non-interactive accounts as the standard. If Active Directory Federation for an account cannot be used, the Account Owner will need to submit Exception to NGI.
2. Account Owner will go to **[Github Issues](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new/choose)** and select Exception Request
3. Under Describe the Request, the Account Owner must provide the business justification for the local account. It must be stated why AWS Federated Authentication with Active Directory Federation Services is not an option.
4. In the section Required Information (Responder Exception), complete questions 1-5.
5. Since Marketplace AMI may not be applicable, the section Required Information (Marketplace AMI) can be skipped.
6. The request will be sent to IRM contact to complete a security exception. After exception has been approved.
7. IRM will provide Cloud Security team the security exception number, account name(s), email of the account owner, and date of the expiration for the exception to the Cloud Security.
8. The Cloud security creates local user and records the security exception number, account name(s), email of the account owner, and date of the expiration
9. Cloud Security will automate new key generation and notifications to user about rotating keys before 90 days.
10. Cloud Security starts sending notification for account not rotated keys after 75 days.
11. Account Owners with issues rotating access keys for various reasons, will need to coordinate with Cloud Security team the rotation of the key prior to 90 days.
12. After 90 days, an account owner and IRM representative will receive an email the access key has not been rotated and must be rotated. This email will be generated every 15 days until the key is rotated or expired.
