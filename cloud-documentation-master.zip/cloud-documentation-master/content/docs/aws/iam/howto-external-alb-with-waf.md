---
title: How to set external ALB with WAF
menu: docs
category: aws
---

**Please note that completing the actions bellow will expose your application to the general Internet. Ensure that your application is properly secured and does not expose any sensitive information before exposing it to Internet. You are fully response for the security of your application and the data exposed by it and accept that responsibility when completing the following actions. If you have any questions about the security of your app or your responsibilities from owning a public-facing application please reach out to your front-office IRM representative for consultation.**

### WAF

* AWS WAF is a web application firewall that lets you monitor the HTTP(S) requests that are forwarded to an Amazon CloudFront distribution, an Amazon API Gateway API, or an Application Load Balancer.

* Every product using EC2 instances ordered from the service catalog will receive an Application Load Balancer (ALB).

* Applications facing the internal Nationwide network only may just use this ALB as is.

* Applications facing the internet are required to attach the [AWS Web Application Firewall (WAF)](https://aws.amazon.com/waf/) to their ALB.

* If your ALB is internet facing and not using a WAF, a default WAF will be attached automatically.

* In the steps below the CloudFormation for attaching the "generic"  WAF to your ALB. If you need special configurations or rules for your applications, please submit a ticket [here](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new/choose).

Note: there are future plans to create internet facing Service Catalog entries that will attach the WAF to your ALB automatically. In the meantime, you can attach the WAF manually.


### Setting up an internet facing application (through CodePipeline on EC2)

1. Make the Load Balancer public facing. In LoadBalancer.yaml, make the following changes:
    * Under ```rLoadBalancer:```
        * Use public subnets - Change subnets to ```oPublicSubnetA```, ```oPublicSubnetB```, and ```oPublicSubnetC``` instead of using the private subnets.
        * Change Scheme to ```internet-facing``` instead of ```internal```
    * Add the following resource. This is a WAF
        ```
        rWebACLAssociation:
          Type: AWS::WAFRegional::WebACLAssociation
          Properties:
            ResourceArn: !Ref rLoadBalancer
            WebACLId: !ImportValue oWAFWebACL
        ```
2. Allow inbound internet access to load balancer. In SecurityGroup.yaml, make the following change:
    * Under ```rLoadBalancerSG:``` add:

        ```
        - IpProtocol: tcp
          FromPort: '443'
          ToPort: '443'
          CidrIp: 0.0.0.0/0
          Description: 'Internet Access'
        ```
3. Get a public CNAME for your load balancer. If you don't already have a remote-route53 call in your LoadBalancer.yaml add the following:
    * Add new resource:

        ```
        rAddCNAME:
            Type: Custom::RemoteRoute53
            Properties:
            ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
            CustomResourceName: remote-route53
            Account: !Sub "${AWS::AccountId}"
            RecordType: CNAME  # A and PTR are not currently supported
            RecordName: !Ref pCname # should have just the name e.g 'media'
            RecordValue: !GetAtt rLoadBalancer.DNSName
            Public: true
        ```

    This will give you a record of **{pCname}.awspubliccloud.nationwide.com** e.g. **media.awspubliccloud.nationwide.com** that you can use as the target of an X.nationwide.com alias.

If you have deployed your app through a pipeline before, after pushing these changes, you may get an error in the Deploy_Consumer_LoadBalancer step in CodePipeline that says "CloudFormation cannot update a stack when a custom-named resource requires replacing. Rename 'MyResourceName' and update the stack again". To fix this, go into CloudFormation and delete the LoadBalancer stack for your app. Then retry that part of the pipeline to fix this.

### Getting an external Certificate

* Follow the instructions in [SSL Public Certificate](/docs/aws/cryptography/howto-publiccert) to get public certificate and import it into the relevant AWS account in ACM.


