---
title: Allow Team Role access to your resources
menu: docs
category: aws
---

### Overview

Once you have gotten a [Federated Team Role Creates](/docs/aws/getting-started-with-aws/howto_federatedappteamroles), you will need to made additional changes to give the role access to you AWS resources

### Access included in the TeamRole

* The Access rules for the Federated Team role can be found in the [TeamRoleGeneralBoundary.yaml](https://github.nwie.net/Nationwide/CDT-IAM/blob/master/Boundaries/TeamRoleGeneralBoundary.yaml)
* The Access rules for the RDS Federated Team role can be found in the [TeamRoleRDSBoundary.yaml](https://github.nwie.net/Nationwide/CDT-IAM/blob/master/Boundaries/TeamRoleRDSBoundary.yaml


### Granting Access to the Role for KMS and S3
To make sure this role has full access from the S3 and KMS side, you can add add the role to the existing Bucket Policy and KMS policies:

Bucket Policy Example (note the addition of !Sub arn:aws:iam::${AWS::AccountId}:role/${pTeamName}-AppTeam-Role)
```
...
        - Sid: ''
          Effect: Allow
          Principal:
            AWS:
              - !Sub arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole
              - !Sub arn:aws:iam::${AWS::AccountId}:role/${pEnvironment}-CLOUDADMIN-AWS
              - !Sub arn:aws:iam::${AWS::AccountId}:role/${pTeamName}-TeamRole-AWS
          Action:
          - s3:Get*
          - s3:Put*
          Resource: !Sub "arn:aws:s3:::${rProductBucket}/*"
        - Sid: ''
          Effect: Allow
          Principal:
            AWS:
              - !Sub arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole
              - !Sub arn:aws:iam::${AWS::AccountId}:role/${pEnvironment}-CLOUDADMIN-AWS
              - !Sub arn:aws:iam::${AWS::AccountId}:role/${pTeamName}-TeamRole-AWS
          Action: s3:ListBucket
          Resource: !Sub "arn:aws:s3:::${rProductBucket}"
```

KMS Policy Example (note the addition of !Sub arn:aws:iam::${AWS::AccountId}:role/${pTeamName}-AppTeam-Role)
```
...
        Statement:
          - Sid: Allow access for Key Administrators
            Effect: Allow
            Principal:
              AWS:
                - !Sub arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole
                - !Sub arn:aws:iam::${AWS::AccountId}:role/${pEnvironment}-CLOUDADMIN-AWS
                - !Sub arn:aws:iam::${AWS::AccountId}:role/${pTeamName}-TeamRole-AWS
            Action:
              - kms:Create*
              - kms:Describe*
              - kms:Enable*
              - kms:List*
              - kms:Put*
              - kms:Update*
              - kms:Revoke*
              - kms:Disable*
              - kms:Get*
              - kms:Delete*
              - kms:TagResource
              - kms:UntagResource
              - kms:ScheduleKeyDeletion
              - kms:CancelKeyDeletion
            Resource: '*'
          - Sid: Allow access to use key
            Effect: Allow
            Principal:
              AWS:
                - !Sub arn:aws:iam::${AWS::AccountId}:role/OrganizationAccountAccessRole
                - !Sub arn:aws:iam::${AWS::AccountId}:role/${pEnvironment}-CLOUDADMIN-AWS
                - !Sub arn:aws:iam::${AWS::AccountId}:role/${pTeamName}-TeamRole-AWS
            Action:
              - kms:Encrypt
              - kms:Decrypt
              - kms:ReEncrypt*
              - kms:GenerateDataKey*
              - kms:DescribeKey
            Resource: '*'
```

Also note that you can hard-code that value in your CloudFormation (Ex: arn:aws:iam::${AWS::AccountId}:role/MyTeamName-TeamRole-AWS) if you do not want to set up the parameters throughout your files.


### Adding Team tag to your resources for access
The team roles that are created are given access based on the TeamName provided during ordering.
Any resource you want to be able to modify will need a matching tag with name Team and value matching the TeamName provided during role creation.
All of your resources should already have tags being added to them in your CloudFormation, so you just need to add an additional tag to the list, examples bellow.
Also note that this tag can be applied to resources created in multiple pipelines, you do not need a specific role per application.

EC2 Snippet Example (With Parameter):
```
Parameters:
  ...
  pTeamName:
    Description: Name of the team managing this resource
    Type: String
    Default: MyTeamName

Resources:
  rEC2Instance:
    Type: AWS::EC2::Instance
    Properties:
      IamInstanceProfile: !Ref pIamInstanceProfile
      InstanceType: !Ref pInstanceType
      SecurityGroupIds:
        - !Ref pSecurityGroup
        - !ImportValue ToolsAccessSG
      ImageId: !Ref pImageId
      SubnetId: !ImportValue oPrivateSubnetA
      Tags:
        ...
        - Key: Environment
          Value: !Ref pEnvironment
        - Key: Team  ### <------------------------
          Value: !Ref pTeamName
```

EC2 Snippet Example (Without Parameter):
```
...
  rEC2Instance:
    Type: AWS::EC2::Instance
    Properties:
      IamInstanceProfile: !Ref pIamInstanceProfile
      InstanceType: !Ref pInstanceType
      SecurityGroupIds:
        - !Ref pSecurityGroup
        - !ImportValue ToolsAccessSG
      ImageId: !Ref pImageId
      SubnetId: !ImportValue oPrivateSubnetA
      Tags:
        ...
        - Key: Environment
          Value: !Ref pEnvironment
        - Key: Team  ### <------------------------
          Value: MyTeamName
```

S3 Snippet Example (With Parameter):
```
Parameters:
  ...
  pTeamName:
    Description: Name of the team managing this resource
    Type: String
    Default: MyTeamName

Resources:
  rProductBucket:
    Type: "AWS::S3::Bucket"
    Properties:
      BucketName: !Sub "${pProductNameLower}-productbucket-${AWS::Region}-${AWS::AccountId}"
      VersioningConfiguration:
        Status: Enabled
      Tags:
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: DataClassification
        Value: !Ref pDataClassification
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pProductName
      - Key: Environment
        Value: !Ref pEnvironment
      - Key: Team  ### <---------------
        Value: !Ref pTeamName
```

S3 Snippet Example (Without Parameter):
```
  rProductBucket:
    Type: "AWS::S3::Bucket"
    Properties:
      BucketName: !Sub "${pProductNameLower}-productbucket-${AWS::Region}-${AWS::AccountId}"
      VersioningConfiguration:
        Status: Enabled
      Tags:
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: DataClassification
        Value: !Ref pDataClassification
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pProductName
      - Key: Environment
        Value: !Ref pEnvironment
      - Key: Team  ### <---------------
        Value: MyTeamName
```





