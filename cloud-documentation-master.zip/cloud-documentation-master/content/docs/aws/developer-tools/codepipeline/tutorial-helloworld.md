---
category: aws
draft: false
title: ExampleApp-HelloWorld
menu: docs
weight: 4
---

### This is a walk-thru of how to setup a 'Hello World' website using Tomcat and deploy it to AWS using CodePipeline.

#### Prerequisites:
 * You are familiar with Git/GitHub. There are many courses are PluralSight if needed.
 * You have a secondary ID & PIDM access and have all the correct access to login into AWS. 
 * You are familiar with some of the services that are provided by AWS such as 
    * EC2
    * LoadBalancers
    * Route53
    * CloudFormation
    * CodePipelines
   
   There are many classes on PluralSight which can give you a fundamental understanding of these which will make this tutorial flow better
 
#### Debugging failures
* To debug failures for the different stages of the pipelines refer to [Troubleshooting Section](/docs/general/troubleshooting/)

### Steps:
* Before a pipeline can be run, you will need a GitHub Repo where you will save your source code.
    * Create a new github repo at [GitHub](https://github.nwie.net/Nationwide). It should be a public repo.
    
    * You will also need a Personal Access Token which will be used in the code pipeline. 
    * Follow the instruction on [HowTo-GithubTokens](/docs/general/github/howto-githubtokens/)
    
* We will be deploying a sample 'Hello World'. You can get the sample code (or use your own)
    * Sample code is available on the site [Java-Maven-Tutorial](https://www.mkyong.com/maven/how-to-create-a-web-application-project-with-maven/)
    * [Another example](https://github.nwie.net/Nationwide/SampleTomcatMaven/tree/master/java-web-project)
    * An completed example of what your repo will looks like can be found at [here]( https://github.nwie.net/Nationwide/katBlueGreen/)    
    
* We will now set up a pipeline to deploy your code.
    * Login into AWS and select -  your BSA tools account Tools{BSA}-CODEPIPELINE-AWS or InfraSvcsProd-CODEPIPELINE-AWS(legacy). This is where all pipelines are built.
    * Search for 'Service Catalog'. Then click on 'Products'
    * This will bring up Nationwide specific available templates for Pipelines
    * Select 'ServerBlueGreen' and 'Launch Product'. Provide a 'Name'
    * Fill-in all the details for the parameters. Pick Linux.
    * To fill in the parameters - refer to [Cloudformation](/docs/aws/management-and-governance/cloud-formation/) 
    * All the details are mandatory and keep in mind the length of some of the parameters
    * When naming the 'ProductName' enter the name of the product you are building. This name will be used to build many the parameters for CodeBuild/CodePipeline

* Click 'Next' and 'Launch' the product. The pipeline runs and creates the stack

* This creates a branch in your GitHub repo IAC* with all the config files needed to deploy the code in different environments. 
   Below is a list of all the files created

	* iac		
		* CloudFormation
			* CodeDeploy-<env>.json
			* CodeDeploy.yaml
			* CodePipeline.json
			* CodePipeline.yaml
			* LoadBalancerAutoScalin-<env>.json
			* ProductRole-<env>.json
			* ProductRole.yaml
			* SecurityGroup-<env>.json
			* SecurityGroup.yaml
		* CodeDeploy
			* appspec.yml
			* start_application.sh
			* stop_application.sh
		* Packer
			* install_application.sh
			* install_aws_services.sh
			* packerfile.json			
		* Route53
			* Param.yaml (Create YAMLs for all environments as needed)
	* appspec.yml
	* buildspec-appvalid.yaml
	* buildspec-bake.yaml
	* buildspec-ci.yaml
	* buildspec-gitint.yaml
	* buildspec-skipping.yaml
	
* There will also be a pull request to merge the new branch with master. When the branch is merged it will trigger a pipeline 

* Details about what all the config files do are in the readmes below
    * [IAC-README](https://github.nwie.net/Nationwide/AWS-PipelineFactory/blob/master/src/Git/code/add_templates/README/Linux/IAC-README.md)
    * [BlueGreen-README](https://github.nwie.net/Nationwide/AWS-PipelineFactory/blob/master/src/Git/code/add_templates/README/Linux/BlueGreen-Readme.md)

#### Changes for ExampleApp
##### Note: All these changes do not need to be made at the same time. Changes can be made incrementally to check and see the progress of the pipeline

This section talks about all the changes that need to be made to the different config files for your HelloWorld App.

 * Follow the instructions in the readmes below
   * [SampleTomcatMaven-README](https://github.nwie.net/Nationwide/SampleTomcatMaven/blob/master/README.md)
   * [MiddlewareTomcatAWS-README](https://github.nwie.net/Nationwide/mw-tomcat/wiki/AWS) under 'Installation'
   * We will be using Apache Tomcat for the webapp.
    
* The default path listed in the LoadBalancerAutoScaling.YAML file for the load balancer needs to be updated to pass the HealthCheck
    * This is in ./iac/CloudFormation/LoadBalancerAutoScaling.yaml->rTargetGroup'->'HealthCheckPath'
    * Change this to the homepage of your website e.g. /SampleWebApplication/
    
* Next, in the iac/Route53 folder has the Param.yaml which currently has the production name your APP which is created by default.
    * Create 3 files and update the values. 
         * Dev<your_business_unit>.yaml
         * Test<your_business_unit>.yaml
         * Dev<your_business_unit>.yaml
    
* Next we will update certificates for each environment
    * In the files iac\CloudFormation\LoadBalancerAutoScaling-<your_business_unit>.json. Update the parameter 'pCommonName'
    * This will be the same be the concatenation of both the values from the Route53 file for that environment.
        * e.g.  ktestappbg-devio02.aws.e1.nwie.net

* SSH - If you want to be able to SSH to your Dev EC2 instance you need to make the following changes
    * In the file ```SecurityGroup.yaml -> rInstanceSG``` add the following
    
              - IpProtocol: tcp
                FromPort: '22'
                ToPort: '22'
                CidrIp: 10.0.0.0/8
                Description: 'SSH'
        
    * Next follow instructions in [HowTo-SSH](/docs/aws/compute/ec2/howto_ssh/) under 'SSH into a Linux machines - adding users through CodePipeline'

* Once all the changes are made commit the code. Every time a commit is made to your GitHub repo a  pipeline is triggered. 

* After your code is successfully deployed using the pipeline in Dev open a browser to your webpage 
    * Example: https://ktestappbg-devio02.aws.e1.nwie.net/SampleWebApplication/ 
    * A completed example of what your repo will looks like can be found at [Completed Example]( https://github.nwie.net/Nationwide/katBlueGreen/) 
     

### Few things to remember     

* Pipelines are created and kicked off in the InfraSvcsProd Account. 

* Once they are in the 'Dev'; 'Test'; 'Prod' deployment stage logs for these can be found in the Dev/Test/Prod environment of the Business Unit you are running as under 'CloudFormation'.
   
* Prior runs of the pipelines are not currently automatically cleaned up. So it is a good idea to cleanup any instances such as LoadBalancers, EC2 instances to avoid incurring charges

* When cleaning up instances created by prior runs always clean them up through CloudFormation and not just the resource itself.

* DO NOT cleanup any entries in the CloudFormation Stack by 'Lambda:CrossAccountCloudFormation'. This is initial setup done when a pipeline is created from Service Catalog.
    * Pipeline Action Role (Lambda:CrossAccountCloudFormation)
    * KMS Key for Product AMI and SSM (Lambda:CrossAccountCloudFormation)
    * IAM Role for Products EC2 (Lambda:CrossAccountCloudFormation)
    * KMS Key for Product AMI and SSM (Lambda:CrossAccountCloudFormation)
