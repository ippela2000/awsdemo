---
category: aws
draft: false
title: How to Skip AMI Bake
menu: docs
weight: 2
---

## What does it do? 

* This new feature speeds up your CodePipeline's runtime by skipping the bake AMI stage of your infrastructure pipeline, when small infrastructure changes have been made. 
* This is done by the buildspec-bake.yaml file searching the package created by the buildspec-ci.yaml for a file called "no-bake". 
* When that file is found it will use the latest encrypted AMI on the account from its previous run. 
* Keep in mind **it is mandatory to have at least baked your AMI once a month in order to get the latest AMI releases.** 
* Examples of small infrastructure changes include changes to:
    * Security Group
    * Product Role


## What gets added to your repo?

The file that gets added to your github repo at the top level is "no-bake" without a file extention (it is case sensitive):
![no-bake](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/no-bake.png)


## Who can utilize this feature?

Developers who can utilize skipping the bake step are those who are using the following pipeline types for both Windows and Linux OS's:
  - Server Blue Green
  - Server Blue Green Quick Deploy
  - Simple Server
  - Simple Server Quick Deploy

## How to revert back to baking your AMI? 

Simply delete the no-bake file in your github repo and buildspec-bake.yaml file will bake the AMI as it did before. 

## Examples of use:

#### How to update to use with existing pipeline:

1.  Verify your buildspec-bake.yaml and buildspec-ci.yaml files mimic the ones listed below: 
        
    *All pipelines that encrypt AMI's utilize the same buildspec-bake.yaml and buildspec-ci.yaml structures these links below serve as an example for all four of those pipeline types*
    * [buildspec-bake.yaml](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple/blob/master/src/templates/buildspec-bake-template-simple.yaml)
        * Keep in mind to replace the jinja code on the buildspec-bake.yaml file on the following lines:
          - All of 5-9 with `"PIPELINE_NAME": "YOURPIPELINENAME"`
          ![PipelineName](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/PipelineName.png)
          - 56 `{ { Foundational_AMI_Name } }` with your OS's AMI (NWLinux7 or windowsServer2016)
          - 62 `{ { pRootDir } }` with your root directory for your changes in your Git Repo (most are iac)
          ![pRootDir](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/FoundDir.png)
    * [buildspec-ci.yaml](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple/blob/master/src/templates/buildspec-ci-template.yaml)
         * The only thing to change is adding the "- no-bake" to your artifacts: 
         ![nobakeartifact](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/nobakeartifact.png)
2.  Add a file called "no-bake" to your github repo at the top level without a file extention (it is case sensitive)
![no-bake](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/no-bake.png)

3.  Make small infrastructure changes and commit.

4. Verify pipeline does not bake.

#### How to add no-bake to newly ordered pipeline: 

1.  Let your pipeline run through the bake stage to first establish a baked AMI.

2.  Verify your buildspec-bake.yaml and buildspec-ci.yaml files contain the no-bake logic:  

    *All pipelines that encrypt AMI's utilize the same buildspec-bake.yaml and buildspec-ci.yaml structures these links below serve as an example for all four of those pipeline types*
    * [buildspec-bake.yaml](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple/blob/master/src/templates/buildspec-bake-template-simple.yaml)
      - The no-bake logic should be in all three build stages (prebuild, build, postbuild)
        * Prebuild:
        ![pre](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/prebuild.png)
        * Build
        ![build](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/build.png)
        * Postbuild
        ![post](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/postbuild.png)
    * [buildspec-ci.yaml](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple/blob/master/src/templates/buildspec-ci-template.yaml)
      - The buildspec-ci-template.yaml will just have "no-bake" as an artifact
      ![nobakeartifact](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/nobakeartifact.png)
3.  Add a file called "no-bake" to your github repo at the top level without a file extention (it is case sensitive)
![no-bake](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/no-bake.png)

4.  Make small infrastructure changes and commit

5.  Verify pipeline does not bake.
