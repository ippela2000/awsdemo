---
title: "Code Pipeline Updates"
category: aws
draft: false
menu: docs
weight: 3
---
# Pipeline Updates

## Updating an existing pipeline

As your EC2 instances associated with your pipeline age, so does the software on them. This includes underlying OS software, leaving us vulnerable. In order to keep infrastructure up to date, we are requesting end users to update their pipelines every 30 days in order to get the latest software and pipeline features. Using a Blue-Green deployment will allow you to deploy new infrastructure without impacting current infrastructure, making a seemless switch between the two.

In order to update your pipelines, please follow these steps:
1. Log into AWS using your BSA Tools account or InfraSvcsProd(legacy) Pipeline role that you used to initially order your pipeline
2. Under Services, search for Service Catalog
3. On the left panel, choose "Provisioned products list"
4. Choose the pipeline you wish to update
5. Click the ACTIONS button on the right and then select Update
6. Choose the latest version of the product (There usually is only one, so choose that)
7. Update any of the items here. If you do not want to change your github access token, be sure to check "Use existing value"
8. Click NEXT in the lower right through the next few screens, finally selecting UPDATE

This will update your pipeline with the latest information from the Cloud Delivery Team. You would then need to approve the Pull Request created again in your Github repository.

## Pipeline Migration

As we learn more about how our end users are using our products, new features are added to our products in order to improve stability and end user experience. Unfortunately, many of these changes require a re-architecture of the product and cannot be added to the product in its current state without sacrificing stability. This section is meant to aid in the process of moving to the new products.

### Product Comparison
The following pipeline products are considered in containment and will not have new features pushed to them. These require ordering a new pipeline and cannot be updated automatically. If you are currently using a pipeline in containment, you may continue using them, but you will not be able to receive new enhancements or bug fixes. 

|In Containment                              | Replacement    | Comments                                 |
|:------------------------------------------:|:--------------:|:----------------------------------------:|
|CI_CD-Application-EC2-Linux-BlueGreen|Server-BlueGreen-QuickDeploy|Select Linux as your platform and NWLinux7 as your Foundational AMI|
|CI_CD-Application-EC2-Linux-Tomcat_BlueGreen|Server-BlueGreen-QuickDeploy|Same as Server-BlueGreen. Follow the instructions [Here](https://github.nwie.net/Nationwide/mw-tomcat/wiki/AWS) to install Tomcat
|CD-Application-EC2-Windows-Simple|Server-Simple|Select Windows as your platform and windowsServer2016 as your Foundational AMI
|Serverless-Simple|Serverless|Updated to provide multiple code language examples and ingress options (no ingress, API Gateway and Loadbalancer)
