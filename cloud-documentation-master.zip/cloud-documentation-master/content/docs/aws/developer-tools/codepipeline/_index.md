---
cardImage:
category: aws
draft: false
title: "Codepipeline"
menu: docs
---

#### If you have never used AWS before **DO NOT** start with creating pipelines.
* Below is a recommended path steps to do before using Code Pipelines

    * First Use the AWS UI to get familiar with basic AWS services like EC2, S3 and IAM. You will do this in your Development AWS account
    * Understanding Identity Access Management (IAM) is key avoiding many of the common access errors you will run into
    * Once you have gotten comfortable with using the UI the next step is to understand Infrastructure as Code (IAC).
    * Use CloudFormations to build what you did through the UI. That way you can use that same Cloudformation in the CodePipeline.
    * Now that you know how to define your infrastructure as code, you can start using code pipeline to automate you application and infrastructure deployment 

[Next - Code Pipeline Overview](/docs/aws/developer-tools/codepipeline/howto-codepipeline-at-nationwide)
