---
category: aws
draft: false
title: How to CodePipeline at Nationwide
menu: docs
weight: 1
---

### AWS Service Catalog

* The **CDT TEAM HAS** provided some templates for commonly used patterns that you can leverage using the **AWS Service Catalog** instead of building them from scratch.
* These pipelines will come with default Cloudformation templates that can be used, but these pipelines can be modified to deploy other Cloudformation as well.
* While development allows you to directly create and manage resources through the UI all changes to AWS resources in higher environments must be made in code through a pipeline.**
* If you have never used AWS before **DO NOT** start with creating pipelines, start [here](/docs/aws/developer-tools/codepipeline/)


### Steps to deploy a Code Pipeline via Service Catalog:
* Before a pipeline can be run, you will need a GitHub Repo where you will save your source code.
    * Create a new github repo at [GitHub](https://github.nwie.net/). **Note: Your GitHub repository must be public**
    * You will also need a Personal Access Token which will be used in the code pipeline. 
    * Follow the instruction on [HowTo-GithubTokens](/docs/general/github/howto-githubtokens) 

* You'll need to log into the **Tools** AWS account in your BSA (Ex: ToolsIO02) and using the CodePipeline role (Ex: **ToolsIO02-CODEPIPELINE-AWS**) for your BSA. 
* If you're currently logged in to another account, return to the AWS [login](https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=urn%3Aamazon%3Awebservices&TargetResource=https://console.aws.amazon.com/servicecatalog/home?region=us-east-1#/products) page to switch accounts.
* Once logged in, navigate to the AWS Service named Service Catalog, and ensure you are in the **US East (N. Virginia)** region. 
* Select Product List. Select **Server-Simple** 
* Select the latest version and click next
* Fill in the details in the Parameters
    * For GitHub Repository URL - Enter the 'Public' Github you created
    * For 'GitHub Repository Service Token' - Enter the Personal Token you saved earlier
    * Enter all the details needed in the page
* Click on 'Next' till you get to 'Launch'
* Once it is launched, go to the 'Provisioned product list' and select your product to get the status
* After the Status is 'Available' go to **Services** and search for **Code Pipelines** and select it
* Look for your pipeline in the list. The first time your pipeline will have a failed status.
* Goto your GitHub repo and there should now be a new branch called IAC-xxxxxxxxxx with all the templates for Server Simple 
* Merge the branch with master and this will trigger your pipeline. 
* Each pipeline comes with a ReadMe that details what the different steps in the pipeline do
* These can be further customized to your needs  

### Video Tutorial 
* There is a video tutorial that walks-through an example implementation you can look at [here](https://videospace.nationwide.com/playlist/dedicated/93125981/1_d5naxk8l/1_57192bat)

### Modifying your pipelines
* Requesting the EC2 Windows Simple, or the Linux Blue Green does not lock you into the particular platform. 
* With a few changes you can convert or change any Pipeline to use any type.
* You can also add S3, EFS to the pipeline etc by adding additional yaml & json files using Cloudformation templates provided in the AWS site
* Your Cloudformation template and parameter files will need to be in your iac/CloudFormation folder. 
* Output file and Output artifact might not be needed if you are not outputting anything in your cloudformation step. Input artifact can be updated with others, but Source is required.
* This is where the Pipeline is referencing the Source output to pull your cloudformation template in the TemplatePath and Configuration.

### Updating your Pipeline
* There are instructions on how to update your current pipeline with any updates to that pipeline by CDT in [HowTo-PipelineMigration](/docs/aws/developer-tools/codepipeline/howto-pipelinemigration/)

### Below is an example flow of most Pipeline templates:

<img src="https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Slide2.PNG" alt="CI/CD pipeline" style="max-width:100%;"/>

**What Pipeline should I use?**

* There are multiple template Pipelines offered as apart of **AWS Service Catalog**. Refer to [Current template offerings](/docs/aws/management-and-governance/service-catalog/) for latest list

## Points to Remember
* Pipelines are 99% customizable within reason. They can be updated to remove some of the template steps, or have other steps added
* All pipeline templates can be modified in Code in the repo to do anything, but some will give you some starting resources to make things go a bit quicker. If you want to deploy out Lambda functions for something completely serverless it is best to start with the Serverless pipeline.
* If you are looking to deploy a web application the recommendation is to use the Server-BlueGreen.
* Some of the steps that come with your ordered pipeline are required like the ServiceNow Cloud stack step, as well as potentially automated RFC that will get created from your Pipelines in the future.
* There are additional deployment steps for other patterns in the HowTo documents


### Pipeline Examples

Take a look at these examples of fully functional pipelines that build sample applications. For repo specific changes there is a Readme included on the master branch that goes over what changes were made from the base Pipeline to have these applications built

* [Linux Tomcat server with Maven install example](https://github.nwie.net/Nationwide/SampleTomcatMaven)
* [Linux server Node.js example](https://github.nwie.net/Nationwide/SamplePipelineApp)
* [Simple Windows EC2 with additional D: drive example](https://github.nwie.net/Nationwide/simple-win-ec2.git)
* [FSX Windows example](https://github.nwie.net/Nationwide/sample-fsx-windows.git)


### Already requested or using a Pipeline?

For those that have requested a pipeline please take a look at the following Guides on Pipelines. These guides will be included in the iac folder in requested pipelines.

* [Linux/Tomcat Blue Green Pipeline](https://github.nwie.net/Nationwide/AWS-PipelineFactory/blob/master/src/Git/code/add_templates/README/Linux/IAC-README.md)
* [Windows EC2 Simple](https://github.nwie.net/Nationwide/AWS-PipelineFactory/blob/master/src/Git/code/add_templates/README/Windows/IAC-README.md)

Any suggestions please open an issue [HERE](https://github.nwie.net/Nationwide/AWS-PipelineFactory/issues/new/choose) and we will work on getting feedback added to our documentation.

### Curious about Blue/Green Deployments?

For those that are curious or have requested a BlueGreen deployment Pipeline check out the following guide on how to use it, to deploy your app in a zero downtime manner

* [BlueGreen ReadMe](https://github.nwie.net/Nationwide/AWS-PipelineFactory/blob/master/src/Git/code/add_templates/README/Linux/BlueGreen-Readme.md)


### Expected Pipeline IAM Errors

![pipeline error 1](/docs/aws/images/pipeline-launch-error.png)
![pipeline error 2](/docs/aws/images//pipeline-launch-error2.png)

### Cloudformation Vs Code Pipeline
* An important difference in deploying Cloudformation in a Pipeline and via AWS CLi is the format of the configuration file (The parameters and their values are exactly the same)

##### Codepipeline Config File Format:

```json
{ 
  "Parameters": {
     "ParamName1": "ParamValue1",
     "ParamName2": "ParamValue2"
  }
}
```
* Below is code template for of Cloudformation you will see in your Code Pipeline. 
* This would be the same format you need to use to add additional Cloudformation to your template provided by CDT via AWS Service Catalog. 
* Anything in <> should be replaced with your own items. There are also comments with each relevant line in the below snippet.


##### Codepipeline step for Cloudformation deployment:

```yaml
  - Name: <action name>
    ActionTypeId:
      Category: Deploy
      Owner: AWS
      Provider: CloudFormation
      Version: '1'
    Configuration:
      ActionMode: CREATE_UPDATE
      Capabilities: CAPABILITY_NAMED_IAM
      RoleArn: !Sub arn:aws:iam::${pDevAccountNumber}:role/${pCodePipelineActionRole}
      StackName: !Sub ${pProduct}-<Cloudformation Name>-Dev${pBusinessUnit}
      TemplateConfiguration: !Sub Source::iac/CloudFormation/<Cloudformation Name>-Dev${pBusinessUnit}.json
      TemplatePath: Source::iac/CloudFormation/<Cloudformation Name>.yaml
      OutputFileName: !Sub Dev${pBusinessUnit}<Cloudformation Name>.json
    InputArtifacts:
      - Name: Source
    OutputArtifacts:
      - Name: !Sub Dev${pBusinessUnit}<name>
    RoleArn: !Sub arn:aws:iam::${pDevAccountNumber}:role/${pCodePipelineActionRole}
    RunOrder: 1
```

