---
title: Tagging to Manage Costs
menu: docs
category: aws
---

### Overview

Below is a list of commonly needed tagging needed by services. 

* [Tagging EBS and Snapshots in Dev](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Tagging%20EBS%20and%20Snapshot%20in%20Dev.docx?d=w11118104d3284b15a6f606c5b88ce7f3&csf=1&e=DW06DD)
* [Tagging EC2 in Dev](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Tagging%20EC2%20in%20Dev.docx?d=w0d3d2ccddebe45699b42096d6f4f11c8&csf=1&e=hm53s0)
* [Tagging Key Management Service in Dev](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Tagging%20Key%20Management%20Service%20in%20Dev.docx?d=wf437ef1f22b342ecbd7b6b9daeb48e13&csf=1&e=qQXyX3)
* [Tagging Lambda to Manage Costs](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Tagging%20Lambda%20in%20Dev.docx?d=w5d717e8b61da427081a22e2c67d794e6&csf=1&e=Uib5yQ)
* [Tagging S3 to Manage Costs](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Tagging%20S3%20in%20Dev.docx?d=wabb29ffd1cb74b8a8a5812fc73eee10d&csf=1&e=JzHj6E)
* [Tagging SQS to Manage Costs](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Tagging%20SQS%20in%20Dev.docx?d=w7668d709c8654a12bda91b37bf085dfe&csf=1&e=AhY7rx)
* [Terminating or Stopping Services Services in Dev](https://onyourside.sharepoint.com/:w:/r/sites/CloudOptimizationServiceTeam/Shared%20Documents/Managing%20Dev/Terminating%20or%20Stopping%20Services%20in%20Dev.docx?d=wf27c19fdbd1b4e9795467a3910ca0cc3&csf=1&e=ASIkOW)
