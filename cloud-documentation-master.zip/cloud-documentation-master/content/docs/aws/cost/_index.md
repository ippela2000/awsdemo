---
title: "Cost"
menu: docs
category: aws
---

### Cost Management

* In the cloud, infrastructure charges will be directly charged back to the BSA and application teams creating those charges.
  
* Each application owner will have access to our cloud cost management platform, Cloudability, to track their costs, usage, anomaly spend, spend forecasting and rightsizing opportunities.

* For the latest information around cloud cost management, onboarding and getting help visit the [Cloud Optimization Team Sharepoint](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/tutorial/tut71-UnderstandingCost/)



