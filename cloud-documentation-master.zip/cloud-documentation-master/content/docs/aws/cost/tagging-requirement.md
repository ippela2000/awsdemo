---
title: Required Tags for Service at Nationwide
menu: docs
category: aws
weight: 1 
---



Per [AWS tagging best practices](https://aws.amazon.com/answers/account-management/aws-tagging-strategies/), different tag categories should be used for each business use case.

### NOTE: Below tagging compliance will go into effect on August 17th, 2020. Please reach out to the cloud success team with any questions.

### Why Is Tagging Required At Nationwide?

* Tagging is a mechanism that helps manage and organize assets in a Cloud environment. 
* Resources should be tagged based on categories, to easily identify them within their use case. 
* Proper tagging can help in organizing cost breakup, automation, and access control.

#### Cost & Billing
 Tagging drives billing. By tagging resources properly, your application will only be billed for those resources. Plus there are certain tags, like ShutDownInstanceAt, that can help with expense management. 
 
#### BSA Reporting 
 Tagging helps drive BSA reporting. If all your resources are tagged with the APRMID tag, business units should be able to tie all the resources together to get an accurate overview of all live resources.

### Required tags

#### EC2
* DataClassification
* ResourceOwner
* APRMID
* ResourceName
* DisbursementCode
* Patch
* ShutDownInstanceAt
* PowerOnInstanceAt

#### All data storage and database products
* DataClassification
* ResourceOwner
* APRMID
* ResourceName
* DisbursementCode

#### All other resources that support tagging
* ResourceOwner
* APRMID
* ResourceName
* DisbursementCode

#### Notes
If your AWS resource was created via Kubernetes, see the [Kubernetes Labeling page](https://gocloud.nwie.net/docs/cnp/kubernetes-labeling/) for more info.

##### EC2
* Any EC2 instance created in a Nationwide AWS account need a set of required tags. The table below has a list of all required tags.
* **Instances that have incomplete or improper tagging may be shut down without notice**
* If your EC2 instance is shutdown, you can look at the "tags" tab in the console and look for the tag 'LastAutomatedShutDown'. 
* Once you have corrected the issue, you can restart.

##### RDS
* You can request changes to the tagging of RDS products by opening a service now request. Information about how to do that can be found here: https://fancy.nwie.net/RDSChangeRequests
* You can alternatively open a github card here: https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues
----

<button class="bootstrap-modal-btn" type="button" class="btn btn-primary" data-toggle="modal" data-target="#required-tags-modal">
  View full listing of policy controlled tags
</button>

<div class="modal fade" id="required-tags-modal" tabindex="-1" role="dialog" aria-labelledby="Required tags table" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table>
          <thead>
              <tr>
                <th>Required in Dev</th>
                <th>Required in Test</th>
                <th>Required in Prod</th>
                <th>Tag Key</th>
                <th>Description</th>
                <th>Allowed Values</th>
                <th>Example(s)</th>
                <th>Applies To</th>
                <th>Additional Information</th>
              </tr>
          </thead>
          <tbody>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>Yes</td>
                <td>DisbursementCode</td>
                <td>Nine digit identifier indicating where costs for this resource will be   charged.</td>
                <td>Nine digit numeric value</td>
                <td>300672001</td>
                <td>All Resources</td>
                <td>Application Product Managers (APMs) should provide a disbursement code.   If you are unsure which code to use, please contact   CloudOptimizationServices@nationwide.com</td>
              </tr>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>Yes</td>
                <td>ResourceOwner</td>
                <td>Primary contact or group for this resource (e.g. Application Owner, Data   Owner). Used for communications.</td>
                <td>A valid email string ending in @nationwide.com</td>
                <td>CloudOptimizationServices@nationwide.com</td>
                <td>All Resources</td>
                <td>Please provide a distribution   group to avoid dependency on a single person. This email distribution group   will be used if there are security concerns with the resource, cost concerns,   for reporting, etc.             The individual responsible for &#39;creation&#39; of the resource will be   responsible for any requested changes.            <em>Note</em>  the resource owner will be   alerted for all pipeline changes, security issues, and any other alerts using   resource owner as the tag.</td>
              </tr>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>Yes</td>
                <td>APRMID<em>*</em></td>
                <td>Four digit application identifier. Recorded in ServiceNow.</td>
                <td>Four digit numeric value</td>
                <td>1345</td>
                <td>All Resources</td>
                <td>Please refer to ServiceNow for your APRMID. If you are unsure which   APRMID to use, please contact CloudOptimizationServices@nationwide.com</td>
              </tr>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>No</td>
                <td>ShutDownInstanceAt</td>
                <td>Indicates that an instance can be shut down at the specified UTC   (Universal Time Coordinated) time.</td>
                <td>A string in the format of hh:am/pm UTC</td>
                <td>11pm UTC,      10pm UTC</td>
                <td>EC2</td>
                <td>UTC is 4 hours ahead of eastern   standard time            Use two digits when selecting time, e.g. “01pm UTC” or &quot;12am   UTC&quot;            If you have questions or concerns, please contact the Cloud Success Team at   CloudSuccessTeam@nationwide.com            In Test/Dev environments, unless there was an exception request, all   resouces will be shut down at 10pm UTC if there is no valid time in the   ShutDownInstanceAt value (example: a false value will be marked with a 10pm   UTC shutdown unless there is an exception)            If exceptions are needed, please navigate to halo.nwie.net and request an   exception.</td>
              </tr>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>No</td>
                <td>PowerOnInstanceAt</td>
                <td>Indicates that an instance can be powered on at the specified UTC   (Universal Time Coordinated) time.</td>
                <td>A string in the format of hh:am/pm UTC</td>
                <td>11am UTC,      08am UTC, False</td>
                <td>EC2</td>
                <td>UTC is 4 hours ahead of eastern   standard time            Use two digits when selecting time, e.g. “01pm UTC” or &quot;12am   UTC&quot;            If you have questions or concerns, please contact the Cloud Success Team at   CloudSuccessTeam@nationwide.com            If exceptions are needed, please navigate to halo.nwie.net and request an   exception.</td>
              </tr>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>Yes</td>
                <td>DataClassification</td>
                <td>Used to determine if a resource stores/uses sensitive data.</td>
                <td>One or more of these   values:      public,       non-public,       sensitive,       PCI</td>
                <td>public</td>
                <td>EBS Volume, Elasticfilesystem, S3, storagegateway, FSX, dynamodb</td>
                <td>Critical to select what the data   actually is, if the data was selected to be public data but is actually   sensitive data, the resource creator/owner will be responsible.            Please see the EDO descriptions of the four types of data for better clarification.</td>
              </tr>
              <tr>
                <td>Yes</td>
                <td>Yes</td>
                <td>Yes</td>
                <td>ResourceName</td>
                <td>Unique name of th resource and its purpose. Please use a description that   is meaningful to people outside of your team.</td>
                <td>Any valid string</td>
                <td>MyInstanceTest02</td>
                <td>All Resources</td>
                <td>Resource name should be a description of the resource and the   workload/app that is using the resource. Please ensure naming conventions are   understandable to those at Nationwide and not just within a team. </td>
              </tr>
          </tbody>
        </table>
        <p><b>*</b>If the work that you are doing doesnt have an APRMID, please do one of the following:</p>
        <p><b>*</b>APRMIDs for innovation or other non-application work guidance:
        <ol>
          <li>Use an APRMID that is most closely aligned to the work you are doing</li>
          <li>Create a new APRMID (go through the standard process) that is specific to innovation work in your area</li>
          <li>As a last resourt, please use the APRMID 999999 - but note this will be reported out as an 'undocumented app'</li>
        </ol>
        <p>** Use Hours only in your <strong>PowerOnInstanceAt and ShutDownInstanceAt</strong> tags.  Adding minutes will result in your tag being ignored.</p>
        <p>** <strong>AutoShutDown8pm</strong> Tag is now deprecated. New pipelines should not set this tag and instead use <strong>ShutDownInstanceAt</strong>.</p>
      </div>
    </div>
  </div>
</div>
