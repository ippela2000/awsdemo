---
title: How to Amazon EMR
menu: docs
category: aws
draft: false
---

## Amazon Elastic MapReduce (EMR)

### What is Amazon EMR

Amazon EMR is a managed Hadoop framework used for building Data Lakes and processing Big Data.

*What is Hadoop?*

  Apache Hadoop is an open source product using a distributed processing architecture in which a task is mapped to a cluster of "commodity" hardware for processing.  Hadoop uses HDFS (Hadoop Distributed File System) to store data locally for processing.  Unlike traditional Data Warehouse systems, Hadoop can process structured, unstructured and semi-structured data.  The namenode distributes the tasks and handles server failures.  In traditional Hadoop clusters, compute and storage scale together due to the HDFS architecture.  Unlike traditional Hadoop clusters, Amazon EMR allows compute and storage to scale independently.  Hadoop offers many programming frameworks such as Mapreduce, Spark, and Presto.

### Amazon EMR Key Features

Amazon EMR is a service that lets you create and manage Hadoop clusters based on EC2 instances. Any application that is based on the supported Hadoop services such as Hive, Hbase, Pig, Spark, and Mapreduce can be use with Amazon EMR.  The Amazon EMR service also offers EMRFS which is a file system that looks like HDFS to the application.  EMRFS allows your application to process data directly from S3, DynamoDB, Kinesis and Redshift so any analytics jobs can span one or more data stores.  Glue can be used with Amazon EMR for the metastore.

### Amazon EMR Architecture

* Amazon EMR supports Hadoop tools such as Hive, Pig and HBase.
* Amazon EMR runs distributed computing frameworks such as MapReduce, Spark and Presto.
* Hue and Zeppelin are the GUI interfaces for the cluster.
* The master node is the access point in to the cluster.  This is node that runs the namenode services of traditional Hadoop clusters.
* The tasks can be executed on core nodes (compute and HDFS) or task nodes (compute only).
* Core nodes and task nodes can be independently scaled up and down in an EMR cluster while the cluster is running.
* All standard Hadoop ecosystem utilities are accessible via command line.
* EMR allows you to choose which Hadoop tools and frameworks you want.  You also have the option to run custom actions (bootstrap scripts) to get customized tools and frameworks.
* EMR allows you to choose programs to run at start up (step functions).

### Amazon EMR Benefits

* **Easy** - With EMR it is not necessary to provision, configure or tune Hadoop nodes.
* **Better Controlled Cost** - EMR use EMRFS, AWS persistent storage and Amazon pricing for EC2 instances.
* **Elastic** - Independently and easily scale master, compute and storage nodes.
* **Secure** - access is controlled with security groups and uses server-side encryption (S3) and client-side encryption (EMRFS).
* **Reliable** - EMR is constantly monitoring, retrying failed tasks and replacing poorly performing nodes.  Additionally, EMR provides the latest secure open source software releases.
* **Flexible** - EMR can be launched as a long-lived (persistant steady state) cluster or as a transient cluster which allows you to define a series of steps to tell the cluster what programs to run and then shut down.

 ### Amazon EMR Notebooks

 Amazon EMR provides Jupyter based notebooks.  EMR Notebooks are preconfigured to work with Spark and are easy to use.  The notebooks support Python, PySpark, Spark SQL, SparkR and Scala programing languages.  Notebooks are not restricted to a single cluster and can be securely run by multi-users.

### Amazon EMR Migration Guide

See the guide for Amazon EMR migration [here]({{site.git_edit_address | append:"/_aws-docs/amazon_emr_migration_guide.pdf"  }})
