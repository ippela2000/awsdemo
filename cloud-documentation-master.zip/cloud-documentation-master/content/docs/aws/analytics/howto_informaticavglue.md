---
title: Informatica vs. Glue
menu: docs
category: aws
draft: false
---

## When to use Informatica versus AWS Glue For ETL

* [Architectural Documentation](https://onyourside.sharepoint.com/:w:/r/sites/edo/dataarchitecture/_layouts/15/Doc.aspx?sourcedoc=%7BE5CB90B1-2B6D-41F1-9028-3F6AE76D95D2%7D&file=AWS%20GLUE%20FAQ.docx&action=default&mobileredirect=true)
- For additional consultation, please contact:
  - Sabitha Darsi [Architect]
  - Joseph Frazier [SDS Data Tech Consultant]
  - David Vu [APM]

### AWS Glue

- AWS Glue is currently an approved AWS Native Service generally available
  - No exceptions are needed from the Cloud Solutions Teams in order to utilize AWS Glue
    - You should consult your application architects, tech leads, and your Data SME(s)
   - Find documentation, notes and examples here: [AWS CloudFormation and Notes](https://github.nwie.net/Nationwide/AWS-CloudFormation/tree/master/Glue)
