---
title: "AWS"
menu: docs
category: aws
---

### What is Amazon Web Services?

[Amazon Web Services](https://aws.amazon.com/) (AWS) is the world's leading cloud service provider. It offers a variety of infrastructure and platform [services](https://aws.amazon.com/products/) through an on-demand, self service interface which can be accessed via [GUI](https://docs.aws.amazon.com/awsconsolehelpdocs/latest/gsg/getting-started.html), [CLI](https://aws.amazon.com/cli/), and [API](https://aws.amazon.com/tools/) clients.

### How is Nationwide using AWS?

Nationwide has adopted AWS as its primary public cloud provider. The [Cloud Delivery](http://inside.nwie.net/inside-web/callupData/getOrgChartView?orgChartId=0000439675) organization is responsible for Nationwide's relationship with AWS and the core platform. Application teams are responsible for building and operating their applications and supporting infrastructure.

### How do I use AWS?

Go to [Getting started with AWS](/docs/aws/getting-started-with-aws/) to walk-through obtaining access to AWS, familiarizing yourself with important services, and Nationwide's pipeline - based model for migrating your application to the cloud.

### Why go to Cloud?

Today, the infrastructure deployment process takes several plus weeks to provision services for app development. Given the process, the services are often over-provisioned to fit a possible future state expectation. Imagine if you could deploy your application cost-optimized and right-sized on cloud infrastructure in hours, not weeks. This is our vision with Nationwide Cloud.

### What is Cloud Computing?

Cloud computing is the on-demand delivery of compute power, database storage, applications, and other IT resources through a cloud services platform via the internet with pay-as-you-go pricing.

### What are the Benefits?

*   Fast response to business needs through frictionless and automated deployments via pipeline
    *   Increased speed to market, agility, and innovation
    *   Self-service deployment
    *   Self-managed right-sized infrastructure
    *   Instant scalability
    *   Rapid deployment of infrastructure-as-code
*   Reduced impacts through decoupling of applications and data (API’s, sharing, etc.)
*   Enable full stack DevSecOps
*   White glove support during migration
*   Inherent consistency among environments

### Does your App or App Area Qualify?

*   Apps that can adapt to a self-service model of build and support using their own change control processes
*   Apps that can support monthly product updates and adapt to the latest AMI template version within 30 days of each update's occurrence.
*   Application areas that understand the dependencies or direct connections of their app
*   Apps that can replicate Dev/Test environments
*   MUST classify data
*   MUST Use Test Data Management
*   Application areas that understand licensing considerations
    *   **No PCI in any environment at this time**
    *   **No PII** in any of the following environments
    *   Sandbox
    *   Dev
    *   Test
    *   Application Area willing to adhere to:

### What Service in AWS can I use?

* Refer to the [Approved Product and Service page](/docs/aws/products/) to get a full list of all approved AWS services that can be used at NW.


[Next - AWS At Nationwide](/docs/aws/aws-at-nationwide)


