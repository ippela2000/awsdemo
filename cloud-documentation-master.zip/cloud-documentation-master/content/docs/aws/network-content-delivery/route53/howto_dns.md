---
title: Friendly DNS Names
menu: docs
category: aws
---

## How To Get DNS/Friendly Names for Resources in AWS

Many of the auto-generated names for resources in AWS are not resolvable on-prem. This means that users trying to access your resources from another on-premise, nwie.net resource (server, file system, etc.) may not be able to use the auto-generated name. "Friendly" DNS names allow you to create another name which resolves to the 'unfriendly' DNS name.

Custom cloudformation resources have been created for registering friendly DNS names with .nwie.net domains. You will just need to paste in a new section to your template and populate the required values to have a friendly name resolvable from both AWS and on-prem.
Currently only CNAMEs and A records are able to be created; CNAME records need an existing A Record to point to. To learn more about the difference between CNAMEs, Aliases, and A Records, see this [link](https://support.dnsimple.com/articles/differences-between-a-cname-alias-url/).

Bellow are some example snippets to map to AWS auto-created entries for load balancers, and CDT auto-created entries for EC2 instances.

Note: Friendly names cannot be re-used by multiple resources (two different EC2 instances for example)

Note: The remote-route53 lambda currently can only be called via CloudFormation. You must use a codepipeline to add a CNAME, A Record, or SAN to your resources.


## Calling the Lambda in CloudFormation

To request an internal (nwie.net) DNS use the function below in your CloudFormation

```
Parameters:
  pRecordName:
    Type: String
    Description: Friendly name to create in DNS
    Default: friendlyname

Resources:
  rAddCNAME:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: CNAME  # PTR are not currently supported
      RecordName: !Ref pRecordName # should not have .aws.e1.nwie.net on it, just the name
      RecordValue: "somename.com"
```
A CNAME record is an additional name for the DNS name.  CNAMEs point to a DNS Name (the A Record for your DNS). For example, you could have a CNAME of "my-site.aws.e1.nwie.net" that points to the DNS Name "someresourcename-1f7Wq123.aws.e1.nwie.net". Note that CNAME records can only point to other names, not IP addresses.  The "A" record for your DNS points to your IP Address.


### Example - Adding DNS(Friendly Name) to an EC2 - 
```
Parameters:
  pCNAME:
    Type: String
    Description: Friendly name to create in DNS
    Default: friendlyname

Resources:
  rEC2Instance:
    Type: "AWS::EC2::Instance"
    ...

  rAddCNAME:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: CNAME  # PTR are not currently supported
      RecordName: !Ref pCNAME # should not have .aws.e1.nwie.net on it, just the name
      RecordValue: !GetAtt rEC2Instance.PrivateDnsName
```

The above will result in a DNS name of friendlyname.aws.e1.nwie.net for the EC2 instance.


### Example - Adding DNS(Friendly Name) to Private Load Balancer
```
Parameters:
  pCNAME:
    Type: String
    Description: Friendly name to create in DNS
    Default: friendlyname

Resources:
  rLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    ...

  rAddCNAME:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: CNAME  # PTR is not currently supported
      RecordName: !Ref pCNAME # should not have .aws.e1.nwie.net on it, just the name
      RecordValue: !GetAtt rLoadBalancer.DNSName
      #Public: true  # This option should only be used with a public Load Balancer to get a X.awspubliccloud.nationwide.com record instead of a X.aws.e1.nwie.net record
```

The above will result in a DNS name of friendlyname.aws.e1.nwie.net for the load balancer.

Since DNS names are unique, for a pipeline with multiple environments (dev, test and prod) pass in the pCname from a parameter file for each stage with a different name.  Ex: dev.friendlyname or test.friendlyname for the dev and test stages of a pipeline.


### Adding DNS(Friendly Name) to Public Load Balancer

   * Get a public CNAME for your load balancer.

        ```
        rAddCNAME:
            Type: Custom::RemoteRoute53
            Properties:
            ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
            CustomResourceName: remote-route53
            Account: !Sub "${AWS::AccountId}"
            RecordType: CNAME  # A and PTR are not currently supported
            RecordName: !Ref pCNAME # should not have just the name e.g 'media'
            RecordValue: !GetAtt rLoadBalancer.DNSName
            Public: true
        ```

This will give you a record of **{pCname}.awspubliccloud.nationwide.com** e.g. **media.awspubliccloud.nationwide.com** that you can use as the target of an X.nationwide.com alias.


### Request an Alias with the Hosting Team for Custom DNS

- You might want to further customize your DNS to be for example to be **media.nationwide.com** instead of **media.awspubliccloud.nationwide.com**
- Follow these instructions to get a [Custom DNS](/docs/aws/network-content-delivery/route53/howto_customdns/)



### Example - A Record Values
```
Parameters:
  pRecordName:
    Type: String
    Description: Friendly name to create in DNS
    Default: friendlyname

Resources:
  rAddCNAME:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: A  # PTR are not currently supported
      RecordName: !Ref pRecordName # should not have .aws.e1.nwie.net on it, just the name
      RecordValue:
        - 1.1.1.1
```

The above will create an A record. The RecordValue entry can be either a single value or a list, but must be of IP addresses, not other DNS names.
A records are DNS entries to map a name to an IP address. THey have to point to an IP address and cannot reference names like CNAME records.


## EFS Friendly Name for Cross-Account Reference
Using the above A Record values, you can now make a friendly name in .aws.e1.nwie.net for reference cross-account.
See []() for full example of EFS implementation via CloudFormation.

```
Parameters:
  pRecordName:
    Type: String
    Description: Friendly name to create in DNS
    Default: friendlyname

Resources:
  rMountTargetSubnetA:
    Type: AWS::EFS::MountTarget
    ...

  rMountTargetSubnetB:
    Type: AWS::EFS::MountTarget
    ...

  rMountTargetSubnetC:
    Type: AWS::EFS::MountTarget
    ...

  # Optional inclusion of .aws.e1.nwie.net DNS record for cross-account access by name
  rEfsARecord:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:us-east-1:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: A
      RecordName: !Ref pRecordName # should not have .aws.e1.nwie.net on it, just the name
      RecordValue:
        - !GetAtt rMountTargetSubnetA.IpAddress
        - !GetAtt rMountTargetSubnetB.IpAddress
        - !GetAtt rMountTargetSubnetC.IpAddress
```

## Debugging failures

A common error when running the code below in your pipeline
```
  rDNS:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:us-east-1:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
```

is

```
See the details in CloudWatch Log Stream: 2020/05/19/[$LATEST]6f8f5932b1ff4e5e914369c6a7debf02 
```

**Where are the log files**

* When the code run a lambda **remote-route53** is executed in the **InfraSrvcsProd** account. 
* The logs for the lambda are also the **InfraSrvcsProd** account and not your **Dev/Test/Prod/Tools** account
* To find the logs
    * Login into **InfraSrvcsProd**
    * Goto the **CloudWatch** service
    * Select **Logs -> Log Groups**
    * In the **Filter** search enter the following **/aws/lambda/remote-route53**
    * Click on **/aws/lambda/remote-route53** loggroup
    
        <img class="img-responsive w-50" src="/docs/aws/images/cloudwatch-route53-lambda-loggroup.jpg">
        
    * Select your log based on when you ran on from the error message from you Cloudformation stack ```e.g. 2020/05/19/[$LATEST]6f8f5932b1ff4e5e914369c6a7debf02```

        <img class="img-responsive w-50" src="/docs/aws/images/cloudwatch-lambda-log.jpg">
        
