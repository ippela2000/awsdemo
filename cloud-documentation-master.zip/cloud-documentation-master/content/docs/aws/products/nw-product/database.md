---
title: Database Product Team
draft: false
menu: docs
category: general
---



### [Database Products](https://onyourside.sharepoint.com/sites/RDDS/SitePages/DB-as-a-Service---Product-Offerings.aspx)

|Category|Product|Offering Type|Current Availability|GA Quarter|Comment|ProductOwner| 
| :----------- | :---------- | :------------- | :--------------------------- | :----------- | :----------- | :----------- |
|**Managed Database**|[AWS Aurora](https://aws.amazon.com/rds/aurora/)|PostgreSQL|![Generic badge](https://img.shields.io/badge/Dev-Green.svg)|TBD|[Issue 3299](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/3299)|hagyk1@nationwide.com|
|**Managed Database**|[RDS Postgres](https://aws.amazon.com/rds/postgresql/)|RDS|Non-critical and non-customer facing apps|TBD|[Issue 3202](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/3202)|hagyk1@nationwide.com|



#### Dependencies 

|Category|Product|Offering Type|GA Quarter|Comment|ProductOwner| 
| :----------- | :---------- | :------------- | :----------- | :----------- | :----------- |
|**Customer Experience Analytics**|IBM|Tealeaf|TBD| [Issue 89](https://github.nwie.net/Nationwide/Migration-Consulting/issues/89)|TBD|
|**ETL**|Informatica|EC2|Q4|[Issue 100](https://github.nwie.net/Nationwide/Migration-Consulting/issues/100)|Joswick, Tyler|
|**IIB**|IIB Strategy|Applications|TBD|[Issue 115](https://github.nwie.net/Nationwide/Migration-Consulting/issues/115)|Adam Yonut|
|**AD**|Domain Controller|Applications|TBD|[Issue 119](https://github.nwie.net/Nationwide/Migration-Consulting/issues/119)|George Pugh|


#### Latest Releases
