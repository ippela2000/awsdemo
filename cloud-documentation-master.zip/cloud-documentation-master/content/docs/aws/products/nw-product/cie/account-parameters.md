---
title: Available Parameters in All AWS Accounts
draft: false
menu: docs
category: general
weight: 2
---

There are various values placed in Parameter Store of every account by the CIE team when deploying initial infrastructure.

Many of these were previously exposed through CloudFormation Exports, but these have caused problems with deployments in many cases, so we have switched to using Parameter Store for storing these values.

The parameters are stored in parameter store with permissions such that any role in the account can access them, so you should not need anything on your role besides the general permission to ssm:GetParam*

### Using the Parameters in CloudFormation
The amazon document covering this is here: https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/dynamic-references.html

Anywhere in your CloudFormation template, you can enter a string like: `{{ "{{resolve:ssm:<ParameterName>:<Version>" }}}}` and that string will be replaced by the referenced value from ParameterStore before the template is launched.

All of the "default" parameters populated by CIE will have a version of 1 to provide a static reference-point.

Example: `{{ "{{resolve:ssm:PrivateSubnetA:1" }}}}`

### CIE Provided Parameters

|Parameter Name|Version|Description|Example Value|
|:-------------|:--------|:-----------|--------------|
|Account_Number|1|ID of the account|850996745251|
|Account_Name|1|Name of the account|DevCDT01|
|Account_Stack_Name|1|Name of the account stack or BSA|CDT01|
|Tools_Account_Number|1|Number for the Tools account of that BSA stack|120638066983|
|Shared_Prod_Account_Number|1|Number for the InfraSvcsProd account|679177070049|
|Shared_Test_Account_Number|1|Number for the InfraSvcsTest account|563161085545|
|CNP_Account_Number|1|References the CNP account number associated with the environment (Dev BSA -> Dev CNP, etc.)|Varies|
|BSA_Disbursement_Code|1|Default disbursement code of the BSA that owns the account stack|300672001|

### Networking Provided Parameters

|Parameter Name|Version|Description|Example Value|
|:-------------|:--------|:-----------|--------------|
|ToolsAccessSG|1|ID of the ToolsAccess security group|sg-0511ec2605bddd7f2|
|VPCID|1|ID of the VPC in the account|vpc-0cc3a9e4c4993178c|
|PrivateSubnetA|1|ID of private subnet A|subnet-069937727fa461753|
|PrivateSubnetB|1|ID of private subnet B|subnet-00c8c35d48cbefe9a|
|PrivateSubnetC|1|ID of private subnet C|subnet-0997e566e59bbb9eb|
|PublicSubnetA|1|ID of public subnet A|subnet-0096208747663c7c8|
|PublicSubnetB|1|ID of public subnet B|subnet-0b1feee3212b2c2b7|
|PublicSubnetC|1|ID of public subnet C|subnet-078b1e45fd873649a|
|PrivatePresSubnetA|1|ID of private pres subnet A|subnet-09866182a3c8a0663|
|PrivatePresSubnetB|1|ID of private pres subnet B|subnet-0beb34fc6ea4ac801|
|PrivatePresSubnetC|1|ID of private pres subnet C|subnet-0165b3a3b9e5e1507|
