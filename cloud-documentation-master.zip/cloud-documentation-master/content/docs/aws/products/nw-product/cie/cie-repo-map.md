---
title: Cloud Infrastructure Repository Map
draft: false
menu: docs
category: general
weight: 1
---

Below are all of the repositories used by the Cloud Infrastructure Engineering team. This covers all Service Catalog Pipeline products such as Server BlueGreen and Simple Server.
This also contains the Foundational code to setup the AWS infrastructure as well as various utilities that are running in environments.

## Foundational Repos
The foundational code that is used to stand up new AWS accounts and maintain managed IAM roles, policies and boundaries.
* [AWS-Logging](https://github.nwie.net/Nationwide/AWS-Logging) - Contains all resources needed for the logging to Splunk setup in AWS
* [AWS-IAM](https://github.nwie.net/Nationwide/AWS-IAM) - Contains all foundational and system IAM roles and policies.
* [AWS-ManagedPolicies](https://github.nwie.net/Nationwide/AWS-ManagedPolicies) - Contains all IAM managed policies and IAM boundaries 
* [AWS-Networking](https://github.nwie.net/Nationwide/AWS-Networking) - Contains all of the networking resources (VPCs, Subnets, NACLs etc.)
* [AWS-Foundations](https://github.nwie.net/Nationwide/AWS-Foundations) - (DEPRECATED) Contains all foundational pipeline templates. (NON DEPRECATED) Used for account creation
* [AWS-Bootstrap-Factory](https://github.nwie.net/Nationwide/AWS-Bootstrap-Factory) - Used for account creation
* [AWS-AWSConfig](https://github.nwie.net/Nationwide/AWS-AWSConfig) - (DEPRECATED?) Contains AWS Config rule used by security? [(See Issue](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/3229))
* [CDT-SC-Bootstrap](https://github.nwie.net/Nationwide/CDT-SC-Bootstrap) - Contains the code to bootstrap an account with Service Catalog portfolios and required resources
* [CDT-Account-Parameters](https://github.nwie.net/Nationwide/CDT-Account-Parameters) - Contains code to deploy parameter store entries to all configured accounts (and the parameter configuration)
* [CDT-IAM](https://github.nwie.net/Nationwide/CDT-IAM) - Contains code/templates for deploying IAM resources (in-progress/test of new deployment method)
* [CDT-SecurityGroups](https://github.nwie.net/Nationwide/CDT-SecurityGroups) - Contains code/templates for deploying security groups to all accounts (in-progress/test of new deployment method)

-----
## Utilities Repos
Code for various utilities such as DNS management and AutoShutdown
* [CDT-OptimizationLambdas](https://github.nwie.net/Nationwide/CDT-OptimizationLambdas) - Contains all of the tagging and autoshutdown scripts for the cost optimization for the cloud.
* [AWS-Utilities](https://github.nwie.net/Nationwide/AWS-Utilities) - (LEGACY) Custom Resource lambdas deployed to all accounts. We are currently trying to remove most lambdas out of this repo and pipeline so they can be deployed separately.
* [CDT-AWS-DNS-Management](https://github.nwie.net/Nationwide/CDT-AWS-DNS-Management) - Contains utilities that manage DNS entries in AWS including automated A-record registration for EC2 instances, on-demand CNAME registration for instances/load balancers, and certificate registration for ALBs.
* [CDT-Util-BotoWrappers](https://github.nwie.net/Nationwide/CDT-Util-BotoWrappers) - Contains utilities that wrap the AWS API via boto3 to fill temporary gaps in CloudFormation support for resources.
* [CDT-Util-General](https://github.nwie.net/Nationwide/CDT-Util-General) - Contains various utilities that don't belong to any other grouping and are not worth their own repository.

------

## AMI Repos
Code to build the Nationwide Approved Amazon Machine Images
* [Linux](https://github.nwie.net/Nationwide/NextGen-Infra-Linux-Pipeline) - Contains pipeline to build and deploy the Linux AMI
* [Windows Server 2016](https://github.nwie.net/Nationwide/windowsServer2016) - Contains pipeline to build and deploy the Windows Server 2016 AMI
* [Oracle](https://github.nwie.net/Nationwide/NextGen-Infra-Oracle) - Contains pipeline to build and deploy the Oracle AMI

------

## Pipeline Factory Repos
### Go-forward
#### ServiceCatalog Product Repos
The templates and pipelines for Service Catalog pipeline products
* [CDT-SC-Serverless](https://github.nwie.net/Nationwide/CDT-SC-Serverless) - Contains the templates that make up the Serverless ServiceCatalog product.
* [CDT-SC-ServiceCatalog-Product](https://github.nwie.net/Nationwide/CDT-SC-ServiceCatalog-Product) - Contains the templates that make up the ServiceCatalog product that deploys a ServiceCatalog Product.
* [CDT-SC-Cloudformation-Simple](https://github.nwie.net/Nationwide/CDT-SC-Cloudformation-Simple) - Contains the templates that make up the Cloudformation-Simple ServiceCatalog product.
* [CDT-SC-FoundationalSeverlessLambda](https://github.nwie.net/Nationwide/CDT-SC-FoundationalSeverlessLambda) - Contains the templates that make up the FoundationalSeverlessLambda ServiceCatalog product.
* [CDT-SC-ServerBlueGreen](https://github.nwie.net/Nationwide/CDT-SC-ServerBlueGreen) - Contains the templates that make up the Server-BlueGreen ServiceCatalog product.
* [CDT-SC-Server-BlueGreen-QuickDeploy](https://github.nwie.net/Nationwide/CDT-SC-Server-BlueGreen-QuickDeploy) - Contains the templates that make up the Server-BlueGreen-QuickDeploy ServiceCatalog product.
* [CDT-SC-Server-Simple](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple) - Contains the templates that make up the Server-Simple ServiceCatalog product.
* [CDT-SC-Server-Simple-QuickDeploy](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple-QuickDeploy) - Contains the templates that make up the Server-Simple-QuickDeploy ServiceCatalog product.
* [CDT-SC-Generic-IAC](https://github.nwie.net/Nationwide/CDT-SC-Generic-IAC) - Contains the templates that make up the Generic-IAC ServiceCatalog product.
* [CDT-SC-AthenaGlue](https://github.nwie.net/Nationwide/CDT-SC-AthenaGlue) - Contains the templates that make up the Athena-Glue ServiceCatalog product.
* [CDT-SC-Step-Function](https://github.nwie.net/Nationwide/CDT-SC-Step-Function) - Contains the templates that make up the Serverless-Step-Function ServiceCatalog product.

#### Lambda Repos
Go forward repos for Lambda's executed when Pipelines are ordered (CDT-GIG) and Lambda's executed while a pipeline runs (Delivery Pipeline Lambdas)
* [CDT-DeliveryPipelineLambdas](https://github.nwie.net/Nationwide/CDT-DeliveryPipelineLambdas) - New repo for lambdas that are executed via pipelines by users. This repo is different because it uses the new Serverless.com deployment technique with a codebuild per lambda.
* [CDT-GIG](https://github.nwie.net/Nationwide/CDT-GIG) - Generic-Infrastructure-Generator product repo. These lambdas are executed when the ServiceCatalog product are ordered. This product generates IAC for users, sets up git webhooks and creates pull requests.
* [CDT-ServiceNowLambdas](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas) - Various lambdas and an ALB fronting them to handle all automated Service Now actions/integrations for pipelines and other products.
* [CDT-SC-SystemTest](https://github.nwie.net/Nationwide/CDT-SC-SystemTest) - The lambda that runs system tests on all newly deployed service catalog products.

### Legacy Pipeline Factory
Soon to be deprecated repos for Lambda's executed while a pipeline runs (Delivery Pipeline Lambdas)
* [AWS-DeliveryPipeline](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline) - Lambdas that are executed via pipelines by users (and other stuff)
* [AWS-ServiceCatalog](https://github.nwie.net/Nationwide/AWS-ServiceCatalog) - (DEPRECATED) Contains the ServiceCatalog source cloudformations. (NOT DEPRECATED) This also contains the pipeline that deploys the Service Catalog portfolios and constraints.

------

## Common
* [AWS-CommonPython](https://github.nwie.net/Nationwide/AWS-CommonPython) - Contains common modules used by CIE lambdas. We are slowly trying to phase out using these common modules.
* [CIE-NWAWSHelper](https://github.nwie.net/Nationwide/CIE-NWAWSHelper) - NWAWSHelper library containing various functions and objects to simplify working with AWS.

------

## Containers for Codebuild
* [AWS-CfnNag](https://github.nwie.net/Nationwide/AWS-CfnNag) - Docker build for a container for running [CFN-NAG](https://github.com/stelligent/cfn_nag) 
* [AWS-BuildTools](https://github.nwie.net/Nationwide/AWS-BuildTools) - Docker build for the "BuildTools" container, which is the default application build container for pipelines.

------

## Examples
* [AWS-CloudFormation](https://github.nwie.net/Nationwide/AWS-CloudFormation) - Sample cloudformation templates to be referenced on the cloud wiki
