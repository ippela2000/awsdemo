---
title: Cloud Public API Offerings
category: general
draft: false
menu: docs
weight: 3
---

## Cloud created public API offerings
### Aprm ID detector
This API is for getting information about all of Nationwides Applications registered with an APRM ID

Test API: https://aprmapi-test.aws.e1.nwie.net

Prod API: https://aprmapi.aws.e1.nwie.net

### Endpoints
- GET /allaprmids/ - returns list of all aprm ids
    - example: "https://aprmapi.aws.e1.nwie.net/aprmid/"
        - Response Body: [{"application_name": "Concourse CI", "aprm_id": "8006"}, {"application_name": "ESS-SIC-Contract ISO Rates Maintenance", "aprm_id": "6239"}, {"application_name": "Domino - Project Request and Tracking", "aprm_id": "4831"}, ....etc.... \]}

- GET /aprmid/{APPLICATION NAME} - the user passes in the application name and the API returns the APRM ID
    - example for: "Claims Gateway", for application names it replaces spaces with %20
        - "https://aprmapi.aws.e1.nwie.net/aprmid/Claims%20Gateway"
        - Response Body: {"application_name": "Claims Gateway", "aprm_id": "2311"}

- GET /applicationname/{APRM ID} - the user passes in the APRM ID and the API returns the application name associated with it
    - example for: APRM ID "1208"
        - "https://aprmapi.aws.e1.nwie.net/applicationname/1208"
        - Response Body: {"application_name": "Alpha Search", "aprm_id": "1208"}

- GET /isaprmidvalid/{APRM ID} - the user passes in the APRM ID and the API returns a "True" for existing APRM ID in Service Now or "False" for an APRM ID not in Service Now
    - example for APRM ID in Service Now:
        - "https://aprmapi.aws.e1.nwie.net/isaprmidvalid/1208"
        - Response Body: {"is_the_aprm_id_valid?": "True"}
    - example for APRM ID not in Service Now:
        - "https://aprmapi.aws.e1.nwie.net/isaprmidvalid/888"
        - Response Body: {"is_the_aprm_id_valid?": "False"}
### Notes
The API queries a DynamoDB table whose source is ServiceNow. The lambda that updates the table runs at the 45 minute mark of every hour so if a new APRM ID is created and not showing with the API call yet, give it an hour and it will appear.

### AWS DNS Management API

This API allows for the creation, update, and deletion of CNAMEs and A records in Route53 in InfraSvcsProd. PTR records
are not yet available in this API.

- URL: https://aws-dns-mgnt.aws.e1.nwie.net/
- POST /record - create a new CNAME or A record (PTR records not yet available)
    - Request Body Options:
        - RecordType: The type of DNS record you would like to create, either "CNAME" or "A" (PTR records not yet available).
        - RecordName: The name of the record, should not have .aws.e1.nwie.net on it, just the name.
        - RecordValue: For CNAMEs this should be a URL, for A records this should be an IP address or list of IP addresses.
        - RecordOwner: The owner of the record. This may be a nwie id, a stack id, an EC2 instance ID, so long as it is
                       unique and denotes an owner of the record. This field will be validated to check ownership of a record
                       name on new creations, deletions and updates.
        - Public (Optional): Boolean flag for records to decided if they should get an .aws.e1.nwie.net or
                             .awspubliccloud.nationwide.com name.
        - TTL (Optional): Time to live value for the record.
    - examples:
        - URL: https://aws-dns-mgnt.aws.e1.nwie.net/record
        - Request Body:

        {

            "RecordType": "CNAME",
            "RecordName": "ExampleRecord",
            "RecordValue": "ExampleValue.aws.e1.nwie.net.",
            "RecordOwner": "Example"
        }

        - Response Body:

        {

            "message": "Successfully updated DNS record",
            "Record Name": "ExampleRecord.aws.e1.nwie.net.",
            "Record Value": [
                "ExampleValue.aws.e1.nwie.net."
            ],
            "Record Type": "CNAME",
            "TTL": 300
        }

        OR
        - Request Body:

        {

            "RecordType": "A",
            "RecordName": "ExampleRecord",
            "RecordValue": ["10.171.1.1" , "10.170.2.2"],
            "RecordOwner": "Example",
            "Public": "False",
            "TTL": 120
        }

        - Response Body:

        {

            "message": "Successfully updated DNS record",
            "Record Name": "ExampleRecord.awspubliccloud.nationwide.com.",
            "Record Value": [
                "10.171.1.1",
                "10.170.2.2"
            ],
            "Record Type": "A",
            "TTL": 120
       }

- DELETE /record - delete an existing CNAME or A record (PTR records not yet available)
    - Request Body Options:
        - RecordType: The type of DNS record you would like to delete, either "CNAME" or "A" (PTR records not yet available).
        - RecordName: The name of the record, should not have .aws.e1.nwie.net on it, just the name.
        - RecordValue: For CNAMEs this should be a URL, for A records this should be an IP address or list of IP addresses.
        - RecordOwner: The owner of the record. This must match the listed owner of the record exactly.
        - Public (Optional): Boolean flag for records to denote if the record has an .aws.e1.nwie.net or
                             .awspubliccloud.nationwide.com name.
        - TTL (Optional): Time to live value for the record.
    - examples:
        - URL: https://aws-dns-mgnt.aws.e1.nwie.net/record
        - Request Body:

        {

            "RecordType": "CNAME",
            "RecordName": "ExampleRecord",
            "RecordValue": "ExampleValue.aws.e1.nwie.net.",
            "RecordOwner": "Example"
        }

        OR
        - Request Body:

        {

            "RecordType": "A",
            "RecordName": "ExampleRecord",
            "RecordValue": ["10.171.1.1" , "10.170.2.2"],
            "RecordOwner": "Example",
            "Public": "False",
            "TTL": 120
        }

        - Response Body:

        {

            "message": "Successfully deleted DNS record"
        }

- PUT /record - update an existing CNAME or A record (PTR records not yet available)
    - Request Body Options:
        - OldResourceProperties: A json object containing the old information about the record. All values that were
                                 explicitly listed on create must be listed here.
        - RecordType: The new type of DNS record you would like to update, either "CNAME" or "A" (PTR records not yet available).
        - RecordName: The new name of the record, should not have .aws.e1.nwie.net on it, just the name.
        - RecordValue: New record value of the record. For CNAMEs this should be a URL, for A records this should be an
                       IP address or list of IP addresses.
        - RecordOwner: The owner of the record. This may be a nwie id, a stack id, an EC2 instance ID, so long as it is
                       unique and denotes an owner of the record.
        - Public (Optional): New boolean flag for records to decided if they should get an .aws.e1.nwie.net or
                             .awspubliccloud.nationwide.com name.
        - TTL (Optional): Time to live value for the record.
    - examples:
        - URL: https://aws-dns-mgnt.aws.e1.nwie.net/record
        - Request Body:

        {

            "OldResourceProperties": {
                "RecordType": "CNAME",
                "RecordName": "ExampleOldName",
                "RecordValue": "ExampleOldValue.aws.e1.nwie.net.",
                "RecordOwner": "Example"
            },
            "RecordType": "CNAME",
            "RecordName": "ExampleRecord",
            "RecordValue": "ExampleValue.aws.e1.nwie.net.",
            "RecordOwner": "Example"
        }

        - Response Body:

        {

            "message": "Successfully updated DNS record",
            "Record Name": "ExampleRecord.aws.e1.nwie.net.",
            "Record Value": [
                "ExampleValue.aws.e1.nwie.net."
            ],
            "Record Type": "CNAME",
            "TTL": 300
        }

        OR
        - Request Body:

        {

            "OldResourceProperties": {
                "RecordType": "A",
                "RecordName": "ExampleOldName",
                "RecordValue": ["1.1.1.1" , "2.2.2.2"],
                "RecordOwner": "Example",,
                "Public": "True",
                "TTL": 120
            },
            "RecordType": "A",
            "RecordName": "ExampleRecord",
            "RecordValue": ["10.171.1.1" , "10.170.2.2"],
            "RecordOwner": "Example",
            "Public": "True",
            "TTL": 120
        }

        - Response Body:

        {

            "message": "Successfully updated DNS record",
            "Record Name": "ExampleRecord.awspubliccloud.nationwide.com.",
            "Record Value": [
                "10.171.1.1",
                "10.170.2.2"
            ],
            "Record Type": "A",
            "TTL": 120
       }
