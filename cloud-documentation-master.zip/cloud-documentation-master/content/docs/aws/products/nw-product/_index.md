---
title: NW Products and Services
menu: docs
category: aws
weight: 3
---

<div class="onboarding-link">
  <h2>
    <a class="onboarding" href="https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md">Request a new AWS native service or feature enhancement here.
    </a>
  </h2>
</div>

## NW Products

Below are products that are supported by the Infrastructure Product Teams

### Cloud Solutions Products

|Product|Notes|Team|
| :----|:----|:----|
|[Gocloud](http://gocloud.nwie.net/)|Main cloud news portal|<a href = "mailto: CloudSuccessTeam@nationwide.com">CloudSuccessTeam@nationwide.com</a>|
|Service Catalog Products|[Pipeline Templates](/docs/aws/management-and-governance/service-catalog/)|[CIE](/docs/aws/products/nw-product/cie/)|
|CLMR framework|Security enforcement framework for AWS|[CSE](/docs/aws/products/nw-product/cse/)|
|CNP|Nationwide container platform|[CNP](/docs/aws/products/nw-product/cnp/)|
|[Halo](https://halo.nwie.net/)|[Product Charter](https://github.nwie.net/Nationwide/halo/wiki/Halo_Product_Charter)|<a href = "mailto: CDS@nationwide.com">CDS@nationwide.com</a>|
|Database Team|I&O DBA Team|[Database Team](/docs/aws/products/nw-product/database/)|

### Amazon Machine Images (AMIs)

| Product| AMI Name| Notes|
| :----------- | :---------- | :--------------- |
| CentOS 7| NWLinux7||
| Ubuntu 18.04 LTS | ubuntu1804 | Debian based Linux with 4.x kernel |
| Windows 2016 | windowsServer2016||
| Oracle| Linux-Oracle-AMI| Only to be used by the Oracle team to build Oracle databases on top of RHEL|
| RHEL 7| NWAWSRHEL7| Only used for vendor specific requirements.  Please note that this AMI is built from an Amazon/RedHat agreement and thus includes its own licensing agreement and requires the user to patch on their own.  The only Nationwide involvement is applying our RedHat 7 secure config.  If OS support is required you can contact Amazon directly.|

### Middleware Components

| Product| Offering Type| Availability| Supported | TSB Status | Comment|
| :---------------- | :--------------------------------- | :-------------------------- | :-------- | :-------- | :------------------------------- |
| Packer Script| Tomcat| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**| Approved |[How to Guide](https://github.nwie.net/Nationwide/mw-tomcat/wiki/AWS) |
| Packer Script| Apache & SSO| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**| Approved | [How to Guide](https://github.nwie.net/Nationwide/mw-apache-httpd/wiki) |
| Container| Apache & SSO| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**| Approved | [TSB](https://nwproduction.service-now.com/nav_to.do?uri=%2Fx_namim_tsb_component.do%3Fsys_id%3D33c6b381db8bbf045b4824f405961937) | |
| EC2|TomEE+| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Exception Required |If EJB, JMS, JAX-RS, and/or JAX-WS are required; This AMI is based on the NWLinux7 Nationwide CentOS base|
| EC2 | Websphere| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Exception Required |[How to Guide](https://github.nwie.net/Nationwide/mw-aws-was-sample/wiki) |


### AWS Native Products

For more information on the AWS Approved Products, refer to the [AWS Native Products page](/docs/aws/products/aws-native-service/)
