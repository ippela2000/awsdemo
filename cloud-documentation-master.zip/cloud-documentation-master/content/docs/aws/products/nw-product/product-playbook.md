---
title: "Products"
draft: false
menu: docs
category: general
weight: 10
---

Cloud Solutions Product Playbook

Vision: Empower customer productivity and innovation through cloud services
---



![Product Lifecycle](/docs/aws/images/product-lifecycle.png)

<details><summary>Define</summary>
<section id="define" markdown="1">
  
### Defining a product

Product Definition is all about establishing a shared understanding of the product your team will be delivering.  Definition, at its most basic is centered on answering 3 primary questions: 
- What problems and/or opportunities is here to solve or take advantage of?
- Who does your product serve? 
- What specific objectives are you pursuing as a team? 

After answering those questions as succinctly as possible, you will be equipped to begin brainstorming guesses about the type of work that could potentially help you accomplish your objectives.  The result of that brainstorming activity will be a backlog of Ideas [see graphic below] to explore directly with your customers as you dig into Product Discovery.

Without a clear definition of your product, you will most likely have difficulty prioritizing your work and maintaining focus on what’s most important for your customers.   Each member of your team, and your stakeholder group, will bring a distinct point of view to your product.  By establishing a clear definition, a high-level roadmap, clear OKRs, and an idea backlog that can be prioritized accordingly, you will have the tools necessary to say “no” with context, or say “yes” to exploring new ideas that support your product vision. 

#### Reminder: The Product Mindset is all About Humility. #### 
Our product ideas are guesses. 70% of what we come up with doesn’t move the needle the way we hope it will.

### Business Model Canvas
The business model canvas is a tool your team can use to outline the overall purpose and value of your product. It covers the partners, activities, resources, value, costs, channels, customers, and revenue streams of your product.

The business model canvas is a great tool to help you understand your product in a straightforward, structured way. Using this canvas will lead to insights about the customers you serve, what value propositions are offered through what channels, and how your product provides value. You can use the business model canvas to understand your product and/or products you interact with or are dependent on. The Business Model Canvas was created by Alexander Osterwalder, of Strategyzer. 

The business model canvas is a shared language for describing, visualizing, assessing and changing business models for your product. It describes the rationale of how a product creates, and delivers value. 


<table>
  <tr>
    <td><b>Customer Segment</b></td>
    <td><b>Challenges</b></td>
    <td><b>Value Proposition</b></td>
    <td><b>Key Partners</b></td>
    <td><b>Key Resources</b></td>
    <td><b>Key Activities</b></td>
  </tr>
  <tr>
    <td>
      <ul>
        <li>Who are your customers?</li>
      </ul>
    </td>
    <td>
      <ul>
        <li>What challenges do they have?</li>
        <li>Known/unknown?</li>
      </ul>
    </td>
    <td>
      <ul>
        <li>What is the value you deliver to your customer?</li>
        <li>What is the customer need that your value proposition addresses?</li>
      </ul>
    </td>
    <td>
      <ul>
        <li>Who are your key partners?</li>
      </ul>
    </td> 
    <td>
      <ul>
        <li>What are the resources you need to deliver your value proposition?</li>
      </ul>
    </td>  
    <td>
      <ul>
        <li>What are the activities you perform every day to deliver your value proposition?</li>
      </ul>
    </td>     
  </tr>
</table>

- **Customer Segments**: List the groups of customers or users who your product is intended to serve
- **Challenges**: What challenges does the Customer face? Are there opportunites that you can help them exploit?
- **Value Proposition**: What are your products and services? What is the job you get done for your customer?
- **Key Partners**: List the partners that you can’t do business without, and/or the products you are dependent on.
- **Key Resources**: The skills, knowledge, means, and money you need to improve and maintain your product.
- **Key Activities**: What do you do every day to run your product?

### Product Charter

A Product Charter is intended to establish a shared understanding around each of the foundational components of your product:

- **Product vision:** A 2-5 year vision of the product/service that your team will provide based the customer and their needs. It describes the future state of the product, without regard to how it is to be achieved. A ision is the ultimate, possibly unattainable, state that the Product Team would like to achieve. It is driven by the Mission and realized through objectives.
- Product description:
    - What is the product?
    - What makes it stand out?
    - Is it feasible to develop the product?
- Values
- Principles
    

### Objectives & Key Results (OKRs)

What are they?
 - Objectives & Key Results (OKRs) provide both a qualitative vision, and quantitative goals for teams to rally around and focus on. 
 - In definition form:
   - Objective – A broad, qualitative, and aspirational goal.  At its best, the Objective is something that gets the team out of bed in the morning and is truly inspirational.
   - Key Results – Quantifiable statements that demonstrate what success looks like for a given objective.  Key Results look much like traditional ‘SMART’ goals (Specific, Measurable, Actionable, Realistic, and Time Bound)
   
[Beginner's Guide to OKR](https://felipecastro.com/en/okr/what-is-okr/)

### The Team Charter

Prior to building a great product that customers and end-users love, it is fundamental to build and establish a team. A strong, unified team must organize and rally around certain core principles. Without a strong team united under common ideals and beliefs it is virtually impossible to build great products. It is therefor paramount the team institute and ordain a charter. 

Much like the preamble of the U.S. Constitution the opening of the charter must commence with a **Mission**
>A Mission indicates the ongoing operational activity of the enterprise. The Mission describes what the business is or will
be doing on a day-to-day basis. A Mission makes a Vision operative; that is, it indicates the ongoing activity that makes the Vision a reality. A Mission is planned by means of Strategies. - From the [Business Motivation Model](https://www.omg.org/spec/BMM/1.3/PDF)

After establishing the mission of the team the next article of the charter is the organizing principle. The mission statement informs the organization of the overall goal, however, the organizing principle demonstrates to the organization why the team was constituted. 

Following the organizing principle, the core principles is the next section, which must embody those propositions the team holds most sacred. A total of four or five simple straight forward points are all that is required. 

**Principles** are given birth from those ideas that reside in all of our minds, hence the next section is the team philosophies. Here in this segment of the charter, the team philosophies are those high order beliefs in which the team can dedicate themselves and long endure in the face of any adversity. - [How to introduce principles](https://blog.agilityscales.com/how-to-define-and-evolve-your-team-principles-81bc2589ba0c)

Our next section of the charter, is the second most important; the team's responsibility. The team responsibility passage exemplifies the work the team will and will not engage. It is essential the team decree the boundaries of their efforts, as it definitely delineates to the organization the various endeavors in which they [team] will participate.

Teams exist to build great products, however, before products are released to the market there are internal organizational stakeholders that must be satisfied. Our team charter must include a component that precisely pinpoints those key stakeholders which have a claim as to how the product is produced and delivered. These key stakeholders could include departments such as architecture, legal, or other delivery partners such as marketing or OCM.

Our final section of the charter concludes with key sponsors of the team. It is these sponsors who will preserve and safeguard the team and their efforts organizationally. As the team continues their aspiration work there will come a point when the team's very existence will be tested. Having sponsors clearly defined in the charter will indicate those key individuals willing and able to give their full measure of support. 

An example team charter can be found [here](https://github.nwie.net/Nationwide/AWS-CloudDataServices/wiki/Team-Charter)


### Roles

#### Product manager

- Good Habits:
  - Should spend most time in product discovery and about half to full hour on delivery questions per day.
  - Review analytics everyday.
  - Strong product teams try 10 - 20 ideas a week
  - Customer Interviews - Freq - 2-3 hours per week
  - Testing Qualitatively - 2 to 3 times a week
  - Stakeholder Management (Legal, Security, Executive Team, Business Partners, Finance, Compliance, etc) for business viability risk. Meet weekly one on one for total of 2-3 hours. Half hour to full hour with most involved stakeholders. Keep them updated, get feedback on new ideas. Use high fidelity prototype for testing business viability individually with each stakeholder
  - Communicating product Learning's - All associates / kiss broadcast meeting every 2 weeks, talk about what worked, what didn't work and what we plan to do in 15-30 mins in product discovery (big learnings - customer impact)
  
#### The Team 
 - Teams are groups of 6-12 people with a leader who acts something like a team CEO. The leader often recruits the rest of the team, and members usually stay with a team for two or more years.
 - Teams are ‘separable’ [separated organizationally] and ‘single-threaded’ [work on a single thing].
 - Teams are responsible for a measurable set of external outcomes, usually focused on customers.
 - Team decide internally both what they will work on and how they do the work.
 - Dependencies between teams are kept to an absolute minimum


### Define Section Output Artifacts

The define category has four (4) output artifacts. These four artifacts can be consolidated into a single document or broken into individual communications. The point being, as we define our product(s) we must construct accountable evidence for the overall organization. Without liability, the product(s) may flounder and wither eventually leading to the product(s) being deprecated or decommissioned completely. 

The four output artifacts are:
1. Product Charter
2. Business Model Canvas
3. Objectives & Key Results (OKRs)
4. The Team Charter

</section>
</details>

----

<details><summary>Discovery</summary>
<section id="discovery" markdown="1">

### What is Discovery?

Product discovery is an important yet often overlooked aspect of engineering development. Product Discovery is very much about the intense collaboration of product management, user experience, and engineering. Product discovery is the process which helps teams make sure they are building products that are usable, but also useful.  In discovery, we are tackling the various risks before we write even one line of production software.  The purpose of discovery is to quickly separate the good ideas from the bad.  Before beginning product discovery, decide if the problem is worth solving, if so move forward.  The output of product discovery is a validated product backlog.

The purpose of product discovery is to address these critical risks:
- Will the user or customer choose to use or buy this?  (Value)
- Can the user figure out how to use this? (Usability)
- Can we build this? (Feasibility)
- Is this solution viable for our business?  (Business Viability)

Remember that for many of the things we work on, most or all of these questions are very straightforward and low risk(Team is confident, been there done that) so we will proceed to delivery.  

No prescribed order but most team test value and usability at the same time, then review approach with engineers and finally business viability (legal, marketing, etc.,.)   

Doing discovery correctly is not easy, but it’s critical to finding solutions that genuinely work for your customers and for your business. 
Keep these important things in mind:
 - Discovery requires an open mind. By definition, “discovery” means you don’t know the answer when you start. You must approach it with an openness to kill or dramatically alter our ideas based on you learn
 - Discovery tackles product risks. These risks go beyond simple usability or feasibility. They also include a product’s value and it’s ability to meet business needs.
 - Discovery is cross-functional. Good innovation and good communication about the product to be delivered requires active participation by product management, product design, and engineering.
 - Discovery requires judgement. You must test the things that matter, and test first the hypotheses that will cause us to fail.
 - Discovery prioritizes fast learning over everything else. The task is not to create reusable code, it is to gain insights into the team as quickly as possible. The most expensive idea is the one that gets built but never used.
 - Discovery uses many tools.  Different experiments require different techniques. Good discovery makes use of both qualitative and quantitative techniques, based on what needs to be learned.
 - Discovery is continuous practice. Discovery is best when it’s an ongoing process, rather than a project phase. Good teams are constantly learning by maintaining a weekly cadence of interacting with customers and users.

Good idea to create opportunity backlog separate from product backlog

### Product Discovery Team

Ideal size is 2-4 people - dinner-conversation-sized so the members can quickly build shared understanding.  The team consists of product manager (who has deep understanding of business's vision & strategy and the market their product serves), user experience (understands users, is comfortable working with them to learn about the way they work, and sketch and create simple UI prototypes), and a senior engineer (who will build product, understands the current architecture of the system, and have insight into newer engineering approaches that could be used so solve tough problems).  The real secret is that the most innovative solutions often come from the engineer supplied with insight about the business problem and the user's problem.

### Discovery Techniques 

In this section, I consider how we frame our discovery work to ensure alignment and to identify key risks.  There are really two goals:
1. The first is to ensure the team is all on the same page in terms of clarity of purpose and alignment.  In particular, we need to agree on the business objective we're focused on, the specific problem we are intending to solve for our customers, which user or customers you're solving that problem for, and how you will know if you've succeed.  These should align directly to your product team's objectives and key results.  
2.  The second purpose is to identify the  big risks that will need to be tackled during product discovery.  We need to tease out the risks and determine where it makes sense to focus our time and how our work fits in with other teams.

#### Opportunity Assessment

For vast majority of product work, which ranges from simple optimization to a feature for medium sized project that requires framing.
* What business objective is this work intended to address?
* How do you know if you have succeeded?  Key Results
* What problem will this solve for our customer?
* What type of customer are we focused on?

#### Customer Letter similar to Press Release

Medium to large effort like redesign

Describe benefits in format of customer letter written from the hypothetical perspective of one of your product's well defined user or customer personas.
* The letter sent to CEO from a happy and impressed customer to explain why he is so happy and grateful for the new product or redesign
* Customer describes how it has changed or improved his life.  
* The letter also includes an imagined congratulatory response from the CEO to the product team explaining how this helped the business. 
* Advantage over press release - better job of creating empathy for the customer's current pain and more clearly emphasizes to the team how their efforts can help the lives of these customers.  

### Personas

In short, you should be able to generate initial drafts of personas in a 2-hour workshop with 5-8 cross-functional participants (any larger and the group will begin to spin):
 * Identify the types of users you serve.  Brainstorm individually, then de-dupe and group your user types.  Expect to end up with a handful of user types.  Don’t panic if you have a couple fewer or a couple more. 
 * Personify your user types.  For each user type, give them a memorable name and a hand-drawn picture that visually summarizes who they are. 
 * Know what you don’t know. As you discuss each user type, you’ll notice that there are some aspects of your customers that you don’t understand.  Document these follow-up items and rough out a quick research plan to obtain the missing information.  

#### Persona Sections

* Persona Name/Context: capture a name that will be easy for you to remember 
 * Goals/Problems: Brainstorm the goals for this particular user – what are they trying to accomplish?  Why?  What are their biggest problems?  Why do they need your product? 
 * Value We Bring: How do you envision your product helping them to accomplish their goals or overcome the problems they are facing.  Get specific – this section can help you as you think thru product prioritization, as well as objectives and key results on an ongoing basis. 
 * What We Need to Learn: As you completed the rest of the sections for your persona, odds are that you made several assumptions or guesses along the way.  That’s OK.  But it’s not OK to just move forward without validating or disproving those assumptions.  This section is intended to start capturing content to generate a customer learning plan that you’ll use during customer interviews on an ongoing basis. 

### Discovery Planning Techniques 

Help identify the bigger challenges and start figuring out solutions (scope and plan our discovery efforts)

#### Story Map
* Stories aren't a written form of requirements, telling stories through collaboration with words and pictures is a mechanism that builds shared understanding
* Stories aren't the requirements, they're discussions about solving problems for our organization, our customers, and our users that lead to agreements on what to build.
* Your job isn't to build more software faster: it's to maximize the outcome and impact you get from what you choose to build.

#### Customer Discover Program 

6 similar Reference Customer 
* Using your product in production.  
* Feel the pain and desperate for solution.  
* Need to spend time with us to test our product.  
* Single market focused and development partners
* They will test early version to go deep on a solution to figure if it works for them.

Current - Kevin A, Kim Boydstun, Tim Morgan, Andrew Seling, Jeff Robeano, and Edwin Delphi

### Discovery Ideation Techniques

#### Customer Interview Questions: 
* Are your customers who you think they are?
* Do they really have the problems you think they have?
* How does the customer solve this problem today?
* What would be required for them to switch?

How:
* Freq - 2-3 hours per week
* Location - Customer place
* Preparation - Be clear beforehand what problem it is you think they have, and think how you'll either confirm or contradict that?
* Team - Bring 2 others, take notes
* Interview - Open end questions, informal, try to learn what they are doing today

#### Concierge Test Technique 

Ask them to show you how they work so that you can learn how to do their job, so that you can work on providing them a better solution.   Do customers job for them manually, do what customer needs done for them.

#### Hack a thon

Identify a problem to solve for product team

### Discovery Prototyping Tech

Learn something at lower cost in terms of time and effort than building a product and to tackle one of product risks.
* Feasibility - Just enough to mitigate feasibility risk, can we build this?
* User - is a simulation, smoke and mirrors.  Low to high fidelity
* Live Data - Used to address a major risk identified in discovery, we need to collect actual usage data/evidence.  Real data but not production ready product such as not all uses cases, automated tests, etc.  
* Hybrid - combine different aspects of each of these in different ways

### Discovery Testing Techniques 

Quickly trying out an idea to separate the good ideas from the bad.  Used for ideas that major risks associated to them as talked about previously.  
* Testing Usability - Done in discovery using prototypes
* Testing Value - Customer must perceive your product to be substantially better to motivate them to buy
* Demand Testing - Do customers even care about this problem?  Enough to buy a new product or switch
* Testing Value Qualitatively - Do customers love this? Will they chose this, if not why?.  Rapid learning and big insights.  2 to 3 a week.
* Testing Value Quantitatively - How well the solution solves the underlying problem
  - A/B Testing
  - Invite Only Testing
  - Customer Discovery Program Testing
  
### Establish and Define a Goal Oriented Roadmap

#### Roadmap

||Timeframe|Timeframe|Timeframe|
| :----------- | :------------------- | :----------------------- | :---------------------------- |
|**Date**|Q4|2019 Q1|2019 Q2|
|**Name**|Production Environments|End-User Experience and Cloud Adoption|End-User Experience and Cloud Adoption|
|**Goal**|Enable BSA developers to self deploy and operate production applications with guardrails in the cloud|Build a usable and stable product|Build a usable and stable product|
|**Features**|Confidential data(PII) allowed in Production<br/>Automate logging, monitoring,config, and change<br/>Public facing applications;<br/>Hardening Ops Processes|1) Make it easier to perform CI/CD/CD activities; 2) Additional Products and Services - Containers, MSSQL RDS,EFS; 3) Improved documentation and on-boarding experience|1) Improve stability of pipelines; 2) Reduce pipelines deployment time by 75% 3) Improved documentation and on-boarding experience|
|**Metrics**|Production application deployed within hours; Cost visibility per application|1) Increase number of apps by 5% month over month in production 2)Pipeline Deployment failures reduced by 10% per month|1) Increase number of apps by 5% month over month in production 2) Pipeline Deployment failures reduced by 10% per month|

### Opportunity Backlog aka Idea Backlog

#### What is it?

"The Opportunity Backlog is a tool that allows a team to frame up the value of a given product idea in terms of its value to your organization as well its target audience." – Jeff Patton 

#### Why do it?

In short, leveraging the opportunity backlog supports several key activities for your product:
 * Establishes a standard evaluation process for comparing the value of ideas
 * Enables the team to constrain the design to a finite, and clear, scope
 * Collects all relevant concerns for a given opportunity in a consumable format
 * Builds shared understanding for the entire team that is working on the opportunity
 * Takes a holistic view including success measurement and adoption strategies
 
 ### Product Backlog aka Delivery Backlog

#### What is it?

The product backlog is a prioritized list of desired product functionality. It provides a centralized and shared understanding of what to build and the order in which to build it. It is a highly visible artifact that is accessible to all product team members. The Product Owner is the primary owner of the product backlog and responsible for its prioritization.  The product backlog is the source for all work fed into either a Sprint backlog or part of the ongoing work a Kanban team will focus on. 
Typically items within the backlog are one of the following types:
•	Feature
•	Tech Debt
•	Defect

### Discovery Section Output Artifacts

The output artifacts are:
1. Goal Oriented Product Roadmap
2. Personas
3. Opportunity Backlog
4. Product Backlog

</section>
</details>

----

<details><summary>Deliver</summary>
<section id="deliver" markdown="1">

### What is Delivery?

Product Delivery is about taking the shared understanding of the product the team defined during Definition and bringing it to life. 
  
Delivery, requires a balance of teamwork and technology incorporating:
   - Agile & DevOps Values and Principles
   - An architecture which provides the environments & tools to enable teams to build faster and leaner
   - Outcomes that feedback back into the learning loop for continuous improvement

### Why is it Important?

Without the ability to take vision and make it a reality, teams would be left with a lot of ideas and not much to show.  Inputs from Discovery will guide the team’s working priorities.  Adhering to the Agile Principles, teams move quickly and effectively. Each member of your team, and your stakeholder group, will bring a distinct point of view to your product and have a chance to continue to share each iteration with feedback at demos. 

Having the right architecture for teams to build their solutions on top of will provide the automation, security and stability needed to allow teams to continue to build as they develop new features. 

Emerging outcomes provide the team with critical learnings that in turn feed back into Discovery phase helping to guide future work.   

#### Sprint Goals

Unclear Sprint Goal Clearer Sprint Goal Enhance shopping cart functionality. Streamline purchasing process to enable an increase in conversion rates. Improve performance. Increase page load time by X%. On-board new market segment. Enable new market segment to purchase Service Y.

https://www.agilesocks.com/creating-good-sprint-goals/


</section>
</details>

----

<details><summary>Measure</summary>
<section id="measure" markdown="1">

### What is Measure?

Determining whether or not the actual outcomes of your work align with the desired outcomes of your work is a critical step in the life cycle. And, while it may be the fourth set of activities in the playbook image, it’s actually something this is interlaced throughout the entire flow. 

Activities in the part of the life cycle center on evaluating two primary categories of metrics:
  - Operational Metrics – system health, performance metrics, etc.
  - User Interaction Metrics - how your customers are using your application.
  - Delivery Metrics - how you deliver your products.
    - Deployment frequency
    - Lead time for change
    - Mean time to recovery
    - Change failure rate

These measures are used to determine whether or not your team is accomplishing the Objectives and Key Results you set out to accomplish, as well as whether or not your users are experiencing your product in the way you’d like them to. 

### Why is it Important?

- Historically, technology projects measured the iron triangle of scope, cost, and timeline. If you got done on time, under budget, and included the features that were agreed upon when requirements were gathered, you were successful. 
- But this method missed the point. It used a binary metric of whether or not something was completed as opposed to focusing on the result of completing something. 
- The Product Management mindset flips that on its ear by saying, “build as little as possible to accomplish your business objectives”. Success becomes based on moving critical metrics (see OKRs) as opposed to getting a certain number of stories or features created. 
- With this in mind, constantly assessing the outcomes of your work is a critical part of the process. By analyzing whether or not your work is moving you closer to, or further from, your OKRs, you are able to incorporate that learning into ideation and discovery work for your product. 
- Assessment closes the loop and kick starts your idea prioritization process based on data, not on emotion. It’s the foundation for all things product. 

### Role of Analytics

Help to understand the following:
- Understand user and customer Behavior
- Measure Product Progress
- Prove Whether Product Ideas work
- Inform Product Decisions
- Inspire Product Work

Type of analytics:
- User Behavior analytics (click paths, engagement)
- Business analytics (active users, conversion rate, lifetime value, retention)
- Financial analytics (ASP, billing, time to close)
- Performance (Load time, uptime)
- Operational costs(storage, hosting)
- Go-to-Market costs (acquisition costs, cost of sales, programs)
- Sentiment (NPS, Customer satisfaction, surveys)
For new features, have a way to measure when it's released to understand if it's working or if there are significant consequences

</section>
</details>

-----

<details><summary>Reference Material</summary>
<section id="reference" markdown="1">
  
[CDT Team Approaches](https://github.nwie.net/Nationwide/CDT/wiki/Cloud-and-Team-Approaches)

[Target Product Playbook](https://github.nwie.net/Nationwide/CDT/blob/master/Docs/Target%20Product%20Playbook.docx)
</section>
</details>

