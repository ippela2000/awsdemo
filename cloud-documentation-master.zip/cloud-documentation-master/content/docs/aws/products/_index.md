---
title: Approved Platforms, Products and Services
menu: docs
category: aws
weight: 3
---

<div class="onboarding-link">
  <h2>
    <a class="onboarding" href="https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md">Request a new AWS native service or feature enhancement here.
    </a>
  </h2>
</div>

## Why are some services supported while others are not?

- As you review the information on this page, you will see a **✔** , **X** or **❗** in the "Supported" column. You are probably asking yourself why and what factors are taken into account? That is a very good question and one that deserves a straight-forward and honest answer.
  - **✔** = Product is available and fully supported
  - **X** = Product is usable however app teams must be able to self-support
  - **❗** = Take pause before using; product is supported, there could be better options available; contact a Cloud Solutions Team member for guidance
- The decision to make a service supported is influenced by the following factors:
  - Technology Standards Boards (TSB) Status
  - Supportability
  - Ease of Use
  - IRM and Legal Considerations
  - Nationwide's architectural strategies
  - General familiarity
  - and any potential cost implications


### NW Product

For more information on the different product teams, refer to the [NW products page](/docs/aws/products/nw-product/)


### AWS Native Products

For more information on the AWS Approved Products, refer to the [AWS Native Products page](/docs/aws/products/aws-native-service/)
