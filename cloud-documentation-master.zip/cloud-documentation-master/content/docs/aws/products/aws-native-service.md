---
title: Approved AWS Native Products
menu: docs
category: aws
weight: 3
---

<div class="onboarding-link">
  <h2>
    <a class="onboarding" href="https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md">Request a new AWS native service or feature enhancement here.
    </a>
  </h2>
</div>

## New! Ohio Region available in BETA. Learn more [here.](https://github.nwie.net/schwarc6/cloud-documentation/blob/master/content/docs/aws/products/OhioRegion.md)


## Why are some services supported while others are not?

- As you review the information on this page, you will see a **✔** , **X**, **❗**, or **❗Ohio** in the "Supported" column. You are probably asking yourself why and what factors are taken into account? That is a very good question and one that deserves a straight-forward and honest answer.
  - **✔** = Product is available and fully supported
  - **X** = Product is usable however app teams must be able to self-support
  - **❗** = Take pause before using; product is supported, there could be better options available; contact a Cloud Solutions Team member for guidance
  - **❗Ohio** = AWS does not currently offer this product in the Ohio region. Contact a Cloud Solutions Team member (or architect) for guidance.
- The decision to make a service supported is influenced by the following factors:
  - Technology Standards Boards (TSB) Status
  - Supportability
  - Ease of Use
  - IRM and Legal Considerations
  - Nationwide's architectural strategies
  - General familiarity
  - and any potential cost implications
- As time progresses and Nationwide becomes more familiar with the differing AWS services the designation of preferred can and will change.

## Native AWS Services

* As time progresses and Nationwide becomes more familiar with the differing AWS services the designation of preferred can and will change.

* All native AWS services not listed on this page are not available in **Dev, Test and Prod** but **are available in Sandbox** for evaluation/testing purposes.  If a blocked aws native service is not available in dev, test or prod and you would like to test in dev, please [Request a new AWS native service or feature enhancement here](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md)

### Compute

| Product| Offering Type| Availability| Supported | TSB Status | Comment|Contact|
| :---------------- | :--------------------------------- | :------------- | :-------- | :-------- | :--------------- | :-----|
|EC2| [Instance Type](https://aws.amazon.com/ec2/instance-types/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Approved |All instance types except **t2.micro** are approved for use||
|EC2| Red Hat [RHEL]| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Approved | Only for vendor products that need it e.g. Oracle, Informatica||
|EC2| CentOS| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None||
|EC2| Ubuntu| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None||
|EC2| Windows| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None||
|Serverless|[Lambda](https://aws.amazon.com/lambda/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012149)| None |CIE@nationwide.com|
| Batch Computing|[Enterprise Workload Automation](/docs/general/batch-services)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**    | Standard | [AWS EC2 and AWS CNP patterns](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/workload-management-esp-edition.pdf?csf=1&e=Eg6odm) | appikav@nationwide.com|

### Containers

| Product| Offering Type|Availability| Supported | TSB Status | Comment|Contact|
| :------------------------------ | :----------------------------------------------------| :-------- | :-------- | :-------- | :------------------------- | :---------------------------|
|Amazon Container Registry| [ECR](https://aws.amazon.com/ecr/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Unsubmitted | Utilized in InfraSvcs Only |CIE@nationwide.com|
| Managed Amazon Containers| [Fargate](https://aws.amazon.com/fargate/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**❗**| Denied as Standard | Recommendation to use [Cloud Native Platform](/docs/cnp/about-cnp)|cloud-platform@nationwide.com|
| Amazon Managed Containers | [ECS](https://aws.amazon.com/ecs/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **❗**| Denied as Standard | Recommendation to use [Cloud Native Platform](/docs/cnp/about-cnp)|cloud-platform@nationwide.com|
| Amazon Managed Kubernetes| [EKS](https://aws.amazon.com/eks/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **❗**| Denied as Standard | Recommendation to use [Cloud Native Platform](/docs/cnp/about-cnp)|cloud-platform@nationwide.com|

### API Gateway(s)

| Product| Offering Type| Availability| Supported | TSB Status | Comment |
| :---------- | :----------------------------------------------------- | :------------------------------------------------------------------------------------- | :-------- | :-------- | :------ |
| API Management |[AWS API Gateway](https://aws.amazon.com/api-gateway/)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **X**|[Approved](/solutions/security/cloud-tsb/) (TSB0012269)|Enterprise preference is Apigee|

### Application Integration

| Product| Offering Type| Availability| Supported | TSB Status | Comment |Contact|
| :-------------- | :----------------------------------- | :------------------- | :-------- | :-------- | :------ |:------ |
|Visual Workflows| [AWS Step Functions](https://aws.amazon.com/step-functions)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012013)|None|CloudSuccessTeam@nationwide.com|
|Message Queuing | [Amazon Simple Queue Service](https://aws.amazon.com/sqs)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012130)|None|CloudSuccessTeam@nationwide.com|
|Pub/Sub Messaging| [Amazon Simple Notification Service](https://aws.amazon.com/sns) | [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012131)|None|CIE@nationwide.com|
|Message Broker | [Amazon MQ](https://aws.amazon.com/amazon-mq)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**❗**|[Approved](/solutions/security/cloud-tsb/) TSB0013215|None|MiddlewareEventandMessaging@nationwide.com|
|Appstream 2.0 | [Amazon Appstream 2.0](https://aws.amazon.com/appstream2/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**X** **❗Ohio** |[Approved](/solutions/security/cloud-tsb/) (TSB0012011)|None||

### Machine Learning

| Product| Offering Type| Availability| Supported | TSB Status | Comment |Contact|
| :------- | :------------------------- | :------------------------- | :-------- | :-------- | :------ | :-----|
| Conversation Bots| [Amazon Lex](https://aws.amazon.com/lex)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔** **❗Ohio** |[Approved](/solutions/security/cloud-tsb/) (TSB0011994)|None|CDS@nationwide.com|
| Text to Speech| [Amazon Polly](https://aws.amazon.com/polly)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0011995)|None|CDS@nationwide.com|

### Relational Database Management Systems

|Product|Offering Type|Availability|Supported|TSB Status|Comment|Contact|
 | :------- | :------------------- | :------------------- | :-------- | :-------- | :-------------------------- |:-------- |
|EC2|MS SQL Server|![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)|  **✔** |[How To Guide](/docs/aws/database/ec2/howto-ec2-sqlserver)|SELINGJ@nationwide.com <br> RDDS.Triage@nationwide.com|
|RDS|[Oracle](https://aws.amazon.com/rds/oracle/)|![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)| **✔** | Approved |[How To Guide](/docs/aws/database/rds/howto-rds-oracle/)|BURNSD23@nationwide.com <br> RDDS.Triage@nationwide.com|
|EC2|Oracle|![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)| **✔** | Approved |[How To Guide](/docs/aws/database/ec2/)|BURNSD23@nationwide.com <br> RDDS.Triage@nationwide.com|
|RDS|[PostgreSQL](https://aws.amazon.com/rds/postgresql/)|Beta| **✔** | Approved |Non-critical / not customer facing apps only [How To Guide](/docs/aws/database/rds/howto-rds-postgres) ; [PostgreSQL Knowledge Repo](https://github.nwie.net/Nationwide/Postgres-Knowledge-Repo)|b.lehmann@nationwide.com <br> RDDS.Triage@nationwide.com|
|RDS|[MS SQL Server](https://aws.amazon.com/rds/sqlserver/)| | **❗** | With Consultation Only | Due to Licensing Cost EC2 is the SQL Server Standard Build |SELINGJ@nationwide.com <br> RDDS.Triage@nationwide.com|


### NoSQL Database Systems

|Product|Offering Type|Availability|Supported|TSB Status|Comment|Contact|
| :------- | :------------------- | :------------------- | :-------- | :-------- | :-------------------------- |:-------- |
|In Memory Data Store and Cache |[ElastiCache](https://aws.amazon.com/elasticache/) | ![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)| **✔**| Submitted | [How To Guide](/docs/aws/database/elasticache/)|CloudSuccessTeam@nationwide.com|
|NoSQL|[DynamoDB](https://aws.amazon.com/dynamodb/)| Beta | **✔** | Submitted |Non-critical / Non Customer Facing Apps Only / [Example](https://github.nwie.net/Nationwide/DynamoDB-Example)|b.lehmann@nationwide.com RDDS.Triage@nationwide.com|


### Analytics

| Product|Offering Type| Availability|Supported|TSB Status|Comment|Contact|
| :----------------- | :--------- | :----------------------- | :-------- | :-------- | :-------------- |:--------------
|ETL| [AWS Glue](https://aws.amazon.com/glue/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **❗**| [Approved](/solutions/security/cloud-tsb/) (TSB0012469) | [Informatica v. Glue](/docs/aws/analytics/howto_informaticavglue)|CDS@nationwide.com|
|Data Query|[Amazon Athena](https://aws.amazon.com/athena/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0011999)|None|CDS@nationwide.com|
|Big data processing| [EMR](https://aws.amazon.com/emr/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**✔**|[Approved](/solutions/security/cloud-tsb/) (TSB12000)| [How To](/docs/aws/analytics/howto-amazon-emr)|NSC-BIGDATA-INFRASTRUCTURE@nationwide.com|
|Managed Data Warehouse|[Redshift](https://aws.amazon.com/redshift/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**✔**|Submitted|[Documentation](/docs/aws/database/redshift/)|CDS@nationwide.com <br> NSC-BIGDATA-INFRASTRUCTURE@nationwide.com|
|Realtime data analysis|[Kinesis](https://aws.amazon.com/kinesis/)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **❗**|[Approved](/solutions/security/cloud-tsb/) (TSB12001)|None|CloudSuccessTeam@nationwide.com|
|R Studio|[Custom Helm Chart](https://github.nwie.net/Nationwide/helm-rstudio-server)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**||None|CDS@nationwide.com|
|Container|[Liquibase Image](https://github.nwie.net/Nationwide/docker-library-liquibase)|![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)|**✔**||[How To](https://github.nwie.net/Nationwide/docker-library-liquibase)|CDS@nationwide.com|

### Storage

|Product|Offering Type|Availability|Supported |TSB Status |Comment|Contact|
| :------------------ | :----------------------------- | :-------------------------- | :-------- | :-------- | :----------:|---------------- |
|Block| [Elastic Block Store](https://aws.amazon.com/ebs/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CloudSuccessTeam@nationwide.com|
|Object|  [S3](https://aws.amazon.com/s3/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CloudSuccessTeam@nationwide.com|
|File System Management|[EFS](https://aws.amazon.com/efs/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012132)| [How To EFS](/docs/aws/storage/efs/howto-efs/)|CloudSuccessTeam@nationwide.com|
|Backup and Archival|[Glacier](https://aws.amazon.com/glacier/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) |**✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0011997) | None|CloudSuccessTeam@nationwide.com|
|Data Transfer|[AWS Snowball](https://aws.amazon.com/snowball/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012002) |[Data Migration Request](https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/new?assignees=mahender%2C+painej1&template=data_migration_request.md)|CDS@nationwide.com|
|Cloud storage for on-prem apps| [Storage Gateway](https://aws.amazon.com/storagegateway/)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0011998)| [How To](/docs/aws/storage/storage-gateway/howto-storagegateway) |CDS@nationwide.com|
|Custom Code|[CloudFormation S3 Object Provider Python](https://github.nwie.net/Nationwide/cfn-s3-object-provider-python)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)|**✔**||[Card 358](https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/358)|CDS@nationwide.com|

### Migration

|Product|Offering Type|Availability|Supported|TSB Status|Comment|Contact|
| :------------------------- | :--------------------------------- | :----------------- | :-------- | :-------- | :------ |:------ |
|DB Migration|[Database Migration Service](https://aws.amazon.com/dms/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012133)|None|hagyk1@nationwide.com|
|Data Transfer|[AWS Snowball](https://aws.amazon.com/snowball/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**|[Approved](/solutions/security/cloud-tsb/) (TSB0012002) |[Data Migration Request](https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/new?assignees=mahender%2C+painej1&template=data_migration_request.md)|CDS@nationwide.com|
|Data Migration |EMC DataDomain Virtual Edition|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Unsubmitted | [How To DDVE](/solutions/data-movement/howto-ddve/)|c.salloum@nationwide.com|

### Networking and Content Delivery

| Product| Offering Type| Availability| Supported | TSB Status | Comment |Contact|
| :------------ | :--------------------- | :------------------------------- | :-------- | :-------- | :------ |:------ |
|Virtual Private Cloud| [VPC](https://aws.amazon.com/vpc/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved|None|CIE@nationwide.com|
|Domain management |[Route 53](https://aws.amazon.com/route53/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved|None|CIE@nationwide.com|
|Dedicated network connection | [DirectConnect](https://aws.amazon.com/directconnect/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔**| Approved| None|CIE@nationwide.com|

### Developer Tools

| Product| Offering Type| Availability| Supported | TSB Status| Comment | Contact|
|------------------|------------|------------|-----------|--------------------|---------|--------------------|
| Code Deployment| [CodeDeploy](https://aws.amazon.com/codedeploy/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved| None| CIE@nationwide.com |
| Fully managaged build service| [CodeBuild](https://aws.amazon.com/codebuild/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved| None| CIE@nationwide.com |
| Fully managed continouse delivery service | [CodePipeline](https://aws.amazon.com/codepipeline/) | [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved| None| CIE@nationwide.com |
| Debug cloud code| [X-Ray](https://aws.amazon.com/xray/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Unsubmitted| None||

### Customer Engagement

| Product  | Offering Type   | Availability| Supported | TSB Status | Comment|
| :------- | :-------------- | :----------------------------------------- | :-------- | :-------- | :------------------------------ |
|Mobile Services |[PinPoint](https://aws.amazon.com/pinpoint/)|[![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)| **✔** **❗Ohio** | Approved | * IT/Business understands only App Notifications are allowed<br/> * Mobile push & SMS can be used but **NOT** email (SES)<br/>\* IT/Business complies with any device-driven notification requirements (Apple, Android) |

### Management Tools

| Product| Offering Type| Availability| Supported | TSB Status | Comment |Contact|
| :--------------- | :------------------------------ | :-------------------------------- | :-------- | :-------- | :------ |:------ |
| Monitoring and Management|[CloudWatch](https://aws.amazon.com/cloudwatch/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CIE@nationwide.com|
| App optimization|[AWS Autoscaling](https://aws.amazon.com/autoscaling/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CIE@nationwide.com|
| IAC Provisioning|[CloudFormation](https://aws.amazon.com/cloudformation/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CIE@nationwide.com|
| API usage tracker|[CloudTrail](https://aws.amazon.com/cloudtrail/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CIE@nationwide.com|
| Catalog for IT services|[Service Catalog](https://aws.amazon.com/servicecatalog/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **✔**| Approved | None|CIE@nationwide.com|
| View operational Data|[Systems Manager](https://aws.amazon.com/systems-manager/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/) | **X**| Unsubmitted | None    ||

### Security

|Product|Offering Type| Availability|TSB Status|Comment|Contact|
| :------------------ | :-------------------------------- | :---------------- | :------ | :------ |:------ |
|Permissions|  [IAM](https://aws.amazon.com/iam/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Approved | None|cse@nationwide.com|
|Credential storage| [Secrets Manager](https://aws.amazon.com/secrets-manager/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Approved | None|cse@nationwide.com|
|Threat detection|[GuardDuty](https://aws.amazon.com/guardduty/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Unsubmitted | None|cse@nationwide.com|
|One sign on for multiple accounts| [AWS Single Sign-On](https://aws.amazon.com/single-sign-on/)  | [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Unsubmitted | None||
|SSL/TLS certificates| [Certificate Manager](https://aws.amazon.com/certificate-manager/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Unsubmitted | None||
|Active Directory|[AWS Microsoft AD](https://aws.amazon.com/directoryservice/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Unsubmitted | None    |
|Ddos protection|[WAF & Shield](https://aws.amazon.com/waf/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Approved | None    |cse@nationwide.com|
|Access history| [ Artifact](https://aws.amazon.com/artifact/)| [![Generic badge](https://img.shields.io/badge/GA-yes-green.svg)](https://shields.io/)  | Unsubmitted | None    |

### Banned

- **Note:** Both Legal, IRM and Architecture have agreed these services are not "go-forward"
- **Note:** These services are **NOT** available in sandbox/dev/test/prod

| Category| Product| Offering Type |Contact|
| :---------------------- | :------------------------- | :------------ |:------------ |
| **Customer Engagement** | Simple Email Service [SES] | Email|mike.smolak@nationwide.com|
| **EC2 Network Security**| Elastic IP Addresses| Static IPv4||


### NW Product

For more information on the different product teams, refer to the [NW products page](/docs/aws/products/nw-product/)
