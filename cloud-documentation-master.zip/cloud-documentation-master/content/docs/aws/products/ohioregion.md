---
title: Ohio Region
menu: docs
category: aws
weight: 3
---

### US-East-2 (Ohio) Region is now available in BETA
   - Ohio has 3 Availability Zones (AZ)
   - LATENCY is NOT addressed yet -we are still building out the network, but it's coming.

### To determine if your Application is a good fit for the Ohio Region, please use the Cloud Diagnostics or [Self-Service Diagnostics](https://gocloud.nwie.net/solutions/migration/self-service-diagnostics/) for guidance
   - Applications that are sensitive to network latency will be considered, where there is a dependency to other applications and databases in DCN/DCE that are not able to migrate to the Virginia region due to run costs, latency, or impact to other applications
   - Applications should continue to replace tight coupling.  Prefer streaming and API’s over file transfers

### NOTE:  Sharing on-prem filesystems to AWS Ohio will not be permitted for security reasons
   - Prefer creation of AWS filesystems (EFS/FSx for Windows) and share back to on-prem (I&O can help!)
   - Sharing on-prem filesystems to AWS Virginia should be removed, and will be enforced at some point
 
### AWS products are not available in every AWS region 
   - GoCloud.nwie.net lists vetted products and indicates if they are not available in AWS Ohio
   - When planning to use AWS products, Check the [AWS Native Services Page](https://gocloud.nwie.net/docs/aws/products/aws-native-service/)
   - Work with Architecture and the [Cloud Success Team](https://github.nwie.net/Nationwide/CloudSuccessTeam)
   - In the future, there will likely be new AWS services available only in Ohio
 
### Now that you know the basics, How do you create Resources in Ohio?
   - Service Catalog resources such as codepipeline, serverless, etc. will have a Region selection option, choose Ohio 
   - For other available resources, you will simply change your region at the top right of the page.
   - As you are working in the new region, please provide your feedback via the [support page](https://gocloud.nwie.net/support/cloud-support/guaranteed-support/#guaranteed-support)

   <img class="img-responsive w-50" src="/docs/aws/products/OhioSelect.jpg">

### Will we need to move our work from the Virginia region to Ohio?
   - No. You are welcome to stay in the Virginia region or leverage both regions
   - If you choose, you are welcome to migrate your Virginia workloads to the Ohio region
   - If you need assistance moving a custom AMI from Virginia region to Ohio submit a request to the [I&O Success team](https://gocloud.nwie.net/support/cloud-support/guaranteed-support/)
   
### Will there be a Kubernetes environment in the Ohio region?
   - Yes.  It is a separate cluster from Virginia and on-prem clusters.

### Why didn't Nationwide simply choose to start in the Ohio region, instead of Virginia?
   - When the decision had to be made, the Ohio region was new and did not offer all of the necessary capabilities
   
[Back to products and services](https://github.nwie.net/schwarc6/cloud-documentation/blob/master/content/docs/aws/products/aws-native-service.md)
