---
category: aws
draft: false
title: "AWS ElastiCache"
menu: docs
---


## AWS ElastiCache Documentation <br />
* [AWS ElastiCache Documentation](https://docs.aws.amazon.com/elasticache/index.html)<br />

## ElastiCache is restricted to Redis and Encryption (at-rest and in-transit)<br />

**What Is Amazon ElastiCache for Redis** <br />
* [AWS ElastiCache Redis Documentation](https://docs.aws.amazon.com/AmazonElastiCache/latest/red-ug/WhatIs.html) <br />

----
## ElastiCache example Cloudformation template
To use ElastiCache in Test and Prod please add the following CloudFormation scipt to your pipeline with your specific parameters (ReplicationGroupId, DisbursementCode, ResourceOwner, APRMID, etc...)

```YAML
---
AWSTemplateFormatVersion: '2010-09-09'
Description: Create Nationwide ElastiCache Redis cluster.
Parameters:
  pReplicationGroupId:
    Description: Name of the replication group
    Type: String
    Default: RedisTest
  pReplicationGroupDescription:
    Description: Description of the replication group
    Type: String
    Default: Testing Redis replication group
  pRedisPort:
    Description: Redis port number
    Type: Number
    Default: 6379
    MinValue: 1
    MaxValue: 65535
  pCacheNodeType:
    Description: Instance type the nodes will launch
    Type: String
    Default: cache.t2.medium
    AllowedValues:
    - cache.t2.medium
    - cache.m3.large
    - cache.m3.xlarge
    - cache.m3.2xlarge
    - cache.r3.large
    - cache.r3.xlarge
    - cache.r3.2xlarge
    - cache.r3.4xlarge
    - cache.r3.8xlarge
  pMultiAZSupport:
    Description: Indicates whether Multi-AZ is enabled.
    Type: String
    Default: true
    AllowedValues:
      - true
      - false
  pNumCacheClusters:
    Description: The number of cache clusters for this replication group.
    Type: Number
    Default: 2
    MinValue: 1
    MaxValue: 6
  pDisbursementCode:
    Description: Customer Disbursement Code
    AllowedPattern: "([A-Za-z0-9]{9})"
    Type: String
    Default: 300672001
  pResourceOwner:
    Description: Your NWIE Short Name
    AllowedPattern: "(^[A-Za-z0-9]*)"
    Type: String
    Default: cordld1
  pAPRMID:
    Description: APRM ID
    AllowedPattern: "([0-9]{4})"
    Type: String
    Default: 1234
  pDataClassification:
    Description: Public_Data, Internal_Use_Only, PCI or Confidental
    Type: String
    Default: Internal_Use_Only
    AllowedValues:
      - Public_Data
      - Internal_Use_Only
      - Confidental
      - PCI
  pResourceName:
    Description: What is the name of this resource ?
    Type: String
    Default: RedisTest
  pEnvironment:
    Description: Cost Center equivalent
    Type: String
    Default: Dev
  pProduct:
    Type: String
    Default: TestingRedis

Resources:
  rSecurityGroup:
    Type: AWS::EC2::SecurityGroup
    Properties:
      GroupDescription: 'Security Group for Replication Group.'
      VpcId: !ImportValue oVPCID
      SecurityGroupIngress:
      - IpProtocol: tcp
        FromPort: !Ref pRedisPort
        ToPort: !Ref pRedisPort
        CidrIp: !ImportValue oVPCCIDR
        Description: 'Primary Data Center Space/User Space/VPN'
      Tags:
      - Key: Name
        Value: !Sub "${pProduct}-Instance-${pEnvironment}"
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pResourceName
      - Key: Environment
        Value: !Ref pEnvironment

  rSubnetGroup:
    Type: 'AWS::ElastiCache::SubnetGroup'
    Properties:
      Description: Subnet Group for Example Replication Group
      SubnetIds:
        - !ImportValue oPrivateSubnetA
        - !ImportValue oPrivateSubnetB
        - !ImportValue oPrivateSubnetC

  rReplicationGroup:
    Type: "AWS::ElastiCache::ReplicationGroup"
    Properties:
      AtRestEncryptionEnabled: true
      AuthToken: ThisIsYourPasswordChangeMe
      AutomaticFailoverEnabled: !Ref pMultiAZSupport
      CacheNodeType: !Ref pCacheNodeType
      CacheSubnetGroupName: !Ref rSubnetGroup
      Engine: redis
      NumCacheClusters: !Ref pNumCacheClusters
      Port: !Ref pRedisPort
      ReplicationGroupId: !Ref pReplicationGroupId
      ReplicationGroupDescription: !Ref pReplicationGroupDescription
      SecurityGroupIds:
        - !GetAtt
          - rSecurityGroup
          - GroupId
      TransitEncryptionEnabled: true

      Tags:
        -
          Key: "DisbursementCode"
          Value:
            Ref: "pDisbursementCode"
        -
          Key: "ResourceOwner"
          Value:
            Ref: "pResourceOwner"
        -
          Key: "APRMID"
          Value:
            Ref: "pAPRMID"
        -
          Key: "DataClassification"
          Value:
            Ref: "pDataClassification"
        -
          Key: "ResourceName"
          Value:
            Ref: "pResourceName"

Outputs:
  oRGEndpoint:
    Description: The primary endpoint location
    Value: !Join
      - ''
      - - 'redis://'
        - !GetAtt
          - rReplicationGroup
          - PrimaryEndPoint.Address
        - ':'
        - !GetAtt
          - rReplicationGroup
          - PrimaryEndPoint.Port
```

**NOTE: Update the AuthToken field in ReplicationGroup properties.  This is the password to connect to the Redis Cache.** <br />
* Use Parameter Store to secure your password. [Parameter Store How To](/docs/aws/cryptography/howto-parameterstore) <br />

