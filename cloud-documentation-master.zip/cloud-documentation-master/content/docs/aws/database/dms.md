---
title: "How to use Database Migration Service (DMS)"
menu: docs
draft: false
category: aws
---


# Database Migration Service (DMS)

You can use the AWS Schema Migration Tool in combination with AWS Data Migration Service to migrate on-prem databases to the AWS cloud in EC2 or RDS.   This allows for both heterogeneous migrations as well as homogeneous migrations.  In the latter case AWS recommends using database native tools if possible.
## AWS SCT (Schema Conversion Tool):
This tool is a client that is downloaded to your laptop or server and it allows for the conversion of one database engine to another.  It will automatically convert as much as it can, however in most cases there will be need for manual conversion of some subset.  It is also able to scan code and suggest changes to sql statements to make correct for the new database engine.

The full documentation on its use can be found at:

[https://docs.aws.amazon.com/SchemaConversionTool/latest/userguide/CHAP\_Welcome.html](https://docs.aws.amazon.com/SchemaConversionTool/latest/userguide/CHAP_Welcome.html)

Please review the documentation and follow the documented steps contained therein when attempting to convert schemas.  The following database engines are supported by AWS SCT:

**Source Engines:**
- DB2 LUW
- MySQL
- Oracle
- PostgreSQL
- SQL Server

**Target Engines:**
- Aurora MySQL
- Aurora PostgreSQL
- MariaDB
- MySQL
- Oracle
- PostgreSQL
- SQL Server

**NOTE:**  Not all combinations are available.  For example if your source is DB2 LUW, Oracle is not available as a target.

## AWS DMS (Database Migration Service)
AWS DMS is a service provided by AWS that you can access by logging into your AWS account. It allows you to migrate data from on-prem to an AWS RDS or EC2 database You can also use it to migrate from AWS back to on-prem if needed.  Additionally, it provides change data capture, CDC, so that replication between the target and source database engines can be maintained.  Please note CDC will require that the database engine logging is turned on and that the logs are available for DMS.

If you are migrating from one type of database engine to another type of database engine, you will need to use AWS SCT first to perform the schema conversion.  You may also need to write some transformation rules within DMS to facilitate the migration between the two different types of database engines.

Both the Migration and any CDC can be monitored through the service for performance and troubleshooting.  Additionally, the DMS logs can be forwarded to Cloudwatch as well.

The documentation for AWS DMS can be found at:

[https://docs.aws.amazon.com/dms/latest/sbs/DMS-SBS-Welcome.html](https://docs.aws.amazon.com/dms/latest/sbs/DMS-SBS-Welcome.html)

## Database Migration Play Books:
AWS provides additional resource to help manage moving from a commercial on-prem database to an Aurora or Open Source Database.  This include migration playbooks for some od the more common types of migration.  This information can be found at:

[https://aws.amazon.com/dms/resources/](https://aws.amazon.com/dms/resources/)

**NOTE:**
If you have additional question, or need help getting started with AWS SCT or AWS DMS, please contact: SRE@nationwide.com

## Migration Process Example

This tool provides great flexibility in regards to migrating data. One of the most common use cases for us at Nationwide is to migrate our on-premise databases to an RDS instance in AWS. We will use the following steps to accomplish this. We will start with a simple MariaDB to Aurora-MySQL migration as an example

#### 1. Stand up the RDS database
Stand up an RDS instance (in our case, Aurora MySQL 5.7), filling in the required fields. To meet security standards, adjust the following settings:
* Public Accessibility: No
* Subnet group: Choose one that uses only private subnets. If one does not exist, contact CDT to have one created for you
* Encryption: Enabled
* Log Exports: Check all logging

#### 2. Prepare your on-premise database
To have your database be able to migrate, we must enable replication on our on-prem database. This varies depending on what engine you are using (oracle, mssql, etc), but in our case we simply need to add a few things to our MariaDB configuration
* Enable binary logging by adding the following to your my.cnf
```
log-bin=bin.log
log-bin-index=log.index
max_binlog_size=100M
binlog_format=row
```
* Restart the database
* Verify binary logging is enabled using `select * from information_schema.global_variables where variable_name='log_bin';`
* Grant the following permissions to your database user
  * `GRANT REPLICATION CLIENT on *.* to myuser;`
  * `GRANT REPLICATION SLAVE on *.* to myuser;`
  * `GRANT SUPER on *.* to myuser;`

#### 3. Create a replication instance
A replication instance initiates the connection between the source and target databases, transfers the data, and caches any changes that occur on the source database during the initial data load.

Go to the DMS console. Then go to Replication Instances and create a new instance. Fill in the required fields. The following settings will be required
* Publicly Accessible: Disable
* Allocated Storage: Varies depending on size of database. For most purposes, the default of 50gb is fine. If you have a large database with many transactions, consider reading through [this article](https://docs.aws.amazon.com/dms/latest/userguide/CHAP_BestPractices.html#CHAP_BestPractices.SizingReplicationInstance).
* Replication Subnet Group: Choose a subnet group with private subnets. If one does not exist, contact CDT to have one created for you
* VPC Security Groups: Choose the security groups that the RDS instance is using

#### 4. Create the endpoints
We will then create two endpoints: a source endpoint and a target endpoint. A source endpoint is the database that the data is coming from while the target endpoint is where the database is getting replicated to.

#### Source Endpoint
Fill in any required fields. The following will be required
* Endpoint Identifier: a name for the endpoint that describes the source database, for example, OldDatabase
* Engine: The engine that the old databases uses. In our case: mariadb
* Server Name: The hostname of the database
* SSL Mode: If the database requires an SSL cert to connect, choose which one you need. Otherwise set to None
* VPC: The VPC that the replication instance is deployed to
* Replication Instance: The instance you created in step 3

#### Target Endpoint
Our target is an RDS instance so we will have a few things different. Fill in any required fields. The following will be required
* Select RDS DB Instance: Enable
* RDS Instance: Choose your RDS instance that you created
* Endpoint Identifier: a name for the endpoint that describes the target database, for example, RDSDatabase
* Engine: The engine that the old databases uses. In our case: aurora
* Server Name: The endpoint of the RDS instance
* SSL Mode: If the database requires an SSL cert to connect, choose which one you need. Otherwise set to None
* VPC: The VPC that the replication instance is deployed to
* Replication Instance: The instance you created in step 3

#### 5. Create the replication task
This step will be what does the lifting of the data to the new database. In the DMS console, select Tasks and then Create Task. Fill in any required fields. The following must be done:
* The instance you created in step 3
* Select the source and target endpoints you created in step 4
* Choose your migration type, whether you want a one time copy or a continuous replication
* Target Table Preparation Mode: If using RDS, change to Do Nothing.
* Enable Logging: enabled
* Schema Name Is: If you want all databases/schemas moved, leave as %. Otherwise, put the databases/schemas that you want to move

Select Add Selection Rule and then Create Task. If you disabled the option to start on creation, when you are ready to start migrating, select the task and press the Start/Resume button and the replication of the databases will begin

#### Troubleshooting

If there are issues with the replication, the CloudWatch logs should tell you whatever happened, assuming you followed the steps in step 5 to enable logging. The easiest way to find the CloudWatch log stream is to select the replication task and go to the Logs tab.

## Author
* Tyler Napierkowski - v1
* Jon Rentz - v2


