---
title: Service Catalog - DatabaseServices-Redshift-Cluster
menu: docs
category: aws
---
## What is it?

The Redshift Cluster product creates an AWS Redshift Cluster and the necessary resources for it to operate.
[What is Amazon Redshift?](https://docs.aws.amazon.com/redshift/latest/mgmt/welcome.html)

## Whats Included

The Redshift Cluster product does not deliver any files to you, but does create associated resources with your cluster
to ensure it functions within Nationwide's AWS cloud. The resources are:
  * Redshift Cluster Subnet Group
  * VPC Security group
  * Product IAM role and Policy
  * KMS key and alias
  * The Redshift cluster itself.

All of these resources are created when you order your Redshift Cluster and you will receive an email with the resource
information when the cluster is ready to use. Upon deletion of your cluster all of the resources will be deleted as well.

## Product Deletion

Redshift clusters in any dev and test account can be deleted by the users who ordered them from the Service Catalog console.
Additionally, upon deletion of your service catalog provisioned product a final snapshot will be created of your cluster with
a lifespan of 30 days. However, for data compliance, any Redshift Cluster in a production account must be deleted by the Cloud
Data Services team. To have a cluster deleted please reach out to them at CloudDataServices@nationwide.com.

## Support

For support on your Redshift Cluster please reach out to Cloud Data Services at CloudDataServices@nationwide.com.

