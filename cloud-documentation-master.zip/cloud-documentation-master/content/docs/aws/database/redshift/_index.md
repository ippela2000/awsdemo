---
title: Redshift Getting Started
menu: docs
draft: false
category: aws
---
## Redshift Data Warehousing

### What is Redshift?

Amazon Redshift is a petabyte-scaled, fully managed data warehouse service designed for data warehouse, business intelligence and data analytics.  Redshift uses columnar architecture to reduce I/O for analytical queries and uses standard ANSI SQL to query the data.  "Fully managed" offers one-click operations for database backup, resizing and tuning.  Amazon is responsible for the infrastructure.  You are responsible for selecting the right data model and performing DBA activities.

### Considerations for choosing Redshift

* Redshift is designed for **OLAP** (Online Analytical Processing) characterized by batched write operations and high volume reads.
* Redshift is not designed for **OLTP** (Online Transaction Processing) characterized by continuous write operations and a large number of small read operations.  For OTLP data warehousing, consider using **DynamoDB**.
* Redshift is not ideal for small datasets (< 100GB).
* Use Redshift for hot, frequently accessed data.

### Redshift Architecture

* Redshift is a massively parallel, shared-nothing columnar architecture for storing data on disk and is made up of Leader node(s) and Compute node(s).
* Redshift physically stores the data on disk by column rather than row and only reads the column data that is required, thereby saving I/O.
* The Leader node uses the SQL endpoint, stores the metadata and coordinates parallel SQL processing.
* The Compute nodes are local, columnar storage which execute the queries in parallel.
* You connect to the leader node using a JDBC or ODBC client using the [Endpoint].
* When sizing your cluster for Production, you should use at least two compute nodes for data mirroring.
* Maintain at least 20% free space for scratch space, **VACUUM**, and temp tables.

### Redshift Table Design

#### Data Sorting
Data sorting physically orders the rows of table data based on certain column(s) to reduce I/O.  Data sorting is achieved by defining a sort key using the table property **SORTKEY**.

##### Best Practices for Sort Keys
* Place the sort key on columns that are frequently filtered.
* Place the sort key on lowest cardinality columns first.
* Sort keys are less beneficial on small tables.
* Define four or less sort key columns.

 #### Data Distribution
Data distribution style is a table property (DISTSTYLE) that dictates how the tables data is distrubted through out the cluster.  There are three choices for this property: **KEY**, **ALL**, and **EVEN**.

##### Best Practices for Data Distribution
* Choosing the right data distribution value allows you to distribute data evenly for parallel processing and minimizes data movement during query processing.
* DISTSTYLE **KEY**
  * optimizes join performances between large tables
  * optimizes insert into select performance
  * optimizes group by performance
  * the column that is being distributed on should contain values that are unique (i.e. userid in a user table) to not cause row skew

* DISTSTYLE **ALL**
  * optimizes join performances with dimension tables
  * reduces disk usage on small tables
  * should only be used on small to medium size dimension tables (<3 million rows)

* DISTSTYLE **EVEN**
  * use if neither **KEY** or **ALL** apply or if you are unsure

#### Additional Best Practices
* Distribution, Sort and Encoding can have significant impact on query performance.
* Convert columns that frequently filtered on from dimension tables to fact tables.
* Convert values that are calculated often into a table.
* Keep data types as wide as necessary (but no longer than necessary)
* When ingesting data into your table
* Schedule **VACUUM** to run based on the number of deletes.
* Use **ANALYZE** to collect table statistics for optimal query performance.

### Redshift Data Ingestion
Loading large datasets can be time consuming and require large computing resources.  How you load your data can impact query performance.

#### COPY Statement
The COPY command loads data in parallel from various sources.  It loads large amounts of data more efficiently than using an INSERT statement.

#### Multi-Row Insert
If you require SQL inserts and cannot use a COPY command, then use a multi-row insert.  Data compression is inefficient when you add data one or a few rows at a time.  Multi-row inserts batch a series of inserts thus increasing performance.

#### Bulk Insert
A bulk insert uses a SELECT clause for higher performance when inserting data.  For example,
    insert into my_table
    (select * from your_table);

#### Staging Table
Redshift does not support upserts when inserting and updating data from a single source.  However, you can mimic this behavior by loading your data into a staging table and then joining it with your target table.

## What is Redshift Spectrum?
Redshift Spectrum is used to execute queries directly agains S3.  Redshift Spectrum uses external tables to query data without having to load and transform it.  Redshift Spectrum is good for heavy scan and aggregate work.

### Considerations for choosing Redshift Spectrum

* Query data in S3 with ANSI SQL.
* Use Redshift Spectrum for historical, less frequently accessed data.
* Perform adhoc queries for data scientist and business analysts.
* Allows you to combine cold data in S3 with local tables.
* Access S3 data from multiple clusters.
* Supports structured and semi-structured data formats.

##### Best Practices Redshift Spectrum
* Parquet or ORC files are good choices for analytical queries.
* Row format files should be compressed for faster performance.
* Optimal files sizes are >1MB and <1GB.
* If you use large files, >1GB, they should be split.
* Partition files on frequently filtered columns.*

## Workload Management (WLM)
WLM in Redshift allows you to manage, prioritize and throttle different types of queries. WLM can also be used to control concurrency and automatically terminate long running queries.  WLM allows you to define rules that monitor and take action on your queries based on those rules.  For example, you might set a rule to abort a query when the resource consumption begins to degrade the cluster performance.
* Use the AWS region US-East-1 (N. Virginia).
* Use of native AWS capabilities/services is preferred.
* Use [AWS Tags.](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/Using_Tags.html)
* Use [Security Group(s)](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_SecurityGroups.html) for your application.
* Use [Amazon Machine Image (AMI)](https://docs.aws.amazon.com/general/latest/gr/glos-chap.html) for server builds
* Use up-to-date applications with the latest AMI.
* Use [Elastic Load Balancer (ELB)  / Application Load Balancer (ALB)](https://aws.amazon.com/elasticloadbalancing/)  for load balancing needs.
* Use [Amazon CloudFormation](https://aws.amazon.com/cloudformation/) for creation of templates and grouping of services.
* A code deployment process has been developed.
* Build everything as code, and use github.nwie.net to securely store it.
* Use [AWS Data At Rest Encryption](https://aws.amazon.com/blogs/security/tag/ec2-instance-store-encryption/) by default (block level).
* Shutdown the infrastructure when not in use.
* Try to start with smaller instances, wherever possible, and change to bigger ones, if you need them.
