---
title: RDS Oracle
menu: docs
category: aws
---

## **Ordering An Oracle Database**

- The best and easiest way is go through the AWS Service Catalog in the infraSvcsProd account
  - From here a Developer or User can order an instance and have it built in their specific BSA account
  - NOTE: If you need multiple environments you will need to deploy multiple RDS service requests. Under the ENVIRONMENT parameter be sure to select DEV.
- The build process takes approximately 15-30 minutes for Dev/test and 20 - 40 minutes for prod as it is setting up multi az for production
  - After a successful build, the builder (Resource Owner) will receive an email indicating the build is complete along with all necessary details on how they can move forward with utilizing the new database.
    - If you do not receive an email within the given time-frames please file an issue [here](https://github.nwie.net/Nationwide/AWS-DataStores/issues/new) and provide as much detail as possible
  - If a build fails, for whatever reason, the builder (Resource Owner) will receive an email indicating the error(s) and why a build could not move forward

## **RDS Requirements**

- Database Engine: Oracle Enterprise Edition.
- Tagging: Refer to the page [Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement) for tagging requirements for your RDS instances.
- No publicly accessible RDS. Cloud formation property PubliclyAccessible: &#39;false&#39;
- No unencrypted storage RDS. Cloud formation property StorageEncrypted: &#39;true&#39;

## ** Supported Version

- Oracle 19C - This is the most current version of Oracle available in RDS and should be used to maintain currency
- Oracle 12C:
  - Oracle 12.2 - This was provided to meet some specific Vendor requirements
  - Oracle 12.1 - Should not be used unless you have a specific vendor requirement for it.

## **Database Master Password Process**

- During the creation of your AWS RDS Oracle a master/builder ID and password are created and then stored in a &quot;master&quot; Secrets Manager.
  - Right now, these credentials [builder ID and PWD] will be used by DDS, Distributed Database Services, to create your application IDs
  - Currently LDAP authentication is not available in Oracle RDS, so all application IDs will be created as local
  - IDs will have to be managed by Secrets manager in lue of LDAP until AWS makes LDAP authentication for Oracle RDS available.

## **Database Generic ID creation and password management**

- During the creation of your AWS RDS Oracle database you have the option of creating locally authenticated generic IDs.
- You will be able to input comma seperated with no spaces IDs into 3 roles (EX: ID1,ID2,ID3), and an ID can only be provisioned to one of the roles.  Roles are:
  - ENDUSER - gives basic connect to database.
  - DEVELOPER - gives access that may be needed by developers.
  - detailed list of privileges for each role is below
- In order to create IDs the following conditions must be met:
  - The ID must be a generic ID registered in IIQ.
    - If it is not registered the ID will not be created, and the requester will receive notification via email.
  - The Primary and Secondary owners should be aware of and approve the usage of the ID in your database
    - They will be sent an email notifying them that their ID has been provisioned.
  - You must have a RDSPowerUser Federated role for your team.  You will have to enter you team tag in the team field in order to be able to retrieve the password for the ID from Secrets Manager.
    - For more information on creating the RDSPowerUser Federated role see: [Federated Application Team Roles](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/how-to-federated-app-team-roles/)
- Application Schema IDs owned by I&O currently cannot be provisioned by this process per the IAM program controls linked below
  - You can autoprovision these IDs if needed after the databas build at: [Automated Database Access Request](https://fancy.nwie.net/AutomatedDatabaseAccessRequest)

**Role Definitions:**
- ENDUSER:
  - alter session, create session, create synonym
- DEVELOPER:
  - ALTER SESSION, CREATE CLUSTER, CREATE DATABASE LINK, CREATE DIMENSION, CREATE INDEXTYPE, CREATE LIBRARY, CREATE MATERIALIZED VIEW, CREATE OPERATOR, CREATE PROCEDURE, CREATE ROLE, CREATE SEQUENCE, CREATE SESSION, CREATE SYNONYM, CREATE TABLE, CREATE TRIGGER, CREATE TYPE, CREATE VIEW, DEBUG CONNECT SESSION, QUERY REWRITE, select_catalog_role, select on ALL_USERS
  - Execute on the following packages: DBMS_JOB, DBMS_LOB, UTL_FILE, UTL_HTTP, UTL_SMTP, UTL_TCP

**ID Provisioning Controls**
The following links are the controls and policies that must be followed for ID provisioning.
- [IAM Program documentation on the ownership of schema IDs](https://onyourside.sharepoint.com/sites/IRM/identity/IAMProg/Lists/FAQ/DispForm.aspx?ID=75&e=IDUCX9)
- [IAM Program documentation on the ownership of non-schema IDs/admin IDs](https://onyourside.sharepoint.com/sites/IRM/identity/IAMProg/Lists/FAQ/DispForm.aspx?ID=76&e=LuSatJ)
- [Access Control Security Standard](https://onyourside.sharepoint.com/sites/IRM/SecurityStandardsPortal/IRMSecurityStandards/Forms/Stds%20%20Controls.aspx?viewpath=%2Fsites%2FIRM%2FSecurityStandardsPortal%2FIRMSecurityStandards%2FForms%2FStds%20%20Controls%2Easpx&id=%2Fsites%2FIRM%2FSecurityStandardsPortal%2FIRMSecurityStandards%2FAccess%20Control%20IT%20Security%20Standard%2Epdf&parent=%2Fsites%2FIRM%2FSecurityStandardsPortal%2FIRMSecurityStandards)
- [Identification and Authentication Standard](https://onyourside.sharepoint.com/sites/IRM/SecurityStandardsPortal/IRMSecurityStandards/Forms/Stds%20%20Controls.aspx?viewpath=%2Fsites%2FIRM%2FSecurityStandardsPortal%2FIRMSecurityStandards%2FForms%2FStds%20%20Controls%2Easpx&id=%2Fsites%2FIRM%2FSecurityStandardsPortal%2FIRMSecurityStandards%2FIdentification%20and%20Authentication%20IT%20Security%20Standard%2Epdf&parent=%2Fsites%2FIRM%2FSecurityStandardsPortal%2FIRMSecurityStandards)

## **Parameter input help**

On Product list - Product details - Launch product : Product Version
  - <ins>Provisioned product:</ins> enter text that contains your instance name.  i.e  myapp01

On Product list - Product details - Launch product : Parameters
  - <ins>Business Unit Name:</ins> select your business unit from the drop-down list.
  - <ins>Environment:</ins> Select the AWS environment you where want the database deployed.
  - <ins>Resource Owner:</ins> enter in a valid NWIE ID.  i.e.  hecklek  *DO NOT ENTER IN AN EMAIL ADDRESS.*
  - <ins>Disbursement Code:</ins> enter in your valid nine digit disbursement code.
  - <ins>ARPM ID:</ins> enter in your valid four digit APRM ID code.
  - <ins>Data Classification:</ins> select a data classification from the drop-down list. (Select Sensitive if it has PII, PCI, etc)
  - <ins>AWS Region:</ins> leave at the default value.
  - <ins>Power on Instance at:</ins> select the UTC time from the drop-down list. NOTE: This UTC Time
  - <ins>Shut down Instance at:</ins> select the UTC time from the drop-down list. NOTE: This UTC Time
  - <ins>RDS Instance type:</ins> select the Instance machine type from the drop-down list.
  - <ins>RDS Instance Name:</ins> enter in name for your Instance.  Best if this matches the *Provisioned Product* entered above. Will be used for Oracle RDS endpoint.
  - <ins>Name of Oracle database:</ins> Enter your Database Name - 3-5 small case alpha (basename) followed by 0-2 digits (iteration). i.e.  sales01.  Usage suffix will be appended automatically based on environment (p for Prod, t for Test, d for Dev, etc).
  - <ins>Database usage environment:</ins> select value from the drop-down list.
  - <ins>Version of database:</ins> select value from the drop-down list.  If you require a database version that is not available in the drop-down list please work with DDS on your specific needs.
  - <ins>Character Set:</ins> select value from the drop-down list.  If you require a character set that is not available in the drop-down list please work with DDS on your specific needs.
  - <ins>Storage Type:</ins> gp2 standard, io1 iop provisioned if needed
  - <ins>Iops:</ins> Only used for io1 (provisioned iops) storage - Please validate the maximum iop input for your instance type.  Theoretical max is 50 * GB provisioned
  - <ins>Initial storage allocated:</ins> For Storage Type io1 Minimum is 100GB and for gp2 Minimum is 20GB ... and max is 16384GB.
  - <ins>Maximum storage limit for database storage auto-scaling in GB:</ins>  Optional.  If entered, must be greater than initial storage allocated.
  - <ins>Generic IDs to be assigned End User Role:</ins> Optional. Must be a valid generic ID in IIQ that is registered for use with Oracle technology.  Can provision multiple IDs by seperating them with a coma with no spaces.
  - <ins>Generic IDs to be assigned Developer Role:</ins> Optional. Not available in AWS Prod environments.  Must be a valid generic ID in IIQ that is registered for use with Oracle technology.  Can provision multiple IDs by seperating them with a coma with no
spaces.
  - <ins>RDSPowerUser Federated role Team name:</ins> enter in your team name.  i.e. nftigers.  To request RDSPowerUser: [Federated Application Team Roles](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/how-to-federated-app-team-roles/)

## ** Decommissioning the RDS Instance
Currently there is no automated process to cleanup all objects associated with an RDS instance when you terminate it. In addition to terminating the  instance, the following items also need deleted
NOTE: It is strongly recommended that you take a final snapshot for any RDS instance that you may need to recover, particularly if you are deleting a production instance.
- In the console go to the RDS Service, and pick the instance you want to delete
  - On the connectivity and security tab, note the name of the Subnet group
  - On the configuration tab note the following
    - Option groups name
    - Parameter group name
    - Note the Instance name
    - Note the Database name
- Delete you RDS Instance
- In the account the RDS Instance resides in delete the following:
  - KMS Key  (If you know you will never need to restore this database from the final snapshot)
    - In Services search for Key Management Service and select it
    - Search for the instance name you noted in the previous step, and it will bring up the associated KMS key
    - Schedule it for deletion (NOTE: KMS keys cannot be immediately deleted, the minimum wait is 7 days so schedule it for 7 days)
  - Option Groups
    - On the RDS service page, select the Option Groups link that appears in the column on the left
    - Search for the option group you notes in the previous step
    - delete it
    - NOTE:  It can take a while before the Option Group can be deleted, AWS can be slow to disassociate the Option Group from the instance
  - Parameter Group
    - On the RDS service page, select the Parameter Group link that appears in the column on the left
    - Search for the parameter group you noted in the previous step
    - delete it
  - Subnet group
    - On the RDS service page, select the Subnet Group link that appears in the column on the left
    - Search for the parameter group you noted in the previous step
    - delete it
- In the InfraSvcsProd account delete the database record out of the rdsoracle table
  - log into InfraSvcsProd
  - Got to the DynamoDB service
  - select Tables from the list on the left side of the page
  - search for rdsoracle and select it
  - open the items tab, and search for the instance you deleted by using a filter on InstanceName and typing in the database name you noted in the previous step
  - select that row, and then under the Actions drop down select delete.


If you run into any issues with the deletion, please open an issue [here](https://github.nwie.net/Nationwide/AWS-DataStores/issues/new)

## **AWS Oracle Documentation**

- [Best Practices for Amazon RDS Oracle](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Oracle.html)
- [Monitoring Amazon RDS](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/CHAP_Monitoring.html)
- [Options for the Oracle Database Engine](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Appendix.Oracle.Options.html)
  - NOTE: Currently the Multimedia and JVM options are included in the standard Nationwide build.  If you need other options, please submit a feature request [here](https://github.nwie.net/Nationwide/AWS-DataStores/issues/new)
- [Oracle Database Log Files](https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_LogAccess.Concepts.Oracle.html)

## **Need A Feature?**

Please submit a feature request [here](https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/new/choose) to RDS support enabled on your instance.

