---
title: How To decommission a RDS instance
menu: docs
category: aws
---

## RDS Decommissioning Process

- The self service decom process is a process in which you are able to tear down RDS instances that you built using the Service Catalog. It can be used with RDS Microsoft SQL Server, RDS PostgreSQL, and RDS Oracle. The process will remove all objects that were provisioned when your instance was built. This helps to reduce clutter and cost.

- The decommissioning process is still very much a Minimal Viable Product. Therefore, not all features are available. Please be aware of the following limitations when using the automated decommission process:
  - You must be the person who ordered the RDS instance initially.
  - You are only able to decommission RDS instances in the Dev and Test environments. Production instances are not supported at this time and still require a request to the DBA group.
  - You can only initiate the decom process through your Provisioned Products List in the Service Catalog. Means of executing a decommission through an API or Code Pipeline will come in future releases


## How do you decommission an instance?

- Log into the InfraSvcsProd-PIPELINE account
- Type "Service Catalog" in the search bar and hit enter.
- Select the "Service Catalog" link that appears.
- Select the "Provisioned Products List" link on the left side of the page
- Search for the pipeline that built your RDS instance. Note: This may not be the same name as your instance.
- When you find the pipeline, select the 3 dots to the left of the pipeline to open the menu
- Select "Terminate Provisioned Product"
- Hit ok
- When the process is complete, you should receive an email. If the process fails, you will also receive a notification to open a request to the DBA group to investigate.

## How do you get assistance (including Prod decom requests) or have any of our questions answered?

- Open a request to the DBA Service Now queue [here](https://fancy.nwie.net/DatabaseRequest).

