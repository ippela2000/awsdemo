---
title: RDS Postgres
menu: docs
category: aws
---

***Postgres is only approved for non-PII data and non-critical, non-customer facing applications.***

## **Ordering A Postgres Database**

- The best and easiest way is go through the AWS Service Catalog in the Tools account for your BSA.  i.e.  ToolsDGS01-CODEPIPELINE-AWS
  - From here a Developer or User can order an instance and have it built in their specific BSA account.
  - NOTE: If you need multiple environments you will need to deploy multiple RDS service requests.
- **Please review and understand all requirements prior to ordering an RDS Instance build through the AWS Service Catalog.**  If you have questions you can use the [#postgres RocketChat channel](https://rocketchat.nwie.net/channel/postgres) or talk with your supporting DBA.
- The build process takes approximately 15 minutes for Dev and Test; Prod will take longer.
  - After a successful build, the builder (Resource Owner) will receive an email indicating the build is complete along with all necessary details on how they can move forward with utilizing the new database.
    - If you do not receive an email within the given time-frame please file an issue [here](https://github.nwie.net/Nationwide/AWS-DataStores/issues/new) and provide as much detail as possible.


## **RDS Requirements**

- **All database user IDs must be registered in IIQ prior to creating a Postgres Instance.**
- Database Version: Currently version 11.4.
- Database CharacterSet: Currently UTF8.
- Tagging: Refer to the page [Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement) for tagging requirements for your RDS instances.
- Determine a schema name.  **This name must be registered in IIQ.**
    - The schema will contain all your database objects.
    - Schema name must: start with a letter; be at least two characters long; be all lower case; maximum of 20 characters.
    - **Register the schema name in IIQ:**
      - Follow [schema id creation instructions for IIQ.](https://onyourside.sharepoint.com/:w:/r/sites/RDDS/Internal/Shared%20Documents/20%20-%20Technical%20Documentation/Postgres/Create%20schema%20ID%20within%20IIQ%20instructions.docx?d=w24fe1671871b4fa39281fdb35a03189e&csf=1&web=1&e=tifLe1)
    - **Please read the _Database user ID creation_ section below.**
- You *must* enter in a **Schema name** and **Team name** (see RDSPowerUser Fedrated Role section below) when creating a Postgres Instance.


## **Database user ID creation**
  - **Currently LDAP authentication is not available in Postgres RDS, so all IDs will be created as local IDs.  NWIE and secondary IDs are prohibited.**
  - **All user IDs entered must be registered in IIQ prior to creating a Postgres Instance.  IDs must be registered as 'Disconnected Directories', type = <ins>Postgres</ins> in IIQ.**
  - **WriteUsers** and **ReadUsers** should be registered in IIQ as type 'Postgres' and should have BSA personnel as primary and secondary ID owners.
  - **Please wait at least twelve hours from the time your IDs are registered in IIQ and you create your RDS Postgres Instance.**
  - During the ordering process you will have the opportunity to enter in a comma delimited list of **WriteUsers** and **ReadUsers**.  *WriteUsers* will get: Select, Insert, Update and Delete permissions.  *ReadUsers* will get: Select permission.
  - For each WriteUser and ReadUser created, a Secret will be created in the AWS Secrets Manager to store the passwords for your IDs.
  - In order to create IDs the following conditions must be met:
    - The ID must be a generic ID registered in IIQ.
      - If IDs are not registered in IIQ the ID will not be created, and the requester will recieve notification via email.
    - The Primary and Secondary owners should be aware of and approve the usage of the ID in your database.
      - They will be sent an email notifying them that their ID has been provisioned.
    - You must have a RDSPowerUser Federated role for your team.  You will have to enter your team name in the team field in order to be able to retrieve the password for your database IDs from Secrets Manager.
      - For more information on creating the RDSPowerUser Federated role see: [Federated Application Team Roles](/docs/aws/getting-started-with-aws/howto_federatedappteamroles)
  - **Currently LDAP authentication is not available in Postgres RDS, so all IDs will be created as local IDs.**
  - These IDs will have to be managed by Secrets manager in lieu of LDAP until AWS makes LDAP authentication for Postgres RDS available.


## **RDSPowerUser federated role is required**
- **This step must be fully completed PRIOR to going through the build process.  You can verify the two required AWS Roles have been created from the Identity and Access Management (IAM) service.**
- You must have a RDSPowerUser Federated role for your team.  Creating this role will allow you access to your AWS resources based on tags.  Your team name will be one of those tags.  You will enter your team name in the team field in order to be able to retrieve the password for your database IDs from Secrets Manager.
      - For more information on creating the RDSPowerUser Federated role see: [Federated Application Team Roles](/docs/aws/getting-started-with-aws/howto_federatedappteamroles)


## **Database Master Password Process**

- During the creation of your AWS RDS Postgres a master/builder ID and password are created and then stored in a &quot;master&quot; Secrets Manager.
  - These credentials [master ID and PWD] will be used by DDS.


## **Parameter input help**

  - <ins>Provisioned product:</ins> enter text that matches your Instance name.  i.e  SalesDev
  - <ins>Business Unit Name:</ins> select your business unit from the drop-down list.
  - <ins>AWS Environment:</ins> select your environment from the drop-down list.  This is the AWS physical environment.
  - <ins>Resource Owner:</ins> Valid Nationwide email. Must include @nationwide.com.
  - <ins>Disbursement Code:</ins> enter in your valid nine digit disbursement code.
  - <ins>APRM ID:</ins> enter in your valid four digit APRM ID code.
  - <ins>Data Classification:</ins> select a data classification from the drop-down list.
  - <ins>AWS Region:</ins> leave at the default value.
  - <ins>Power on Instance at:</ins> select the UTC time from the drop-down list.
  - <ins>Shut down Instance at:</ins> select the UTC time from the drop-down list.
  - <ins>RDS Instance type:</ins> select the Instance machine type from the drop-down list.
  - <ins>RDS Instance Name:</ins> enter in name for your Instance.  Best if this matches the *Provisioned Product* entered above.
  - <ins>Name of Postgres database:</ins> Enter your Database Name - 3-5 small case alpha (basename) followed by 0-2 digits (iteration). i.e.  sales01.  Usage suffix will be appended automatically based on environment (p for Prod, t for Test, d for Dev, etc).
  - <ins>Database usage environment:</ins> select value from the drop-down list.  This is your LOGICAL environment.
  - <ins>Version of database:</ins> select value from the drop-down list.  If you require a database version that is not available in the drop-down list please work with DDS on your specific needs.
  - <ins>Character Set:</ins> select value from the drop-down list.  If you require a character set that is not available in the drop-down list please work with DDS on your specific needs.
  - <ins>Storage Type:</ins> gp2 standard, io1 iop provisioned if needed
  - <ins>Iops:</ins> Only used for io1 (provisioned iops) storage
  - <ins>Initial storage allocated:</ins> For Storage Type io1 Minimum is 100GB and for gp2 Minimum is 20GB ... and max is 16384GB
  - <ins>Maximum storage limit for database storage auto-scaling in GB:</ins>  Optional.  If entered, must be greater than initial storage allocated.
  - <ins>Schema:</ins> enter in a schema name.  USE ALL **lowercase** LETTERS.  NO SPACES.  Schema name must: start with a letter; be at least two characters long; be all lower case; maximum of 20 characters.
  - <ins>Team:</ins> enter in your team name.  i.e. nftigers.  To request RDSPowerUser: [Federated Application Team Roles](/docs/aws/getting-started-with-aws/howto_federatedappteamroles)
  - <ins>WriteUsers:</ins> comma delimited list of Write users.  Optional.  USE ALL **lowercase** LETTERS. NO SPACES.  i.e.  etlid,loadid
  - <ins>ReadUsers:</ins> comma delimited list of Read users.  Optional.  USE ALL **lowercase** LETTERS. NO SPACES.  i.e.  reportingid,readid

## **Decommissioning the RDS Instance**

  - Please refer to the How To document [here.](https://cloud-documentation.apps.aws.e1.nwie.net/docs/aws/database/rds/howto-rds-decom/)

If you run into any issues with the deletion, please open an issue [here.](https://github.nwie.net/Nationwide/AWS-DataStores/issues/new)

## **How do you get detailed assistance and guidance?**

- Open a request to the DBA ServiceNow queue [here.](https://fancy.nwie.net/DatabaseRequest)

## **Need A Feature?**

Please submit a feature request [here](https://github.nwie.net/Nationwide/AWS-DataStores/issues/new) to RDS support enabled on your instance.



