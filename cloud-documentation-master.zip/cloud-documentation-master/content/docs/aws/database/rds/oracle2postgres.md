---
title: Oracle to PostgreSQL Migration
menu: docs
category: aws
---

## ORACLE TO POSTGRES MIGRATION

### CREATE A NEW RDS INSTANCE OF POSTGRESQL
Click on Services and click on RDS Instance
 - Click on Instances (on the left menu)
 - Click on Launch DB Instance
 - Select Engine => PostgreSQL (or Amazon Aurora with PostgreSQL compatible)
 - Click on Select
 - Click on Dev/Test for DEVO or Production for PROD
 - Click on Next Step

Instance Specifications:
 - DB Engine Version:  PostgreSQL
 - DB Instance Class:
   - DEVO = db.t2.large
   - PROD Small = db.r4.4xlarge
   - PROD Mid = db.r4.8xlarge
   - PROD Large = db.r4.16xlarge
 - Multi-AZ Deployment: No for DEVO and temporarily No for PROD (we should only set up after the bulk load for PROD)
 - Storage Type: General Purpose (SSD)
 - Allocate Storage:
   - For DEVO, choose a size that is 3x your current DEVO DB size including temp area but with a minimum of 100GB. This can be changed in the future as necessary.
   - For PROD, choose a size that is 4x your current Objects size including temp area.
    **Use your judgement for PROD sizes!!!**

Settings:
 - DB Instance Identifier: `<dbname>`
 - Master Username: `<dba user>`
 - Master Password: (lowercase)
 - Confirm Password: (lowercase)
 - Click on Next Step

Network & Security:
 - VPC: Default VPC
 - Subnet Group: default
 - Publicly Accessible: Yes
 - Availability Zone: Choose the zone accordingly.
 - VPC Security Group: Choose your (VPC) AND default (VPC)

Database Options:
 - Database Name: `<dbname>`
 - Database Port: 5432
 - DB Parameter Group: choose the one created for your database
 - Copy Tags to Snapshots: Check this box
 - Enable Encryption: Yes
 - Master Key: (default) aws/rds

Backup:
 - Backup Retention Period: 7 days for DEVO / 30 days for PROD
 - Backup Window: Select Window
 - Start Time:
   - 03:00 UTC for DEVO
   - 08:00 UTC for PROD NA
   - 01:00 UTC for PROD EU
   - 16:00 UTC for PROD FE
   - 17:00 UTC for PROD CN
 - Duration: 0.5 hours for DEVO and PROD

Monitoring:
 - Enable Enhanced Monitoring:
   - No for DEVO
   - Yes for PROD

Maintenance:
 - Auto Minor Version Upgrade: Yes for DEVO / No for PROD (this will trigger a bounce when necessary)
 - Maintenance Window: Select Window
 - Start Day: Sunday
 - Start Time:
   - DEVO - 07:00 UTC
   - PROD NA - 09:00 UTC
   - PROD EU - 02:00 UTC
   - PROD FE - 17:00 UTC
   - PROD CN - 18:00 UTC
 - Duration: 0.5 hours for DEVO and PROD
 - Click on Launch DB Instance

Wait for your new RDS PostgreSQL instance to be fully launched!

## CONNECT TO THE NEW POSTGRESQL DATABASE
Try to connect to your RDS instance (postgres should be installed on your local box/please go to the bin folder to run the below command)

`psql --host=<db host name> --port=5432 --user=<username> --dbname=<databasename>`

You got inside the instance! You can use the following command to list the databases inside your instance

`\l+`

(there are 4 databases that always get created besides your database)

You should see something like:
List of databases

|   Name    |  Owner   | Encoding |   Collate   |    Ctype    |   Access privileges |
|:----|:----|:----|:----|:----|:----|
| `<yourdb>`  | `<dba user>` | UTF8     | en_US.UTF-8 | en_US.UTF-8 |
| postgres  | `<dba user>` | UTF8     | en_US.UTF-8 | en_US.UTF-8 |
| rdsadmin  | rdsadmin | UTF8     | en_US.UTF-8 | en_US.UTF-8 | `rdsadmin=CTc/rdsadmin` |
| template0 | rdsadmin | UTF8     | en_US.UTF-8 | en_US.UTF-8 | `=c/rdsadmin` |
| |          |          |             |             | `rdsadmin=CTc/rdsadmin` |
| template1 | `<dba user>` | UTF8     | en_US.UTF-8 | en_US.UTF-8 | `=c/<dba user>` |
|  |          |          |             |             | `<dba user>=CTc/<dba user>` |

(5 rows)

## CREATE LOCK MONITOR VIEW
```
CREATE VIEW lock_monitor AS(
SELECT
  COALESCE(blockingl.relation::regclass::text,blockingl.locktype) as locked_item,
  now() - blockeda.query_start AS waiting_duration, blockeda.pid AS blocked_pid,
  blockeda.query as blocked_query, blockedl.mode as blocked_mode,
  blockinga.pid AS blocking_pid, blockinga.query as blocking_query,
  blockingl.mode as blocking_mode
FROM pg_catalog.pg_locks blockedl
JOIN pg_stat_activity blockeda ON blockedl.pid = blockeda.pid
JOIN pg_catalog.pg_locks blockingl ON(
  ( (blockingl.transactionid=blockedl.transactionid) OR
  (blockingl.relation=blockedl.relation AND blockingl.locktype=blockedl.locktype)
  ) AND blockedl.pid != blockingl.pid)
JOIN pg_stat_activity blockinga ON blockingl.pid = blockinga.pid
  AND blockinga.datid = blockeda.datid
WHERE NOT blockedl.granted
AND blockinga.datname = current_database()
);

SELECT * from lock_monitor;
```
## RUN SCHEMA CONVERSION TOOL
### PREREQUISITES FOR THE SCT (SCHEMA CONVERSION TOOL)
1.	Download and install tool- http://docs.aws.amazon.com/SchemaConversionTool/latest/userguide/CHAP_SchemaConversionTool.Installing.html
2.	Download the Oracle and Postgres database drivers
    1.	AWS SCT Jar Files
    2.	Download the correct drivers for PostgreSQL and Oracle.
    3.	Under the Settings Tab, select Global Settings and then go to the Drivers page to fill in the path to the downloaded drivers.
3.	Under the File tab, select New Project.
4.	Select Oracle to Amazon RDS for Postgres.
5.	Connect to Oracle, use the TNS Alias Settings.
6.	Connect to Postgres, either RDS instance or a local version of Postgres
7.	Under the Settings tab, select Project Settings and go to the SQL Scripting tab. Change the Target SQL Script to Multiple Files.

### USE SCT(SCHEMA CONVERSION TOOL) TO CREATE THE ORACLE TO POSTGRES SCHEMA

1.	Using either the Actions tab, or by right clicking on the Oracle schema, choose "Create Report". This can be saved as a PDF
    1.	The Summary tab will show the color-coded bar graph of which objects are easily converted and which will require more work.
    2.	The Action Items tab will show each individual problem, i.e. Unsupported Data types, PostgreSQL does not support Materialized Views.
2.	To begin converting the schema, use either the Actions tab or right click on the schema and choose "Convert Schema". These changes are just made locally in the project.
    1.	To start over, right click on a Postgres object and select Refresh from Database. To save the changes to the Postgres database right click and select Save to Database.
    2.	If the target database is not Amazon RDS and the oracle extensions in the schema AWS_ORACLE_EXT are needed, right click on the target database tree and select Apply Extension Pack.
3.	To save the SQL files use the Actions tabs or right click on the schema on the Postgres side and select "Save as SQL"
4.	Ensure that there are separated SQL files for each type of database object. The files have to be run in following order:
    1.	Scripts that can be run before the DMS task
        1.	create_database.sql
        2.	create_sequence.sql
        3.	create_table.sql
        4.	create_view.sql
    2.	Scripts that cannot run before the DMS task
        1.	create_index.sql
        2.	create_constraint.sql
        3.	create_forgein_key_constraint.sql
        4.	create_tunction.sql
5.	Edit these files locally and run them on the Postgres database through psql. To create objects on Postgres using SCT, right click on the object and select "Apply to Database".
6.	To edit the mapping rules (example: lowercase table names) go to the Settings tab and select "Mapping Rules"
    1.	Select Export script for DMS to save this to be used for the DMS task.

### MODIFY- DATA TYPES

| VARCHAR2 | VARCHAR |
|:----|:----|
| CHAR | CHAR(1) or VARCHAR(x) |
| NUMBER | NUMERIC or BIGINT for scale=0 |
| DATE | TIMESTAMP(0) WITH TIME ZONE |
| TIMESTAMP(n) | TIMESTAMP(n) WITH TIME ZONE |
| TIMESTAMP(n) | WITH TIME ZONE	TIMESTAMP(n) WITH TIME ZONE |
| CLOB, NCLOB | TEXT |
| BLOB | BYTEA |
| XMLTYPE | XML |
| UROWID | OID |

1.	Char(1), if this is used as a Boolean flag, use the PostgreSQL Boolean type when possible
2.	When possible for Timestamp use Timestamp (time stamp without time zone) in PostgreSQL.
3.	Date in Oracle will include a time portion so for these, use either Timestamp or Date if the business logic just requires the date part
4.	Number(5,0) can be Integer and Number(10,0) can be Bigint, Integer and Bigint will perform better in PostgreSQL
5.	Number(n,2) should be changed to Numeric(n,2) in PostgreSQL. Ideal for currency fields since the money type can cause problems because of formatting and floating point or double can cause rounding issues.
6.	For CLOB and Long the Text data type can be used in PostgreSQL, this can store up to 1GB of data.

## DATABASE MIGRATION SERVICES
### CONFIGURE THE POSTGRESQL DATABASE
Run the schema, sequence, and table create scripts on the Target RDS instance. This will create the `<schema name>` database, the sequences, and all of the tables. Do not create Indexes, Functions or Triggers yet.

### SET UP DMS HOST
 - Go to Console Access
 - Make sure you are on the correct AWS region
 - Click on Services
 - Click on DMS under Migration
 - Click on Replication Instances on the left menu
 - Click on Create replication instance
 - Name: `replication-instance-<destinationDBname>`    Example: replication-instance-dbanme
 - Description: `Replication instance for <destinationDBname>`    Example: Replication instance for dbname
 - Instance Class: Choose dms.c4.large for DEVO
 - VPC: Choose the one for your service
 - Multi-AZ: No for DEVO
 - Click on Advanced to expand the options
 - Allocated storage (GB): 50 for DEVO   (you are only capturing the delta here)
 - Replication Subnet Group: Leave the default
 - Availability zone: Choose the one (a/b/c) corresponding to your EC2/RDS setup
 - VPC Security Group(s): select default on the bottom of the list
 - KMS master key:(Default) aws/dms
 - Click on Create replication instance

### SET UP A SOURCE ENDPOINT FOR DMS HOST
Now you need to set up a source endpoint for the DMS host.

Click on Services/DMS
 - Click on Endpoints
 - Click on Create endpoint
 - Endpoint type: Source
 - Endpoint identifier: `endpoint-source-<sourceDBname>-<targetClass>`
 -  Source engine: oracle
 - Server name: paste your EC2 Private DNS here
 - Port: `<port number>`
 - SSL mode: none
 - User name: `<dba user>`
 - Password: `<<dba user> password>`
 - SID: `<your source DB>`
 - (no need to expand Advanced section)
 - VPC: the VPC for your service
 - Replication instance: the one you created
 - Refresh schemas after successful connection test: Leave checked
 - Click on Run test
 - If the above test is successful, click on Create endpoint

Go back to Replication instances, find yours and copy the Public IP address to the XLS file.
Log out from the interim account.

### SET UP A DESTINATION ENDPOINT FOR DMS HOST
Now you need to setup a destination endpoint for the DMS host.
 - Click on Console Access
 - Make sure you are on the correct AWS region
 - Click on Services/DMS
 - Click on Endpoints
 - Click on Create endpoint
 - Endpoint type: Target
 - Endpoint identifier: `endpoint-target-<destinationDBname>`   Example: endpoint-target-tbars1na
 - Source engine: postgres
 - Server name: `<paste your RDS Endpoint here>`
 - Port: 5432
 - SSL mode: require
 - User name: `<dba user>`
 - Password: `<<dba user> password>`
 - Database name: `<your postgres DB>`
 - (no need to expand Advanced section)
 - VPC: the VPC for your service
 - Replication instance: the one you created
 - Refresh schemas after successful connection test: Leave checked
 - Click on Run test
 - If the above test is successful, click on Save

### SET UP A DMS REPLICATION TASK

Create new task:
 - Click on Services/DMS
 - Click on Tasks
 - Click on Create task
 - Task Name: `<destinationDBname>-bulkload-ongoing-replication`
 -  Replication instance: Select yours
 - Source endpoint: Select yours
 - Target endpoint: Select yours
 - Migration type: Migrate existing data and replicate ongoing changes
 - Start task on create: Uncheck the box

Task settings:
 - Target table preparation mode: Do nothing
 - Stop task after full load completes: Stop Before Applying Cached Changes
 - Include LOB columns in replication: Limited LOB mode  or Full LOB mode Depending on your queries in the evaluation of the oracle database
 - LOB chunk size (Kb): 32 (Limited) or 64 (Full)
 - Enable logging: Check the box
 - Click on Advanced Settings
 - Under Control Table Settings, check all 4 boxes for the 4 Control Tables

Table mappings (repeat the following as many times as necessary to include all the selection rules you need):
 - Schema name is: `<SCHEMA NAME>`
 - Table name is like: Depends on each case or % for all tables
 -  Action: Include
 - Click on Add selection rule

Add transformation rule for schema:
 - Click below on add transformation rule
 - Target: Schema
 - Schema name is: `<SCHEMA NAME>`
 - Action: Make lowercase
 - Click on Add transformation rule

Add transformation rule for tables:
 - Click below on add transformation rule
 - Target: Table
 - Schema name is: `<SCHEMA NAME>`
 - Table name is like: %
 - Action: Make lowercase
 - Click on Add transformation rule

Add transformation rule for columns:
 - Click below on add transformation rule
 - Target: Column
 - Schema name is: `<SCHEMA NAME>`
 - Table name is like: %
 - Column name is like: %
 - Action: Make lowercase
 - Click on Add transformation rule
 - Click on Create task

### START THE DMS TASK WITH FULL LOAD
All the tables should be migrated without any errors. Start the DMS job selecting the 1st option on the resume popup.
Do an alter system switch logfile; on the primary database if the replication task seems to be hanging.

## MONITORING THE TASK
Choose Enable Logging during the set up to be able to monitor the task in progress under the Task Monitoring tab.
Multiple things can break. Keep a close eye.
On RDS:
```
reset role;
select * from public.awsdms_apply_exceptions;
select * from public.awsdms_status;
select * from public.awsdms_suspended_tables;
select * from public.awsdms_history;
```

Once the migration is 100% completed, stop(paused) the ongoing migration job.

### CDC MONITORING
For now we are creating two alarms, one for CDC latency on the source and the other CDC latency on the target. The threshold for both of these was set to 1,300 for 3 datapoints over 15 minutes.
Trouble Shooting: https://docs.aws.amazon.com/dms/latest/sbs/CHAP_Oracle2PostgreSQL.Troubleshooting.html

### AFTER BULK LOAD FINISHES
1.	Vacuum the postgres Database here
2.	Restart your DMS task as well to apply cached CDC changes ==> Start/Resume ==> Start
    1.	Restart the DMS task by selecting Start(Resume), DMS will keep the PostgreSQL database up to date until the latency is equal to, or close to, zero when the target has completely caught up to the source.

## KNOWN ISSUES – DMS
### LARGE TABLES NOT MIGRATING
If you have a task that's taking longer than any other ones you've seen, especially towards the end of the migration. Sometime you can be sitting there and watching as the number of migrated rows increases by only 1,000 every minute.

**SOLUTION**

Task setting: CommitRate: 50000
Replication Instance Setting: maxFileSize=1048576

### DMS TASK FAILING TO START OR STOP
During our cutovers there are cases where you need the DMS task to stop ASAP and to make sure it has moved over all of the data. In one case it took almost an hour for the DMS task to move from the "Stopping" to "Stopped" state. There are also situations where you want to stop the task, start it again, wait for the last changes to be carried over, and then completely stop the task. Waiting on a DMS task to start or stop can add unexpected time to the cutover steps.

**SOLUTION**

Alter system switch logfile;
Run this on the Oracle host to trigger the DMS task to start or stop.

### TASK FAILING FOR VALIDATION- DECIMAL PRECISION
If you have a number like 0.000000009996574 on the Oracle side, and it is being migrated to the number 0.00000001 on the PostgreSQL side, then the task will fail that table for data validation. This will be a problem for financial or other precise data types where this precision is very important for data integrity.

**SOLUTION**

Endpoint setting: numberDataTypeScale=-1

This will prevent any limit from being applied to the number of decimal points of the data one the PostgreSQL side. By default the endpoint will not have this setting so if you notice a data validation failure in this case then you will have to add this setting to you endpoint.


## DATA VALIDATION AND FUNCTIONAL TESTING
### SOME QUERIES FOR COMPARING COUNTS
1.	Check that there are the same number of table:
    ```
    SELECT COUNT(*) FROM information_schema.tables WHERE table_schema='<schema name>';
    SELECT COUNT(*) FROM user_tables WHERE tablespace_name = '<SCHEMA NAME>';
    ```
2.	Check that every table has the same number of rows. To create the scripts:
    ```
    SELECT 'COUNT(*) FROM '||table_name||';'
    FROM information_schema.tables WHERE table_schema='<schema name>';
    Select ‘count(*) from ‘||table_name||';'
    FROM user_tables WHERE tablespace_name='<SCHEMA NAME>';
    ```
3.	Check that indexes exist on the same table and columns
    ```
    SELECT t.relname as table_name, i.relname as index_name, array_to_string(array_agg(a.attname), ', ') as column_names
    FROM pg_class t, pg_class i, pg_index ix, pg_attribute a
    WHERE t.oid = ix.indrelid and i.oid = ix.indexrelid and a.attrelid = t.oid
    and a.attnum = ANY(ix.indkey) and t.relkind = 'r'
    GROUP BY 1, 2 ORDER BY 1, 2
    ```
- Need to check this:
    ```
    SELECT table_name, index_name, column_name
    FROM dba_ind_columns
    WHERE table_owner='XXXX'
    ORDER BY 1,2
    ```

4.	Check that all of the foreign keys got created successfully
```
select tc.constraint_name,
(SELECT data_type FROM information_schema.columns WHERE column_name=kcu.column_name AND table_name=tc.table_name),
(SELECT data_type FROM information_schema.columns WHERE column_name=ccu.column_name AND table_name=ccu.table_name)
from information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE constraint_type = 'FOREIGN KEY'
AND ccu.table_schema='<schema name>';
PERFORM DATA VALIDATION
```

### ROW COUNT ON ORACLE
```
set serveroutput on feedback off pages 0
DECLARE
val NUMBER;
BEGIN
FOR I IN (SELECT OWNER,TABLE_NAME FROM DBA_TABLES where OWNER='<SCHEMA NAME>' order by 2) LOOP
EXECUTE IMMEDIATE 'SELECT count(*) FROM ' || i.owner || '.' || i.table_name INTO val;
DBMS_OUTPUT.PUT_LINE(i.owner || '.' || i.table_name || '==>' || val );
END LOOP;
END;
/
```
### ROW COUNT ON POSTGRESQL
```
\pset tuples_only
\pset pager off

select upper(table_schema)|| '.' || upper(table_name) || '==>' ||
       (xpath('/row/cnt/text()', xml_count))[1]::text::int as row_count
from (
  select table_name, table_schema,
         query_to_xml(format('select count(*) as cnt from %I.%I', table_schema, table_name), false, true, '') as xml_count
  from information_schema.tables
  where table_schema = '<schema name>'
) t
order by upper(table_name) collate "C";
```
### REVIEW REPLICATION ERRORS AND EXCEPTIONS

`select * from public.awsdms_apply_exceptions;`

 - to see CDC related stats
`select * from public.awsdms_history where timeslot > now() - interval '1 hours';`

 - to see DMS task status
`select * from public.awsdms_status;`

 - to check any suspended tables
`select * from public.awsdms_suspended_tables;`

## CUTOVER STEPS
### CHANGE OWNERSHIP OF ALL OBJECTS TO <SCHEMA NAME>
```
\pset tuples_only
\pset footer off
\o change_owner.sql
SELECT 'ALTER TABLE '|| schemaname || '.' || tablename ||' OWNER TO <schema name>;'
FROM pg_tables WHERE schemaname ='<schema name>'
ORDER BY schemaname, tablename;

SELECT 'ALTER SEQUENCE '|| sequence_schema || '.' || sequence_name ||' OWNER TO <schema name>;'
FROM information_schema.sequences WHERE sequence_schema ='<schema name>'
ORDER BY sequence_schema, sequence_name;

SELECT 'ALTER VIEW '|| table_schema || '.' || table_name ||' OWNER TO <schema name>;'
FROM information_schema.views WHERE table_schema ='<schema name>'
ORDER BY table_schema, table_name;

\o


\i change_owner.sql
```
- Verify that everything has been changed to `<schema name>` as the owner, the output of the following sql should be zero rows
```
SELECT
    n.nspname AS schema_name,
    c.relname AS rel_name,
    c.relkind AS rel_kind,
    pg_get_userbyid(c.relowner) AS owner_name
  FROM pg_class c
  JOIN pg_namespace n ON n.oid = c.relnamespace
  where n.nspname='<schema name>' and  pg_get_userbyid(c.relowner)='<dba user>'
UNION ALL
```
- functions (or procedures)
```
SELECT
    n.nspname AS schema_name,
    p.proname,
    'p',
    pg_get_userbyid(p.proowner)
  FROM pg_proc p
  JOIN pg_namespace n ON n.oid = p.pronamespace
  where n.nspname='<schema name>' and pg_get_userbyid(p.proowner)='<dba user>';
```
### INCREMENT SEQUENCES
Set the high water (10% more than Oracle) mark for Sequences. Run the following code in Source Oracle database and execute the output in PostgreSQL:
```
select 'alter sequence <schema name>.'|| sequence_name ||' restart with ' || to_char( last_number + round(last_number*10/100)) ||';' from
dba_sequences where sequence_owner='<SCHEMA NAME>';
```
### MAKE SURE NOT NULL BLOBS AND CLOBS IN ORACLE ARE ALSO NOT NULL IN POSTGRESQL
After DMS, run the following SQL to see if there are any CLOB or BLOB columns in Oracle that are NOT NULL. If there are, alter the tables in PostgreSQL to make sure the same columns are NOT NULL.
```
select TABLE_NAME, COLUMN_NAME, DATA_TYPE, NULLABLE from dba_tab_columns where DATA_TYPE in ('CLOB','BLOB') and NULLABLE = 'N' and
table_name in (select table_name from audacx.rds_migration_staging where schema_name='AUDACX' and migrate_table='YES') order by 1,2;
```
### ALL CUTOVER STEPS
1.	Stop all Oracle Dependencies, including client connections and running scripts
    1.	This SQL statement should return nothing: `SELECT MACHINE, COUNT FROM V$SESSION GROUP BY MACHINE;`
    2.	Let the AWS DMS task apply the final changes from the Oracle database on the PostgreSQL database: `ALTER SYSTEM CHECKPOINT;`
2.	List any sessions: `SELECT SID, SERIAL#, STATUS FROM V$SESSION;` and kill them: `ALTER SYSTEM KILL 'sid, serial_number' IMMEDIATE;`
3.	Shut down listeners on the Oracle Database
4.	Stop the DMS task and confirm that it has ended.
5.	Here you can set up a Rollback if needed.
6.	Enable Triggers on PostgreSQL.

## GENERATING THE CUTOVER STEP-BY-STEP
The following call will prepare a very detailed script with all the steps necessary for both Oracle and RDS, including:
1.	(Oracle) Verify if there is any status 3 (ERROR) rows during data validation
2.	(Oracle) Check existing session count per machine for the module(s) being migrated
3.	(Dev) Stop the application
4.	(Oracle) Block the module(s) being migrated
5.	(Oracle) Make the tables read only
6.	(Oracle) Table/row counts / Max of last_updated_date
7.	(DMS) Finalize DMS migration
8.	(RDS) Table/row counts / Max of last_updated_date
9.	(RDS) Collect stats
10.	(Oracle/RDS) Compare index counts
11.	(RDS) Add NON NULL constraints to CLOB/BLOB columns
12.	(Oracle/RDS) Compare constraint counts
13.	(Oracle/RDS) Check constraint status
14.	(RDS) Enable triggers
15.	(Oracle/RDS) Compare trigger counts
16.	(Oracle/RDS) Check trigger status
17.	(RDS) Add default values
18.	(Oracle/RDS) Compare default counts
19.	(RDS) Add sequences
20.	(Oracle/RDS) Compare sequence counts
21.	(Oracle/RDS) Compare table/row counts and max(last_updated_date)
22.	(Runbook) Resume runbook activities

## MIGRATION CHECKLIST
### DURING DMS CHECKLIST (WEEK BEFORE)

| 1	Schema Validation |
|:----|
| 2	Bulk Load data Validation |
| 3	(Create EC2 Instance for Trigger Cron)—if needed |
| 4	Change to Multi AZ |
| 5	Prepare scripts for: Foreign Key , increase sequence, and any triggers |
| 6	Vacuum PostgreSQL DB |
| 7	Create Primary/Secondary Indexes |
| 8	Enable Monitoring at sev 3 |

### PRE CUT OVER CHECK (DAY OF/DAY BEFORE)

| 1	Review for any replication errors |
|:----|
| 2	Increase work memory |
| 3	(Unit test with long running queries) |

### CUT OVER CHECKLIST (DURING DOWN TIME)

| 	**Stop Oracle Side** |
|:----|
| 1	Stop all Oracle Dependencies |
| 2	Shut down listeners on the Oracle DB |
| 3	Stop DMS |
| 	**PostgreSQL Cut Over Steps** |
| 4	Validate Data count(*) and (Random/Recent)  |
| 5	Increment Sequences |
| 6	Alter columns to bigint |
| 7	Change ownership of all object to `<schema name>` |
| 8	Create all indexes and foreign keys on Postgres |
| 9	Create Triggers on PostgreSQL (audit and partition) |
| 10	Re-grant all Permissions (sequences) |
| 11	Schema Validation |
| 12	Drop UCI columns – if any |
| 13	vacuum analyze (or vacuum full) |
| 14	Take a snapshot |
| 15	Decrease Work mem |
| 	**Open PostgreSQL** |
| 16	Update JIRA with all connection information |
| 17	Verify the sessions are connecting |
| 18	Verify if sessions are waiting |
| 19	Verify blockers and waiters |

### POST CUT OVER CHECKLIST (DAY OF/DAY AFTER)

| 1	Copy validation logs to Drive |
|:----|
| 2	Copy DMS logs to Drive |
| 3	Add txt file to Drive with Snapshot name |

### LATER CHANGES CHECKLIST



| 1	Change DMS migration password on oracle |
|:----|
| 2	Change `<dba user>` password |
| 3	Delete DMS Endpoints |
| 4	Delete DMS Replication Task |
| 5	Delete DMS Replication Instance |
| 6	Modify Alert Thresholds as needed |
| 7	Modify PG Parameters as needed |


Below is the list of articles that discuss managing a database on RDS:

https://aws.amazon.com/premiumsupport/knowledge-center/rds-common-dba-tasks/
https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Appendix.PostgreSQL.CommonDBATasks.html
https://aws.amazon.com/blogs/database/part-1-role-of-the-dba-when-moving-to-amazon-rds-responsibilities/
https://aws.amazon.com/blogs/database/managing-postgresql-users-and-roles/
