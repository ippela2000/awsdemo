---
category: aws
draft: false
title: "Oracle on EC2"
menu: docs
---

## **Oracle EC2 Supported Products**

- Oracle 19C version 19.7
  - Service catalog product: DatabaseServices-EC2-Oracle19c
  - Product owner: Don Burns, burnsd23, DDS Oracle Product Manager
  - non-prod environments take approximately 45 minutes to deploy
  - Prod/DR environments take approximately 1 hour 10 minutes to deploy
    - When you select PROD for the DB environment a DR host with a standby database is automatically created in another AZ
    - **NOTE:** Due to an AWS hard limit of 1 hour for cross account deployments, the Service Catalog product will complete before the standby is finished.  The requester and resource owner will receive an email once both production and dr deploys are complete.
  - **UPDATES 7/20/2020**
    - You can now provision SCHEMA and Application IDs when requesting a 19C database
      - details under Ordering An Oracle EC2 Product via Service Catalog
    - Liquibase setup is now part of provisioning
- Oracle 19C Multitenant Database for Dev/Test (MVP)
  - Service Catalog Product: DDS-ORACLE19c-PDB-ADD
  - All 19c databases have multitenant capability, however currently this functionality is limited to Dev and Test
  - You must first order a standard 19C database using the DatabaseServices-EC2-Oracle19c
    - This product provision what Oracle calls a Container Database, CDB, and what Oracle refers to as a Pluggable Database, PDB.  The PDB is where the application tables and data live.
    - **NOTE:** If you plan to use the CDB you are provisioning for additional PDBs, please take that into account when ordering storage. If you are going to have 8 PDBs and expect them to be 20G each please order at least 200G.
  - **Benefits of using 19C Multitenant**
    - Allows for adding a new database to an existing host under the current container database
      - Instead of provisioning multiple EC2 instance one for each database you can now provision multiple databases on an existing EC2 instance.
      - For example if you have 8 test databases using 8 t3.large EC2 instance you can now have a single r.2xlarge and provision all 8 databases.
      - this reduces cost of ownership for databases, and requires less storage as you only need a single deployment of the Oracle binaries.
    - Provisioning of a database within an existing container database takes approximately 5 minutes
  - Details on ordering a database for an existing host are below
  - **UPDATES 7/20/2020**
    - You can now provision SCHEMA and Application IDs when requesting a 19C Multitenant Database
      - details under Ordering An Oracle EC2 Product via Service Catalog
    - Liquibase setup is now part of provisioning
- Oracle 12C version 12.1
  - Oracle 12C is in retirement and needs a TSB exception in order to provision
  - The product is no longer available in Service catalog
  - If you have an exception, please open a Service Now request to [Distributed Database Service](https://fancy.nwie.net/DatabaseRequest)
  - **UPDATES 7/20/2020**
    - You can now provision SCHEMA and Application IDs when requesting a 12.1 database
      - details under Ordering An Oracle EC2 Product via Service Catalog
    - Liquibase setup is now part of provisioning

## **Ordering An Oracle EC2 Product via Service Catalog**

- Log into your BSA tools account using the CODEPIPELINE role and go to the AWS Service Catalog service
  - Search for oracle19c in the Product list and click on the link
  - Follow the service catalog process once you have selected the product
    - Product List: There is only one product, on this page just click launch product
    - Product Version:
      - Name* Field:  Fill in a unique name for the product you are provisioning.  This name will be how you can find the product you have provisioned within Service catalog, and is extremely important to have when/if you need to decommission the product in the future.
      - Version:  There is only one version which should already be selected.
      - Click Next
    - Launch Product
      - Parameters:  Fill out all parameters, once done you can click NEXT
        - **Parameter input help**
        EC2 Instance Setup:
        - <ins>Requester:</ins> This is who is filling out the product request form.  Will be emailed on completion and if there is an error. Valid nwie email address.  EX: shortname@natiownide.com
        - <ins>Business Unit Name:</ins> select your business unit from the drop-down list.
        - <ins>Environment:</ins> Select the AWS environment you where want the database deployed.
        - <ins>Resource Owner:</ins> enter in a valid NWIE email address.  EX: shortname@natiownide.com
        - <ins>Disbursement Code:</ins> enter in your valid nine digit disbursement code.
        - <ins>Resource Name:</ins> Name for resource being provisioned, something meaningful that describes the product
        - <ins>ARPM ID:</ins> enter in your valid four digit APRM ID code.
        - <ins>Data Classification:</ins> select a data classification from the drop-down list. (Select Sensitive if it has PII, PCI, etc)
        - <ins>Power on Instance at:</ins> select the UTC time from the drop-down list. NOTE: This UTC Time
        - <ins>Shut down Instance at:</ins> select the UTC time from the drop-down list. NOTE: This UTC Time
        - <ins>Patch::</ins> This should always be set to true for database instances
        Oracle Database Setup:
        - <ins>EC2 Instance type:</ins> select the Instance machine type from the drop-down list.
        - <ins>Storage Type:</ins> gp2 standard, io1 iop provisioned if needed
        - <ins>Data Disk Group GiB/Disk:</ins> The disk group is comprised of two disks.  So if you select 100G you will get two 100G disks or 200G total storage for the Data Disk Group
        - <ins>Provisioned Iops:</ins> Only used for i01 storage.  The theoretical max is 50 times GB, However instance types have limitations per volume and also at the instance level, so be sure to understand what those are for the instance you provisioned.
        - <ins>Flash Disk Group GiB/Disk:</ins> The disk group is comprised of two disks.  So if you select 25G you will get two 25G disks or 50G total storage for the Flash Disk Group
        - <ins>Provisioned Iops:</ins> Only used for i01 storage.  The theoretical max is 50 times GB, However instance types have limitations per volume and also at the instance level, so be sure to understand what those are for the insta
nce you provisioned.
        - <ins>Primary Database Name:</ins> Enter your Database Name - 3-5 small case alpha (basename) followed by 0-2 digits (iteration). i.e.  sales01.  Usage suffix will be appended automatically based on environment (p for Prod, t for Test, d for Dev, etc). If you provision Prod, a DR database will be created.  This is a standard Data Guard configuration for DR.
        - <ins>Character Set:</ins> select value from the drop-down list.  If you require a character set that is not available in the drop-down list please work with DDS on your specific needs.
        - <ins>Day of week for backup:</ins> What day for the backup to run - 0=Sunday, 1=Monday, etc
        - <ins>UTC Hour for backup to start:</ins> UTC hour for backup to start
        - <ins>Minute for backup to start:</ins> Minute in 5 min increments for backup to start
        - <ins>Database usage environment:</ins> select value from the drop-down list.
        - <ins>DR Provisioned::</ins> Default true.  Only relevant when provisioning production.  If your application is not critical, and you do not want to procivision a DR with production this can be set to false. 
        Optional Schema IDs, Application IDs, and CNAME (host name alias)
        - <ins>Schema IDs:</ins> Comma separated list of schema IDs
          - Schema IDs must be owned by DDS - this will be validated and the IDS will not be provisioned if they are not owned by DDS
          - Schema IDs are granted the dataowner role, and are set up for liquibase access
          - The primary and secondary owner of the ID will be notified it was provisioned, and if they did not approve its use for this database they can have it removed.
        - <ins>App IDs:</ins> Comma separated list of application IDs
          - Application IDs are owned by the BSA application area
          - They are provisioned as local IDs, and the id/password information is stored in Secrets Manger in the BSA account
            - In order to access the Secret a team name needs to be provided.  Only memebers of this team can access the secret
            - The format of the secret name is: ID-DATABASE-ACCOUNT-UUID
          - Application IDs are given the enduser role.
          - Access to the schema for application IDs is done via role which can be built using liquibase
          - The primary and secondary owner of the ID will be notified it was provisioned, and if they did not approve its use for this database they can have it removed.
        - <ins>Federated Team Name:</ins> The name portion of your federated team role (the first part before the hyphen)
          - More information on getting a Federated team role can be found [here](https://gocloud.nwie.net/docs/aws/getting-started-with-aws/howto_federatedappteamroles/)
        - <ins>CNAME Host Alias:</ins> CNAME record that will get created in aws.e1.nwie.net, can be used for host to connect to the database.
        - <ins>CNAME Host Alias for DR Host:</ins> CNAME record that will get created in aws.e1.nwie.net, can be used for host to connect to the database. Only provisioned if PROD provisioned
        Other Parameters:  Do not modify any parameters in this section.
    - TagOptions:  All required tags are already included, you do not need to add any on this page you can click NEXT
    - Notifications: Nothing needs to be done on this page, you can click NEXT
    - Review:
      - Review the parameters you entered.  If something looks incorrect you can hit the PREVIOUS button and go back and fix it
      - If everything looks good, click LAUNCH
    - fill out the rest of the form with the specifics for your database.
  - This will take you to a page that will have a link to cloudformation.  You can click the link if you wish, this will show a cross account deploy being done to the account and environment you selected.
  - After a successful build, the builder (Resource Owner) will receive an email indicating the build is complete along with all necessary details on how they can move forward with utilizing the new database.
    - If you do not receive an email within the time frames listed in the product description above please file an issue [here](https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/new/choose) and provide as much detail as possible.
  - If a build fails, for whatever reason an email will be sent to the resource owner, please file and issue as above.

## **Ordering a 19c Multitenant Database on an existing host via Serive Catalog**
- Log into your BSA tools account using the CODEPIPELINE role and go to the AWS Service Catalog service
  - Search for oracle19c in the Product list and click on the link
  - Follow the service catalog process once you have selected the product
    - Product List: There is only one product, on this page just click launch product
    - Product Version:
      - Name* Field:  Fill in a unique name for the product you are provisioning.  This name will be how you can find the product you have provisioned within Service catalog, and is extremely important to have when/if you need to decommission the product in the future.
      - Version:  There is only one version which should already be selected.
      - Click Next
    - Launch Product
      - Parameters:  Fill out all parameters, once done you can click NEXT
        - **Parameter input help**
        EC2 Instance Setup:
        - <ins>Business Unit Name:</ins> select your business unit from the drop-down list.
        - <ins>Environment:</ins> Select the AWS environment you where want the database deployed.
        - <ins>Application ID:</ins> This is the APRM ID for the application using the database.
        - <ins>Resource Owner:</ins> enter in a valid NWIE email address.  EX: shortname@natiownide.com
        - <ins>Requester:</ins> This is who is filling out the product request form.  Will be emailed on completion and if there is an error. Valid nwie email address.  EX: shortname@natiownide.com
        Pluggable Database Information:
        - <ins>Existing Database Host to Deploy PDB</ins> This is the host your current database resides on.  Do not include domain as part of the host name.
        - <ins>Name of Oracle Database</ins> Pluggable Database Name: 3-5 small case alpha (basename) followed by 0-2 digits (iteration). i.e.  sales01.  Usage suffix will be appended automatically based on environment (t for Test, d for Dev, etc).
        - <ins>Database usage environment:</ins> select value from the drop-down list.
        - <ins>Initial storage allocated to Database in GB</ins> Amount of storage needed for PDB.  NOTE: Thier must be sufficient storage in the CDB otherwise this will error.  If you need to increase CDB storage please request that [here](https://fancy.nwie.net/DatabaseRequest).
        - <ins>Character Set:</ins> select value from the drop-down list.
        Optional Schema IDs and Application IDs
        - <ins>Schema IDs:</ins> Comma separated list of schema IDs
          - Schema IDs must be owned by DDS - this will be validated and the IDS will not be provisioned if they are not owned by DDS
          - Schema IDs are granted the dataowner role, and are set up for liquibase access
          - The primary and secondary owner of the ID will be notified it was provisioned, and if they did not approve its use for this database they can have it removed.
        - <ins>App IDs:</ins> Comma separated list of application IDs
          - Application IDs are owned by the BSA application area
          - They are provisioned as local IDs, and the id/password information is stored in Secrets Manger in the BSA account
            - In order to access the Secret a team name needs to be provided.  Only memebers of this team can access the secret
            - The format of the secret name is: ID-DATABASE-ACCOUNT-UUID
          - Application IDs are given the enduser role.
          - Access to the schema for application IDs is done via role which can be built using liquibase
          - The primary and secondary owner of the ID will be notified it was provisioned, and if they did not approve its use for this database they can have it removed.
        - <ins>Federated Team Name:</ins> The name portion of your federated team role (the first part before the hyphen)
          - More information on getting a Federated team role can be found [here](https://gocloud.nwie.net/docs/aws/getting-started-with-aws/howto_federatedappteamroles/)

If you have an existing 19C database in Dev or Test built prior to May 27th 2020, and would like to use it for multiple PDBs you can do so.
- There may be some inital one time set up that needs to be done by a DBA
- This includes adding additional space
- Making sure all automations are in place for provisioning additional PDBs.
- Open a request [here](https://fancy.nwie.net/DatabaseRequest).
 
## **Requirements**

- Database Engine: Oracle Enterprise Edition.
- Tagging: Refer to the page [Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement) for tagging requirements for your RDS instances.
- No publicly accessible EC2. Cloud formation property PubliclyAccessible: &#39;false&#39;
- No unencrypted storage EC2. Cloud formation property StorageEncrypted: &#39;true&#39;

## **Database Access**

- During the ordering process in Service Catalog you are asked to provide a ldap authenticated ID.
  - This ID should be the secondary ID of the I&O DBA you are working with for you database migration
  - The DBA will be able to log into the EC2 host, and get the application access to the database

## **Features**
-  Provision of Schema and Application IDs
   -  You may provision both schema and application IDs as part of the database provisioning process
   -  Integration with liquibase is available
   -  This can give you immediate access to the database
-  Host Alias for DNS Friendly names
   -  You may provision an optional CNAME for your EC2 instances and use that name to connect to the database
   -  the CNAME will be created in the .aws.e1.nwie.net domain  **Do not include domain**
   -  Can be used to maintain the same host alias if you need to migrate between EC2 instances

## **Decomission an Oracle EC2 Provisioned Product**
- Log into your BSA Tools account with the CODEPIPELINE role.
- Type "Service Catalog" in the search bar and hit enter.
- Select the "Service Catalog" link that appears.
- Select the "Provisioned Products List" link on the left side of the page
- Search for the Name of the product you used when you provisioned it.
- When you find the product, select the 3 dots to the left of the pipeline to open the menu
- Select "Terminate Provisioned Product"
- Hit ok
- This will go back to the cloudformation stack of the provisioned product, and remove it along with all resources associated with it.

## **How do you get assistance**
- Open a request to the DBA Service Now queue [here](https://fancy.nwie.net/DatabaseRequest).

## **Additional Information**
- Oracle EC2 databases are built with the same standards as on-prem databases
  - the same monitoring tools are used (Oracle Enterprise Manager, Data Performance Analyzer, etc)
  - Support for the database is exactly the same as on-prem
  - You should follow the same procedures as you do for on-prem databases for engaging hosting solution for any issues.

## **AWS Oracle EC2 Documentation**
- [Best Practices for Oracle on Amazon EC2](https://docs.aws.amazon.com/whitepapers/latest/oracle-database-aws-best-practices/introduction.html)
- [Determining IOP Needs for Oracle](https://d1.awsstatic.com/whitepapers/determining-iops-needs-for-oracle-database-on-aws.pdf)

## **Need Distributed Database Consulting?**

Engage with us through our main page [here](https://onyourside.sharepoint.com/sites/RDDS/SitePages/Welcome-to-Distributed-Database-(DDS).aspx) .

## **Need A Feature in the EC2 product?**

Please submit a feature request [here](https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/new/choose) .
