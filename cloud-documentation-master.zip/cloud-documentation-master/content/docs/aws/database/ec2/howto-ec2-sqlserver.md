---
category: aws
draft: false
title: "SQL Server on EC2"
menu: docs
---

## Ordering an EC2 MS SQL Server Instance

- Note:
  - EC2 SQL Servers are the standard SQL Server build in AWS.
    - RDS Instances are by consultation only due to the significant cost for SQL licensing in AWS 

- EC2 SQL Server Features
  - All builds
    - SQL Server 2019 is the current standard with 2017 sill available as an option.
    - Builds can be tailored to fit application requirements. Both instances sizes and disk performance can be modified
    - Standard GP2 Disk performance. If you require specifying IOPS for greater performance we can migrate to IOPS level performance disks without downtime.
    - Standard DNS name
      - We will handle the failover of instance DNS entries upon a cluster failover in cluster builds. 
      - You can the create your own CNAME DNS entry that points to the instance DNS name for a more friendly name. Please see the page [Cloud Public API Offerings](/docs/aws/products/nw-product/cie/cloud-public-api-offerings/) on GoCloud for documentation on creating DNS records.
    - Automatic monthly patching per Nationwide standard patching policies. 
  - AlwaysOn Clusters
    - This is the standard HA/DR for SQL Server instances
    - The default build is a two-node cluster set to synchronous mode meaning there is no data loss on failover
    - If your application requirements allow for potential minor data loss (Under 15 minutes, but in most cases data loss is seconds) and does not require automatic failover, Asynchronous mode is available. Asynchronous mode allows much better performance. Speak with a SQL DBA if you feel your applicaition is a good candidate.
    - Auto mirroring of databases in HA builds. When a database is created or restored to the primary node a process will automatically copy it to the secondary node, add it to the AlwaysON availability group, and initiate synchronization.
    - Auto mirroring of new logins to secondary node
  - Backups
    - Translog Backups roughly every 5 minute to a S3 bucket. This ensures your data is protected as quickly as possible.
    - Full Backups every 24 hours to an S3 bucket.
    - S3 buckets are mirrored to multiple AZs. 
    - Standard backup retention in Dev and Test is 7 days. If you do not require backup sin Dev\Test, we can disable this. 
    - Standard backup retention in Prod is 35 days.
    - Backups automatically fall out of S3 bucket based on time.
    - For non-standard times please work with a SQL Server DBA
    - Future state of backups are being investigated by the Nationwide Backup team and backups could possibly be migrated to a standard tool at a later date.
    - DBAs can do full restore of backups to a new instance in case of DR event or any other need such as a new test environment. Open a request to the SQL DBAs to perform this. This may be a self-service call in the future. 
   

- Service Catalog
  - From here a User can order an instance and have it built in their specific BSA account
  - At this point in time you can build Dev and Test instances through the Service Catalog. We are looking at releasing a Production build at a later date. To build a production AO instance please submit a request to the SQL DBA team.
  - All Development and Test instances will be built using Developer Edition of SQL Server. This edition has no licensing cost and is identical in features to Enterprise edition.
  - All Production instances will be built using Enterprise edition. 
  - Initial Service Catalog builds will be limited to 4 core builds (m5.xlarge and r5.xlarge). 
  - If you feel that you need a different class of server hardware than what is offered, please work with a SQL Server DBA. We can modify instance types to any supported instance type required. 

- Build Options
  - All builds, regardless if they are single nodes or HA, take approximately 40 minutes. 
  - After a successful build, the Resource Owner specified at build time will receive an email indicating the build is complete along with all necessary details on how they can move forward with utilizing the new database.
    - If you do not receive an email within an hour of requesting a build please open a service now ticket to run-database-sqlserver and provide as much detail as possible (Account, environment, Stack name, etc)
  - If a build fails, for whatever reason, the Resource Owner specified at build time will receive an email indicating the error(s) and why a build could not move forward. Failed builds will role back automatically as to not have partially built infrastrucutre charging money. Please reach out to the SQL DBA team for assistance. 
  - You can specify Logins and Databases you would like provisioned to the instance at build
    - Users: You can provide a comma seperated list of NWIE users. Do not include NWIE or @nationwide.com, just your NWIE shortname. YOu can also use NWIE groups as well. Again, just provide the NWIE group name without adding the domain to it. 
    - Databases: You can provide a comma seperated list of databases. Databases must fit SQL Server naming standards. The database creation will provion the specified users inside of them with rights to created tables and such. Databases will not be created unless you specify users as well.

- How to Build
  - You can build an instance the following ways:
    - 'Service Catalog' in the InfraSvcsProd account
    - Request to the SQL Server DBA team using a service request in Service Now
    - Planned in the near future:
      - In your code pipeline using a custom resource

- Deleting Your Instance. 
  - Only non-production instances are available for self termination. ALL instance terminations must be requested through a Service Now database request. This could change in the future as we develop processes to safely terminate production data.

- Data Modifications
  - In Prod, Data modification requests are expected to operate the same as they do on prem and require the appropriate approvals through ServiceNow.

### Elevated ID Rights

- If your ID requires elevated rights that are not provisioned at build time you may contact the DBA team by submitting a Service Now request to run-database-sqlserver [HERE](https://fancy.nwie.net/DatabaseRequest). 
- When assigining elevated rights, we follow the IAM standard of 'least privilege' (See the section 'Least Privilege' [HERE](https://onyourside.sharepoint.com/:b:/r/sites/IRM/SecurityStandardsPortal/IRMSecurityStandards/Access%20Control%20IT%20Security%20Standard.pdf?csf=1&e=h4S72n)).
- Elevated rights require first working with a DBA, and if a solution cannot be found that works within IRM\IAM rules, an approved IRM exception must be filed before rights will be given.
- Temporary elevation of rights without an IRM exception can be given for app installs/migrations and are at the descretion of the SQL DBAs. Elevated rights will only be temporary and will be removed immediately after the activity is complete.

## EC2 SQL Server Decommissioning Process

- The self-service decom process is a process in which you are able to tear down EC2 SQL Server instances that you built using the Service Catalog. The process will remove all objects that were provisioned when your instance was built. This helps to reduce clutter and cost.
- Please be aware of the following limitations when using the automated decommission process:
  - You must be the person who ordered the EC2 SQL instance initially.
  - You are only able to decommission EC2 SQL instances in the Dev and Test environments. Production instances are not supported at this time and still require a request to the DBA group. 
  - You can only initiate the decom process through your Provisioned Products List in the Service Catalog. Means of executing a decommission through an API or Code Pipeline will come in future releases


## How do you decommission an instance?

- Log into your BSAs Tools account
- Type "Service Catalog" in the search bar and hit enter.
- Select the "Service Catalog" link that appears.
- Select the "Provisioned Products List" link on the left side of the page
- Search for the pipeline that built your EC2 SQL instance. Note: This may not be the same name as your instance.
- When you find the pipeline, select the 3 dots to the left of the pipeline to open the menu
- Select "Terminate Provisioned Product" 
- Hit ok
- When the process is complete, the resource owner should receive an email. If the process fails, you will also receive a notification to open a request to the DBA group to investigate.
- An alternative is to request a SQL DBA to initiate the terminate process

## How do you get assistance (including Prod decom requests) or have any of our questions answered?

- Open a request to the DBA Service Now queue [here](https://fancy.nwie.net/DatabaseRequest).
