---
title: Tagging your EC2 instances
menu: docs
category: aws
---



Per [AWS tagging best practices](https://aws.amazon.com/answers/account-management/aws-tagging-strategies/), different tag categories should be used for each business use case.

### Why Is Tagging Required At Nationwide?

* Tagging is a mechanism that helps manage and organize assets in a Cloud environment. 
* Resources should be tagged based on categories, to easily identify them within their use case. 
* Proper tagging can help in organizing cost breakup, automation, and access control.

#### Cost & Billing
 Tagging drives billing. By tagging resources properly, your application will only be billed for those resources. Plus there are certain tags, like ShutDownInstanceAt, that can help with expense management. 
 
#### BSA Reporting 
 Tagging helps drive BSA reporting. If all your resources are tagged with the APRMID tag, business units should be able to tie all the resources together to get an accurate overview of all live resources.

#### Required Tags
* Any EC2 instance created in a Nationwide AWS account need a set of required tags. The table below has a list of all required tags.
* Refer to the page [Required Tags for Service at Nationwide](/docs/aws/cost/tagging-requirement) for tagging requirements for your EC2 instances.
