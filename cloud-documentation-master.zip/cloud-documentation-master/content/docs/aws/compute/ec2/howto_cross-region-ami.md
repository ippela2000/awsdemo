---
title: How to Make Multi-Region AMIs
menu: docs
category: aws
---

## Multi-region AMI explanation

If you plan to deploy an EC2-based application in both the Virginia and Ohio regions and/or across multiple accounts, you should bake the AMI once and use it everywhere to avoid introducing differences between the environments.

When ordering a pipeline from one region, by default, it only produces an AMI and deploys resources in that region. The pipeline bakes a single AMI and shares it to all environments of that region, but you cannot use that same AMI in alternate regions.

If your application is only going to run in a single region, you do not need to make any changes from the default. The steps below show to update your pipeline to copy your AMI from one region to another.

At this point, fully multi-region pipelines and applications are not a standard that the CIE team has a pre-made solution for.

## Updating a CodePipeline to deploy AMI to multiple regions

The Share_AMI step of a pipeline in the BuildAndPackage stage is the one that shares the AMI that you created in your Tools account over to the other environments of the stack.

To enable your pipeline to also have it copy the image over into another region, you need to duplicate this step and modify the flags to have it copied to another region as well.

### Default example

```yaml
- Name: Share_AMI
  ActionTypeId:
    Category: Invoke
    Owner: AWS
    Provider: Lambda
    Version: '1'
  Configuration:
    FunctionName: share-ami
    UserParameters: !Sub |
      {
        "environments": [
          "Prod${pBusinessUnit}",
          "Test${pBusinessUnit}",
          "Dev${pBusinessUnit}"
        ],
        "baked_encrypted": "true"
      }
  InputArtifacts:
    - Name: EncryptAMI
  OutputArtifacts: []
  RoleArn: !Sub arn:aws:iam::${pSharedProdAccountNumber}:role/${pCodePipelineActionRole}
  RunOrder: 4
```

This setup specifically shares the AMI over to the Dev, Test, and Prod environments of the current account stack with the same region it is being called.

Replacing this step with the following, will have it copied to all 3 environments in both the Virginia and Ohio region (assuming the pipeline currently exists in the Virginia region)

### Multi-region example

```yaml
  - Name: Share_AMI_Virginia
    ActionTypeId:
      Category: Invoke
      Owner: AWS
      Provider: Lambda
      Version: '1'
    Configuration:
      FunctionName: share-ami
      UserParameters: !Sub |
        {
          "environments": [
              "Prod${pBusinessUnit}",
              "Test${pBusinessUnit}",
              "Dev${pBusinessUnit}"
          ],
          "baked_encrypted": "true",
          "region": "us-east-1"
        }
    InputArtifacts:
      - Name: EncryptedAMI
    OutputArtifacts:
      - Name: VirginiaAMI
    RunOrder: 4
  - Name: Share_AMI_Ohio
    ActionTypeId:
      Category: Invoke
      Owner: AWS
      Provider: Lambda
      Version: '1'
    Configuration:
      FunctionName: share-ami
      UserParameters: !Sub |
        {
          "environments": [
              "Prod${pBusinessUnit}",
              "Test${pBusinessUnit}",
              "Dev${pBusinessUnit}"
          ],
          "baked_encrypted": "true",
          "region": "us-east-2"
        }
    InputArtifacts:
      - Name: EncryptedAMI
    OutputArtifacts:
      - Name: OhioAMI
    RunOrder: 4
```

The above steps will share the AMI into both the Ohio and Virginia regions. The AMI will get a different ID in the Ohio region than in the Virginia region.

The OutputArtifacts store the AMI ID of the regions if you need to reference them specifically in future stages of your pipeline. You can leave these off if you do not have any need to do that.