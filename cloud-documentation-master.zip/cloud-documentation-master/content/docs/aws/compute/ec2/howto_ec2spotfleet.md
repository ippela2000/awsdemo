---
title: How to use EC2 Spot Fleet
menu: docs
category: aws
---

## Spot Fleet Template Customization

Using EC2 Spot fleet is easier than it seems! However, due to the nature of spot fleet, some customization of the template is most likely required to get the desired benefits out of this service.

The SpotFleet is configured with one or more LaunchSpecifications that defines the configuration for individual instance types. For the sake of simplicity, only a single LaunchSpecification is included in the template. In practice, you can add additional configurations to vary by EC2 instance type or any other parameter.

While there is a considerable number of ways that a SpotFleet can be configured, we will only touch on some of the most important parameters in this documentation.

### Parameters

- ImageId
    - The AmiId to use for the instances.
- TargetCapacity
    - The number of "units" to request for the Spot Fleet
- IamFleetRole
    - The role that allowed Spot Fleet to request instances on your behalf.

### Optional Parameters

- SpotPrice
    - The maximum price to pay for a spot instance. By default, this will be the on demand price, but it can be configured globally or on a per instance type basis.
- LoadBalancersConfig
    - Spot Fleet can be assigned to an existing load balancer when being used to bolster the capacity of an already running application.
- WeightedCapacity
    - The number of "units" a specified instance type provides. This number is divided into the TargetCapacity parameter to determine the number of EC2 Instances to request.
- IamInstanceProfile
    - The Instance profile to use for ec2 instances, if desired.
- ValidFrom
    - SpotFleet can utilized a delayed start time, if desired.
- ValidUntil
    - SpotFleet can be configured to end automatically, if desired.
- TerminateInstanceWithExpiration
    - If combined with the "ValidUntil" parameter, SpotFleet will terminate existing instances once expired.

### Further Reading

[Nationwide Example Template](https://github.nwie.net/Nationwide/AWS-CloudFormation/tree/master/EC2/EC2SpotFleet.yaml)

[How Spot Fleet Works](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-fleet.html)

[Spot Fleet Requests Example Configurations](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/spot-fleet-examples.html)

[Amazon EC2 Spot Fleet Role](https://docs.aws.amazon.com/batch/latest/userguide/spot_fleet_IAM_role.html)

### AWS CloudFormation Documentation

[AWS::EC2::SpotFleet CloudFormation Documentation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-spotfleet.html)

[AWS::EC2::SpotFleet SpotFleetRequestConfigData CloudFormation Documentation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ec2-spotfleet-spotfleetrequestconfigdata.html)

[AWS::EC2::SpotFleet SpotFleetLaunchSpecification CloudFormation Documentation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-ec2-spotfleet-spotfleetrequestconfigdata-launchspecifications.html)
