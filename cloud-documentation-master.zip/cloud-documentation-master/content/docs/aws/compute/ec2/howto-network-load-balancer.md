---
title: Network Load balancer in pipeline
menu: docs
category: aws
---

### How To Add NLB To Pipeline in AWS

you can order the server blue green quick deploy pipeline and add the network load balancer to the existing pipeline
you will get a dns name with -nlb  for the NLB, for example if you common name is abc.nwie.net for you application load
balancer, you will get abc-nlb.nwie.net dns name for you network load balancer




### Pipeline Modification

Order your server blue green quick deploy pipeline and add the NLB to master/iac/CloudFormation/LoadBalancerAutoScaling.yaml
```
  rNetworkLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name:  !Sub ${pProduct}-NLB-${pColor}-${pRandomString}
      Subnets:
        - !ImportValue oPrivateSubnetA
        - !ImportValue oPrivateSubnetB
        - !ImportValue oPrivateSubnetC
      Scheme: internal
      Type: network
      Tags:
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pProduct
      - Key: Environment
        Value: !Ref pEnvironment

  # Create the target group for the network load balancer
  rNetworkTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    DependsOn: rNetworkLoadBalancer
    Properties:
      Name: !Sub ${pProduct}-NLB-${pColor}-${pRandomString}
      VpcId: !ImportValue oVPCID
      Port: 22
      Protocol: TCP
      HealthCheckIntervalSeconds: 10
      HealthCheckProtocol: TCP
      HealthCheckTimeoutSeconds: 10
      HealthyThresholdCount: 3
      TargetGroupAttributes:
        - Key: deregistration_delay.timeout_seconds
          Value: 30

  # Create the listener for the network load balancer
  rNetworkLoadBalancerListener:
    Type: AWS::ElasticLoadBalancingV2::Listener
    DependsOn:
      - rNetworkCreateCertificate
      - rNetworkTargetGroup
      - rNetworkLoadBalancer
    Properties:
      LoadBalancerArn: !Ref rNetworkLoadBalancer
      Port: 22
      Protocol: TCP
      DefaultActions:
        - Type: forward
          TargetGroupArn: !Ref rNetworkTargetGroup
```

Export the private DNS

```
Outputs:
  oNetworkLoadBalancerDNSName:
    Value: !GetAtt rNetworkLoadBalancer.DNSName
```
