---
title: Use Pre-Made Security Groups
menu: docs
category: aws
---

## OnPrem -> AWS Common Access Security Groups

|Security Group Name|Access Granted|
|-----|-----|
| ToolsAccessSG | Access to SharedProd & Nationwide Tools |
| Standard-Database-Access-SG | Permits all of on-prem to standard SQL and Oracle ports |
| Standard-Management-Access-SG | Permits all of on-prem to SSH and RDP |
| Standard-Web-Access-SG | Permits all of on-prem to 80/443/9080/9443 for standard HTTP/S and Tomcat |
| Standard-Windows-Domain-Access-SG | Permits the standard ports for Windows servers to join and interact with the domain and SCM |
| Standard-Lambda-Outbound-Access-SG | Permits all destinations/ports outbound, nothing inbound. Intended for use with lambdas for typical outbound-only access. |

The above security groups are pre-approved and will not result in notifications about overly-permissive groups.
Controls around security groups will change over time and likely get more restrictive, this page will always have the latest list of pre-approved security groups.

If you have other thoughts/ideas for common access from on-prem, please submit a feature request [HERE](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md) to get additional security groups added.


## Using Pre-Made Security Groups

Security groups are now set up to be referenced using Parameter Store instead of CloudFormation exports. There is a parameter in every account for each of the above security groups, with the parameter having -SG appended to the security group name noted above (IE: Standard-Database-Access parameter is Standard-Database-Access-SG)


### EC2 CloudFormation Example
```
Resources:
  rEC2Instance:
    Type: AWS::EC2::Instance
    Properties:
      IamInstanceProfile: ...
      InstanceType: ...
      SecurityGroupIds:
        - "{{ "{{resolve:ssm:Standard-Database-Access-SG:1" }}}}"
      ImageId: ...
      SubnetId: "{{ "{{resolve:ssm:PrivateSubnetA:1" }}}}"
      KeyName: ...
      Tags:
        ...
```


### LoadBalancer CloudFormation Example
```
Resources:
  rLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name: ...
      Subnets:
        - "{{ "{{resolve:ssm:PrivateSubnetA:1" }}}}"
        - "{{ "{{resolve:ssm:PrivateSubnetB:1" }}}}"
        - "{{ "{{resolve:ssm:PrivateSubnetC:1" }}}}"
      Scheme: internal
      SecurityGroups:
        - "{{ "{{resolve:ssm:Standard-Web-Access-SG:1" }}}}"
      Tags:
        ...
```
