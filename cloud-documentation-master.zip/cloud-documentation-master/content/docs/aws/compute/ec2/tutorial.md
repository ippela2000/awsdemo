---
title: "EC2 Tutorials"
menu: docs
category: aws
---


## Overview

This section has a few tutorials that can help you get started on creating an EC2 in your BSAs NW account.

## Elastic Compute Cloud
* Elastic Compute Cloud, or EC2, provides virtual machines and block storage to run your application. Firewalls, load balancing, and auto - scaling are also part of the EC2 service.
* If you are unfamiliar with EC2, we recommend completing **[this tutorial](https://github.nwie.net/Nationwide/cloud-tutorials/blob/master/ec2/create-ec2.md)** before proceeding.

