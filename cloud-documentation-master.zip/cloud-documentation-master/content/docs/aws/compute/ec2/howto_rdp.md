---
title: RDP with EC2
menu: docs
category: aws
---

###  If you use the following method, you are responsible for any changes that you make manually.

#### Security Group Requirements:

RDP access to Windows Servers is enabled via Security Group ToolsAccess or OnPrem-AWS-Windows-Domain-Access.  Other Security Groups that contain inbound port 3389 can be used, however we have included the port in some of our Security Groups for ease of use.  Reference either one of these Security Groups in your EC2 CloudFormation using the following:

```
SecurityGroupIds:
  - !ImportValue ToolsAccessSG
```


An Example can be found here on line 213:  https://github.nwie.net/Nationwide/AWS-CloudFormation/blob/master/EC2/Windows/EC2.yaml


#### How to Initiate the Connection:
Once a Security Group that contains port 3389 is applied to the EC2 instance you will be able to execute the remove desktop connection.  To open the connection:
- open the Run command (Windows Key + R) and type “mstsc” or search “Remote Desktop Connection” from the Start Menu
- type the IP Address or DNS Alias (if one was created) in the Remote Desktop Connection window
- press “Connect”
- type your Username and Password


#### How to get permissions to RDP to a Server:
Windows Servers in AWS utilize the AdminMe process exactly like onPrem Windows Servers.  In the CloudFormation templates available via the AWS-CloudFormation git repo or by EC2.yaml deployed via Service Catalog pipeline order; there is a parameter included named “pAppAdmins”.  Populating this field during manual CloudFormation executions, or in the corresponding .json input file in your pipeline, with valid Active Directory users or groups.  This will result in those Active Directory users and groups having an entry in http://adminme.nwie.net/login for elevating Power User to Administrator permissions.  RDP access does not require Administrator rights but it does require Power User right.  Anyone not included in the “pAppAdmins” field will not have RDP access to the server.
More information about AdminMe can be found here: https://adminme.nwie.net/faq


#### AWS KeyPairs and NW Windows Instances:
AWS KeyPairs are not usable once the NW Windows Instance completes its build.  Attempting to use local\administrator and the KeyPair password will result in logon failures.


#### NW Windows Instances and Setting Local Administrators:
Creating a local administrator on a Window server is not allowed without obtaining a Security Exception.  The exception form may be located here:  https://fulcrum.apps.nwie.net/ or you can reach out to your IRM Rep for information.  Unauthorized local administrators will be removed from the server without notification.
