---
title: Autoscaling Guide
menu: docs
category: aws
---

## Concepts

### EC2 Autoscaling & Health Checks
“Amazon EC2 Auto Scaling helps you ensure that you have the correct number of Amazon EC2 instances available to handle the load for your application. You create collections of EC2 instances, called Auto Scaling groups…[If you specify scaling policies, then Amazon EC2 Auto Scaling can launch or terminate instances as demand on your application increases or decreases.](https://docs.aws.amazon.com/autoscaling/ec2/userguide/what-is-amazon-ec2-auto-scaling.html)”

“After an instance is fully configured and passes the initial health checks Amazon EC2 Auto Scaling marks it as healthy. Amazon EC2 Auto Scaling checks that all instances within the Auto Scaling group are running and in good shape by periodically checking the health state of the instances. [If the instance is in any state other than running or if the system status is "impaired", Amazon EC2 Auto Scaling considers the instance to be unhealthy and launches a replacement instance.](https://docs.aws.amazon.com/autoscaling/ec2/userguide/healthcheck.html)”

![EC2 Autoscaling Group](/docs/aws/images/AutoscalingConsoleInstances.png)

![Autoscaling Console Log](/docs/aws/images/AutoScalingConsoleLog.png)

#### Amazon EC2 Auto Scaling supports the following types of scaling [policies](https://docs.aws.amazon.com/autoscaling/ec2/userguide/as-scale-based-on-demand.html#as-scaling-types):
- Target tracking scaling—Increase or decrease the current capacity of the group based on a target value for a specific metric. This is similar to the way that your thermostat maintains the temperature of your home—you select a temperature and the thermostat does the rest.
- Step scaling—Increase or decrease the current capacity of the group based on a set of scaling adjustments, known as step adjustments, that vary based on the size of the alarm breach.
- Simple scaling—Increase or decrease the current capacity of the group based on a single scaling adjustment.

For autoscaling on CPU or RAM usage, SRE suggests [target tracking policies](https://docs.aws.amazon.com/autoscaling/ec2/userguide/as-scaling-target-tracking.html).

![Autoscaling Console Log](/docs/aws/images/TargetTrackingPolicy.png)

### Elastic Load Balancing & Health Checks
“Your Application Load Balancer periodically sends requests to its registered targets to test their status. These tests are health checks. Each load balancer node routes requests only to the healthy targets in the enabled Availability Zones for the load balancer…[If a target group contains only unhealthy registered targets, the load balancer nodes route requests across its unhealthy targets.](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/target-group-health-checks.html)” 

![Autoscaling Console Log](/docs/aws/images/RegisteredTargets.png)

### Combining ELB and EC2 Health Checks
By default, EC2 health checks only check the health of the EC2 instance; not the application running on it. If the application becomes unhealthy, autoscaling will not replace the EC2, and users might notice impacts.

EC2 Autoscaling can take [ELB health checks into account](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-as-group.html#cfn-as-group-healthchecktype) when determining whether an instance is healthy or not. If either ELB checks or EC2 checks fail, the instance will be [marked as unhealthy and replaced](https://docs.aws.amazon.com/autoscaling/ec2/userguide/healthcheck.html).

![Autoscaling Console Log](/docs/aws/images/ELBHealthChecks.png)

## Example

#### Application

NateBook is a new critical application that will allow agents to manage their book of business. The front-end is a single page application hosted on S3/CloudFront, with the database hosted on EC2 and managed by I&O. 

The application tier is on EC2 and managed by the application team. Preliminary estimates are that the the application needs 2 vCPUs and 2GB of RAM at minimum load, and at maximum load, 20 vCPUs and 40GB of RAM. 

The team wants to maximize the availability of the application, while keeping infrastructure and support costs low. How can they do this?

#### EC2 Autoscaling
[First, they'll need to choose an EC2 instance type](https://aws.amazon.com/ec2/instance-types/). They will start with c5.large instances, which provide 2 vCPU and 4GB of RAM. [They'll set the autoscaling group to use a minimum of two instances](https://docs.aws.amazon.com/autoscaling/ec2/userguide/asg-capacity-limits.html), to ensure that an instance failure during minimum load will not take down the application. They'll also set the maximum instance count to 10, which gives us 20 vCPUs and 40GB of RAM. This protects them from runaway autoscaling due to improper configurations or other bugs.
 
Next, [configure a target tracking autoscaling policy](https://docs.aws.amazon.com/autoscaling/ec2/userguide/as-scaling-target-tracking.html) to maintain average CPU at 70%, and a second policy to maintain average RAM consumption at 70% . AWS will automatically add and remove instances to maintain these values without us having to do anything. 

#### Elastic Load Balancing
Next, the team will add an Application Load Balancer in front of their EC2 instances and [enable health checks](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/target-group-health-checks.html). They’ll also update the EC2 Autoscaling configuration to [take ELB health checks into account](https://docs.aws.amazon.com/autoscaling/ec2/userguide/as-add-elb-healthcheck.html) when determining if an instance is healthy or unhealthy.

#### Summary
With this setup, NateBook’s application layer will automatically scale from 4 vCPU and 8GB of RAM to 20 vCPUs and 40GB of RAM. Unhealthy instances will automatically be [drained](https://aws.amazon.com/blogs/aws/elb-connection-draining-remove-instances-from-service-with-care/) and replaced.
