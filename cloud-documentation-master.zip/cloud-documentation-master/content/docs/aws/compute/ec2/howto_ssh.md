---
title: Using SSH with EC2
menu: docs
category: aws
---

#### SSH into a Linux machines using a private ssh key

* Logging into an EC2 instance from a Mac or Linux server:
  * Create a key pair in AWS. Go to EC2 -> Key Pairs -> Create Key Pair.
  * Copy this private ssh key to your home directory or a secure directory. To login you would use a command similar to:
  ```- ssh -i $.pem centos@$hostname||$ip_address ```
  * ```Example: ssh -i myShortName_infrasecprod.pem centos@10.163.15.168```
  * Make sure that you have port 22 open for tcp on the EC2 instance. This can be updated in your attached Security Group
* Logging into an EC2 instance from a Windows machine using PuTTY
  * https://www.youtube.com/watch?v=bi7ow5NGC-U
  * https://awsinsider.net/articles/2017/01/18/connecting-to-a-linux-instance.aspx - the user will be: ```centos@$DNS||$hostname```

###  If you use the following method, you are responsible for any changes that you make manually.

#### SSH into a Linux machines - adding users through CodePipeline

1. Create a shell script (for instance, add_admin_users.sh) in the iac/Packer directory. [File here](https://gist.github.nwie.net/knowls3/0f581818052c9e9f26cb6ff29140684b)
2. Add the following code to the "provisioners" section in your iac/Packer/packerfile.json file. [File here](https://gist.github.nwie.net/knowls3/49e20b9612d1bdf9c6cbf46ec6da0b1f)

3. Let your pipeline run and update with this new information. To login, you would use
``` ssh <NWIE ID>@<IP Address> ```

If that still doesn't work, the user may not have a Unix LDAP id, and will need to request one through ServiceNow.

1. Go to [ServiceNow](https://nwproduction.service-now.com/ess/?id=sc_cat_item&sys_id=5a41a00ddbf71bc0a6225d104b9619cc)
2. In *Brief Description put [shortname] – ENDUSER Unix Group
3. In *Request Type dropdown select Unix (Groups & Net Group)
4. In *Select Group Name(s) put ENDUSER Unix Group
5. Select Add to Cart
