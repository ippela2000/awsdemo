---
title: WindowsDriveLetters
menu: docs
category: aws
---

### Purpose

There are some apps that require specific drive letters to run.  This how to is intended for use ONLY when an application requires a specific drive letter.  Generally speaking drive letters are automatically assigned during the AMI bake process, this is done alphabetically, and is not an issue on the launched instance.  However, if there is legacy code that requires a specific drive letter, these instructions provide a methodology to achieve consistent, arbitrary drive letters.

Note: the methodology described here relies on setting volume names, however this should not be an issue for most apps.

We face two problems.  How to handle initial ordering of the drives during the bake process, and how to make sure every instance that launches based on that AMI makes use of the same drive letters.

## Steps we will take
1. Request additional drives for our windows instance
2. Provide a map between the device name and the drive letter we want it to have
3. Format the disks and map them to the correct drive letter
4. Set the Label (Volume Name) to match the drive letter
5. Bake the AMI
6. When the instance launches for the first time, adjust the drive letters to match the label

All code examples on this page are available in the [PipelineWinDrives](https://github.nwie.net/Nationwide/PipelineWinDrives) repository.  That code has inline comments that this code does not.

## Provision additional drive(s)

In AWS, EC2 instances map ABS volumes.  In your packerfile.json, in the builders section, add code similar to the following:
```
...
  "builders": [
    {
...
      "launch_block_device_mappings": [
        {
          "device_name": "/dev/xvde",
          "delete_on_termination": true,
          "volume_size": 100,
          "volume_type": "gp2"
        },
        {
          "device_name": "/dev/xvdf",
          "delete_on_termination": true,
          "volume_size": 500,
          "volume_type": "gp2"
        }
      ],
...
```

Device name can be anything from /dev/xvdb to /dev/xvdz.  volume size is the size in GB.  Remember that charges acrue on the size of the storage requested for EBS volumes, not just on used capacity.  If you feel that delete_on_termination should be false, chances are that these instructions will be a poor fit in some ways.  One drive only can be specified, but I recommend keeping the square bracket, regardless.

## Spell out our drive mappings.

Create a configuration file named DriveConfig.json, and place it in our github repo in the ./iac/Packer directory.  Here is some example code:
```
{
    "Map" : [
        { "Device": "/dev/xvde",
          "Drive": "E"
        },
        { "Device": "/dev/xvdf",
          "Drive": "F"
        }
    ]
}
```

Here again, even when only mapping one drive, be careful to maintain the use of the square bracket.

As an alternative to storing this in github, a copy could be placed in an S3 bucket.

## Copy Amazon Utility to GitHub

The following code is modified from [Amazons Windows Guide](https://docs.aws.amazon.com/AWSEC2/latest/WindowsGuide/ec2-windows-volumes.html), specifically "Mapping Disks to Volumes on Your Windows Instance".

It's a little large to quote here.  The example file is named [EBSList.ps1](https://github.nwie.net/Nationwide/PipelineWinDrives/blob/master/EBSList.ps1).

Place a copy of EBSList.ps1 in your ./iac/Packer directory, as well.

Again, using an s3 bucket is an alternative, and the changes to the code should be obvious if you wish to choose that route.

## Add code to move the files we just added

In packerfile.json, in the provisioners section.
```
...
  "provisioners": [
    ...
    {
      "type": "file",
      "source": "./iac/Packer/AlignDrive.ps1",
      "destination": "C:\\Windows\\Temp\\AlignDrive.ps1"
    },
    {
      "type": "file",
      "source": "./iac/Packer/EBSList.ps1",
      "destination": "C:\\Windows\\Temp\\EBSList.ps1"
    },
    {
      "type": "file",
      "source": "./iac/Packer/DriveConfig.json",
      "destination": "C:\\Windows\\Temp\\DriveConfig.json"
    },
    {
      "type": "powershell",
      "script": "./iac/Packer/install_myapp.ps1"
    },
    ...
  ]
  ...
}
```
The first section adds a directory for our files.  The next two copy the files we just added to our instance.  The third runs your custom installation script.


## Initialize disks based on the config file

```
$disks = C:\Windows\Temp\EBSList.ps1 | Where-Object { $_.EbsVolumeId -like "vol*" }

$DriveMap = ConvertFrom-JSON -InputObject (Get-Content C:\nwtools\build\aws\DriveConfig.json -Raw)

foreach ($disk in $disks) {
    foreach ($mapping in $DriveMap.Map) {
        if ($disk.Device -eq $mapping.Device) {
            if ( (Get-Disk -Number $disk.Disk).PartitionStyle -eq "RAW") {
              Initialize-Disk -Number $disk.Disk -PartitionStyle MBR
              New-Partition -diskNumber $disk.Disk -useMaximumSize -DriveLetter $mapping.Drive
              Format-Volume -DriveLetter $mapping.Drive -FileSystem NTFS -NewFileSystemLabel $mapping.Drive -Confirm:$false
            }
        }
    }
}
```

Note the use of the file locations from the previous step.  If you change that, change it here, as well.
This step runs during your Bake AMI step, and should run before software is installed.  [Example Script](https://github.nwie.net/Nationwide/PipelineWinDrives/blob/master/install_myapp.ps1)

## On first run, map the drives

Edit your packer_userdata.ps1 file , inserting the following code right after the script sets ErrorActionPreference to stop.  As of this writing, that happens right around line 10.
```
$Partitions = Get-Partition

foreach ($Partition in $Partitions) {
    $Volume = Get-Volume -Partition $Partition

    if ($Partition.Driveletter -eq "C" -or $Volume.FileSystemLabel -eq "C")  {Continue}

    if ($Partition.Driveletter -ne $Volume.FileSystemLabel) {
        if ( $Volume.FileSystemLabel.length -ne 1 ) {Continue}

        $DrivePath = -join($Volume.FileSystemLabel,":")
        if (Test-Path $DrivePath) {
            Remove-PartitionAccessPath -DriveLetter $Volume.FileSystemLabel -AccessPath $DrivePath
        }

        Set-Partition -DiskNumber $Partition.DiskNumber -PartitionNumber $Partition.PartitionNumber -NewDriveLetter $Volume.FilesystemLabel
    }
}
```

The example file is named [AlignDrive.ps1](https://github.nwie.net/Nationwide/PipelineWinDrives/blob/master/AlignDrive.ps1)

Alternatively, this code could also be separated into it's own file and a process set to run it at a specific time in the boot process.   There should be no issue in running this multiple times.

Finally, modify the UserData in your EC2.yaml or LoadBalancerAutoScaling.yaml to call the align drive script.
```
powershell.exe -command C:\Windows\Temp\AlignDrive.ps1;
```
```
EC2.yaml code snippet ...

            - " --region "
            - Ref: AWS::Region
            - "\n"
            - 'powershell.exe -command C:\Windows\Temp\AlignDrive.ps1'
            - "\n"
            - "</script>\n"
 ```

Search for UserData.  How best to do this is left to your discretion, as this is one of the sections of the yaml file most likely to be require modification.

### Parting thoughts
Remember that all of the code examples used here are available at [PipelineWinDrives](https://github.nwie.net/Nationwide/PipelineWinDrives).  That is a public repo that anyone can contribute to.  The code is commented in-line in that repo, whereas comments were deleted for brevity, here.

If you make improvements to the code, please also update this documentation.
