---
title: Linting CloudFormation
draft: false
menu: docs
---
Validate CloudFormation yaml/json templates against the CloudFormation spec and additional checks. Includes checking valid values for resource properties and best practices.

## Installation
1. Install [VSCode](https://code.visualstudio.com/docs/setup/setup-overview).
2. Install [cfn-lint](https://github.com/aws-cloudformation/cfn-python-lint)
3. [Install](https://code.visualstudio.com/docs/editor/extension-gallery) the [vscode-cfn-lint](https://marketplace.visualstudio.com/items?itemName=kddejong.vscode-cfn-lint) extension.

## Common Issues
`Unable to start cfn-lint (Error: spawn cfn-lint ENOENT). Is cfn-lint installed correctly?`

Go to Settings -> User Settings -> Search Bar **"Cfn Lint: Path"** and paste correct path into box.

`unknown tag <!XYZ> at line ##, column ##`

Go to Settings -> User Settings -> Search Bar **"Yaml:Custom"**, select "Edit in settings.json" and paste in the following:

```
    "yaml.customTags": [
        "!And",
        "!If",
        "!Not",
        "!Equals",
        "!Or",
        "!FindInMap",
        "!Base64",
        "!Cidr",
        "!Ref",
        "!Sub",
        "!GetAtt",
        "!GetAZs",
        "!ImportValue",
        "!Select",
        "!Split",
        "!Join"
    ]
```
