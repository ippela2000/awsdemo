---
category: aws
draft: false
title: "Cloud Formation"
menu: docs
---

CloudFormation is a service that allows you to define your AWS infrastructure as code, in YAML or JSON format. Then, your code can be instantiated to create real resources in AWS for your application to consume.

At the bottom of this [page](#internally-approved-cloudformation-templates) there is a link to a list of internally approved templates, but first let's take a look at a simple CloudFormation stack which creates a Linux EC2 instance. The full cloudformation template can be found [here]({{site.git_edit_address | append:"/_aws-docs/sampleStack.yml"  }})
```yaml
### Define our template version and give it a description
AWSTemplateFormatVersion: '2010-09-09'
Description: Create Nationwide Linux Server
Metadata:
 ...
Parameters:
  pMachineName:
    Description: Name of the instance
    Type: String
  ...
Resources:
  EC2Instance:
    Type: "AWS::EC2::Instance"
    Properties:
      InstanceType:
        Ref: pInstanceType
      SecurityGroupIds:
        - Ref: pSecurityGroup
      ImageId: ami-df232ba0
      SubnetId:
        Ref: pPrivateSubnetId
      Tags:
        - Key: "Name"
          Value:
            Ref: "pMachineName"
        ...
Outputs:
  Instance:
    Value:
      Fn::GetAtt:
      - EC2Instance
      - PrivateDnsName
    Description: DNS Name of the newly created EC2 instance
```

#### Parameters
The stack starts by defining a long list of parameters, along with some default values. If this were a real CloudFormation stack, we would define our values elsewhere and pass them in as appropriate for each environment, but the defaults will do for now.

In order to access the value of a parameter you use `REF` and the name of the parameter, as seen above under the **"Tags"** section.

#### Tags
[Tags](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/Using_Tags.html) are arbitrary metadata that can be associated with your AWS resources. By themselves, they allow you to quickly identify resources with matching tags. Nationwide also has [Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement) cloud policy; for example, instances without a valid `APRMID` tag will be automatically shutdown by watchdog functions.

#### Resources
This is where we define our AWS resources to be provisioned or modified. In this instance, we are defining a EC2 Instance of the type [`t2.medium`](https://aws.amazon.com/ec2/instance-types/?sc_channel=PS&sc_campaign=acquisition_US&sc_publisher=google&sc_medium=ec2_b&sc_content=sitelink&sc_detail=ec2%20instance%20types&sc_category=ec2&sc_segment=instance_types&sc_matchtype=e&sc_country=US&s_kwcid=AL!4422!3!175055296709!e!!g!!ec2%20instance%20types&ef_id=WxfpRAAABw5AlhME:20180606172258:s), with a number of different tags, and a UserData script. You can [refer](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/intrinsic-function-reference-getatt.html) to the attributes of a CloudFormation resource internally by referencing its name and the attribute you want to get. For example, `!GetAtt myExampleServer.SubnetId
` will return the SubnetId of the resource `myExampleServer`.

## Deploying CloudFormation Stacks

We'll now deploy the stack above via the AWS Management Console (an example of deploying a stack via AWS CLI can be found <a href='https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/how-to-aws-cli/#creating-a-stack-from-a-manual-cloudformation-template' id='here' class='anchor' aria-hidden='true'>here</a>). To do so, open your browser, log into your AWS developer account (or your BSA's Dev Account), and select CloudFormation from the Services tab. Click "New Stack" and upload [this file]({{site.git_edit_address | append:"/_aws-docs/sampleStack.yml"  }}). Continue through the GUI, using the following values:

|Field|Value|
|-----|-----|
| Stack Name | Any e.g. myNameSampleStack |

Linux Server Information

|Field|Value|
|-----|-----|
|Machine Name| Any e.g. myNameSampleServer |
|Instance Type| t2.medium |
|Security Group|Select one, e.g. ToolsAccess|

EC2 Contact Information

|Field|Value|
|-----|-----|
| Resource Owner | your nwie ID |
| ShutDownInstanceAt | 12am UTC |
| DisbursementCode | Your nine digit disbursement code |
| APRM ID | 9999 |
| DataClassification | Internal_use_only |
| ResourceName | Your application Name e.g. MyTestApp|
| SecurityException| False |
| Patch | false |
| CNAME | Leave Blank |

Click **Next** through the following screens and deploy your stack (note that we are going to delete this stack immediately so you can ignore tagging and any other paramters for this exercise). Click through some of the logs as your resources provision. When your stack has finished successfully, select it, click **Actions** and delete your stack.

### Internally Approved CloudFormation Templates

Internally approved CloudFormation templates can be found [here](https://github.nwie.net/Nationwide/AWS-Cloudformation). 
**[Questions?](https://rocketchat.nwie.net/channel/AWS)**
