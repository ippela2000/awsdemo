---
title: Generic-IAC Pipeline
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included](#whats-included)
  - [Github files defined](#github-files-defined)
- [Why pick this product?](#why-pick-this-product)

----

## What is it?
The Generic-IAC product is a simplified deployment method that allows users to execute any infrastructure-as-code (IAC) without the full CodePipeline service. The idea behind this is to allow users to use whatever infrastructure-as-code (IAC) mechanism they want while committing via GitHub and having the guardrails in place in the CodePipeline action roles.


<img src="/docs/aws/images/iac-graphic.jpg">

## What's Included
[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Generic-IAC)

The Generic-IAC Pipeline creates 4 resources in AWS:
 - A CodeBuild project in your BSA Tools account (InfraSvcsProd for legacy).
 - Three IAM Roles. A “CodePipeline Action” Role for Dev/Test/Prod for the BSA accounts chosen. These are the same roles used by a normal CodePipeline to create resources in AWS. They can be “Assumed” by the CodeBuild to manually create any resource a CodePipeline can.

OPTIONAL - Language and framework examples. When you choose this option, you get access to templates for Serverless.com in Go, Python, Java, or Javascript, or AWS CDK in Python, Java, or Javascript. See below for more information.

There is no actual "Pipeline"; all actions will happen inside a single CodeBuild execution.

You will receive a Pull Request on your repository containing a single file: buildspec.yaml. This file is where you should put whatever commands you would like to execute in the environment. By default, it just contains code to set up AWS credentials profiles for your 3 roles and then create and tag an S3 bucket in dev/test/prod via the AWS CLI.

As per usual, this product also creates a WebHook on your repository to trigger the pipeline.

### Github files defined
* buildspec-gitinit.yaml - The file that gets executed by the CodeBuild. Place any commands you want to run here.
* OPTIONAL language/framework:
    - AWS CDK (Python, Java, Javascript)
        - buildspec.yaml - The file that gets executed by the CodeBuild. Place any commands you want to run here
        - CDK folder - files specific to the chosen language with a sample app. Refer to the README file for more information and helpful commands
    - Serverless.com (Go, Python, Java, Javascript)
        - buildspec.yaml - The file that gets executed by the CodeBuild. Place any commands you want to run here
        - params.yaml - used by the serverless.yaml template to get order information
        - serverless.yaml - defines the lambda service resources for the serverless sample app
        - Language-specific files - sample lambda "Hello World" functions

## Why pick this product?

 - Since this product is extremely simple (a single CodeBuild), it's extremely fast. Depending on what you are doing, the execution time can be a low as 20 seconds.
 - This product also allows for you to pick what mechanism you deploy with:
     - AWS CLI
     - CloudFormation files via the CLI
     - TerraForm (installation required)
     - Python Script executing Boto3
     - Serverless.com
     - AWS Cloud Development Kit (AWS CDK)
 - With this flexibility, you lose some out-of-box functionality. Since you are doing everything manually, you lose some of the features CloudFormation and CodePipeline give you, such as: Create/Update separation, artifact handling and uploading, BlueGreen deploys, etc. This is all still possible with this product, it's just DIY.
 - This does not contain a complex base or sample template (unless you choose the sample language/framework option). The example that ships with the base product is very basic and does not do much. You must implement any more complex functionality.
