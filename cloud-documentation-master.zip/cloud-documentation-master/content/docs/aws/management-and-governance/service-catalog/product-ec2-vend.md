---
title: EC2 Vending Machine
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [Whats included](#whats-included)
- [Order Fields](#order-fields)
    - [Common](#common)
    - [Instance Config](#instance-config)
    - [App and Access Config](#app-and-access-config)
    - [Standard Tag Values](#standard-tag-values)
- [Accessing Server](#accessing-server)
- [Patching](#patching)
- [Customization](#customization)

----

## What is it?
[Code can be viewed here.](https://github.nwie.net/Nationwide/CDT-SC-EC2-Pet)
EC2 vending machine is a new product intended for use with EC2 pet instances. It does not create a pipeline, provide IAC, etc. and instead just provisions an EC2 instance based on the provided input.


## Whats included
Unlike many of the other products, this one does not provide the user with a pipeline, IAC in their GitHub repo, etc. This product directly provisions an EC2 instance into the user's AWS account and sets it up for remote management.
There are various configuration options detailed below, but the primary down-side to this product currently is the lack of full configurability and flexibility.
If you have any ideas for other customizations for the EC2, please submit them as a feature request [here.](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md)

Created as part of the product is the following:
* Security Group
* Role + Instance Profile
* EC2 Instance
  * Will be launched with the latest Nationwide AMI for either Linux or Windows
  * WIll be joined to the NWIE domain and setup for remote management using either pAppAdmins and/or pServiceAccountAdmins (see more bellow)
  * Will have a single EBS volume (root volume) of the specified size


## Order Fields

#### Common
* **pProduct**: Standard pProduct value, used to generate resource names.
* **pEnvironment**: Dev/Test/Prod, the environment to deploy the instance into.
* **pRegion**: The region to deploy the instance into, currently only allows us-east-1

#### Instance Config
* **pOperatingSystem**: Windows/Linux, which operating system to launch the instance with. Will use the currently latest Nationwide AMI of the specified OS.
* **pInstanceType**: Size of the instance to launch. See [here](https://aws.amazon.com/ec2/instance-types/) for documentation on the different instance types and what they come with.
* **pRootVolumeSize**: Size of the base volume (C: or /) for the instance.

#### App and Access Config
* **pAppAdmins**: Used for both Windows and Linux; one or more AD groups that will have RDP/SSH access to the server.
* **pServiceAccountAdmins**: Used for Windows, ignore for Linux; used to specify any service accounts that need management acess to the server.
* **pCname**: Optional, DNS name on the .aws.e1.nwie.net domain to create for more convenient access to the server. Only provide the name (myname), not the full record (myname.aws.e1.nwie.net), the domain will be applied automatically.
* **pTrafficFromPort**: The "from" field in a port range that the application requires. The security group that gets created will use this and the next 2 fields to define the custom rule for any ports required and not included in the default security groups on the instance.
* **pTrafficToPort**: The "to" field in a port range that the application requires.
* **pTrafficProtocol**: The protocol (tcp/udp) for the port range to be opened in the security group.

#### Standard Tag Values
* **pShutDownInstanceAt**: Standard ShutDownInstanceAt tag, time value when the server should be automatically shut down at night to save cost (ex: 5pm UTC)
* **pPowerOnInstanceAt**: Standard PowerOnInstanceAt tag, time value when the server should be powered back on (ex: 4am UTC)
* **pDisbursementCode**: Disbursement code for the team/manager that owns and pays for the instance.
* **pResourceOwner**: Owner of the resource, either a team or individual, should map to an @nationwide.com email.
* **pAPRMID**: APRMID for the application.
* **pDataClassification**: Classification of data that will be stored on the instance, one of: Public_Data, Internal_Use_Only, Confidential, PCI


## Accessing Server
Integration with the standard NWIE domain for remote management is included by default in the EC2 instances launched from this product, wether Windows or Linux.

The fields noted above for AppAdmin and ServiceAccount are used to define who has access to either SSH or RDP into the server.

The setup for the servers launched from this product are the same as documented:

* [SSH For Linux](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/ssh-with-ec2/)
* [RDP For Windows](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/rdp-with-ec2/)


## Patching
All EC2 instances created with this product have the Patch tag set to True. This will result in the server being automatically patched using the standard on-prem patching process. No action needs to be taken by users.


## Customization
There is currently no path to customize the instance launched by this product beyond the settings included during the the ordering process. If you would like to use this to create a pet instance but need customization beyond what this offers, please submit a feature request [here](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=general_issue.md) noting what customizations you would require.
