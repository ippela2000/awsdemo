---
title: Serverless Step Function Pipeline
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [Whats Included](#whats-included)
  - [Pipeline stages defined](#pipeline-stages-defined)
    - [*Source*](#source)
    - [*BuildAndPackage*](#buildandpackage)
    - [{Account}](#account)
    - [{Account}_Approval](#accountapproval)
  - [Included Files and What They Do](#included-files-and-what-they-do)
- [How to Update Your Step Function](#how-to-update-your-step-function)
- [Troubleshooting specific steps](#troubleshooting-specific-steps)
- [Reminders](#reminders)

## What is it?
The Serverless Step Function Pipeline is a Service Catalog product that can be ordered via the AWS console. The purpose is to create
a pipeline to deploy a Step Function.
[What is a Step Function?](https://docs.aws.amazon.com/step-functions/latest/dg/welcome.html)

## Whats Included
[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Step-Function)

Serverless Step Function includes 1 pipeline for deployment of your step function. This pipeline deploys the step function and the IAM role for that state machine to each environment in your BSA.

Also included is the StepFunction.yaml file and its corresponding parameter files. This file contains the details of your step function as well as the tag that you will edit to change the body of the state machine.

Lastly, ProductRole.yaml and its corresponding parameter files contain the details of the IAM role for the step function deployed by the pipeline.

The base product DOES NOT include any lambdas or other resources to be called by the step function. They can be added in after ordering if needed.

OPTIONAL templates for:
  - S3: Cloudwatch event triggers Step Function from S3 object add*
  - DynamoDB & SQS: Step Function gets an item from DynamoDB and sends to SQS*
  - Scheduled Lambda: CloudWatch Event Cron Expression triggers Step Function with a lambda on a schedule*
    * *Each template comes wiht an SNS Step Function topic and notification        

### Pipeline stages defined
Below are the stages in this pipeline. The {Account} stages happen identically in your dev, test and prod BSA accounts.

#### *Source*
* **Application_Source** : This step watches an S3 bucket for new updates. When a change is checked into your github repo a Code Build (AWS Service) is kicked off to zip the contents of the repo and add it to the watched bucket. On change the pipeline will start.

#### *BuildAndPackage*
* **Update_CodePipeline** : Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)

#### {Account}
* **Deploy_ProductRole**: Deploys the role your step function will use in the dev account. This runs the ProductRole.yaml file, using the matching ProductRole-{Account}.json file to populate the parameters.
* **Deploy_StepFunction**: Deploys your step function to the dev account. This runs the StepFunction.yaml file, using the matching StepFunction-{Account}.json file.

#### {Account}_Approval
* **{Account}Approval**: Manual approval step before proceeding into the next environment. This can be commented out if you do not want to have to manually release your change into the next environment.

### Included Files and What They Do

- **iac/CloudFormation**
  - **CodePipeline.yaml**: Yaml file that represents deployment pipeline.
  - **CodePipeline.json**: Json file representing parameters for CodePipeline.yaml
  - **ProductRole.yaml**: Yaml file that represents IAM role for step function
  - **ProductRole-{Account}.json**: Json file repsresenting paramters for ProductRole.json for each environment
  - **StepFunction.yaml**: Yaml that represents your step function
  - **Stepfunction-{Account}.json**: Json file representing parameters for StepFunction.yaml
- **buildspec-gitint.yaml**: Used when the webhook is called to zip up the repo for the start of the Pipeline. Creates a deploy.zip that the Source stage of the pipeline then reads in.
- **iac/Cloudformation-{OPTIONAL FILES}**
  - **DynamoDB.json**: Json file representing parameters for DynamoDB.yaml
  - **DynamoDB.yaml**: Yaml file that defines the DynamoDB table
  - **SQS.json**: Json file representing parameters for SQS.yaml
  - **SQS.yaml**: Yaml file that defines the Simple Queue Service queue parameters
  - **EventTrigger.json**: Json file representing parameters for EventTrigger.yaml
  - **EventTrigger.yaml**: Yaml file that defines the role and Cloudwatch Rule (EventPattern for S3, and ScheduleExpression for Lambda)
  - **S3.json**: Json file representing parameters for S3.yaml
  - **S3.yaml**: Yaml file that defines the S3 bucket and bucket policy
  - **Lambda.json**: Json file representing parameters for Lambda.yaml
  - **Lambda.yaml**: Yaml file that defines the lambda and lambda role to be triggered by the Step Function

## How to Update Your Step Function

The body of your step function is in **StepFunction.yaml**. To change the Definition of your state machine, update the **DefinitionString** property of the rStepFunction resource. Step Function State Machines are written in the json-based Amazon States Language. Documentation on Amazon States Language can be found [here](https://docs.aws.amazon.com/step-functions/latest/dg/concepts-amazon-states-language.html).

## Troubleshooting specific steps

- Application_Source
  - This step will always be in a failed state when you first request your Pipeline. You need to merge the IAC branch into your branch specified to  kick off the pipeline, or make any change to the branch specified.
  - If you made a change and it is not kicking off, check the Github CodeBuild for your Pipeline in your BSA Tools account or InfraSvcsProd(legacy). Commits will kick off this CodeBuild to move your code to your Pipeline S3 bucket
  - Check your Github Webhook under repo settings, and then hook. This should be a green checkmark and never a red triangle. If it is a red triangle, you can select the webhook and then redeliver the most recent change.
- Update_CodePipeline
  - Cloudwatch logs can be found under the AWS Cloudwatch service. Under /aws/lambda/Scan_Update_CodePipeline
  - Make sure your CodePipeline.yaml is properly formatted and deploying correctly. Your Pipeline's cloudformation stack can be checked under the Cloudformation service in your BSA Tools account or InfraSvcsProd(legacy) and then you can search for your Pipeline name and find a stack similar to the following: {Product Name}-{BSA Name}-CodePipeline-us-east-1. You can view any Cloudformation errors for your Pipeline update here.
- Cloudformation in Dev{BSA}/Test{BSA}/Prod{BSA}
  - Need to login to the specific account to troubleshoot failed Cloudformation deployments
  - Validate Cloudformation in Dev account before adding it into the Pipeline!

## Reminders

The pipeline provided is a template that we have made to allow BSAs to hit the ground running with a pipeline. These Pipelines are 100% customizable (Within reason). You can also add actions to the pipelines and most applications will have customized Pipelines. Feel free to experiment and ask any questions in the [AWS Rocketchat channel](https://rocketchat.nwie.net/channel/AWS).
