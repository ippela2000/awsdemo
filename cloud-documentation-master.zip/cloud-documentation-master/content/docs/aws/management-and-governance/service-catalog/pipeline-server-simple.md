---
title: Server-Simple Pipeline
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included](#whats-included)
  - [Pipeline stages defined](#pipeline-stages-defined)
    - [*Source*](#source)
    - [*BuildAndPackage*](#buildandpackage)
    - [*Dev{Account}*](#devaccount)
    - [*Dev{Account}_Approval*](#devaccountapproval)
    - [*ServiceNow*](#servicenow)
  - [Github files defined](#github-files-defined)
    - [iac/Cloudformation](#iaccloudformation)
    - [iac/Packer](#iacpacker)
    - [Server-Simple-SampleApp](#server-simple-sampleapp)
- [How to add an application](#how-to-add-an-application)
- [How to make an application public](#how-to-make-an-application-public)
- [How to change your CI - BYOCI](#how-to-change-your-ci---byoci)
- [Troubleshooting Pipelines](#troubleshooting-pipelines)

----

## What is it?
![Server-Simple](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/SimpleServer.png)<br />
The Simple Server Pipeline creates the necessary infrastructure needed for a Simple EC2 (Windows and Linux) Application using a CD Pipeline. The difference between this pipeline and Simple-Cloudformation is the fact that this allows you to bake your app into an AMI before deploying.


## What's Included
[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Server-Simple)

### Pipeline stages defined
Below are the stages in this pipeline. The {Account} stages happen identically in your dev, test and prod BSA accounts.

#### *Source*
* **Application_Source** : This step watches an S3 bucket for new updates. When a change is checked into your github repo a Code Build (AWS Service) is kicked off to zip the contents of the repo and add it to the watched bucket. On change the pipeline will start.

#### *BuildAndPackage*
* **Update_CodePipeline** : Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)
* **Application_Build** : Runs the ‘-ci-‘ codebuild job to build your application. This directly runs the commands in your buildspec-ci.yaml file, explained further bellow.
* **Bake_AMI** : Runs the ‘-bake-‘ codebuild job to bake an AMI for your application to run on. This directly runs the commands your buildspec-bake.yaml file. Packer is used by default to install any dependencies and load any files onto the Nationwide base AMIs to create your application’s AMI.
* **Get_Pipeline_Artifacts** : Runs a script that pulls in various pieces of information from the currently pipeline executions’ artifacts and stores them in a Dynamo table. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Get_Pipeline_Artifacts)
* **Share_AMI** : Shares the AMI created in the Bake_AMI stage to all of your accounts (Dev/Test/Prod accounts in your BU stack) [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_AMI/Share_AMI)

#### *Dev{Account}*
* **Deploy_Security_Groups** : creates any security groups used for your instances or load balancers. These are your firewall rules for AWS
* **Deploy_Product_Roles** : creates Identity Access Management roles that can be used for your EC2 instances
* **Deploy_EC2** : creates a single EC2 instance using the baked AMI from above
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.

#### *Dev{Account}_Approval*
* **DevelopmentApproval** : This step is the manual gate check approval to verify that you want to deploy your application to the next environment

#### *ServiceNow*
These steps run before and after the production stage of this pipeline.
* **Create_Or_Update_ServiceNow** : a lambda function that is used by pipeline to create a resource in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)
* **Create_RFC** : a lambda function that is designed to be ran by AWS CodePipeline to create an RFC in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)


### Github files defined
* buildspec-appvalid.yaml - File that is used to run automated validation and tests after deployment into each environment
* buildspec-bake.yaml - Controls the AMI bake process. Location of were the foundational AMI is specified. Calls the files in iac/Packer
* buildspec-gitinit.yaml - Used when the webhook is called to zip up the repo for the start of the Pipeline
* buildspec-ci.yaml - Controls the Application Build step. Will have maven, npm commands, etc. for any application builds that need to happen. You can bring your own CI [How to change your CI (Bring your own CI, BYOCI)](#How-to-change-your-CI-BYOCI)
#### iac/Cloudformation
All infrastructure specific files will be deployed to the folder labeled **iac** (infrastructure as code).
* iac/CloudFormation/EC2.yaml - Cloudformation file that creates a single EC2 instance based off of the AMI baked in the pipeline. Logs the vital windows build processes via CloudFormation and is viewable in CloudWatch, for more information on where and what is logged follow this [HowTo-ViewWindowsLogs](https://github.nwie.net/Nationwide/Next-Gen-Infra/blob/gh-pages/pages/HowTo-ViewWindowsLogs) doc.
* iac/CloudFormation/EC2-{environment}.json - Parameter file per environment that contains variables per environment for the specified cloud formation
* CodePipeline.json & CodePipeline.yaml - paramater file and cloudformation file that controls every action in the Pipeline. Update this cloudformation file to add or remove steps from the pipeline
* iac/CloudFormation/ProductRole-{environment}.json - Environment specific parameters for the product role cloudformation
* iac/CloudFormation/ProductRole.yaml - Creates Identity Access Management roles for EC2 instances
* iac/CloudFormation/SecurityGroup-{environment}.json - Environment parameters for the security group cloudformation
* iac/CloudFormation/SecurityGroup.yaml - Creates EC2 instance security group, and Loadbalancer security group
#### iac/Packer
* iac/Packer/etc/awslogs/ - Folder that contains log configuration
* iac/Packer/packerfile.json - Packer configuration file for how to build and bake the AMI in the Bake_AMI step. Under the provisioners section additional scripts can be added here, as well as moving any items from the Application_Codebuild step
##### Linux
*	iac/Packer/install_aws_services.sh - Installs the Code Deploy agent in the AMI bake process
*	iac/Packer/install_application-template.sh - Can be modified to run any application configuration or installation that can be done in the AMI bake process. This will be something that is set for every environment.
##### Windows
*   iac/Packer/packer_userdata.ps1 - Updates the windows firewall to support WinRM connections from packer.
*	iac/Packer/install_aws_services.ps1 - Installs the Code Deploy agent in the AMI bake process
*	iac/Packer/install_dependencies.ps1 - Can be modified to run any application configuration or installation that can be done in the AMI bake process. This will be something that is set for every environment.


#### Server-Simple-SampleApp
##### Linux
*	Server-Simple-SampleApp/src-hello-world/main/java/com/mycompany/app - Java app that gives string response of “Congratulations on a successful pipeline!”
*	Server-Simple-SampleApp/src-hello-world/test/java/com/mycompany/app - unit test for Sample app listed above
*	Server-Simple-SampleApp/pom-hello-world.xml - defines compile process for the sample java app defined above
##### Windows
*	Server-Simple-SampleApp/index.html - html page that displays "Congrats on a successful deployment of a Windows {Product} pipeline!"
*   iac/Packer/install_dependencies.ps1 - Installation occurs here, copies executable script from bucket, creates Windows Service, Windows service runs EC2 as a webserver listening on port 80 

NOTE: This sample app creates a web server listening on port 80 for health checks by the load balancer on initial product order. The app lives as a service by creating a Windows service titled SampleApp in the Windows Services. To use port 80 for your app or services please comment out or remove the code in install_dependencies.ps1.


## How to add an application

In order to add your application to the pipeline you have to make changes to these three files:

1) buildspec-ci.yaml - This file defines how the application will be built. The sample provided uses maven to compile a .jar file and outputs the resultant jar file. <br />
2) iac/Packer/packerfile.json - This file defines the bake process and tells packer what to install into your AMI. The sample provided just installs java using yum (and the default install_aws_services which should stay regardless of your customizations.) <br />
3) *Linux* **iac/Packer/install_application.sh** used when there is a silent or automated install, in packer it needs to be moved to the final location.<br />
4) *Windows* **iac/Packer/install_dependencies.ps1** used when there is a silent or automated install; in packer it needs to be moved to the final location. To use port 80 for your app or services please comment out or remove the code.

## How to make an application public
- [Using an application load balancer](https://pages.github.nwie.net/Nationwide/Next-Gen-Infra/pages/Howto-WAF/)

## How to change your CI - BYOCI
**If you choose this route you will be responsible for owning and troubleshooting.**

If you want to bring your own CI (like Jenkins), that can be done. Make sure the following is being done:
* Make sure your current Jenkins build is storing your artifacts in Nexus.
* In your Application_Build step, in the pipeline, you can modify the buildspec-ci.yaml to download the artifact from Nexus instead of doing a full application build at this stage.
* Can be done with a curl command to the location of the artifact in Nexus.
  * You may need to use the maven-dependency-plugin when working with SNAPSHOTS

## Troubleshooting Pipelines

* Remember what environment you are troubleshooting in. If Cloudformation is being run to deploy something into the BSA's Dev account. You will want to look in the Dev account Cloudformation stacks to see any errors. If it is built in Lambda calls from the base template those will most likely be running in InfraSvcs and can looked at in the Cloudwatch logs which can be gotten to from the details in the step of the Pipeline
* Do not copy the CodePipeline.json file between accounts when moving iac contents. This contains Pipeline specific settings. If you want to duplicate the actions of a Pipeline move the CodePipeline.yaml file to the new repo.
* Use Splunk Cloud. Logs will be going into Splunk Cloud so if you get specific request errors you can search for them in Splunk to get more information. Very useful for troubleshooting S3 access denies which will help with showing the role that is trying to access the bucket as well as the specific bucket location

Troubleshooting specific steps:
* Application_Source
    * This step will always be in a failed state when you first request your Pipeline. You need to merge the IAC branch into your branch specified to kick off the pipeline, or make any change to the branch specified.
    * If you made a change and it is not kicking off, check the Github CodeBuild for your Pipeline in your BSA Tools account or InfraSvcsProd(legacy). Commits will kick off this CodeBuild to move your code to your Pipeline S3 bucket
    * Check your Github Webhook under repo settings, and then hook. This should be a green checkmark and never a red triangle. If it is a red triangle, you can select the webhook and then redeliver the most recent change.
* Update_CodePipeline
    * Cloudwatch logs can be found under the AWS Cloudwatch service. Under /aws/lambda/Scan_Update_CodePipeline
    * Make sure your CodePipeline.yaml is properly formatted and deploying correctly. Your Pipeline's cloudformation stack can be checked under the Cloudformation service in your BSA Tools account or InfraSvcsProd(legacy) and then you can search for your Pipeline name and find a stack similar to the following: {Product Name}-{BSA Name}-CodePipeline-us-east-1. You can view any Cloudformation errors for your Pipeline update here.
* Application_Build
    * Select details and the execution details to see the logs of the temporary Docker image.
    * Controlled by your Buildspec-ci.yaml
* Bake_AMI
    * Select details and the execution details to see the logs of the temporary Docker image as well as Packer executions.
    * Controlled by Buildspec-bake.yaml. This also calls files from your iac/Packer folder and runs what is specified.
    * If accessing an S3 bucket in Packer make sure you have an IAM Instance profile assigned
    * Validate your installation scripts on an Instance before adding to a Pipeline to troubleshoot.
* Cloudformation in Dev{BSA}/Test{BSA}/Prod{BSA}
    * Need to login to the specific account to troubleshoot failed Cloudformation deployments
    * Validate Cloudformation in Dev account before adding it into the Pipeline!
