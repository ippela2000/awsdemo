---
title: Static Website Cloudfront S3 Pipeline
menu: docs
category: aws
---

## What is it?
The Static Website Cloudfront S3 pipeline is a Service Catalog product that can be ordered via the AWS console. The pipeline
creates a Cloudfront distribution and the necessary S3 origin and logging buckets in dev, test and prod, as well
as providing a CodeBuild in your BSA's Tools account for automated uploads to your s3 buckets in higher environments. It
also creates and deploys a Lambda@Edge function to apply security HTTP headers.


## Architecture
AWS CloudFront, WAF, and S3 services should be used together to host static S3 sites.  CloudFront hosts the site's
fully qualified domain name (FQDN) and can optionally cache content to AWS regions.  The use of CloudFront is required as
it is the only mechanism to put a web application firewall (WAF) policy in front of the site to protect against web attacks.
In addition, using CloudFront prevents the need to make the S3 bucket's policy public. Cloudfront sites are also externally hosted.


When HTTP(s) requests are made to access page content, client initiated traffic will be routed to CloudFront via DNS.
CloudFront's WAF policy will inspect traffic before responding with cached content or forwarding traffic to the origin S3 bucket.
Traffic from a client to Cloudfront and from Cloudfront to the origin S3 bucket must be encrypted HTTPS traffic.
Client HTTP requests must be redirected to HTTPS at the CloudFront distribution so no HTTP traffic should ever hit the S3 origin.


## Whats Included

[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Cloudfront-S3)

Static Website Cloudfront S3 includes 1 pipeline for deployment of your distribution and s3 buckets as well as a CodeBuild
in your BSA's tools accounts.

### Pipeline stages defined

#### *Source*

* **Application_Source**: This step watches an S3 bucket for new updates. When a change is checked into your github repo
a Code Build (AWS Service) is kicked off to zip the contents of the repo and add it to the watched bucket. On change the
pipeline will start.

#### *BuildAndPackage*

* **Update_CodePipeline**: Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in
your iac/CloudFormation folder.
[Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)

#### *Dev{Account}*

* **Deploy_S3_Buckets**: Deploys a cloudformation stack to your BSA's dev account that creates an origin S3 bucket for your 
Cloudfront distribution, origin access identity (OAI) for the distribution, and a logging S3 bucket for your distribution as well as bucket policies for both buckets.
* **Deploy_Content_To_S3**: This is a codebuild job that will upload files to your dev origin S3 bucket from the src folder
of your github repo and can also be used to run node commands for angular sites or other commands.
* **Deploy_Cloudfront**: Deploys a cloudformation stack to your BSA's dev account that creates a Cloudfront Distribution. 
Additionally, this stage deploys a Lambda@Edge function with its IAM role and a Lambda version. This function will apply the 
required security HTTP headers to responses from your distribution and can be edited within the cloudfront.yaml file.

#### *Dev{Account}_Approval*

* **DevelopmentApproval** : This step is the manual gate check approval to verify that you want to deploy your application
to the next environment

#### *Test{Account}*

* **Deploy_S3_Buckets**: Deploys a cloudformation stack to your BSA's test account that creates an origin S3 bucket for your 
Cloudfront distribution, origin access identity (OAI) for the distribution, and a logging S3 bucket for your distribution as 
well as bucket policies for both for both buckets.
* **Deploy_Content_To_S3**: This is a codebuild job that will upload files to your test origin S3 bucket from the src folder
of your github repo and can also be used to run node commands for angular sites or other commands.
* **Deploy_Cloudfront**: Deploys a cloudformation stack to your BSA's test account that creates a Cloudfront Distribution. 
Additionally, this stage deploys a Lambda@Edge function with its IAM role and a Lambda version. This function will apply the 
required security HTTP headers to responses from your distribution and can be edited within the cloudfront.yaml file.

#### *Test{Account}_Approval*

* **TestApproval** : This step is the manual gate check approval to verify that you want to deploy your application
to the next environment

#### *Prod{Account}*

* **Deploy_S3_Buckets**: Deploys a cloudformation stack to your BSA's prod account that creates an origin S3 bucket for your 
Cloudfront distribution, origin access identity (OAI) for the distribution, and a logging S3 bucket for your distribution as 
well as bucket policies for both for both buckets.
* **Deploy_Content_To_S3**: This is a codebuild job that will upload files to your test origin S3 bucket from the src folder
of your github repo and can also be used to run node commands for angular sites or other commands.
* **Deploy_Cloudfront**: Deploys a cloudformation stack to your BSA's prod account that creates a Cloudfront Distribution. 
Additionally, this stage deploys a Lambda@Edge function with its IAM role and a Lambda version. This function will apply the 
required security HTTP headers to responses from your distribution and can be edited within the cloudfront.yaml file.

### Github files defined

The following are definitions to all files deployed to the github repo associated with the ordered service catalog
product Static-Website-Cloudfront-S3. These files get added to your repo during the provisioning of your static website
pipeline.

**buildspec**

* buildspec-gitint.yaml - Used when the webhook is called to zip up the repo for the start of the Pipeline
* buildspec-s3upload.yaml - Codebuild script to upload files to your origin S3 buckets in each account. Edit this file
to change what is being uploaded to your origin buckets.

**iac/Cloudformation**

This will be where the infrastructure as code will be for your pipeline.
* iac/Cloudformation/CodePipeline.yaml - Yaml file that represents deployment pipeline.
* iac/Cloudformation/CodePipeline.json - Json file representing parameters for CodePipeline.yaml.
* iac/Cloudformation/Cloudfront.yaml - Yaml file with cloudformation for the Cloudfront distribution, OAI and bucket
policy update. This file also contains the Lambda@Edge function and its IAM role and Lambda version.
* iac/Cloudformation/Cloudfront-{environment}.json - Json file with parameters for the Cloudfront.yaml cloudformation.
* iac/Cloudformation/S3Buckets.yaml - Yaml file with cloudformation for the origin and logging S3 buckets and their respective 
bucket policies as well as the origin access identity that is needed for the Cloudfront distribution to acces your origin bucket.
* iac/Cloudformation/S3Buckets-{environment}.json - Json file with parameters for the S3Buckets.yaml cloudformation.

**src**

This will be where the source files for your static website will go
* index.html - Sample html page that serves as the default root object for the Cloudfront.yaml file, this is just a sample
and should be removed/replaced by your static website's code. You may update the name/location of the default root object
in the Cloudfront.yaml file.

## How To Delete

Because this product contains a Lambda@Edge function, the delete procedure is different than other Service Catalog products.
Lambda@Edge functions are replicated in all regions and thus cannot be immediately deleted like any other Lambda function.
To be able to delete your provisioned product you will first need to update the Cloudfront.yaml code to remove the lambda
association for your Cloudfront distribution and let the pipeline run through. By disassociating your Lambda@Edge function
from your Cloudfront distribution AWS will begin to remove the regional replications of the lambda and allow the main
function to be deleted. However, this process may take up to several hours and Amazon provides no updates for when it is
completed. It is recommended that you remove the association and then wait at least one day before deleting the provisioned
product.

## Create a friendlyname in Route53

You can add a friendly DNS in Route53 to a cloudfront distribution using the ```Type: Custom::RemoteRoute53``` function

```
          rAddCNAME:
            Condition: TestOrProd
            Type: Custom::RemoteRoute53
            Properties:
              ServiceToken: !Sub "arn:aws:lambda:us-east-1:${AWS::AccountId}:function:RemoteRoute53"
              Account: !Sub "${AWS::AccountId}"
              RecordType: CNAME # A and PTR are not currently supported
              RecordName: !Ref pCname # just the name e.g 'media'
              RecordValue: !GetAtt myDistributionTest.DomainName
              Public: true
```

This will give you a record of **{pCname}.awspubliccloud.nationwide.com** e.g. **media.awspubliccloud.nationwide.com**


## How to get an External SSL Certificate

* You will have to get an external SSL certificate and add the CNAME/Alias & Certificate together to the CF distribution.
* Follow the instructions on [SSLPublicCertificate](/docs/aws/cryptography/howto-publiccert) to get public certificate and import it into the relevant AWS account in ACM.


## How to associate the certificate to the distribution

* Once the ARN is uploaded into ACM copy the arn of the certificate and add it to the CloudFormation of CloudFront as reference by **!Ref pCertificateArn** in the code below.
* Also associate the friendly DNS created in route53 earlier with the CF distribution as referenced by **!Ref pFriendlyDomainName** e.g. **media.awspubliccloud.nationwide.com** in the code below.

 ```
            rDistribution:
                Type: AWS::CloudFront::Distribution
                Properties:
                  DistributionConfig:
                    ViewerCertificate: !If
                      - TestOrProd
                      - AcmCertificateArn: !Ref pCertificateArn
                        MinimumProtocolVersion: TLSv1.1_2016
                        SslSupportMethod: sni-only
                      - !Ref AWS::NoValue
                    Origins:
                    - DomainName: !Sub "${pOriginBucket}.s3.amazonaws.com"
                      Id: !Sub "${pProduct}Origin"
                      S3OriginConfig:
                        OriginAccessIdentity: !Sub "origin-access-identity/cloudfront/${rOriginAccessIdentity}"
                    Enabled: True
                    Aliases: !If
                      - TestOrProd
                        - !Ref pFriendlyDomainName
                      - !Ref AWS::NoValue
                    DefaultRootObject: index.html
                    Logging:
                      IncludeCookies: False
                      Bucket: !Sub "${pLogBucket}.s3.amazonaws.com"
                    DefaultCacheBehavior:
                      TargetOriginId: !Sub "${pProduct}Origin"
                      ForwardedValues:
                        QueryString: False
                        Cookies:
                          Forward: none
                      ViewerProtocolPolicy: redirect-to-https
                    PriceClass: PriceClass_100

   ```


## Example Git Repo

Below are come examples of applications who have implemented CloudFront
- PLDS-SRE App
    - [CloudFront](https://github.nwie.net/Nationwide/PLDS-SRE-AWS-IAC)
    - [Lambda](https://github.nwie.net/Nationwide/PLDS-Servicing-Lambdas)
- DGS-Sales App
    - [CloudFront](https://github.nwie.net/Nationwide/dgs-sales-life-ui-refresh/tree/develop)


## Cloudfront FAQ

#### FAQ

* Why was an **AWS WAF Web ACL** added to my distribution?

The AWS WAF Web ACL is required for all Cloudfront distributions at Nationwide and is applied automatically. This is
for protecting the site against web attacks.

* Why are no logs are showing up in my logging bucket?

Currently the logging buckets that are created are for future use dependent on a security exception, please leave them
in your pipeline for now, release notes will be made when this is available.

* Why must AES-256 encryption be used for the origin bucket?

Cloudfront does not support KMS encryption, only AES-256.

* Can I add a nwie.net domain to Cloudfront?

No, Cloudfront is an external domain and nwie.net should not be used or configured on external domains.

* Why can't the "Best Performance" price class be used?

Nationwide only does business in the United States. The best performance price class will use every region as a
Cloudfront CDN which is not needed for any of our applications. The US, Canada, and Europe one has been approved
by IRM/Legal to be used.

* How should I go about clearing the Cloudfront cache after updating my application?

It is recommended to have this as part of your Codebuild job that moves your application over to the S3 bucket to run an AWS
CLI command to invalidate the cloudfront cache. Wildcards can be used to clear multiple files and for pricing Wildcards
are cheaper then specific files, but can have a larger initial page load by users.
[Here](https://docs.aws.amazon.com/cli/latest/reference/cloudfront/create-invalidation.html#create-invalidation) is the
documentation on invalidating the cache using the CLI.

## Troubleshooting specific steps

- Application_Source
  - This step will always be in a failed state when you first request your Pipeline. You need to merge the IAC branch into your branch specified to  kick off the pipeline, or make any change to the branch specified.
  - If you made a change and it is not kicking off, check the Github CodeBuild for your Pipeline in your BSA Tools account or InfraSvcsProd(legacy). Commits will kick off this CodeBuild to move your code to your Pipeline S3 bucket
  - Check your Github Webhook under repo settings, and then hook. This should be a green checkmark and never a red triangle. If it is a red triangle, you can select the webhook and then redeliver the most recent change.
- Update_CodePipeline
  - Cloudwatch logs can be found under the AWS Cloudwatch service. Under /aws/lambda/Scan_Update_CodePipeline
  - Make sure your CodePipeline.yaml is properly formatted and deploying correctly. Your Pipeline's cloudformation stack can be checked under the Cloudformation service in your BSA Tools account or InfraSvcsProd(legacy) and then you can search for your Pipeline name and find a stack similar to the following: {Product Name}-{BSA Name}-CodePipeline-us-east-1. You can view any Cloudformation errors for your Pipeline update here.
- Cloudformation in Dev{BSA}/Test{BSA}/Prod{BSA}
  - Need to login to the specific account to troubleshoot failed Cloudformation deployments
  - Validate Cloudformation in Dev account before adding it into the Pipeline!
- CodeBuild jobs
  - Your CodeBuild exists in your BSA's Tools Account with the naming format "{Provisioned Product Name}-{BSA}-S3Upload-us-east-1"
  - After you open your code build in the console you will be able to see the logs of all executions to debug.
