---
title: Serverless Pipeline
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included](#whats-included)
  - [Pipeline stages defined](#pipeline-stages-defined)
    - [*Source*](#source)
    - [*BuildAndPackage*](#buildandpackage)
    - [*ServiceNow*](#servicenow)
    - [*Dev{Account}*](#devaccount)
    - [*Dev{Account}_Approval*](#devaccountapproval)
    - [*Test{Account}*](#testaccount)
    - [*Test{Account}_Approval*](#testaccountapproval)
    - [*Prod{Account}*](#prodaccount)
    - [*ServiceNowProd*](#servicenowprod)
  - [Github files defined](#github-files-defined)
- [How to make an application public](#how-to-make-an-application-public)

----

## What is it?
![Serverless](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/ServerlessSimple.png)
This pipeline creates the AWS services needed for deploying an application on a completely serverless infrastructure. That means not managing EC2s and a lower bill. The "Serverless" Service Catalog product provides options for multiple Lambda function language examples (Go, Java, Node.js, or Python) and also ingress resources (no ingress, API Gateway or Loadbalancer). AWS's services Lambda and API Gateway (or Load Balancer) provides the developers the ability to get their applications off of EC2s and callable via API. For more information on AWS services Lambda, API Gateway and ALB (Application Load Balancer) please read the following documentation:

[What is Lambda?](https://docs.aws.amazon.com/lambda/latest/dg/welcome.html)<br/>
[What is API Gateway?](https://docs.aws.amazon.com/apigateway/latest/developerguide/welcome.html)<br/>
[What is an Application Load Balancer?](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html)

## What's Included
[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Serverless)

### Pipeline stages defined
#### *Source*
* **Application_Source** : This step watches an S3 bucket for new updates. When a change is checked into your github repo a Code Build (AWS Service) is kicked off to zip the contents of the repo and add it to the watched bucket. On change the pipeline will start.

#### *BuildAndPackage*
* **Update_CodePipeline** : Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)
* **Application_Build** : code build job used to build the application, uses the buildspec-ci.yaml file
* **code_Build** : code build job used to build the serverless application, uses the buildspec-serverless.yaml file
* **Get_Pipeline_Artifacts** : Runs a script that pulls in various pieces of information from the currently pipeline executions’ artifacts and stores them in a Dynamo table. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Get_Pipeline_Artifacts)

#### *ServiceNow*
These steps run before and after the production stage of this pipeline.
* **Create_Or_Update_ServiceNow** : a lambda function that is used by pipeline to create a resource in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)
* **Create_RFC** : a lambda function that is designed to be ran by AWS CodePipeline to create an RFC in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)

#### *Dev{Account}*
* **Deploy_Lambda** : deploys the cloudformation script Lambda.yaml, which is a lambda that validates proper EC2 security groups
* **Deploy_API_Gateway** : deploys the cloudformation script ApiGateway.yaml, which creates the AWS's API Gateway resource
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.
*
* **OR** (for LoadBalancer)
*
* **Deploy_Lambda** : deploys the cloudformation script Lambda.yaml, which creates the Lambda resources
* **Deploy_SecurityGroup** : deploys the cloudformation script SecurityGroup.yaml, which creates the Security Group
* **Deploy_LoadBalancer** : deploys the cloudformation script LoadBalancer.yaml, which creates the ALB resources (including listener and default TargetGroup)
* **Deploy_Target_Group** : calls a custom (Lambda) resource to connect the listener and target group to a Lambda function
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.

#### *Dev{Account}_Approval*
* **DevelopmentApproval** : This step is the manual gate check approval to verify that you want to deploy your application to the next environment

#### *Test{Account}*
* **Deploy_Lambda** : deploys the cloudformation script Lambda.yaml, which is a lambda that validates proper EC2 security groups
* **Deploy_API_Gateway** : deploys the cloudformation script ApiGateway.yaml, which is creates the AWS's API Gateway resource
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.
*
* **OR** (for LoadBalancer)
*
* **Deploy_Lambda** : deploys the cloudformation script Lambda.yaml, which creates the Lambda resources
* **Deploy_SecurityGroup** : deploys the cloudformation script SecurityGroup.yaml, which creates the Security Group
* **Deploy_LoadBalancer** : deploys the cloudformation script LoadBalancer.yaml, which creates the ALB resources (including listener and default TargetGroup)
* **Deploy_Target_Group** : calls a custom (Lambda) resource to connect the listener and target group to a Lambda function
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.

#### *Test{Account}_Approval*
* **TestApproval** : This step is the manual gate check approval to verify that you want to deploy your application to the next environment

#### *Prod{Account}*
* **Deploy_Lambda** : deploys the cloudformation script Lambda.yaml, which is a lambda that validates proper EC2 security groups
* **Deploy_API_Gateway** : deploys the cloudformation script ApiGateway.yaml, which is creates the AWS's API Gateway resource
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.
*
* **OR** (for LoadBalancer)
*
* **Deploy_Lambda** : deploys the cloudformation script Lambda.yaml, which creates the Lambda resources
* **Deploy_SecurityGroup** : deploys the cloudformation script SecurityGroup.yaml, which creates the Security Group
* **Deploy_LoadBalancer** : deploys the cloudformation script LoadBalancer.yaml, which creates the ALB resources (including listener and default TargetGroup)
* **Deploy_Target_Group** : calls a custom (Lambda) resource to connect the listener and target group to a Lambda function
* **Application_Validation** : runs any automated validation from the buildspec-appvalid.yaml. If no validation is in here, this can be left empty and validation can be done manually before going to the next environment.

#### *ServiceNowProd*
* **Close_RFC** : lambda function that is designed to be run by AWS CodePipeline to close an RFC in ServiceNow.

### Github files defined
The following are definitions to all files deployed to the github repo associated with the ordered service catalog product Serverless. These files get added to your repo during the provisioning of your Serverless Pipeline.

* buildspec-appvalid.yaml - File that is used to run automated validation and tests after deployment into each environment
* buildspec-gitinit.yaml - Used when the webhook is called to zip up the repo for the start of the Pipeline
* buildspec-serverless.yaml - code build script for apps, filled with sample app upon creation of pipeline.

**Serverless-SampleApp**
* Serverless-SampleApp/src/main.py - Basic lambda function that returns Hello World.
* Serverless-SampleApp/src/requirements.txt - text file that defines requests.
* Serverless-SampleApp/test/test_lambda.py - unit test for the main.py to assure its working

* **NOTE** - You will get a directory src/main/java/example instead of Serverless-SampleApp if you pick Java as the example language.

**iac/Cloudformation**
* iac/Cloudformation/CodePipeline.json & CodePipeline.yaml - paramater file and cloudformation file that controls every action in the Pipeline. Update this cloudformation file to add or remove steps from the pipeline
* iac/CloudFormation/Lambda-{environment}.json - Environment specific parameters for the lambda cloudformation yaml file
* iac/CloudFormation/Lambda.yaml - Cloudformation file that creates the lambda based on the provided parameters in the Lambda-{environment}.json file.
* **For API Gateway**
* iac/Cloudformation/ApiGateway-{environment}.json - Environment specific parameters for the Api Gateway cloudformation yaml file
* iac/Cloudformation/ApiGateway.yaml - file that creates the API gateway resource required for serverless architecture
* **For LoadBalancer**
* iac/Cloudformation/LoadBalancer-{environment}.json - Environment specific parameters for the Load Balancer cloudformation yaml file
* iac/Cloudformation/LoadBalancer.yaml - file that creates the Load Balancer resource required for serverless architecture
* iac/Cloudformation/SecurityGroup-{environment}.json - Environment specific parameters for the Security Group cloudformation yaml file
* iac/Cloudformation/SecurityGroup.yaml - file that creates the Security Group resource required for serverless architecture

## How to make an application public
- [Using an application load balancer](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/setting-up-internet-facing-apps/)
