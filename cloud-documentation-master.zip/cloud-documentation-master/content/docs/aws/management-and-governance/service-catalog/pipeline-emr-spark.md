---
title: EMR-Spark Pipeline
menu: docs
category: aws
---
![EMRSpark](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/emrspark.png)
## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included?](#whats-included)
  - [Pipeline Stages Defined](#pipeline-stages-defined)
    - [*Source*](#source)
    - [*BuildAndPackage*](#buildandpackage)
    - [*{Env}{BSA}*](#envbsa)
  - [Github files defined](#github-files-defined)

----

## What is it?
EMR-Spark is a Service Catalog product that deploys an AWS EMR cluster for running Apache Spark. EMR's are a managed Hadoop framework used for building Data Lakes and processing Big Data. Apache Spark is an open-source distributed general-purpose cluster-computing framework. Spark provides an interface for programming entire clusters with implicit data parallelism and fault tolerance. These EMRs are also able to be connected to via Amazon EMR Notebooks, click here for more information on how to use [Amazon EMR Notebooks](https://docs.aws.amazon.com/emr/latest/ManagementGuide/emr-managed-notebooks.html). For more information on EMRs do's and don'ts follow our [How-To-EMR](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/how-to-emr/) doc.

## What's Included?
When you order the EMR-Spark Service Catalog product you will receive:
* a pipeline
* an S3 bucket
  - *ProductName*-sparkapplogs-us-east-1-*AccountNumber*
* an EMR (1 master and 2 nodes)
  - The EMR name will also be your *ProductName*

### Pipeline Stages Defined
Below are the stages in your pipeline:

#### *Source*
* **Application_Source**: Pulls in the deploy.zip from the pipeline-artifact-563161085545-us-east-1 bucket, which is the entire contents of your repo zipped up.

#### *BuildAndPackage*
*  **Update_Codepipeline**: Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder.

#### *{Env}{BSA}*
* **Deploy_SecurityGroup**: Deploys the security group for your EMR in the account in the stage name. This runs the SecurityGroup.yaml file, using the matching SecurityGroup.json file to populate the parameters.
* **Deploy_ProductRole**: Deploys the role your ec2 instances will use in the account in the stage name. This runs the ProductRole.yaml file, using the matching ProductRole.json file to populate the parameters.
* **Deploy_SparkAppLogBucket**: Deploys three S3 buckets that are required for the EMR. The 3 buckets are sparkoutput, sparkartifact, and sparkappslogs. The naming convention is defined above. The *ProductName*-sparkapplogs-us-east-1-*AccountNumber* bucket will be the desired location for all of the app logs.
* **Deploy_EMR**: Deploys the desired EMR. This runs the EMR.yaml file, using the matching EMR.jsn file to populate the parameters.

### Github files defined

*iac/CloudFormation*
* **CodePipeline.json** & **CodePipeline.yaml**: Cloudformation file that controls every action in the Pipeline. Update this cloudformation file to add or remove steps from the pipeline.
* **EMR.json**: parameter file for the EMR.yaml file. Contains parameters
* **EMR.yaml**: Cloudformation file that creates the the EMR based on the notebook other parameters provided in the EMR.json.
* **ProductRole.json**: parameter file for the KinesisStream.yaml. Contains parameters:
  - *pProduct*: name that is used when name the product role.
  - *pEnvironment*: location where the role will be deployed.
  - *pRegion*: aws region
* **ProductRole.yaml**: Cloudformation that deploys the role for the EMR S3 buckets.
* **SecurityGroup.json**: parameter file for SecurityGroup.yaml. Contains parameters:
  - *pProduct*: named used to create the securitygroup.yaml
  - *pDisbursementCode*: Users Disbursement code
  - *pResourceOwner*: User(s) who ordered the product
  - *pAPRMID*: Users APRMID
  - *pResourceName*: filled in with the products name
  - *pEnvironment*: Environment where the security group will be deployed
* **SecurityGroup.yaml**: Cloudformation that deploys the security group related to the EMR nodes
* **SparkAppLogBucket.json**:  parameter file for SparkAppLogBucket.yaml. Contains parameters:
  - *pProduct*: name used to create the prefix to the three s3 buckets.
  - *pProductNameLower*: the pProduct variable but in lower case, required for bucket creation.
  - *pEnvironment*: location of the S3 buckets.
  - *pPipelineRole*: codepipeline action role n
  - *pAdminRole*: CDT admin role
  - *pAccessRole*: the ProductRole created in Deploy_ProductRole stage
  - *pResourceOwner*: User(s) who ordered product
  - *pAPRMID*: Users APRMID
  - *pDataClassification*: Classification of the data
  - *pDisbursementCode*: Users Disbursement code
* **SparkAppLogBucket.yaml**: Cloudformation file that deploys the an S3 bucket required for EMR.
