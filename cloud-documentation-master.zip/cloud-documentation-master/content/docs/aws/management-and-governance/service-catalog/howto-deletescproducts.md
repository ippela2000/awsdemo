---
title: The deletion of Service Catalog products
menu: docs
category: aws
---

## How to delete Service Catalog products

To delete your Service Catalog products please follow the following procedure:
1) Log into you AWS role that you ordered the Service Catalog product from (InfraSvcsProd-CodePipeline or Tools(yourBSA)-CODEPIPELINE)<br />
  example:<br />
  ![infraCodepipeline](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/Infracodepipeline.png)<br />
  ![toolsbsa](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/toolsbsa.png)<br />
2) Search for the service "Service Catalog"<br />
  ![SC](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/SC.png)
3) On the left, select Provisioned products list<br />
![PP](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/provProducts.png)
4) Select the desired product<br />
![SP](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/selectProduct.png)
5) In the top right, select Actions and then Terminate<br />
![Term](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/terminate.png)
6) Please note, if your unneeded Service Catalog product has deployed resources to Prod, this will not delete those Prod resources, to delete those Prod resources, send a Service Now ticket to the
[Cloud-Solutions](https://nwproduction.service-now.com/nav_to.do?uri=%2Fincident.do%3Fsys_id%3D-1%26sysparm_query%3Dactive%3Dtrue%26sysparm_stack%3Dincident_list.do%3Fsysparm_query%3Dactive%3Dtrue) group.<br />
![SC](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/SN.png)
![sd](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/shortdesc.png)
  * 1 *Contact* = Your name or resource owners name
  * 2 *CI name* = Your CI name
  * 3 *Impact* = small
  * 4 *Urgency* = Medium
  * 5 *Assignment Group* = Cloud-Solutions
  * 6 *Incident Owning Group* = Your Service Now Group
  * 7 *Short Description* = List the resources and which prod account these resources are located in
