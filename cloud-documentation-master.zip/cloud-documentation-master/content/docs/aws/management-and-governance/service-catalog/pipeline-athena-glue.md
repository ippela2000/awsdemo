---
title: Athena-Glue Pipeline
menu: docs
category: aws
---
## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included](#whats-included)
  - [Pipeline stages defined](#pipeline-stages-defined)
    - [Source](#source)
    - [BuildAndPackage](#buildandpackage)
    - [Dev{Account}](#devaccount)
    - [Dev{Account}_Approval](#devaccountapproval)
  - [Github File Overview](#github-file-overview)
    - [iac/Cloudformation](#iaccloudformation)
- [Troubleshooting Pipelines](#troubleshooting-pipelines)
- [Troubleshooting Pipelines](#troubleshooting-pipelines-1)

## What is it?
This product is for creating Glue jobs, S3 Buckets and Athena tables to Extract, Transform and Load data and make it viewable.


## What's Included
[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-AthenaGlue)

The Athena Glue Pipeline launches a CodePipeline that creates several resources: an input S3 bucket that will contain your raw data, a Glue Crawler that will automatically go through your data-filled S3 bucket and create a Glue table based on found metadata, a Glue database for the newly made Glue table, and a sample Athena query which will let users access and perform operations on their Glue data through SQL queries.

### Pipeline stages defined

#### Source

* **Application_Source** : This step watches an S3 bucket for new updates. When a change is checked into your github repo a Code Build (AWS Service) is kicked off to zip the contents of the repo and add it to the watched bucket. On change the pipeline will start.

#### BuildAndPackage

* **Update_CodePipeline** : Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)

#### Dev{Account}

* **Deploy_IAM_Roles** : creates Identity Access Management roles that are used by the resources made later on by the pipeline.
* **Deploy_S3** : creates an S3 bucket in the corresponding account that you can use to store your data for queries.

* **Deploy_GlueDB** : creates a few Glue resources, specifically a Glue database and a Glue crawler. The crawler should automatically point to the S3 bucket made in the previous step. Once you put data into the S3 bucket, you can run the crawler to automatically create a Glue table with metadata about your files.

#### Dev{Account}_Approval

* This step is the manual gate check approval to verify that you want to deploy your application to the next environment

The following steps in Test and Production will end up being a mimic of what is included in Dev Environment to have the same steps be followed to deploy something in every environment and using the same code.

### Github File Overview

The following are definitions to all files deployed to the github repo associated with the ordered service catalog product Athena-Glue. These files get added to your repo during the provisioning of your Athena-Glue pipeline.

* buildspec-s3copy.yaml - Takes the files for the pipeline and copies them into an S3 bucket, and lints the pipeline configuration in order to check for errors.
* buildspec-gitinit.yaml - Used when the webhook is called to zip up the repo for the start of the Pipeline. Creates a deploy.zip that the Source stage of the pipeline then reads in.


#### iac/Cloudformation
* CodePipeline.json & CodePipeline.yaml - paramater file and cloudformation file that controls every action in the Pipeline. Update this cloudformation file to add or remove steps from the pipeline.
* S3-{Account}.json & S3.yaml - the parameter and cloudformation files responsible for the creation and configuration of the input S3 bucket. You can change bucket permissions and properties in these files.
* GlueResources-{Account}.json & GlueResources.yaml - the parameter and cloudformation files responsible for the creation and configuration of the Glue datbase and crawler. You can change glue resource properties and permissions with these files.
* AthenaTestQuery-{Account}.json & AthenaTestQuery.yaml - the parameter and cloudformation files responsible for the creation and configuration of the sample Athena query. You can change query permissions and properties in these files.

<br />
## Troubleshooting Pipelines

* Remember what environment you are troubleshooting in. If Cloudformation is being run to deploy something into the BSA's Dev account. You will want to look in the Dev account Cloudformation stacks to see any errors. If it is built in Lambda calls from the base template those will most likely be running in InfraSvcs and can looked at in the Cloudwatch logs which can be gotten to from the details in the step of the Pipeline
* Do not copy the CodePipeline.json file between accounts when moving iac contents. This contains Pipeline specific settings. If you want to duplicate the actions of a Pipeline move the CodePipeline.yaml file to the new repo.
* Use Splunk Cloud. Logs will be going into Splunk Cloud so if you get specific request errors you can search for them in Splunk to get more information. Very useful for troubleshooting S3 access denies which will help with showing the role that is trying to access the bucket as well as the specific bucket location

## Troubleshooting Pipelines
* Application_Source
    * This step will always be in a failed state when you first request your Pipeline. You need to merge the IAC branch into your branch specified to kick off the pipeline, or make any change to the branch specified.
    * If you made a change and it is not kicking off, check the Github CodeBuild for your Pipeline in your BSA Tools account or InfraSvcsProd(legacy). Commits will kick off this CodeBuild to move your code to your Pipeline S3 bucket
    * Check your Github Webhook under repo settings, and then hook. This should be a green checkmark and never a red triangle. If it is a red triangle, you can select the webhook and then redeliver the most recent change.
* Update_CodePipeline
    * Cloudwatch logs can be found under the AWS Cloudwatch service. Under /aws/lambda/Scan_Update_CodePipeline
    * Make sure your CodePipeline.yaml is properly formatted and deploying correctly. Your Pipeline's cloudformation stack can be checked under the Cloudformation service in your BSA Tools account or InfraSvcsProd(legacy) and then you can search for your Pipeline name and find a stack similar to the following: {Product Name}-{BSA Name}-CodePipeline-us-east-1. You can view any Cloudformation errors for your Pipeline update here.
* Application_Build
    * Select details and the execution details to see the logs of the temporary Docker image.
    * Controlled by your Buildspec-ci.yaml
* Cloudformation in Dev{BSA}/Test{BSA}/Prod{BSA}
    * Need to login to the specific account to troubleshoot failed Cloudformation deployments
    * Validate Cloudformation in Dev account before adding it into the Pipeline!

