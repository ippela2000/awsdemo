---
category: aws
draft: false
title: Inside the Service Catalog
menu: docs
weight: 1
---

## What Happens When You Order a Pipeline from Service Catalog

When you order a pipeline from Service Catalog, there are more resources created than just the pipeline. Below is a list
of these resources and an explanation of what they are used for with your pipeline. Not every pipeline will have all of
the resources listed below.

### Additional Resources

  - **CodeBuild GitHub Code**: This is a codebuild job that exists in your Tools Account and is triggered when you push
  the repo you used when ordering. This job packages the code in your repo into a **deploy.zip** file that is uploaded to the S3 bucket
  that is used in the **Application Source** stage of pipelines. This job uses the buildspec-gitint.yaml file.
  - **CodeBuild Ami Bake**: This is a codebuild job that exists in your Tools account that uses Packer to bake the Amazon
  Machine Image (AMI) for your instance. This job uses the buildspec-bake.yaml file.
  - **CodeBuild CI**: This is a codebuild job that is used in the **Application Build** step of pipelines and is used to
  build your application for deployment to your EC2 instance and exists in your Tools account. This job uses the
  buildspec-ci.yaml file, which should be updated after ordering to be specific to your app.
  - **CodeBuild AppValid Dev/Test/Prod**: This is a codebuild job that exists in your BSA's dev, test and prod accounts
  that will be use to validate the application deployment in an automated fashion. This uses the buildspec-appvalid.yaml
  file, by default this file will not validate your deployment, you must update it to validate your app.
  - **BSA Dev/Test/Prod Pipeline Action Role**: These are roles that are deployed into your BSA's dev, test and prod accounts
  for your pipeline to assume in those accounts. Your pipeline assumes these roles for cloudformation deployments and other actions
  such as lambda invocations. These roles will follow the naming scheme of
  **YOUR_PRODUCT_NAME-YOUR_BSA01-codepipeline-action-us-east-1** where YOUR_PRODUCT_NAME is the name you entered when
  ordering from Service Catalog, and YOUR_BSA is the name of your BSA. An example would be
  exampleproduct-CDT01-codepipeline-action-us-east-1
  - **BSA Tools Pipeline Action Role**: This is an IAM role deployed into your tools account and is what your pipeline uses
  to interact with resources in the tools account such as CodeBuild jobs.
  - **BSA Tools Pipeline Service Role**: This is the role that is associated with your pipeline, the pipeline uses it when assuming
  into any of the associated action roles.
  - **SNS Subscriptions**: This subscribes the emails addresses you gave when ordering to Amazon Simple Notification
  Service (SNS) topics that will send messages about pipeline failures and approval states should you choose to subscribe.
  Upon creation the emails given will be sent a confirmation email for both failures and approvals, it is **not** required
  to subscribe but it is **recommended**.

### How and Where to Troubleshoot

Not all resources in your pipeline exist in the same place. Depending on the stage or action of your pipeline you may need
to log into a different account to troubleshoot any issues. Below is where to troubleshoot the most common pipeline issues.
Not all of the stages listed below will be in every pipeline.

  - **Application Source**: This is the first stage in any pipeline ordered from Service Catalog. Upon ordering your
  pipeline, this stage will be in a failed state until you merge the initial pull request that was made to your Github
  repo. Upon merging this pull request, the CodeBuild GitHub Code job will trigger and create a deploy.zip
  in the pipeline-artifact s3 bucket in your tools account. If you have been using the **Release Change** button to trigger
  your pipeline, you will need to trigger the pipeline with a GitHub commit at least once every 60 days as the object
  policy on the artifact bucket deletes objects after this period of time.

  ![application source](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/app_source.png)

  - **Build and Package**:
    - **Update Codepipeline**: This is a lambda function that exists in InfraSvcsProd that detects changes made to your
    codepipeline.yaml file, updates the pipeline accordingly and begins a new execution based on the new code. Any errors
    with this function can be seen by clicking the "Details" button below the action name in your pipeline.
    - **Application Build**: This stage is the Codebuild CI that is listed in the section above. This exists in your tools
    account and to trouble shoot it you can click the "Details" button below the action name in your pipeline and then
    click the link within the details window to see the full logs.
    - **Bake Ami**: This stage is the Codebuild Ami Bake that is listed in the section above. This exists in your tools
    account and to trouble shoot it you can click the "Details" button below the action name in your pipeline and then
    click the link within the details window to see the full logs.
    - **Share Ami**: This is a lambda function that exists in InfraSvcsProd that shares your baked ami to your BSA's dev,
    test and prod accounts. Any errors with this function can be seen by clicking the "Details" button below the action
    name in your pipeline.

   ![build and package](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/build_package.png)

  - **Dev/Test/Prod BSA**:
    - **Cloudformation**: All Cloudformation deployments within a dev, test or prod stage will be deployed to the
      corresponding dev, test or prod account. If you see errors such as "No Reason Given" or that your stack is in an
      unupdatable state of "Rollback Complete" you can open the target account (dev, test or prod), and search for the stack
      within that account to see the full event history and error message.
    - **Application Validation**: This stage is the Codebuild App Valid that is listed in the section above. This exists
    in your tools account and to trouble shoot it you can click the "Details" button below the action name in your pipeline.

    ![bsa stage](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/dev_stage.png)

    - **CIE Lambdas**: If you have a lambda stage in your dev, test or prod stage that was there when you ordered the pipeline, this
    lambda exists in InfraSvcsProd. Any errors with this function can be seen by clicking the "Details" button below the
    action name in your pipeline. This will give you a brief description of the error. Once this has been clicked, you
    can open the link inside the pop up in InfraSvcsProd to view more logs. Clicking the "Details" button on successful
    executions will attempt to open the Cloudwatch logs in your current window, which will result in no logs being found,
    unless your pipeline is in InfraSvcsProd, as the logs do not exist in your Tools account. To view successful execution
    logs please open this link in the InfraSvcsProd account.

    ![cie lambda](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/cie_lambda.png)

    - **Developer Lambdas**: If you are using a lambda that you have deployed yourself and have added into your pipeline,
    to troubleshoot it you can click the "Details" link in that step of the pipeline to see a brief description of the error,
    or you can go to the account in which your lambda exists and read its Cloudwatch logs for the execution.
    You can copy the link within the details window and open it in the corresponding dev, test or prod account to see the
    full logs.  Clicking the "Details" button on successful executions will attempt to open the Cloudwatch logs in your
    current window, which will result in no logs being found as the logs for developer lambdas exist within the same account
    that the lambda does. To view successful execution logs please open this link in the corresponding BSA account.
    - **CodeDeploy**: If your pipeline is using CodeDeploy in your pipeline you can find the CodeDeploy in the corresponding
    dev, test or prod account and can view its logs and state within that account.

    ![code deploy](https://github.nwie.net/Nationwide/NW-Cloud-Docs/raw/master/docs/img/code_deploy.png)

### What Does "Bake AMI" Mean

For pipelines that deploy EC2 instances (Server-Simple, Server-BlueGreen, Server-Simple-QuickDeploy, Server-BlueGreen-QuickDeploy)
there is a step in the **Build and Package** stage called "Bake AMI". This is the stage in which all Nationwide software
is "baked" (installed) into the AMI (Amazon Machine Image) that will be used by the EC2 instance. If your application
also has a way for automated installations this is done within the Bake AMI step as well. The bake process is a
CodeBuild job that runs a **Packer** script to bake the AMI. Packer is an open source tool to automate the creation of
any type of machine image. Documentation on Packer can be found [here](https://www.packer.io/docs/index.html). The files used in the
bake process can be found within the **iac/CloudFormation/Packer** directory in the pull request made to your repo.

### What Happens in the Bake

The following section assumes you do **not** have a no-bake file in your github repo. For information go to the [How-to-no-bake](/docs/aws/developer-tools/codepipeline/howto-nobake/).

The first thing that happens in the bake is the "Pre Build" section of the buildspec-bake.yaml file within the codebuild.
Within this stage, the first action is to get the execution ID of your current pipeline execution. Next is the installation
of Packer and JQ to the codebuild job performing the bake as these tools are required for baking. The last action of the
prebuild is the cleaning of any leftover resources from previous bakes.

The next stage of baking is the "Build" section of the buildspec-bake.yaml file. The first action of the build stage is
the execution of the **get-latest-ami** lambda function that was created by the CIE team to get the latest version of the
foundational AMI for your OS of choice for your AMI to be build on top of. After this the **packer build** command is run
to actually build the AMI. This step takes the packerfile.json you were given in the pull request for your repo and has
Packer execute the code within to create your AMI. This command creates an EC2 instance to build your image behind the scenes,
for more information on packerfiles and on what Packer is doing behind the scenes please click
[here](https://www.packer.io/intro/getting-started/build-image.html). If your app supports silent or automated installations
this step will be executing all commands that you list in the **install_application.sh** file within the **Packer** directory
in your repo.

The final stage of baking is the "Post Build" section of the buildspec-bake.yaml file. This stage is where your AMI will
be encrypted before being shared to your BSA's dev, test and prod account at a later stage in your pipeline. This stage
also completes the AMI creation by provisioning an EC2 instance with the image to confirm its creation. The final step of
this stage is to remove any resources used throughout the bake process.

### CIE Pipeline Lambdas

Within many pipelines ordered from Service Catalog there will be lambda functions executed within the pipeline to perform
actions necessary for pipeline executions. In addition to the lambdas mentioned in the second section on this page, these
functions include:

  - **[deploy-cloudformation](https://github.nwie.net/Nationwide/CDT-DeliveryPipelineLambdas/tree/master/src/Deploy_CloudFormation)**: This lambda is used within Blue Green and Blue Green Quick Deploy pipelines to deploy cloudformation
  cross-account. In other pipelines this is done with the native cloudformation action for codepipeline, but for the Blue
  Green and Blue Green Quick Deploy Service catalog products a random string is required for the stack deployments in the
  actions that use this lambda, which is a feature not supported by the native cloudformation action.
  - **[execute-codedeploy](https://github.nwie.net/Nationwide/CDT-DeliveryPipelineLambdas/tree/master/src/Execute_CodeDeploy)**: This lambda is used to execute a codedeploy job within the Quick Deploy pipeline options. This
  is used instead of the native codedeploy action for codepipeline because the Quick Deploy deployments require a random
  string for each deployment.
  - **[route53-bluegreen](https://github.nwie.net/Nationwide/CDT-DeliveryPipelineLambdas/tree/master/src/Route53_BlueGreen)**: This lambda receives an event from BlueGreen and BlueGreen QuickDeploy CodePipelines and pulls/stores information
  in DynamoDB to do a blue-green deployment by rerouting the application's cname.
  - **[unique-value](https://github.nwie.net/Nationwide/CDT-DeliveryPipelineLambdas/tree/master/src/Unique_Value)**: This lambda is used to generate the unique value required for quick deploy pipeline deployments.
  - **[servicenow-resource-prod](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas/tree/master/src/AWSResourceClient)**: This lambda is used to create CIs from CodePipeline.
  - **[servicenow-change-prod](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas/tree/master/src/AWSChangeClient)**: This lambda is used to create RFCs from codepipeline.
  - **[create-nw-cert](https://github.nwie.net/Nationwide/CDT-AWS-DNS-Management/tree/master/src/Create_NW_Cert)**: This lambda is not found by default in any ordered pipeline but can be added in using the information
  on this [SSLPublicCertificate](/docs/aws/cryptography/howto-publiccert). This lambda creates a Nationwide cert for internet facing applications.
