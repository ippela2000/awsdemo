---
category: aws
draft: false
title: Service Catalog
menu: docs
---

### AWS Service Catalog

* The **CDT TEAM HAS** provided some templates for commonly used patterns that you can leverage using the **AWS Service Catalog** instead of building them from scratch.
* These pipelines will come with default Cloudformation templates that can be used, but these pipelines can be modified to deploy other Cloudformation as well.
* While development allows you to directly create and manage resources through the UI all changes to AWS resources in higher environments must be made in code through a pipeline.**

### AWS Service Catalog Product Ownership

All provisioned products in AWS Service Catalog are owned by a particular user. This is automatically assigned to the user that orders the product.
This can be problematic on teams whem multiple people need to be able to update and manage those products. Luckily it is possible to change the owner of these provsioned products.

The current recommendation is for users to change the ownserhip of their provisioned products to a [Federated Team Role](/docs/aws/getting-started-with-aws/howto_federatedappteamroles/)  after ordering.
This will allow all members of the team role AD group in the account to manage the provisioned product(s).

Perform the following steps on an existing Provisioned Product to change the owner:
* Go to the Service Catalog console
* Naviate to "Provisioned products list"
* Locate the provisioned product you want to update, click the '...' menu next to the product name
* Select 'Change provisioned product owner'
* Populate the ARN field with the Arn of your federated app team role
  * Format: `arn:aws:iam::<AWS Account Number>:role/<TeamRoleName>`
  * EX in InfraSvcsProd: `arn:aws:iam::679177070049:role/SamuraiCats-TeamRole-AWS`
  * See [HERE](/docs/aws/getting-started-with-aws/aws-account-numbers/) to find your account number if you do not know it, it should only ever be a 'Tools' account or the 'InfraSvcsProd'(679177070049) account depending on where you ordered your product.

### Template Pipelines

* There are multiple template Pipelines offered as apart of **AWS Service Catalog**. The current template offerings are:

* [Athena-Glue](/docs/aws/management-and-governance/service-catalog/pipeline-athena-glue/)
  - A pipeline to deploy a managed ETL tool
* [CloudFormation-Simple](/docs/aws/management-and-governance/service-catalog/pipeline-cloudformation-simple/)
  - A simple pipeline that only deploys a single EC2
  - Recommended to people
* [Ec2-AutoScallingGroup](/docs/aws/management-and-governance/service-catalog/pipeline-ec2autoscallinggroup/)
  - A simple pipeline that only deploys an application load balancer and ec2 auto scaling group
* [Generic-IAC](/docs/aws/management-and-governance/service-catalog/pipeline-generic-iac/)
  - A pipeline for advanced users. 
  - Allows for arbitrary IAC execution with Pipeline Action roles. 
  - Very flexible, but without any pre-built features.
* [Server-BlueGreen](/docs/aws/management-and-governance/service-catalog/pipeline-server-bluegreen/)
  - Application baked into infrastructure in a single pipeline
  - Slower application deployments (~45 minutes)
* [Server-BlueGreen-QuickDeploy](/docs/aws/management-and-governance/service-catalog/pipeline-server-bluegreen-quickdeploy/)
  - Two separate pipelines are deployed to be maintained
  - Application deployed separately from infrastructure
  - Rapid application deployments (~5-10 minutes)
* [Server-Simple-QuickDeploy](/docs/aws/management-and-governance/service-catalog/pipeline-server-simple-quickdeploy/)
  - Two separate pipelines are deployed to be maintained
  - Application deployed separately from infrastructure
  - Rapid application deployments (~5-10 minutes)
* [Server-Simple](/docs/aws/management-and-governance/service-catalog/pipeline-server-simple/)
  - Application baked into infrastructure in a single pipeline
  - Slower application deployments (~45 minutes)
* [Serverless](/docs/aws/management-and-governance/service-catalog/pipeline-serverless-simple/)
  - A pipeline to deploy a lambda function (multiple language examples) with or without an ingress point (API Gateway/LoadBalancer)
* [Serverless-Step-Function](/docs/aws/management-and-governance/service-catalog/pipeline-serverless-stepfunction/)
  - A pipeline to deploy an AWS Step Function state machine
* [Static-Website-Cloudfront-S3](/docs/aws/management-and-governance/service-catalog/pipeline-static-website-cloudfront-s3/)
  - A pipeline to deploy a Cloudfront distribution and associated S3 buckets
