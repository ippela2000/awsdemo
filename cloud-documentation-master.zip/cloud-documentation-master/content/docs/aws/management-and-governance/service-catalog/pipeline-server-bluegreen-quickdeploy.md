---
title: Server-BlueGreen-QuickDeploy Pipeline
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included](#whats-included)
  - [Infrastructure Pipeline](#infrastructure-pipeline)
    - [Source](#source)
    - [BuildAndPackage](#buildandpackage)
    - [{Account}_SharedResources](#accountsharedresources)
    - [{Account}_Deployment](#accountdeployment)
    - [*ServiceNow*](#servicenow)
  - [Application Pipeline](#application-pipeline)
    - [Source](#source-1)
    - [BuildAndPackage](#buildandpackage-1)
    - [{Account}_AppDeployment](#accountappdeployment)
    - [{Environment}{Account}_Approval](#environmentaccountapproval)
  - [Included Files and What They Do](#included-files-and-what-they-do)
    - [Server-BlueGreen-QuickDeploy-SampleApp](#server-bluegreen-quickdeploy-sampleapp)
    - [iac/Cloudformation](#iaccloudformation)
    - [iac/CodeDeploy](#iaccodedeploy)
    - [iac/Packer](#iacpacker)
- [How to add an application](#how-to-add-an-application)
- [How to make an application public](#how-to-make-an-application-public)
- [How to modify your Target Groups Health Check](#how-to-modify-your-target-groups-health-check)
- [How to change your CI - BYOCI](#how-to-change-your-ci---byoci)
- [How to swap DNS back to previous versions](#how-to-swap-dns-back-to-previous-versions)
- [Troubleshooting Pipelines](#troubleshooting-pipelines)
- [Reminders](#reminders)

<br /><br />

## What is it?
The Server BlueGreen QuickDeploy Pipeline is a Service Catalog product that can be ordered via the AWS console.
This Pipeline's focus is to create the infrastructure for an application team in order to deploy their app using the Blue/Green deployment method.
This product differs from the other Server-BlueGreen because it has a second "Application only" pipeline for App-only changes. This allows for application teams to iterate faster.


## What's Included

[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Server-BlueGreen-QuickDeploy)

The Server-BlueGreen-QuickDeploy pattern creates 2 pipelines, 1 that deploys infrastructure and loads an app onto it, and one that just loads an app onto the existing infrastructure. The -Application pipeline is an addon to the -Infrastructure pipeline, not an independent thing. The -Infrastructure pipeline must be run first to build out the infrastructure for the -Application pipeline to be able to deploy onto that infrastructure.

Both pipelines run off of the same github repo and source files. If you only modify your application source, the Application pipeline will be run. If you modify anything in the iac/ folder, or any of the buildspec-*.yaml files, the Infrastructure pipeline will run instead.

From the infrastructure pipeline, you get 2 full setups (blue and green) per environment as well as some shared resources between the 2. The shared resources include a role that your EC2 instances will run as and a security group that your load balancers and EC2 instances will use. Each blue and green setup is comprised of an autoscaling group, load balancer, CodeDeploy deployment group, and DNS records.

When deployed into an environment, you will have DNS records mapping to your individual load balancers ({DevCname}-blue.aws.e1.nwie.net and {DevCname}-green.aws.e1.nwie.net). The "active" infrastructure is then determined by which of those that your main record is pointing to. {DevCname}.aws.e1.nwie.net will be an alias to either {DevCname}-blue.aws.e1.nwie.net or {DevCname}-green.aws.e1.nwie.net.

When the application pipeline is run, it builds your application, detects which is currently your "standby" infrastructure (blue or green), and runs CodeDeploy pointed at the "standby" (blue or green) deployment group to deploy that built app onto the "standby" infrastructure. After that deployment is complete, it then runs a script to switch your DNS record ({DevCname}.aws.e1.nwie.net) to point to the newly updated infrastructure, making it "active."

Example:
Infrastructure pipeline has already been run through completely, and Green is your current active environment.
{DevCname}.aws.e1.nwie.net is currently an alias to {DevCname}-green.aws.e1.nwie.net.

1. You commit a change to your application source code
2. The Application pipeline kicks off and builds your application
3. The Execute_CodeDeploy script detects that Green is your active deployment, so runs against the Blue deployment group, deploying your updated application onto your Blue infrastructure.
4. The DNS_BlueGreen_Swap action then runs and modifies the {DevCname}.aws.e1.nwie.net record to now be an alias to {DevCname}-blue.aws.e1.nwie.net and updates the tracker table to note that change.

Your Green infrastructure is still present and unchanged, available to be quickly made active again by switch {DevCname}.aws.e1.nwie.net back to {DevCname}-green.aws.e1.nwie.net. There is currently no mechanism in place to allow manually making this switch back, but that feature is being worked on.


<br /><br />
### Infrastructure Pipeline
Below are the stages in this pipeline. The {Account} stages happen identically in your dev, test and prod BSA accounts.

#### Source

* **Application_Source** : Pulls in the deploy.zip from the pipelinefactory-679177070049-us-east-1 bucket, which is the entire contents of your repo zipped up.

#### BuildAndPackage

* **Update_CodePipeline** : Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)
* **Application_Build** : Runs the ‘-ci-‘ codebuild job to build your application. This directly runs the commands in your buildspec-ci.yaml file, explained further bellow.
* **Bake_AMI** : Runs the ‘-bake-‘ codebuild job to bake an AMI for your application to run on. This directly runs the commands your buildspec-bake.yaml file. Packer is used by default to install any dependencies and load any files onto the Nationwide base AMIs to create your application’s AMI.
* **Get_Pipeline_Artifacts** : Runs a script that pulls in various pieces of information from the currently pipeline executions’ artifacts and stores them in a Dynamo table. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Get_Pipeline_Artifacts)
* **Share_AMI** : Shares the AMI created in the Bake_AMI stage to all of your accounts (Dev/Test/Prod accounts in your BU stack) [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_AMI/Share_AMI)

#### {Account}_SharedResources

* **Deploy_SecurityGroup** : Deploys the security group for your load balancers and ec2 instances in the account in the stage name. This runs the SecurityGroup.yaml file, using the matching SecurityGroup-{Account}.json file to populate the parameters.
* **Deploy_ProductRole** : Deploys the role your ec2 instances will use in the account in the stage name. This runs the ProductRole.yaml file, using the matching ProductRole-{Account}.json file to populate the parameters.

#### {Account}_Deployment

* **{Color}_Deploy_LBASG** : Deploys the load balancer, autoscaling group, target group, etc. for the {Color}(Blue/Green) infrastructure into your {Account}. This runs the LoadBalancerAutoScaling.yaml file, using the matching LoadBalancerAutoScaling-{Account}.json for parameters as well as some hard-coded overrides from the pipeline itself for parameters. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Deployment/Deploy_CloudFormation)
* **{Color}_Deploy_CodeDeployDG** : Deploys the CodeDeploy deployment group configured with the autoscaling group and load balancer from the previous action into your {Account}. This runs the CodeDeploy.yaml, using the matching CodeDeploy-{Account}.json for parameters as well as some hard-coded overrides from the pipeline itself for parameters.
* **{Color}_Execute_CodeDeploy** : Runs CodeDeploy on the deployment group created above to deploy your application onto the instances(ASG) created in the {Color}_Deploy_LBASG action. This runs CodeDeploy with the appspec.yaml file in your repo. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Execute_CodeDeploy)
* **{Color}_App_Validation (optional-enabled by default)** : Runs the ‘-appvalid-‘ codebuild job to perform automated application validation. This codebuild job directly runs the commands in the buildspec-appvalid.yaml file. This action is not directly required, but enabled by default in this pipeline. If you do not have any automated validation you want to do here, you can comment out the file to shave a little time off of your pipeline runtime.
* **{Color}_DNS_BlueGreen_Swap** : Runs a script that handles the blue/green swapping of your environment. The script updates records in its tracking database (Route53_BlueGreen_Tracker dynamo table) and updates the route53 records that determine your “active” infrastructure. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_DNS/Route53_BlueGreen_Quick)
* **{Environment}Approval** : Manual approval step before proceeding into the next environment. This can be commented out if you do not want to have to manually release your change into the next environment.


#### *ServiceNow*
These steps run before and after the production stage of this pipeline.
* **Create_Or_Update_ServiceNow** : a lambda function that is used by pipeline to create a resource in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)
* **Create_RFC** : a lambda function that is designed to be ran by AWS CodePipeline to create an RFC in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)
<br /><br />
### Application Pipeline

Below are the stages in this pipeline. The {Account} stages happened identically in your dev, test and prod BSA accounts.

#### Source

* **Application_Source** : Pulls in the deploy.zip from the pipelinefactory-679177070049-us-east-1 bucket, which is the entire contents of your repo zipped up.

#### BuildAndPackage

* **Application_Build** : Runs the ‘-ci-‘ codebuild job to build your application. This directly runs the commands in your buildspec-ci.yaml file, explained further bellow.

#### {Account}_AppDeployment

* **Execute_CodeDeploy** : Runs CodeDeploy on the current “standby” deployment group to deploy your application onto the instances(ASG) created in the infrastructure pipeline. This runs CodeDeploy with the appspec.yaml file in your repo. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Execute_CodeDeploy)
* **Application_Validation (optional-disabled by default)** : Runs the ‘-appvalid-‘ codebuild job to perform automated application validation. This codebuild job directly runs the commands in the buildspec-appvalid.yaml file. This action is disabled by default in the Application pipeline, if you have automated application validation you wish to perform, you will need to uncomment this action in your CodePipeline.yaml
* **DNS_BlueGreen_Swap** : Runs a script that handles the blue/green swapping of your environment. The script updates records in its tracking database (Route53_BlueGreen_Tracker dynamo table) and updates the route53 records that determine your “active” infrastructure. This sets your primary CNAME to be an alias to the CNAME of the infrastructure that was just updated in the previous action. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_DNS/Route53_BlueGreen_Quick)

#### {Environment}{Account}_Approval

* **{Environment}Approval** : Manual approval step before proceeding into the next environment. This can be commented out if you do not want to have to manually release your change into the next environment.

<br /><br />
### Included Files and What They Do

The following are definitions to all files deployed to the github repo associated with the ordered service catalog product Server-BlueGreen-QuickDeploy. These files get added to your repo during the provisioning of your Server BlueGreen QuickDeploy Pipeline.

* appspec.yaml - File that defines the actions for codedeploy to perform, including which scripts will be run during the standard stages.
* buildspec-appvalid.yaml - File that is used to run automated validation and tests after deployment into each environment
* buildspec-bake.yaml - Controls the AMI bake process. Location of were the foundational AMI is specified. Calls the files in iac/Packer
* buildspec-ci.yaml - Controls the Application Build step. Will have maven, npm commands, etc. for any application builds that need to happen. You can bring your own CI [How to change your CI (Bring your own CI, BYOCI)](#How-to-change-your-CI-BYOCI)
* buildspec-gitinit.yaml - Used when the webhook is called to zip up the repo for the start of the Pipeline. Creates a deploy.zip that the Source stage of the pipeline then reads in.

#### Server-BlueGreen-QuickDeploy-SampleApp
##### Linux
*	Server-Simple-SampleApp/src-hello-world/main/java/com/mycompany/app - Java app that gives string response of “Congratulations on a successful pipeline!”
*	Server-Simple-SampleApp/src-hello-world/test/java/com/mycompany/app - unit test for Sample app listed above
*	Server-Simple-SampleApp/pom-hello-world.xml - defines compile process for the sample java app defined above
##### Windows
*	Server-Simple-SampleApp/index.html - html page that displays "Congrats on a successful deployment of a Windows {Product} pipeline!"
*   iac/Packer/install_dependencies.ps1 - Installation occurs here, copies executable script from bucket, creates Windows Service, Windows service runs EC2 as a webserver listening on port 80

NOTE: This sample app creates a web server listening on port 80 for health checks by the load balancer on initial product order. The app lives as a service by creating a Windows service titled SampleApp in the Windows Services. To use port 80 for your app or services please comment out or remove the code in install_dependencies.ps1.

#### iac/Cloudformation
* iac/CloudFormation/LoadBalancerAutoScaling-{environment}.json - Environment specific parameters for the loadbalancer and autoscaling cloudformation
* iac/CloudFormation/LoadBalancerAutoScaling.yaml - Creates an Application Load Balancer and default listening rule. Creates an autoscaling group with scaling policies. Need to configure the healthcheck here with a url that will give back a 200 with a healthy application
* CodePipeline.json & CodePipeline.yaml - paramater file and cloudformation file that controls every action in the Pipeline. Update this cloudformation file to add or remove steps from the pipeline
* iac/CloudFormation/ProductRole-{environment}.json - Environment specific parameters for the product role cloudformation
* iac/CloudFormation/ProductRole.yaml - Creates Identity Access Managment roles for EC2 instances
* iac/CloudFormation/SecurityGroup-{environment}.json - Environment parameters for the security group cloudformation
* iac/CloudFormation/SecurityGroup.yaml - Creates EC2 instance security group, and Loadbalancer security group

#### iac/CodeDeploy
* iac/CodeDeploy/after_install.sh(.ps1 for windows) - Script run by CodeDeploy after application install
* iac/CodeDeploy/application_start.sh(.ps1 for windows) - Script run by CodeDeploy to start the installed application
* iac/CodeDeploy/application_stop.sh(.ps1 for windows) - Script run by CodeDeploy to stop the installed application
* iac/CodeDeploy/before_install.sh(.ps1 for windows) - Script run by CodeDeploy before application installation is performed
* iac/CodeDeploy/validate_service.sh(.ps1 for windows) - Script run by CodeDeploy as a final step after installing/starting the application to perform any validation needed.

#### iac/Packer
* (Linux)iac/Packer/install_aws_services.sh - Installs the Code Deploy agent in the AMI bake process
* (Linux)iac/Packer/install_application.sh - Can be modified to run any application configuration or installation that can be done in the AMI bake process. This will be something that is set for every environment.
* (Linux)iac/Packer/packerfile.json - Packer configuration file for how to build and bake the AMI in the Bake_AMI step. Under the provisioners section additional scripts can be added here, as well as moving any items from the Application_Codebuild step
* (Windows)iac/Packer/install_aws_services.ps1 - Installs the Code Deploy agent in the AMI bake process and syspreps the AMI
* (Windows)iac/Packer/packer_userdata.ps1 - Updates the windows firewall to support WinRM connections from packer.
* (Windows)iac/Packer/install_dependencies.ps1 - Can be modified to run any application configuration or installation that can be done in the AMI bake process. This will be something that is set for every environment. Put your application install here.

* iac/Packer/packerfile.json - Packer configuration file for how to build and bake the AMI in the Bake_AMI step. Under the provisioners section additional scripts can be added here, as well as moving any items from the Application_Codebuild step


<br /><br />
## How to add an application
In order to add your application to the pipeline you have to make changes to these files:

1. buildspec-ci.yaml: This file defines how the application will be built. The sample provided uses maven to compile a .jar file and outputs the resultant jar file.
2. appspec.yml: This file defines what codedeploy will do on execution. The sample copies the jar file from CI step onto the server, then runs through the shell scripts in the CodeDeploy folder.
3. iac/Packer/packerfile.json: This file defines the bake process and tells packer what to install into your AMI. The sample provided just installs java using yum (and the default install_aws_services which should stay regardless of your customizations.)
4. **Linux** iac/CodeDeploy/start_application.sh: This script will be run on your server by CodeDeploy to start your application. The sample provided just executes the jar file previously copied to the server with java.
5. **Linux** iac/CodeDeploy/stop_application.sh: This script will be run by CodeDeploy on your server to stop your application when performing updates. The sample provided finds all java processes and kills them.
6. **Windows** iac/Packer/install_dependencies.ps1 used when there is a silent or automated install; in packer it needs to be moved to the final location. To use port 80 for your app or services please comment out or remove the code.


<br /><br />
## How to make an application public

**Please note that completing the actions bellow will expose your application to the general Internet. Ensure that your application is properly secured and does not expose any sensitive information before exposing it to Internet. You are fully response for the security of your application and the data exposed by it and accept that responsibility when completing the following actions. If you have any questions about the security of your app or your responsibilities from owning a public-facing application please reach out to your front-office IRM representative for consultation.**

To make an application public you will just need to replace some of the files in your repo with prepared templates that include all of the required changes for a public loadbalancer, security group, dns records, etc.

Replace the files in your repo with the files found [HERE](https://github.nwie.net/Nationwide/AWS-CloudFormation/tree/master/BlueGreen-PublicFiles) matching the same name.

This will result in a setup where you have both a private and public load balancer. The public load balancer will have a DNS record of ${pDevCname}.awspubliccloud.nationwide.com and a matching cert that will only be valid from within the Nationwide network.

Once this is successfully deployed, you will need to get a valid X.nationwide.com domain and certificate. The standard on-prem process for these will need to be followed with requests submitted to middleware [HERE](https://nwproduction.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D18b62d580fc14680085d6509b1050e9f%26sysparm_link_parent%3Dcb8d9b290f1f7100a5eee478b1050e65%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_default%26sysparm_view%3Dtext_search)

Please reach out to the CIE or SRE teams if you have any questions on the above process.


<br /><br />
## How to modify your Target Groups Health Check
* In your Loadbalancer.yaml there will be a resource that is being created called "rTargetGroup".
    * Under the properties there will be a few properties to make note of. Port, Protocol, HealthCheckPath, HealthCheckProtocol, and HealthCheckIntervalSeconds.
        * Port is the port used in the Health Check
        * Protocol is the protocol to use for routing traffic to the targets.
        * HealthCheckPath will be the path to a page on your app. Most likely will be the home page
        * HealthCheckProtocol is the protocol that the load balancer uses when performing health checks on the targets, such as HTTP or HTTPS.
        * HealthCheckIntervalSeconds the approximate number of seconds between health checks for an individual target
    * As mentioned this Health Check will need to be configured for the Loadbalancer to route traffic to the targets. If this is not configured correctly your deployment will fail.
    * By Default Tomcat/TomEE runs on port 9443. If you are not running your App on that port, the default values will need to be updated, as well as the default values in your Security Group since it will have 9443 opened by default.


<br /><br />
## How to change your CI - BYOCI
**If you choose this route you will be responsible for owning.**

If you want to bring your own CI (like Jenkins), that can be done. Make sure the following is being done:
* Make sure your current Jenkins build is storing your artifacts in Nexus.
* In your Application_Build step, in the pipeline, you can modify the buildspec-ci.yaml to download the artifact from Nexus instead of doing a full application build at this stage.
* Can be done with a curl command to the location of the artifact in Nexus.
  * You may need to use the maven-dependency-plugin when working with SNAPSHOTS

<br /><br />
## How to swap DNS back to previous versions

If you have an issue with your application and wish to rollback, you can swap your DNS record that your application uses back to the previously deployed load balancer. Changing the DNS back to the previous load balancer forces traffic back to the previous application code.

To make this change, please visit [The Cloud Control Board](https://ccb.aws.e1.nwie.net/bluegreen) to have the record swapped. If you have access to the tools account that deploys the product, then you have access to make these changes. You can find more information in the [CCB Github Repo](https://github.nwie.net/Nationwide/CDT-CCB#blue-green-deployments).

## Troubleshooting Pipelines

* Remember what environment you are troubleshooting in. If Cloudformation is being run to deploy something into the BSA's Dev account. You will want to look in the Dev account Cloudformation stacks to see any errors. If it is built in Lambda calls from the base template those will most likely be running in InfraSvcs and can looked at in the Cloudwatch logs which can be gotten to from the details in the step of the Pipeline
* Do not copy the CodePipeline.json file between accounts when moving iac contents. This contains Pipeline specific settings. If you want to duplicate the actions of a Pipeline move the CodePipeline.yaml file to the new repo.
* Use Splunk Cloud. Logs will be going into Splunk Cloud so if you get specific request errors you can search for them in Splunk to get more information. Very useful for troubleshooting S3 access denies which will help with showing the role that is trying to access the bucket as well as the specific bucket location

Troubleshooting specific steps:
* Application_Source
    * This step will always be in a failed state when you first request your Pipeline. You need to merge the IAC branch into your branch specified to kick off the pipeline, or make any change to the branch specified.
    * If you made a change and it is not kicking off, check the Github CodeBuild for your Pipeline in your BSA Tools account or InfraSvcsProd(legacy). Commits will kick off this CodeBuild to move your code to your Pipeline S3 bucket
    * Check your Github Webhook under repo settings, and then hook. This should be a green checkmark and never a red triangle. If it is a red triangle, you can select the webhook and then redeliver the most recent change.
* Update_CodePipeline
    * Cloudwatch logs can be found under the AWS Cloudwatch service. Under /aws/lambda/Scan_Update_CodePipeline
    * Make sure your CodePipeline.yaml is properly formatted and deploying correctly. Your Pipeline's cloudformation stack can be checked under the Cloudformation service in your BSA Tools account or InfraSvcsProd(legacy) and then you can search for your Pipeline name and find a stack similar to the following: {Product Name}-{BSA Name}-CodePipeline-us-east-1. You can view any Cloudformation errors for your Pipeline update here.
* Application_Build
    * Select details and the execution details to see the logs of the temporary Docker image.
    * Controlled by your Buildspec-ci.yaml
* Bake_AMI
    * Select details and the execution details to see the logs of the temporary Docker image as well as Packer executions.
    * Controlled by Buildspec-bake.yaml. This also calls files from your iac/Packer folder and runs what is specified.
    * If accessing an S3 bucket in Packer make sure you have an IAM Instance profile assigned
    * Validate your installation scripts on an Instance before adding to a Pipeline to troubleshoot.
* Cloudformation in Dev{BSA}/Test{BSA}/Prod{BSA}
    * Need to login to the specific account to troubleshoot failed Cloudformation deployments
    * Validate Cloudformation in Dev account before adding it into the Pipeline!

<br /><br />
## Reminders

The pipeline provided is a template that we have made to allow BSA's to hit the ground running with a pipeline. These Pipelines are 100% customizable (Within reason). Things like the service now sections for RFC's, and Cloud Stack config updates are required, but if your application doesn't need a load balancer remove that action. You can also add actions to the pipelines and most applications will have customized Pipelines. Feel free to experiment and ask any questions in the [AWS Rocketchat channel](https://rocketchat.nwie.net/channel/AWS).
