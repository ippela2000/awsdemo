---
title: CloudFormation-Simple Pipeline
menu: docs
category: aws
---

## Table of Contents
- [Table of Contents](#table-of-contents)
- [What is it?](#what-is-it)
- [What's Included](#whats-included)
  - [Pipeline stages defined](#pipeline-stages-defined)
    - [*Source*](#source)
    - [*BuildAndPackage*](#buildandpackage)
    - [*Dev{Account}*](#devaccount)
    - [*Dev{Account}_Approval*](#devaccountapproval)
    - [*Test{Account}*](#testaccount)
    - [*Test{Account}_Approval*](#testaccountapproval)
    - [*ServiceNow*](#servicenow)
    - [*Prod{Account}*](#prodaccount)
    - [*ServiceNowProd*](#servicenowprod)
  - [Github files defined](#github-files-defined)
    - [iac/Cloudformation](#iaccloudformation)
- [How to add an application](#how-to-add-an-application)
- [How to make an application public](#how-to-make-an-application-public)

----

## What is it?
![CloudFormation-Simple](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/CloudFormationSimple.png)<br />
The Simple CloudFormation Pipeline is a Service Catalog product that can be ordered via the AWS console. This Pipeline's focus is to create the infrastructure for an application team in order to deploy their app onto the provided services. The infrastructure that is created is a S3 and an EC2 instance. This pipeline, ordered as is, does not provide the ability to automate installs via the pipeline. This is a bare bones product and creation and onus of automated install scripts rely on the app owners/developers.


## What's Included
[Repository for Pipeline Templates](https://github.nwie.net/Nationwide/CDT-SC-Cloudformation-Simple)

The CloudFormation Simple Pipeline creates the necessary infrastructure needed for a Simple EC2 (Windows and Linux) Appplication using a CD Pipeline.

### Pipeline stages defined

#### *Source*
* **Application_Source** : This step watches an S3 bucket for new updates. When a change is checked into your github repo a Code Build (AWS Service) is kicked off to zip the contents of the repo and add it to the watched bucket. On change the pipeline will start.

#### *BuildAndPackage*
* **Update_CodePipeline** : Runs a script that allows the pipeline to update itself via the CodePipeline.yaml file in your iac/CloudFormation folder. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Scan_Update_CodePipeline)
* **Get_Pipeline_Artifacts** : Runs a script that pulls in various pieces of information from the currently pipeline executions’ artifacts and stores them in a Dynamo table. [Source Code](https://github.nwie.net/Nationwide/AWS-DeliveryPipeline/tree/master/src/Manage_Delivery_Pipeline/Get_Pipeline_Artifacts)

#### *Dev{Account}*
* **Cleanup_EC2_Product** : CloudFormation script that builds the Delivery Pipeline to deploy a Simple CloudFormation Stack, this stack creates the each of the stages below
* **Deploy_ProductRole** : CloudFormation script that deploys the product role for the deployed EC2 instances
* **Deploy_EC2** : CloudFormation script that deploys the resources needed to create an EC2 instance.

#### *Dev{Account}_Approval*
* **DevelopmentApproval** : This step is the manual gate check approval to verify that you want to deploy your application to the next environment

#### *Test{Account}*
* **Cleanup_EC2_Product** : CloudFormation script that builds the Delivery Pipeline to deploy a Simple CloudFormation Stack, this stack creates the each of the stages below
* **Deploy_ProductRole** : CloudFormation script that deploys the product role for the deployed EC2 instances
* **Deploy_EC2** : CloudFormation script that deploys the resources needed to create an EC2 instance.

#### *Test{Account}_Approval*
* **TestApproval** : This step is the manual gate check approval to verify that you want to deploy your application to the next environment

#### *ServiceNow*
* **Create_Or_Update_ServiceNow** : a lambda function that is used by pipeline to create a resource in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)
* **Create_RFC** : a lambda function that is designed to be ran by AWS CodePipeline to create an RFC in ServiceNow [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)

#### *Prod{Account}*
* **Cleanup_EC2_Product** : CloudFormation script that builds the Delivery Pipeline to deploy a Simple CloudFormation Stack, this stack creates the each of the stages below.
* **Deploy_ProductRole** : CloudFormation script that deploys the product role for the deployed EC2 instances
* **Deploy_EC2** : CloudFormation script that deploys the resources needed to create an EC2 instance.

#### *ServiceNowProd*
* **Close_RFC** : Runs ServiceNowPipelineChange lambda that is designed to be run by AWS CodePipeline to close
an RFC in ServiceNow. [Source Code](https://github.nwie.net/Nationwide/CDT-ServiceNowLambdas)

### Github files defined
* buildspec-gitinit.yaml - Used when the webhook is called to zip up the repo for the start of the Pipeline

#### iac/Cloudformation
All infrastructure specific files will be deployed to the folder labeled **iac** (infrastructure as code).
* iac/CloudFormation/CodePipeline.yaml - Builds the Delivery Pipeline to deploy a Simple CloudFormation Stack
* iac/CloudFormation/CodePipeline.json - Parameter file used by CodePipeline.yaml
* iac/CloudFormation/ProductRole.yaml - Product Role for deployed EC2 instances. Built from a Production Pipeline.
* iac/CloudFormation/ProductRole-{Account} - Parameter file used by ProductRole.yaml to create the product role for each EC2 in eah Account
* iac/CloudFormation/Simple-EC2.yaml - Creation of all resources needed to deploy an EC2 instance. Logs the vital windows build processes via CloudFormation and is viewable in CloudWatch, for more information on where and what is logged follow this [HowTo-ViewWindowsLogs](https://github.nwie.net/Nationwide/Next-Gen-Infra/blob/gh-pages/pages/HowTo-ViewWindowsLogs) doc.
* iac/CloudFormation/Simple-EC2-{Account}.json - Parameter file used by Simple-EC2.yaml to create EC2

## How to add an application
In order to add an application to this pipeline you would need to install the application onto the EC2 instance and utilize the services created with the Pipeline. It is the responsibility of the application team to write/manage the scripts for all installs of the application in their Git repo. Out of the box, this pipeline does NOT have application integration. Another option for an out of the box application integration solution would be Simple-Server Pipeline in Service Catalog.

## How to make an application public
- [Using an application load balancer](https://pages.github.nwie.net/Nationwide/Next-Gen-Infra/pages/Howto-WAF/)
