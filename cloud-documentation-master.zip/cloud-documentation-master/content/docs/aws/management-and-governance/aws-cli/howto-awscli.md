---
title: AWS CLI
menu: docs
category: aws
---

# AWS Command Line Interface

----

## Download the AWS CLI
* [Download AWS CLI](https://aws.amazon.com/cli/)

----

## AWS CLI Documentation
* [AWS CLI Documentation](https://docs.aws.amazon.com/cli/latest/reference/)

----

## Configure AWS CLI

For demonstration purposes,your environment might be different, we are going to configure on a Windows 10 desktop.We are also assuming you have downloaded the AWS CLI and installed it.

* Step 1) Open the Windows command prompt

* Step 2) Type the following:
    * aws configure

 * Step 3) If all goes correctly you will be presented with your first question:
    * AWS Access Key ID
    * Do not type anything here ... just hit the enter button

* Step 4) If all goes correctly you will be presented with your second question:
    * AWS Secret Access Key
    * Do not type anything here ... just hit the enter button

* Step 5) If all goes correctly you will be presented with your third question:
    * Default region name
    * Here you want to enter: us-east-1

* Step 6) If all goes correctly you will be presented with your fourth question:
    * Default output format
    * Here you want to enter: json

Below is a screenshot of the AWS CLI
<img src="/docs/aws/images/AwsCLI.png">


If all goes properly a filed named "config" will be placed at the following location:
* C:\users\YOURSHORTNAME\\.aws
* Open the file with notepad and the contents should look like this
<img src="/docs/aws/images/AwsCliConfigFile.png">

----

## Before Using The AWS CLI

* You will need to get your AWS Credentials which include:
    * aws_access_key_id
    * aws_secret_access_key
    * aws_session_token
    
* The easiest way to get your AWS credentials is go to the [Tools](/docs/aws/management-and-governance/aws-cli/howto_tools/) section and then navigate to the **Aws-Federator**. 

* **DO NOT SKIP reading the documentation prior to running the federator**

* Once you have found the **Aws-Federator** section, you will need to download the binary that is specific to your OS (Windows,Linux,Mac). 

* There is a [readme](https://github.nwie.net/Nationwide/aws-federator/blob/master/README.md) that you should review prior to running the utility. 

* There is also a [rocketChat Channel](https://rocketchat.nwie.net/channel/AWS-FEDERATOR-DEV) in case you have questions or need help.

* At the Windows command prompt the first thing you will need to do is set your command prompt proxy that way your session can traverse the Nationwide network and reach out to AWS.

* The [Development Environment HTTP Proxy Settings page](https://nest.nwie.net/content/articles/iboss-proxy-settings.html) on [Nest](https://nest.nwie.net/) has the configuration details.



----


## AWS CLI Tutorials

* Once the proxy has been set you can now execute AWS CLI commands.  
* You can use commands to perform tasks like querying data, creating/managing AWS resources, building/executing Cloudformation templates, and anything else you would use the AWS console or SDK to do.  


## Below we outline some use-cases for the AWS CLI.

### Describing all tags for the ec2 environment in the us-east-1 region

 The following example will describe all the tags for the ec2 environment in the us-east-1 region
 * `aws ec2 describe-tags --profile YOUR_AWS_ROLE_NAME_HERE --region us-east-1 --filters "Name=key,Values=DisbursementCode"`
 <img src="/docs/aws/images/AwsCliBasicUseCase.png">




###  Decoding an error message

<img src="/docs/aws/images/AwsCLIDecodeMessage.png">



### Creating a stack from a Manual Cloudformation template

Manual Cloudformation templates can be found here: https://github.nwie.net/Nationwide/AWS-CloudFormation.  The following example creates a stack containing a Linux EC2 instance:

* First you need to download the Linux EC2 template from the AWS-CloudFormation repo.
* Inside the template YAML, you will see a list of parameters as shown below.


<img src="/docs/aws/images/ec2tempParams1.PNG" width = "40%" height = "40%"/> <img src="/docs/aws/images/ec2tempParams2.PNG" width = "47%" height = "47%"/>




* The next step is to create a config json file containing the your specified parameter values.
  * The format is as follows:

```json
[
  {
    "ParameterKey": "ParamName1",
    "ParameterValue": "ParamValue1"
  },
  {
    "ParameterKey": "ParamName2",
    "ParameterValue": "ParamValue2"
  }
]
```

* Here is the config file for this example

<img src="/docs/aws/images/configFileCLI.PNG">


* Once you have the template, config file, and current AWS credentials, you can now execute the command to create the stack:
<br>
`aws cloudformation create-stack --stack-name <YourStackname> --template-body file://<TemplateFilePath> --parameters file://<ConfigFilePath> --profile <AWS_accountName> --region <AWS_region>`

<img src="/docs/aws/images/createStackWithConfig.PNG">


* If the command executes correctly, it will return the stackID of the newly created stack.







