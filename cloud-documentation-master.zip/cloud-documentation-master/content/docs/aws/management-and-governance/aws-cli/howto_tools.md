---
title: Aws-Federator
menu: docs
category: aws
---


## Aws-Federator

Aws-Federator is a Nationwide developed tool that gets your AWS Federation tokens which are utilized for automation from NW to AWS.
 - [Readme](https://github.nwie.net/Nationwide/aws-federator/blob/master/README.md)
 - [Releases](https://github.nwie.net/Nationwide/aws-federator/releases)
 
**Note: [saml2aws](https://github.com/Versent/saml2aws) and [pidm](https://github.nwie.net/Nationwide/pidm/blob/master/README.md) cli tools are no longer needed to login into AWS. You only need the AWS Federator** 

