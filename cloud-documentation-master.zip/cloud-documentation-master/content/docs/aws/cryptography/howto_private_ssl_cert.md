---
title: SSL Internal Certificate
menu: docs
category: aws
---


## What is it?
Application Load Balancers that will be serving HTTPS require an SSL certificate to be hosted in ACM.
SSL certificates need to match the friendly DNS name that will be used when accessing the resource or will show as invalid, so you will also need to register a friendly name for your load balancer.
Metadata is required when you request the certificate

IE: If your DNS name is somename.ec2.amazonaws.com, but your certificate is myapplication.aws.e1.nwie.net, the cert will show invalid to users.
So we will register a CNAME of myapplication.aws.e1.nwie.net, which will resolve to somename.ec2.amazonaws.com so that the certificate matches the name users will access the application with.

Custom cloudformation resources have been created for both registering DNS and getting valid certificates from the on-prem certificate manager, so all users will trust the assigned certificates automatically.
You will just need to paste in a few additional sections into your load balancer template and populate the required fields:

Creating of internal (nwie.net) certs is mostly automated at this time. Below are the steps you will follow
1. Friendly DNS name creation can be done using the ```Type: Custom::remote-route53``` function
2. Request an Alias to the Hosting Team (Optional)
3. Internal SSL Certificate creation for .aws.e1.nwie.net and uploading to ACM using the function ```Type: Custom::create-nw-cert``` in CloudFormation.
4. If you want a Custom link of something.nwie.net instead of something.aws.e1.nwie.net, you have to generate it manually with these [instructions](https://onyourside.sharepoint.com/sites/SSLCertificateManagement/Instructions/Generate%20Internal%20Certificates.pdf?csf=1&e=MGsJi0&cid=41e70dbe-ba79-4f65-97f0-5aa9bec03fd8) and get it uploaded to ACM by the Cloud-Solutions team.


## Friendly DNS Name

To request an internal(nwie.net) DNS associated with the Cert use the function below in your CloudFormation

```
Parameters:
  pCname:
    Type: String
    Description: Friendly name to create in DNS
    Default: friendlyname

Resources:
  rAddCNAME:
      Type: Custom::RemoteRoute53
      Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      Account: !Sub "${AWS::AccountId}"
      RecordType: CNAME  # A and PTR are not currently supported
      RecordName: !Ref pCname # should not have .aws.e1.nwie.net on it, just the name
      RecordValue: !GetAtt rLoadBalancer.DNSName
```

The above will result in a DNS name of **friendlyname.aws.e1.nwie.net**. For more details on DNS check these [instructions](/docs/aws/network-content-delivery/route53/howto_dns/)


### Request an Alias with the Hosting Team for Custom DNS

- You might want to further customize your DNS to be for example to be **friendlyname.nwie.net** instead of **friendlyname.aws.e1.nwie.net**
- Follow these [instructions](/docs/aws/network-content-delivery/route53/howto_customdns/) on how to request an ALIAS.


### Internal Certificate for friendlyname.aws.e1.nwie.net on ALB

After you have determined your DNS you will then create an internal certificate using the custom function ```Type: Custom::CreateNWCert``` in your CloudFormation

```
Parameters:
  pResourceOwner:
    Description: Main contact for the resource / asset- Application Owner, Data Owner (NWIE ID)
    Type: String
    Default: #REPLACEME
  pDisbursementCode:
    Description: Cost Center equivalent
    Type: String
    AllowedPattern: ^[0-9]{9}$
    ConstraintDescription: Must be a valid Disbursement Code
    Default: #REPLACEME
  pCommonName:
    Type: String
    Description: Name of the certificate to create
    Default: friendlyname.aws.e1.nwie.net
  pSAN:
    Type: String
    Description: Subject Alternative Name for CNAME (can use CommonName again if you don't have a SAN)
    Default: anotherfriendlyname.aws.e1.nwie.net

Resources:
  rCertificate:
    Type: Custom::CreateNWCert
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: create-nw-cert
      CommonName: !Ref pCommonName
      Metadata:           #Metadata is required property
        Application_Owner_Group_Email: !Sub "${pResourceOwner}@nationwide.com"
        APRMID: !Ref pAPRMID
        Application_Name: !Ref pProduct
      SANs:
        - !Ref pSAN  # This can also be listed out manually for many values without using param
      Tags:
        ResourceOwner: !Ref pResourceOwner  # This tag is required for ownership tracking
        DisbursementCode: !Ref pDisbursementCode  # This tag is required for ownership tracking

  rLoadBalancerListener:
    Type: AWS::ElasticLoadBalancingV2::Listener
    Properties:
      LoadBalancerArn: !Ref rLoadBalancer
      Port: 443
      Protocol: HTTPS
      Certificates:
        - CertificateArn: !GetAtt rCertificate.Arn
      DefaultActions:
        - Type: forward
          TargetGroupArn: #Your TargetGroup ARN

  rListenerCertificate:
    Type: AWS::ElasticLoadBalancingV2::ListenerCertificate
    Properties:
      Certificates:
        - CertificateArn: !GetAtt rCertificate.Arn
      ListenerArn: !Ref rLoadBalancerListener
```

The above snippet will create a certificate with a Common Name of friendlyname.aws.e1.nwie.net, a single SAN of anotherfriendlyname.aws.e1.nwie.net and apply it to the load balancer listening interface (ALB).


## Example with AutoScaling, ALB, DNS, Certificate, and WAF Usage
```
AWSTemplateFormatVersion: '2010-09-09'
Description: Creates an AutoScaling group, ALB, DNS name, and certificate

Parameters:
  pProduct:
    Type: String
    Default: JTestALB
  pInstanceType:
    Description: EC2 instance type
    Type: String
    Default: m4.large
    AllowedValues:
    - t2.medium
    - t2.large
    - m1.small
    - m1.medium
    - m1.large
    - m1.xlarge
    - m2.xlarge
    - m2.2xlarge
    - m2.4xlarge
    - m3.medium
    - m3.large
    - m3.xlarge
    - m3.2xlarge
    - m4.large
    - m4.xlarge
    - m4.2xlarge
    - m4.4xlarge
    - m4.10xlarge
    - c1.medium
    - c1.xlarge
    - c3.large
    - c3.xlarge
    - c3.2xlarge
    - c3.4xlarge
    - c3.8xlarge
    - c4.large
    - c4.xlarge
    - c4.2xlarge
    - c4.4xlarge
    - c4.8xlarge
    - g2.2xlarge
    - g2.8xlarge
    - r3.large
    - r3.xlarge
    - r3.2xlarge
    - r3.4xlarge
    - r3.8xlarge
    - i2.xlarge
    - i2.2xlarge
    - i2.4xlarge
    - i2.8xlarge
    - d2.xlarge
    - d2.2xlarge
    - d2.4xlarge
    - d2.8xlarge
    - hi1.4xlarge
    - hs1.8xlarge
    - cr1.8xlarge
    - cc2.8xlarge
    - cg1.4xlarge
  pAMIId:
    Description: ID of the AMI to be used
    Type: String
  pServerName:
    Description: Name of the Server
    Type: String
  pDesiredCapacity:
    Description: Desired capacity for the AutoScaling Group
    Type: String
    Default: '1'
  pMinSize:
    Description: Minimum capacity for the AutoScaling Group
    Type: String
    Default: '1'
  pMaxSize:
    Description: Maximum capacity for the AutoScaling Group
    Type: String
    Default: '3'
  pCname:
    Type: String
    Description: Cname to create in DNS (friendlyname)
  pCommonName:
    Type: String
    Description: Name of the certificate to create (friendlyname.aws.e1.nwie.net)
  pSAN:
    Type: String
    Description: Subject Alternative Name for CNAME (anotherfriendlyname.aws.e1.nwie.net) (can use CommonName again if you don't have a SAN)

  # Required Tags
  pPatch:
    Type: String
    Default: False
    Description: Will your server be patched
  pAlert:
    Type: String
    Default: False
    Description: Tag which control stop of instances (EC2:Scheduler)
  pAutoShutDown8pm:
    Description: Flag to indicate that an instance can be shut down at 8pm
    Type: String
    Default: False
  pDisbursementCode:
    Description: Cost Center equivalent
    Type: String
    AllowedPattern: ^[0-9]{9}$
    ConstraintDescription: Must be a valid Disbursement Code
  pResourceOwner:
    Description: Main contact for the resource / asset- Application Owner, Data Owner (NWIE ID)
    Type: String
  pAPRMID:
    Description: Application ID
    Type: String
  pDataClassification:
    Description: Major - Public Data, Internal Use Only, Confidential | Minor - PCI-DSS, PHI, PII and NA
    Type: String
    Default: Internal_Use_Only
  pResourceName:
    Description: Unique Name of the resource and its purpose.
    Type: String
    Default: JTestALB
  pEnvironment:
    Description: Cost Center equivalent
    Type: String
  pLoadBalancerName:
    Description: The name for the load balancer
    Type: String

Resources:
  # Creates a certificate to use on the ALB
  rCertificate:
    Type: Custom::CreateNWCert
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: create-nw-cert
      CommonName: !Ref pCommonName
      SANs:
        - !Ref pSAN
      Tags:
        ResourceOwner: !Ref pResourceOwner
        DisbursementCode: !Ref pDisbursementCode

  # Creates a basic role and instance profile to assign to EC2 instances spun up by autoscaling group
  rProductInstanceRole:
    Type: AWS::IAM::Role
    Properties:
      RoleName: !Sub "${pProduct}-EC2-${pEnvironment}"
      AssumeRolePolicyDocument:
        Version: '2012-10-17'
        Statement:
        - Effect: Allow
          Principal:
            Service:
            - ec2.amazonaws.com
          Action:
          - sts:AssumeRole
      Path: "/"
      Policies:
      - PolicyName: !Sub "${pProduct}-Policy"
        PolicyDocument:
          Version: '2012-10-17'
          Statement:
          - Action:
              - 'ssm:DescribeParameters'
              - 'ec2:DescribeTags'
            Resource: '*'
            Effect: Allow
          - Action:
              - 'ssm:GetParameters'
            Resource: '*'
            Effect: Allow
          - Action:
              - 'logs:CreateLogGroup'
              - 'logs:CreateLogStream'
              - 'logs:PutLogEvents'
              - 'logs:DescribeLogStreams'
            Resource:
              - !Sub "arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:${pProduct}"
              - !Sub "arn:aws:logs:${AWS::Region}:${AWS::AccountId}:log-group:${pProduct}*"
            Effect: Allow
          - Action:
              - 's3:ListBucket'
              - 's3:GetBucketLocation'
              - 's3:GetBucketAcl'
              - 's3:GetObject'
              - 's3:GetObjectAcl'
            Resource: '*'
            Effect: Allow
          - Action:
              - 'kms:Decrypt'
            Resource: '*'
            Effect: Allow

  rProductInstanceProfile:
    Type: AWS::IAM::InstanceProfile
    Properties:
      Path: "/"
      Roles:
      - !Ref rProductInstanceRole

  # Defines the launch configuration for instances in the autoscaling group
  # Uses pre-made WebAccess security group to grant access to all internal Nationwide resources
  rLaunchConfig:
    Type: AWS::AutoScaling::LaunchConfiguration
    Properties:
      UserData:
        Fn::Base64:
          Fn::Join:
          - ''
          - []
      SecurityGroups:
        - !ImportValue OnPrem-AWS-Web-Access
      InstanceType: !Ref pInstanceType
      ImageId: !Ref pAMIId
      IamInstanceProfile: !Ref rProductInstanceProfile

  # Creates the autoscaling group with listening interfaces in all private subnets with all required tags
  rAutoScalingGroup:
    Type: AWS::AutoScaling::AutoScalingGroup
    Properties:
      VPCZoneIdentifier:
        - !ImportValue oPrivateSubnetA
        - !ImportValue oPrivateSubnetB
        - !ImportValue oPrivateSubnetC
      LaunchConfigurationName: !Ref rLaunchConfig
      DesiredCapacity: !Ref pDesiredCapacity
      MinSize: !Ref pMinSize
      MaxSize: !Ref pMaxSize
      Tags:
      - Key: Name
        Value: !Ref pServerName
        PropagateAtLaunch: 'true'
      - Key: Alert
        Value: !Ref pAlert
        PropagateAtLaunch: 'true'
      - Key: AutoShutDown8pm
        Value: !Ref pAutoShutDown8pm
        PropagateAtLaunch: 'true'
      - Key: APRMID
        Value: !Ref pAPRMID
        PropagateAtLaunch: 'true'
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
        PropagateAtLaunch: 'true'
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
        PropagateAtLaunch: 'true'
      - Key: DataClassification
        Value: !Ref pDataClassification
        PropagateAtLaunch: 'true'
      - Key: ResourceName
        Value: !Ref pResourceName
        PropagateAtLaunch: 'true'
      - Key: Environment
        Value: !Ref pEnvironment
        PropagateAtLaunch: 'true'

  # Defines a single step increment when scaling up
  rServerScaleUpPolicy:
    Type: AWS::AutoScaling::ScalingPolicy
    Properties:
      AdjustmentType: ChangeInCapacity
      AutoScalingGroupName: !Ref rAutoScalingGroup
      Cooldown: '60'
      ScalingAdjustment: '1'

  # Defines a single step increment when scaling down
  rServerScaleDownPolicy:
    Type: AWS::AutoScaling::ScalingPolicy
    Properties:
      AdjustmentType: ChangeInCapacity
      AutoScalingGroupName: !Ref rAutoScalingGroup
      Cooldown: '60'
      ScalingAdjustment: "-1"

  # Defines CPU-based rule to scale up the autoscaling group
  rCPUAlarmHigh:
    Type: AWS::CloudWatch::Alarm
    Properties:
      AlarmDescription: Scale-up if CPU > 90% for 10 minutes
      MetricName: CPUUtilization
      Namespace: AWS/EC2
      Statistic: Average
      Period: '300'
      EvaluationPeriods: '2'
      Threshold: '90'
      AlarmActions:
      - Ref: rServerScaleUpPolicy
      Dimensions:
      - Name: AutoScalingGroupName
        Value: !Ref rAutoScalingGroup
      ComparisonOperator: GreaterThanThreshold

  # Defines CPU-based rule to scale down the autoscaling group
  rCPUAlarmLow:
    Type: AWS::CloudWatch::Alarm
    Properties:
      AlarmDescription: Scale-down if CPU < 70% for 10 minutes
      MetricName: CPUUtilization
      Namespace: AWS/EC2
      Statistic: Average
      Period: '300'
      EvaluationPeriods: '2'
      Threshold: '70'
      AlarmActions:
      - Ref: rServerScaleDownPolicy
      Dimensions:
      - Name: AutoScalingGroupName
        Value: !Ref rAutoScalingGroup
      ComparisonOperator: LessThanThreshold

  # Sets up a target group, probing with HTTPS to 443 every 60 seconds
  rTargetGroup:
    Type: AWS::ElasticLoadBalancingV2::TargetGroup
    DependsOn: rLoadBalancer
    Properties:
      Name: !Sub ${pProduct}-${pEnvironment}
      VpcId: !ImportValue oVPCID
      Port: 443
      Protocol: HTTPS
      Matcher:
        HttpCode: 200-299
      HealthCheckIntervalSeconds: 60
      HealthCheckPath: /
      HealthCheckProtocol: HTTPS
      HealthCheckTimeoutSeconds: 5
      HealthyThresholdCount: 2
      TargetGroupAttributes:
        - Key: deregistration_delay.timeout_seconds
          Value: 30

  # Creates Application Load Blancer (ALB)
  rLoadBalancer:
    Type: AWS::ElasticLoadBalancingV2::LoadBalancer
    Properties:
      Name: !Ref pLoadBalancerName
      Subnets:
        - !ImportValue oPrivateSubnetA
        - !ImportValue oPrivateSubnetB
        - !ImportValue oPrivateSubnetC
      Scheme: internal
      SecurityGroups:
        - !Ref rSecurityGroup
      Tags:
      - Key: DisbursementCode
        Value: !Ref pDisbursementCode
      - Key: ResourceOwner
        Value: !Ref pResourceOwner
      - Key: APRMID
        Value: !Ref pAPRMID
      - Key: ResourceName
        Value: !Ref pResourceName
      - Key: Environment
        Value: !Ref pEnvironment

  # Creates ALB listener
  rLoadBalancerListener:
    Type: AWS::ElasticLoadBalancingV2::Listener
    Properties:
      LoadBalancerArn: !Ref rLoadBalancer
      Port: 443
      Protocol: HTTPS
      Certificates:
        - CertificateArn: !GetAtt rCertificate.Arn
      DefaultActions:
        - Type: forward
          TargetGroupArn: !Ref rTargetGroup

  # Applies certificate to the ALB listener
  rListenerCertificate:
    Type: AWS::ElasticLoadBalancingV2::ListenerCertificate
    Properties:
      Certificates:
        - CertificateArn: !GetAtt rCertificate.Arn
      ListenerArn: !Ref rLoadBalancerListener

  # Forwards all paths
  rListenerRule:
    Type: AWS::ElasticLoadBalancingV2::ListenerRule
    Properties:
      ListenerArn: !Ref rLoadBalancerListener
      Priority: 1
      Conditions:
        - Field: path-pattern
          Values:
            - /
      Actions:
        - TargetGroupArn: !Ref rTargetGroup
          Type: forward

  # Adds WAF policy to ALB
  rWAFAssociation:
    Type: "AWS::WAFRegional::WebACLAssociation"
    Properties:
      ResourceArn: !Ref rLoadBalancer
      WebACLId: !ImportValue oWAFWebACL

  # Create friendly DNS name
  rAddCNAME:
    Type: Custom::RemoteRoute53
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: remote-route53
      RecordType: CNAME  # A and PTR are not currently supported
      RecordName: !Ref pCname # should not have .aws.e1.nwie.net on it, just the name
      RecordValue: !GetAtt rLoadBalancer.DNSName

Outputs:
  oAutoScalingGroupId:
    Description: AutoScaling Group Id
    Value: !Ref rAutoScalingGroup

  oLaunchConfigurationId:
    Description: Launch configuration Id
    Value: !Ref rLaunchConfig

  oALBInternalDNSName:
    Description: DNS name of the ELB
    Value: !Ref pCommonName

  oSecuritygroup:
    Description: ID of the security group created
    Value: !GetAtt rSecurityGroup.GroupId
```

## Debugging failures

A common error when running the code below in your pipeline
```
  rCertificate:
    Type: Custom::CreateNWCert
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
      CustomResourceName: create-nw-cert
```

is

```
Failed to create resource. | See the details in CloudWatch Log Stream: 2020/05/19/[$LATEST]6f8f5932b1ff4e5e914369c6a7debf02 
```

**Where are the log files**

* When the code run a lambda **create-nw-cert** is executed in the **InfraSrvcsProd** account. 
* The logs for the lambda are also the **InfraSrvcsProd** account and not your **Dev/Test/Prod/Tools** account
* To find the logs
    * Login into **InfraSrvcsProd**
    * Goto the **CloudWatch** service
    * Select **Logs -> Log Groups**
    * In the **Filter** search enter the following **/aws/lambda/create-nw-cert**
    * Click on **/aws/lambda/create-nw-cert** loggroup
    
        <img class="img-responsive w-50" src="/docs/aws/images/cloudwatch-createcert-lambda-loggroup.jpg">
        
    * Select your log based on when you ran on from the error message from you Cloudformation stack ```e.g. 2020/05/19/[$LATEST]6f8f5932b1ff4e5e914369c6a7debf02```

        <img class="img-responsive w-50" src="/docs/aws/images/cloudwatch-lambda-log.jpg">
        
