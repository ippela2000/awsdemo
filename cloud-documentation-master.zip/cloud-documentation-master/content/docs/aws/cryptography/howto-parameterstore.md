---
title: Parameter Store
menu: docs
category: aws
---

## Description

AWS Systems Manager Parameter Store provides secure, hierarchical storage for configuration data management and secrets management.  Nationwide will centrally store Usernames, Passwords, and configuration files here so that they can be managed from a single point.  Securing and allowing minimal access to the Parameter Store is crucial to preventing unauthorized access to privileged information.

## When are they encrypted

Parameters are stored encrypted and passed to an instance encrypted; but they can be easily viewed in clear text via the Parameter Store or on the instance calling the Parameter.  Actions that require information from the Parameter Store should be executed in a way that does not expose them to the end user.

## Access to parameters

* AWS Policies controls access to parameters.  
* Action type “ssm:GetParameters” gives access to read any Parameter. It should be limited only to roles that need it.  
* You should use a KMS key to encrypt parameters. This can be a **Custom Key** or **AWS Managed Key** e.g  alias/aws/ssm
* You can create a **Customer Managed Key** using the **Key Management Service** to limit access to a key


## Creating a custom KMS key using the AWS console (Dev ONLY)
* Go to the KMS Service.
* Select **Customer Managed Keys**
* Select Advanced Options Key Material Origin: KMS and create a Custom Key

![ssm_kms_key](/docs/aws/images/ssm_kms_key.jpg)

* Assign Key Administrators: (these are users who can change the key)

```yaml
        {
            "Sid": "AllowAdministratorAccess",
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::555495844400:role/ESSSIRISRESTORE-ESS01-codepipeline-action-us-east-1",
                    "arn:aws:iam::555495844400:role/UTILITY-GigCfnDeployer",
                    "arn:aws:iam::555495844400:role/DevESS01-CLOUDADMIN-AWS",
                    "arn:aws:iam::555495844400:role/OrganizationAccountAccessRole",
                    "arn:aws:iam::555495844400:role/Apotheosis-TeamRole-AWS"
                ]
            },
            "Action": [
                "kms:Create*",
                "kms:Describe*",
                "kms:Enable*",
                "kms:List*",
                "kms:Put*",
                "kms:Update*",
                "kms:Revoke*",
                "kms:Disable*",
                "kms:Get*",
                "kms:Delete*",
                "kms:TagResource",
                "kms:UntagResource",
                "kms:ScheduleKeyDeletion",
                "kms:CancelKeyDeletion"
            ],
            "Resource": "*"
        }
```


* Give your **team-role** and other users access to use the key e.g. ```arn:aws:iam::555495844400:role/Apotheosis-TeamRole-AWS``` access to the key, by updating the Key Policy
```yaml
        {
            "Sid": "AllowUserAccess",
            "Effect": "Allow",
            "Principal": {
                "AWS": [
                    "arn:aws:iam::555495844400:role/ESSSIRISRESTORE-DevESS01-EC2-us-east-1",
                    "arn:aws:iam::555495844400:role/Apotheosis-TeamRole-AWS",
                    "arn:aws:iam::555495844400:root"
                ]
            },
            "Action": [
                "kms:Encrypt",
                "kms:Decrypt",
                "kms:ReEncrypt*",
                "kms:GenerateDataKey*",
                "kms:DescribeKey"
            ],
            "Resource": "*"
        }

```

* Add Tags (Optional):  This can help with knowing the key's use
* Review Key Policy and click **Finish**
* The key is now accessible only to specified Role or users assigned in the key policy.

## Create a parameter using the console (Dev ONLY)

* Select Parameter Store in AWS Systems Manager
* Select Create Parameter button
* Assign a name, description, and select SecureString as the Type
* Assign the KMS Key ID (which is the key previously created in the Encryption Keys section of IAM)
* Set the Value and click Create Parameter
* **The value is now encrypted and accessible only to Roles and Users specified on the Encryption Keys section**
![ssm_console](/docs/aws/images/ssm_console.jpg)


## How to add SSM parameter to the parameter store for test and prod environments

### 1) Add files to your Git repo (iac\CloudFormation)
* To add a SSM Parameter in Test and Prod environments you need to create a Code Pipeline.
* In your Cloud Formation, you will call a Custom Lambda to create the Parameter Store entries not the native CF yaml
```yaml
  rSSMParameter:
    Type: Custom::SSMParameter
    Properties:
      ServiceToken: !Sub "arn:aws:lambda:us-east-1:${AWS::AccountId}:function:SSMParameter"
```
* Add the following files to your iac\CloudFormation folder in your Github repo: 
  * [SSM Parameter.json](https://github.nwie.net/Nationwide/AWS-CloudFormation/blob/master/SSMParameter/SSMParameter.json) 
  * [SSM Parameter.yaml](https://github.nwie.net/Nationwide/AWS-CloudFormation/blob/master/SSMParameter/SSMParameter.yaml)

**SSM Parameter Store JSON** <br />
![SSMParameterJSON](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/SSMJSON.png) <br />
    1. pSSMParameterName - **Required Variable** this is the name of the parameter you wish to create. <br />
    2. pSSMParameterDesc - **Required Variable** this is a description of the parameter you wish to create.<br />
    3. pKmsId - *Optional* this is the Key ID of the KMS Key that you wish to use to encrypt the parameter value. If you do not provide this parameter, the SSM Parameter you created will be public to the account. <br />
    4. pOverwrite - *Optional* this is a optional variable that accepts True or False (case sensitive) values. If this parameter is set to true, on upon creation it will create the parameter as requested, but upon rerun of your pipeline it will overwrite a value for your parameter in the parameter store. <br />
    5. pTeamRole - *Optional* this is an optional variable, providing it attaches a tag that will give the users the ability to go in and change password of the SSM Parameter after it has been created. <br />

For unwanted optional variables, comment them out or delete them from the file.<br />

**SSM Parameter CloudFormation** <br />
![SSMParameterCloudFormation](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/SSMCloudFormation.png)

For unwanted optional variables, comment them out or delete them from the file.<br />

### 2) Add the SSM parameter stage to your codepipeline.yaml file
The changes to your codepipeline.yaml are also listed below. The passwords will be randomly generated strings of characters anywhere from 8 to 12 characters in length.

**SSM Parameter added to pipeline** <br />
This is an example of a code snippit that will need to be added to the codepipeline.yaml in the test and prod stages <br />
In the example below, this is running in the test environment. <br />
![CodePipeline Snippet](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/SSMParameterCodepipeline.png)

## How to create a SSM parameter with a value of your choice
* If you would like to create a SSM Parameter with a desired value, you must add your federated application team role as the value of pTeamRole parameter in your [SSMParameter.json](https://github.nwie.net/Nationwide/AWS-CloudFormation/blob/master/SSMParameter/SSMParameter.json) file:
![pTeamRole](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/ValueSet.png)
* An example of **YourFederatedTeamRole** is **Apothesis**, this is only the **Team Name** _NOT_ the fullname of the role.
![ssm_param_json](/docs/aws/images/ssm_param_json.jpg)

* This in turn adds a tag to your SSM Parameter named "Team" with a value of your federated application team role. 
  
![TeamRoleTag](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/TeamRoleTag.png)<br />

* Example **Tag**
![team_tag](/docs/aws/images/team_tag.jpg)

This will then give everyone with access to the federated application team role the ability to make edits to the SSM Parameter in Test and Prod via console.<br />

Once the the SSM Parameter has been added, and the desired value for it has been set, if you wish to re-run the pipeline set pOverwrite to False in the SSMParameter.json file and it will not change via pipeline:
![OverwriteImage](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/OverwriteFalse.png) <br />

## Example repository
 
 Below is an application that implemented SSM ParamterStore using a Custom KMS key in a CodePipeline
  * [ESS-SIRIS-SQL-RESTORE](https://github.nwie.net/Nationwide/ESS-SIRIS-SQL-RESTORE/blob/master/iac/CloudFormation/SSMParameter.yaml)  

For more information on Federated Application Team Roles follow this [link](/docs/aws/getting-started-with-aws/howto_federatedappteamroles).

