---
title: SSL Public Certificate
menu: docs
category: aws
---


## What is it?
Websites that will be serving HTTPS require an SSL certificate to be hosted in ACM.
SSL certificates need to match the friendly DNS name that will be used when accessing the resource or will show as invalid, so you will also need to register a friendly name for your load balancer/cloudfront-distribution.

Creating of external certs is not fully automated at this time. Below are the steps you will follow
1. DNS name creation can be done using the ```Type: Custom::RemoteRoute53``` function
2. Request an Alias to the Hosting Team (Optional)
3. Public Certification creation is still a manual step to the Middleware team
4. Once certificate is obtained you will need to reach out to CDT to get it imported in ACM.


### Friendly DNS Name

You will also need a DNS associated with the Certificate you requested.

Depending on how you are implementing your application you will most likely be using a Public ALB or CloudFront. You will use one of the code snippets below

For internet-facing applications, use public domain, awspubliccloud.nationwide.com. For Test and Dev instances, use [t or d].awspubliccloud.nationwide.com. The cert provided automatically is signed from the local on-prem CA (only valid from Nationwide devices). It is intentional that publicly trusted certs for X.awspubliccloud.nationwide.com domains are internally trusted only, as apps should not be exposed to external users with that domain, only X.nationwide.com.

   * Get a public CNAME for your load balancer.

     ```
        rAddCNAME:
            Type: Custom::RemoteRoute53
            Properties:
            ServiceToken: !Sub "arn:aws:lambda:${AWS::Region}:${AWS::AccountId}:function:ExecuteCustomResource"
            CustomResourceName: remote-route53
            Account: !Sub "${AWS::AccountId}"
            RecordType: CNAME  # A and PTR are not currently supported
            RecordName: !Ref pCname # should not have just the name e.g 'media'
            RecordValue: !GetAtt rLoadBalancer.DNSName
            Public: true
     ```

   * Get a public CNAME for your CloudFront Distribution.

        ```
          rAddCNAME:
            Condition: TestOrProd
            Type: Custom::RemoteRoute53
            Properties:
              ServiceToken: !Sub "arn:aws:lambda:us-east-1:${AWS::AccountId}:function:RemoteRoute53"
              Account: !Sub "${AWS::AccountId}"
              RecordType: CNAME # A and PTR are not currently supported
              RecordName: !Ref pCname # should not have .aws.e1.nwie.net on it, just the name
              RecordValue: !GetAtt myDistributionTest.DomainName
              Public: true
        ```

This will give you a record of **{pCname}.awspubliccloud.nationwide.com** e.g. **media.awspubliccloud.nationwide.com** that you can use as the target of an X.nationwide.com alias. More details can be found at [How_To_DNS](/docs/aws/network-content-delivery/route53/howto_dns)

### Request an Alias with the Hosting Team for Custom DNS

- You might want to further customize your DNS to be for example to be **media.nationwide.com** instead of **media.awspubliccloud.nationwide.com**
- Follow these [instructions](/docs/aws/network-content-delivery/route53/howto_customdns/) on how.


### Request an external SSL Certificates with the Middleware team

- Requesting an external SSL certificate is still a manual process.
- If you have an existing cert, you can re-use that.
- For new certificate Submit ServiceNow request to [Web Middleware Support Services](https://nwproduction.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3Df666b2e70f17ce00085d6509b1050e68%26sysparm_link_parent%3Dcb8d9b290f1f7100a5eee478b1050e65%26sysparm_catalog%3De0d08b13c3330100c8b837659bba8fb4%26sysparm_catalog_view%3Dcatalog_Service_Catalog).
  - Select SSL Certificate for Request Type and complete the required fields.
  - If needed: [Request form instructions](https://onyourside.sharepoint.com/:w:/r/sites/SSLCertificateManagement/_layouts/15/Doc.aspx?sourcedoc=%7BCF3354BB-43E7-4F82-9F87-4793EEAF663E%7D&file=Request%20External%20Certificates.docx&action=default&mobileredirect=true) and skip to “COMPLETE THE REQUEST FORM” section.
  - You will need certificates for all your environments.
  - You will need the following from the Middleware team once the request is completed
    - Certificate Private key (This should be unencrypted)
    - Certificate Body
    - Certificate Chain of Authority


### Upload the Certificate to ACM

- Once the certificate is created, provide it to a member of CIE to be added into the AWS Certificate Manager for the environment it is being used
- This can be done via [Auxiliary Service Request](https://nwproduction.service-now.com/com.glideapp.servicecatalog_cat_item_view.do?v=1&sysparm_id=1a9708690f465a00085d6509b1050ed5) to CLOUD-SOLUTIONS
- DO NOT ATTACH unencrypted keys to the ticket, have the team reach out to you for the details to upload the certificate in AWS to ACM in the correct environment
    - Certificate Private key (This should be unencrypted)
    - Certificate Body
    - Certificate Chain of Authority
- Save the ACM ARN.



