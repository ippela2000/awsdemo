---
title: Secrets Manager
menu: docs
category: aws
---

### Secrets Manager

AWS Secrets Manager enables you to store, retrieve, control access to, rotate, audit, and monitor secrets centrally.

 To retrieve secrets, you replace secrets in plain text in your applications with code to pull in those secrets programmatically using the Secrets Manager API or via cloudformation in your pipeline.  You use AWS Identity and Access Management (IAM) policies to control which users and applications can access these secrets. 

**Note:** *Secrets must be created in higher environments via cloudformation, and a random password should be generated.  Information on Generating a random password [here](https://docs.aws.amazon.com/secretsmanager/latest/apireference/API_GetRandomPassword.html).*

To create and use a secret via your pipeline, note that the following steps should be followed in order:

1.  Define the secret without referencing the service or database. You can't reference the service or database because it doesn't exist yet.    
2. Define a resource-based permission policy for the secret (optional)
3.  Next, define the service or database. Include the reference to the secret to use stored credentials to define the database master user and password.  Note that this is not included in the snippets below.  You will add the first 'create secret' snippet above your current yaml for the resource, then add the 'secret attachment' snippet below your current yaml for the resource.
4.  Finally, define a `SecretTargetAttachment` resource type to finish configuring the secret with the required database engine type and the connection details of the service or database. 

### Secrets Manager Cloudformation snippets

The following cloudformation snippets can be added to one of your existing pipeline templates (e.g., ec2.yaml, loadbalancerautoscaling.yaml, s3.yaml, etc).  

The snippet includes the Team Tag, enabling your access to the secret upon deployment. In addition to the secret snippet, you may also want to create a KMS key for encrypting/decrypting the secret and IAM access.  An example with appropriate access is provided at the bottom of this page.

#### Secret with Randomly-generated Password:

     Resources:  
      rSecretsManager:  
        Type: AWS::SecretsManager::Secret  
        Properties:  
          Name: MyAppSecret  
          Description: "This is a secret with a dynamically generated password."  
          GenerateSecretString:  
            SecretStringTemplate: '{"username": "yourusername"}'  
            GenerateStringKey: 'password'  
            PasswordLength: 16  
            ExcludeCharacters: '"@/\'  
          KmsKeyId: !Ref pKMSID  
          Tags:  
          - Key: DisbursementCode  
            Value: !Ref pDisbursementCode  
          - Key: ResourceOwner  
            Value: !Ref pResourceOwner  
          - Key: DataClassification  
            Value: !Ref pDataClassification  
          - Key: APRMID  
            Value: !Ref pAPRMID  
          - Key: Team  
            Value: YourFederatedTeamTag  

#### Secret with Hard-coded Password (not recommended):
      Resources: 
       rSecretsManager: 
          Type: 'AWS::SecretsManager::Secret'  
          Properties:  
            Name: MyNonSecureSecret  
            Description: This secret has a hardcoded password in SecretString (use GenerateSecretString instead)  
            SecretString: '{"username":"MasterUsername","password":"secret-password"}'  
            KmsKeyId: !Ref pKMSID 
            Tags:  
            - Key: DisbursementCode  
              Value: !Ref pDisbursementCode  
            - Key: ResourceOwner  
              Value: !Ref pResourceOwner  
            - Key: DataClassification  
              Value: !Ref pDataClassification  
            - Key: APRMID  
              Value: !Ref pAPRMID  
            - Key: Team  
              Value: YourFederatedTeamTag  

#### Create a Resource-Based Permission Policy for the Secret:
```
  rMySecretResourcePolicy:
      Type: 'AWS::SecretsManager::ResourcePolicy'
      Properties:
          SecretId: !Ref rSecretsManager
          ResourcePolicy:
            Version: 2012-10-17
            Statement:
              - Resource: '*'
                Action: 'secretsmanager:DeleteSecret'
                Effect: Deny
                Principal:
                  AWS: !Sub 'arn:aws:iam::${AWS::AccountId}:root'
```
#### Secret Target Attachment:
  This is a SecretTargetAttachment example resource for an RDS instance.  It updates the referenced Secret resource with properties about the referenced RDS instance
 ```
  rSecretRDSInstanceAttachment
    Type: "AWS::SecretsManager::SecretTargetAttachment"
    Properties:
      SecretId: !Ref rSecretsManager
      TargetId: !Ref rMyRDSInstance
      TargetType: AWS::RDS::DBInstance
```

#### KMS Key for Secrets Manager:

**Note** you can omit the KMSKey from the secret, and the standard aws/secretsmanager KMS Key will be automatically created and assigned to your secret. If creating your own KMS key, you must provide permissions for secrets managers as in the example below:

    rResources:  
      rProductKmsKeyParam:  
        Type: AWS::KMS::Key  
        Properties:  
          Enabled: true  
          EnableKeyRotation: false  
          KeyPolicy:  
            Version: '2012-10-17'  
            Id: key-default-1  
            Statement:  
              - Sid: Enable Secrets Manager Key  
                Effect: Allow  
                Principal:  
                  AWS:  
                    - !Sub "arn:aws:iam::${AWS::AccountId}:root"  
                    - !Sub "arn:aws:iam::${AWS::AccountId}:role/${pActionRole}"  
                  Action:  
                    - kms:Encrypt,  
                    - kms:Decrypt,  
                    - kms:ReEncrypt*,  
                    - kms:GenerateDataKey*,  
                    - kms:CreateGrant,  
                    - kms:DescribeKey  
                  Resource: '*',  
                    Condition: {  
                        StringEquals: [  
                            - kms:ViaService:"secretsmanager.us-east-1.amazonaws.com",  
                            - kms:CallerAccount:${AWS::AccountId}  
                      ]  
                   }  
              - Sid: allow Role access to key  
                Effect: Allow  
                Principal:  
                  AWS: !GetAtt YourRoleARNforAccess  
                Action:  
                  - kms:Encrypt,  
                  - kms:Decrypt,  
                  - kms:ReEncrypt*,  
                  - kms:GenerateDataKey*,  
                  - kms:DescribeKey  
                Resource: '*'  
          Tags:  
          - Key: DisbursementCode  
            Value: !Ref pDisbursementCode  
          - Key: ResourceOwner  
            Value: !Ref pResourceOwner  
          - Key: DataClassification  
            Value: !Ref pDataClassification  
          - Key: APRMID  
            Value: !Ref pAPRMID  
          - Key: Team  
            Value: YourFederatedTeamRoleTag  
