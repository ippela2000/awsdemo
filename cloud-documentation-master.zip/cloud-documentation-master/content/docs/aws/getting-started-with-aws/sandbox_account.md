---
title: Temporary Sandbox Account
menu: docs
category: aws
description: Details on obtaining a temporary unrestricted sandbox account for AWS service experimentation.
weight: 1
---

**AWS BSA accounts will not longer come with a permanent Sandbox account**

<br />

## AWS Temporary Sandbox Accounts

The typical AWS BSA accounts come with a lot of security restrictions and requirements. Newly released AWS services are also not enabled in these account until they have been requested and reviewed. 

Many users want the ability to experiment with AWS services without the Natinowide security controls in the way, commonly while working through online courses or testing if a new AWS service might be good for thier application.
   
To facilitate this need, and reduce cost from the previous always-on BSA Sandbox accounts, a process for requesting a 30-day fully unrestricted account has been made. <br /><br />

## Account Details

* Accounts last for 30 days, with no extensions or exceptions
* Users have full administrative access in these accounts
* There are no required tags, security responders, etc.
* The accounts do not have any connectivity to Nationwide's on-prem network
* The accounts do not have any connectivity to other BSA AWS accounts
* **No Nationwide data, PII data, PCI data, etc. is allowed in these accounts** you are fully response for ensuring that Nationwide data does not end up in your Sandbox account.

## Requesting a Sandbox Account

To request a temporary sandbox account, [submit a request](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=new_sandbox_account.md) to the CIE team.

You will receive an email with details on signing in once the account has been created.

You will also receive warning emails 7 days before and 1 day before the account is set to be deleted to remind you to remove anything you wish to keep.

**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

## Additional User Access to Sandbox Account

Part of the Sandbox account creation will be a new Active Directory group tied to a federated role within the account. 
In the request you are asked for a list of users to include in this group. The group name will be provided in the welcome email you will receive when the account is created.
If you need to add additional people to the group after creation, you can submit a standard group addition request in IIQ:

   * Login to [IIQ](https://iiq.nwie.net/identityiq/home.jsf)

   * Click on the **Menu Icon**. Note:If IIQ.nwie.net is not added to your list of trusted websites, the menu lines will not show up

     <img class="img-responsive w-25" src="/docs/aws/images/iiq-menu.jpg">
     

   * Click on  **Manage Access** -> **Manage User Access**
   
     <img class="img-responsive d-flex w-25" src="/docs/aws/images/iiq_manage-user-access.jpg">


   * Search for the user using the nwieid e.g. **KALURK2** and select it. 
   
     <img class="img-responsive w-50" src="/docs/aws/images/iiq_search_user.jpg">


   * You can search and select multiple users.
   
     <img class="img-responsive w-50" src="/docs/aws/images/iiq_multiple_user.jpg">
     

   * Next, click on **Manage Access** tab -> **Add Access** tab -> Search for the AD group you want to be added to add. You can add multiple AD groups in the same request.
     ```
        e.g.
            * DEVIO02-CUSTOMADMIN-AWS_542948635112
            * SamuraiCats-TeamRole-AWS_416350540093
     ```           
     <img class="img-responsive w-75" src="/docs/aws/images/iiq_aws_ad_group.jpg">
    
    
   * Next click on the **Review** tab and click the **Submit** button at the end of the page     
     <img class="img-responsive w-75" src="/docs/aws/images/iiq_aws_review_submit.jpg">
    
    
   * You will receive an email when your UserID has been added to the appropriate groups. This process could take anywhere from 1-2 weeks.

   * You can also check the status of your request in the IIQ home page under **Track My Requests**
    <img class="img-responsive w-100" src="/docs/aws/images/iiq_track_requests.jpg">
