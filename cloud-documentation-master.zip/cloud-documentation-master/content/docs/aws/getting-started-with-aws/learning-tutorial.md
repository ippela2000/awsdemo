---
title: Tutorial
menu: docs
category: aws
---

Below is a recommended path to getting started with using AWS Services.

## Get Foundational Training
* Getting a good understanding of you AWS Services will set you up for success on your cloud journey. Start with the [foundational-aws-learning page](https://cloud-documentation.apps.aws.e1.nwie.net/learning/aws/general/foundational-aws-learning/) 

## Simple Storage Service
* [Simple Storage Service, or S3](https://docs.aws.amazon.com/AmazonS3/latest/user-guide/what-is-s3.html), provides highly scalable object storage for your application's data files. 
* It can also be used to host public-facing static web content in conjunction with the CloudFront CDN service.
* Use the [Learning section](/learning/aws/general/beginner-aws-learning/) to understand this service
* We also recommend completing **[this S3 tutorial](https://github.nwie.net/Nationwide/cloud-tutorials/blob/master/s3/create-a-new-s3.md)** to get familiar with the service in NW accounts


## Identity Access Management
* [Identity Access Management, or IAM](https://docs.aws.amazon.com/IAM/latest/UserGuide/introduction.html) is an aws service to help you secure access to you AWS account and resources.
* Use the [Learning section](/learning/aws/general/beginner-aws-learning/) to understand this service


## Elastic Compute Cloud
* [Elastic Compute Cloud, or EC2](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/concepts.html), provides virtual machines and block storage to run your application. Firewalls, load balancing, and auto - scaling are also part of the EC2 service.
* Use the [Learning section](/learning/aws/general/beginner-aws-learning/) to understand this service
* We also recommend completing **[this EC2 tutorial](https://github.nwie.net/Nationwide/cloud-tutorials/blob/master/ec2/create-ec2.md)** to get familair on how to standup an EC2 in Nationwide BSA accounts.


## CloudWatch
* [CloudWatch](https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/WhatIsCloudWatch.html) provides monitoring, logging, and alerting for resources in AWS. 
* Use the [Learning section](/learning/aws/general/beginner-aws-learning/) to understand this service

## AWS CLI
* [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/cli-chap-welcome.html) is a command line tool to manage your AWS resource
* Using the AWS CLI required additional configuration.
* Follow the instruction on the [AWS CLI GoCloud page](/docs/aws/management-and-governance/aws-cli/howto-awscli/) to setup the **AWS CLI**; **Federator** & **PIDM** 
* Use the [Learning section](/learning/aws/general/advanced-aws-learning-developer/) to understand this service and also run sample CLI commands


## CloudFormation
* Now that you know how to deploy EC2 Servers and S3 bucket in AWS we will learn how to use CloudFormation to deploy them
* [CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html) is an AWS service that allows you to define your AWS infrastructure as code, in YAML or JSON format. 
* Then, your code can be instantiated to create real resources in AWS for your application to consume. 
* Use the [Learning section](/learning/aws/general/intermediate-aws-learning/) to understand this service
* You can then refer to the [Cloudformation on GoCloud](/docs/aws/management-and-governance/cloud-formation/) to deploy Cloudformation in your BSA stack


## CodeBuild
* Next you should understand the CodeBuild Service in the Cloud 
* [CodeBuild](https://docs.aws.amazon.com/codebuild/latest/userguide/welcome.html) a a fully managed build service in AWS. 
* Use the [Learning section](/learning/aws/general/intermediate-aws-learning/) to understand this service. **Note: At Nationwide CodePipelines are centralized to the Tools Accounts**


## CodeDeploy
* [CodeDeploy](https://docs.aws.amazon.com/codedeploy/latest/userguide/welcome.html) is a deployment service that automated application deployment in AWS. 
* Use the [Learning section](/learning/aws/general/intermediate-aws-learning/) to understand this service. **Note: At Nationwide CodePipelines are centralized to the Tools Accounts**


## CodePipeline
* Codepipeline helps you automate steps in your software delivery process, such as initiating automatic builds and then deploying to Amazon EC2 instances. 
* Use the [Learning section](/learning/aws/general/intermediate-aws-learning/) to understand this service, **Note: At Nationwide CodePipelines are centralized to the Tools Accounts**
* You can then refer to the [CodePipeline on GoCloud](/docs/aws/developer-tools/codepipeline/howto-codepipeline-at-nationwide) to deploy a CodePipeline in your BSA stack

## Other resources 
* Check out the videos in the Teaching Thursday series on cloud [here](https://videospace.nationwide.com/channel/Cloud%2BEnablement/93125981).
* Also check out Robot Pirate Radio, a discussion forum about all things innovation at Nationwide. [Join the movement](https://onyourside.sharepoint.com/sites/KISS/SitePages/Robot%20Pirate%20Radio.aspx)!

**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

**[Previous - Additional Access](/docs/aws/getting-started-with-aws/additional-access/)**
