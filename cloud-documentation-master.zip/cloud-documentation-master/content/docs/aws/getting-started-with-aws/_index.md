---
title: "Getting Started with AWS"
description: "Getting Started with AWS"
menu: docs
category: aws
weight: 4
---

## Overview
This section has all the details on what you will need to get started with using AWS at Nationwide.

1. How to get access to AWS
2. Basic services you should be familiar with like **EC2**, **S3**, **CloudWatch** etc.
3. Get familiar with using **AWS CLI**
4. Understanding Infrastructure as Code with **CloudFormation**
5. Deploying changes with **CodePipeline** and **Service Catalog**
6. How to deploy your own application to the cloud.

If you get stuck or have questions the tutorial doesn't cover, please reach out to us on **[RocketChat](https://rocketchat.nwie.net/channel/AWS)**.

Let's get started!

**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

**[Next - Getting Access to AWS](/docs/aws/getting-started-with-aws/access-to-aws/)**
