---
title: Other Access Requests
description: "Getting access to Splunk and New Relic"
menu: docs
category: aws
weight: 4
---

## Access to Splunk Cloud

* All the logs from AWS (CloudWatch; CloudTrail etc) are in Splunk and can be queried for debugging and analysis. You can get access and learn how to use Splunk from the [DevOps Portal for Splunk](https://devops-portal-ui.apps.aws.e1.nwie.net/tools/splunk/overview)


## Access to New Relic

* At Nationwide we use New Relic to build observability (Monitoring & Alerting) for our Apps. You can get access and learn how to use NewRelic from the [DevOps Portal for NewRelic](https://devops-portal-ui.apps.aws.e1.nwie.net/tools/newrelic/overview) page  

## Other access requests

Other access requests that teams usually need are
* Requesting a [GenericID](https://onyourside.sharepoint.com/sites/IDADMIN/SitePages/Home.aspx) for RDS.
* Requesting a [Federated Application Team Role](/docs/aws/getting-started-with-aws/howto_federatedappteamroles)

**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

**[Previous - Federated Team Role](/docs/aws/getting-started-with-aws/howto_federatedappteamroles))**/**[Next - Learning Tutorial](/docs/aws/getting-started-with-aws/learning-tutorial/)**
