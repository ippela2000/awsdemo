---
title: Login into AWS
menu: docs
category: aws
weight: 2
---



## Logging Into AWS Console with PrimaryID

* With Multi-Factor Authentication enabled (MFA) you no longer have to use a [Secondaryid](/docs/aws/getting-started-with-aws/getting-secondary-id)** to login into AWS. You can now use your primaryId and password
* Navigate to [Nationwide's AWS Login Page](https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=urn:amazon:webservices) 
* Enter your nwieid and password.
* If your nwie-id is not registered for MFA, you will prompted at this time to enroll.
* Follow the instruction at [Multi-Factor Authentication (MFA) - Enrollment and Authentication Flow](https://nwproduction.service-now.com/kb_knowledge.do?sys_id=0b39b053dbe29f046019f3e31d961975&sysparm_record_target=kb_knowledge&sysparm_record_row=7&sysparm_record_rows=14&sysparm_record_list=active%3Dtrue%5Eworkflow_state%21%3Dretired%5Eu_owner%3Djavascript%3Anew+NWGroups%28%29.myGroups%28%29%5Elatest%3DNULL%5EORlatest%3Dtrue%5EORDERBYnumber)
* Once logged in, make sure you are in the **N. Virginia** region, which can be seen/changed in the upper right once signed in.

    <img class="img-responsive w-50" src="/docs/aws/images/region-n.virgina.jpg">

## Debugging login failures

   * SAML Errors

        * If you get a SAML error when you login into AWS
        
            <img class="img-responsive w-50" src="/docs/aws/images/aws_login_saml_error.jpg">
            
            check the following
            * Check to make sure you are in the AWS AD group. Open a command prompt and run the command below
                ```
                net user <nwie-id> /domain
                ```
                
            * Clear your Cache
            * Check the URL you are using to login - [Nationwide's AWS Login Page](https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=urn:amazon:webservices)
            * You might be having what is know as  **"token bloat issues"**            
               **Cause:** SAML responses have a max of 50,000 characters and because of the number of AD groups you are in the response might have exceeded this
                
               **Fix:** Reach out to the IAM team via their RocketChat Channel **#iam-support** or file a [ServiceNow Incident](https://nwproduction.service-now.com/incident.do?sys_id=-1&sysparm_query=active=true&sysparm_stack=incident_list.do?sysparm_query=active=true) to the Assignment group:  **IAM-Support-Identity**        
            
            
   * MFA Errors
        Below are some common login failures due to MFA you could run into and how to resolve them
        
        * [KM314670 - MFA - We Didn't Recognize the Username or Password](https://nwproduction.service-now.com/kb_knowledge.do?sys_id=6a421a79dbfadfc41239fd341d9619e7&sysparm_record_target=kb_knowledge&sysparm_record_row=8&sysparm_record_rows=14&sysparm_record_list=active%3Dtrue%5Eworkflow_state%21%3Dretired%5Eu_owner%3Djavascript%3Anew+NWGroups%28%29.myGroups%28%29%5Elatest%3DNULL%5EORlatest%3Dtrue%5EORDERBYnumber)
        * [KM314673 - MFA - You have Entered an Incorrect Passcode](https://nwproduction.service-now.com/kb_knowledge.do?sys_id=9a2d1671db7653c4cb2d5278dc9619c7&sysparm_record_target=kb_knowledge&sysparm_record_row=9&sysparm_record_rows=14&sysparm_record_list=active%3Dtrue%5Eworkflow_state%21%3Dretired%5Eu_owner%3Djavascript%3Anew+NWGroups%28%29.myGroups%28%29%5Elatest%3DNULL%5EORlatest%3Dtrue%5EORDERBYnumber)
        * [KM314675 - MFA - Verification Error: There was a Problem Processing Your Request](https://nwproduction.service-now.com/kb_knowledge.do?sys_id=a5d1e275dbf653c4cb2d5278dc9619b6&sysparm_record_target=kb_knowledge&sysparm_record_row=10&sysparm_record_rows=14&sysparm_record_list=active%3Dtrue%5Eworkflow_state%21%3Dretired%5Eu_owner%3Djavascript%3Anew+NWGroups%28%29.myGroups%28%29%5Elatest%3DNULL%5EORlatest%3Dtrue%5EORDERBYnumber)
        * [KM314739 - MFA - Your Account is locked](https://nwproduction.service-now.com/kb_knowledge.do?sys_id=99037f7ddbb613c493165635dc9619a9&sysparm_record_target=kb_knowledge&sysparm_record_row=11&sysparm_record_rows=14&sysparm_record_list=active%3Dtrue%5Eworkflow_state%21%3Dretired%5Eu_owner%3Djavascript%3Anew+NWGroups%28%29.myGroups%28%29%5Elatest%3DNULL%5EORlatest%3Dtrue%5EORDERBYnumber)


**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

**[Previous - Access to AWS](/docs/aws/getting-started-with-aws/access-to-aws//)**/**[Next - Federated Team Role](/docs/aws/getting-started-with-aws/howto_federatedappteamroles)**
