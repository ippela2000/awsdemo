---
title: AWS Accounts
menu: docs
category: aws
weight: 6
---


### AWS Account Names and Numbers

The dropdowns below contain the AWS account names and numbers. You will need this to know which AD group to request access to

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsDGS01</td>
            <td>021395123595</td>
        </tr>
        <tr>
            <td>ProdDGS01</td>
            <td>505880943498</td>
        </tr>
        <tr>
            <td>TestDGS01</td>
            <td>640203397201</td>
        </tr>
        <tr>
            <td>DevDGS01</td>
            <td>819109286492</td>
        </tr>
     </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsCP01</td>
            <td>703606876235</td>
        </tr>
        <tr>
            <td>ProdCP01</td>
            <td>271942324821</td>
        </tr>
        <tr>
            <td>TestCP01</td>
            <td>405507766639</td>
        </tr>
        <tr>
            <td>DevCP01</td>
            <td>010896039642</td>
        </tr>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ProdDB01</td>
            <td>741794010583</td>
        </tr>
        <tr>
            <td>TestDB01</td>
            <td>962002981704</td>
        </tr>
        <tr>
            <td>DevDB01</td>
            <td>140245236663</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIO02</td>
            <td>590146589676</td>
        </tr>
        <tr>
            <td>ProdIO02</td>
            <td>114597825358</td>
        </tr>
        <tr>
            <td>TestIO02</td>
            <td>445709204409</td>
        </tr>
        <tr>
            <td>DevIO02</td>
            <td>542948635112</td>
        </tr>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsSDS01</td>
            <td>220250290941</td>
        </tr>
        <tr>
            <td>ProdSDS01</td>
            <td>496089651388</td>
        </tr>
        <tr>
            <td>TestSDS01</td>
            <td>317023088298</td>
        </tr>
        <tr>
            <td>DevSDS01</td>
            <td>352235038927</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsSDSTC01</td>
            <td>165135544265</td>
        </tr>
        <tr>
            <td>ProdSDSTC01</td>
            <td>641663250432</td>
        </tr>
        <tr>
            <td>TestSDSTC01</td>
            <td>947964740141</td>
        </tr>
        <tr>
            <td>DevSDSTC01</td>
            <td>835789338311</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsDW01</td>
            <td>976693839188</td>
        </tr>
        <tr>
            <td>ProdDW01</td>
            <td>785562577411</td>
        </tr>
        <tr>
            <td>TestDW01</td>
            <td>168341759447</td>
        </tr>
        <tr>
            <td>DevDW01</td>
            <td>786994105833</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsMCC01</td>
            <td>330324737156</td>
        </tr>
        <tr>
            <td>ProdMCC01</td>
            <td>325242188472</td>
        </tr>
        <tr>
            <td>TestMCC01</td>
            <td>028712194355</td>
        </tr>
        <tr>
            <td>DevMCC01</td>
            <td>329878246089</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsCLMS01</td>
            <td>814916182178</td>
        </tr>
        <tr>
            <td>ProdCLMS01</td>
            <td>024504907374</td>
        </tr>
        <tr>
            <td>TestCLMS01</td>
            <td>200511752081</td>
        </tr>
        <tr>
            <td>DevCLMS01</td>
            <td>472797667874</td>
        </tr>
    </tbody>
</table>


<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIAS01</td>
            <td>281979852052</td>
        </tr>
        <tr>
            <td>ProdIAS01</td>
            <td>039343969323</td>
        </tr>
        <tr>
            <td>TestIAS01</td>
            <td>036108323843</td>
        </tr>
        <tr>
            <td>DevIAS01</td>
            <td>025230338403</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsPLS01</td>
            <td>911042973277</td>
        </tr>
        <tr>
            <td>ProdPLS01</td>
            <td>793754345457</td>
        </tr>
        <tr>
            <td>TestPLS01</td>
            <td>281870877364</td>
        </tr>
        <tr>
            <td>DevPLS01</td>
            <td>409855723139</td>
        </tr>
    </tbody>
</table>
<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsCSB01</td>
            <td>908492922888</td>
        </tr>
        <tr>
            <td>ProdCSB01</td>
            <td>302743575447</td>
        </tr>
        <tr>
            <td>TestCSB01</td>
            <td>452463411479</td>
        </tr>
        <tr>
            <td>DevCSB01</td>
            <td>374495023036</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsAGS01</td>
            <td>672233818875</td>
        </tr>
        <tr>
            <td>ProdAGS01</td>
            <td>794216164735</td>
        </tr>
        <tr>
            <td>TestAGS01</td>
            <td>962511458142</td>
        </tr>
        <tr>
            <td>DevAGS01</td>
            <td>056995733544</td>
        </tr>
    </tbody>
</table>


<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsNWI01</td>
            <td>734785002498</td>
        </tr>
        <tr>
            <td>ProdNWI01</td>
            <td>319809808007</td>
        </tr>
        <tr>
            <td>TestNWI01</td>
            <td>270314848753</td>
        </tr>
        <tr>
            <td>DevNWI01</td>
            <td>585574843351</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsHRIT01</td>
            <td>903750302877</td>
        </tr>
        <tr>
            <td>ProdHRIT01</td>
            <td>527412974711</td>
        </tr>
        <tr>
            <td>TestHRIT01</td>
            <td>960566926339</td>
        </tr>
        <tr>
            <td>DevHRIT01</td>
            <td>541451410564</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsRP01</td>
            <td>298989933158</td>
        </tr>
        <tr>
            <td>ProdRP01</td>
            <td>283524971805</td>
        </tr>
        <tr>
            <td>TestRP01</td>
            <td>948260700223</td>
        </tr>
        <tr>
            <td>DevRP01</td>
            <td>179502567229</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIRM01</td>
            <td>467742123292</td>
        </tr>
        <tr>
            <td>ProdIRM01</td>
            <td>812390785843</td>
        </tr>
        <tr>
            <td>TestIRM01</td>
            <td>701486185364</td>
        </tr>
        <tr>
            <td>DevIRM01</td>
            <td>046231817936</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsEDO01</td>
            <td>715705998750</td>
        </tr>
        <tr>
            <td>ProdEDO01</td>
            <td>139604990815</td>
        </tr>
        <tr>
            <td>TestEDO01</td>
            <td>019695954516</td>
        </tr>
        <tr>
            <td>DevEDO01</td>
            <td>416350540093</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIPS01</td>
            <td>913590871550</td>
        </tr>
        <tr>
            <td>ProdIPS01</td>
            <td>725796754268</td>
        </tr>
        <tr>
            <td>TestIPS01</td>
            <td>241798381892</td>
        </tr>
        <tr>
            <td>DevIPS01</td>
            <td>884407648916</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsCLS01</td>
            <td>381714450555</td>
        </tr>
        <tr>
            <td>ProdCLS01</td>
            <td>157320119477</td>
        </tr>
        <tr>
            <td>TestCLS01</td>
            <td>786822837490</td>
        </tr>
        <tr>
            <td>DevCLS01</td>
            <td>280251055963</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsESS01</td>
            <td>593462114986</td>
        </tr>
        <tr>
            <td>ProdESS01</td>
            <td>776426964915</td>
        </tr>
        <tr>
            <td>TestESS01</td>
            <td>194411384007</td>
        </tr>
        <tr>
            <td>DevESS01</td>
            <td>555495844400</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsNFN01</td>
            <td>977437615963</td>
        </tr>
        <tr>
            <td>ProdNFN01</td>
            <td>084671533998</td>
        </tr>
        <tr>
            <td>TestNFN01</td>
            <td>107351867743</td>
        </tr>
        <tr>
            <td>DevNFN01</td>
            <td>115069333977</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsFIT01</td>
            <td>835284213543</td>
        </tr>
        <tr>
            <td>ProdFIT01</td>
            <td>287589555014</td>
        </tr>
        <tr>
            <td>TestFIT01</td>
            <td>883595631217</td>
        </tr>
        <tr>
            <td>DevFIT01</td>
            <td>025927455745</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsPET01</td>
            <td>321437859381</td>
        </tr>
        <tr>
            <td>ProdPET01</td>
            <td>704821510442</td>
        </tr>
        <tr>
            <td>TestPET01</td>
            <td>304522407519</td>
        </tr>
        <tr>
            <td>DevPET01</td>
            <td>478159127373</td>
        </tr>
    </tbody>
</table>


<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsITA01</td>
            <td>854113526657</td>
        </tr>
        <tr>
            <td>ProdITA01</td>
            <td>180045914896</td>
        </tr>
        <tr>
            <td>TestITA01</td>
            <td>245076092459</td>
        </tr>
        <tr>
            <td>DevITA01</td>
            <td>563244904657</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsECTO01</td>
            <td>829251876110</td>
        </tr>
        <tr>
            <td>ProdECTO01</td>
            <td>804496847309</td>
        </tr>
        <tr>
            <td>TestECTO01</td>
            <td>211391510395</td>
        </tr>
        <tr>
            <td>DevECTO01</td>
            <td>162530861841</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsPLDS01</td>
            <td>346468756860</td>
        </tr>
        <tr>
            <td>ProdPLDS01</td>
            <td>806644691500</td>
        </tr>
        <tr>
            <td>TestPLDS01</td>
            <td>445555826648</td>
        </tr>
        <tr>
            <td>DevPLDS01</td>
            <td>799293427417</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsEPD01</td>
            <td>039180857937</td>
        </tr>
        <tr>
            <td>ProdEPD01</td>
            <td>887556207593</td>
        </tr>
        <tr>
            <td>TestEPD01</td>
            <td>357458127159</td>
        </tr>
        <tr>
            <td>DevEPD01</td>
            <td>752352124067</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsANN01</td>
            <td>971339687881</td>
        </tr>
        <tr>
            <td>ProdANN01</td>
            <td>756760662274</td>
        </tr>
        <tr>
            <td>TestANN01</td>
            <td>858656040678</td>
        </tr>
        <tr>
            <td>DevANN01</td>
            <td>102469153450</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsCPEKS01</td>
            <td>067970477252</td>
        </tr>
        <tr>
            <td>ProdCPEKS01</td>
            <td>868451402272</td>
        </tr>
        <tr>
            <td>TestCPEKS01</td>
            <td>774502282033</td>
        </tr>
        <tr>
            <td>DevCPEKS01</td>
            <td>223086607816</td>
        </tr>
    </tbody>
</table>




<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIODA01</td>
            <td>977797236801</td>
        </tr>
        <tr>
            <td>ProdIODA01</td>
            <td>254363398379</td>
        </tr>
        <tr>
            <td>TestIODA01</td>
            <td>482506969033</td>
        </tr>
        <tr>
            <td>DevIODA01</td>
            <td>210963629777</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIOST01</td>
            <td>282687184546</td>
        </tr>
        <tr>
            <td>ProdIOST01</td>
            <td>181261839652</td>
        </tr>
        <tr>
            <td>TestIOST01</td>
            <td>031463549381</td>
        </tr>
        <tr>
            <td>DevIOST01</td>
            <td>327265447613</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIOIAM01</td>
            <td>619529163913</td>
        </tr>
        <tr>
            <td>ProdIOIAM01</td>
            <td>346730611004</td>
        </tr>
        <tr>
            <td>TestIOIAM01</td>
            <td>869330863085</td>
        </tr>
        <tr>
            <td>DevIOIAM01</td>
            <td>267390973453</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIOMID01</td>
            <td>454221550337</td>
        </tr>
        <tr>
            <td>ProdIOMID01</td>
            <td>951661313744</td>
        </tr>
        <tr>
            <td>TestIOMID01</td>
            <td>488977892832</td>
        </tr>
        <tr>
            <td>DevIOMID01</td>
            <td>737576221178</td>
        </tr>
    </tbody>
</table>

<table>
    <tbody>
        <tr>
            <td>Account Name</td>
            <td>Account Number</td>
        </tr>
        <tr>
            <td>ToolsIODB01</td>
            <td>732933647181</td>
        </tr>
        <tr>
            <td>ProdIODB01</td>
            <td>350732409635</td>
        </tr>
        <tr>
            <td>TestIODB01</td>
            <td>359757730432</td>
        </tr>
        <tr>
            <td>DevIODB01</td>
            <td>337726305731</td>
        </tr>
    </tbody>
</table>


### AMS Accounts

* Most teams **do not** need this access.
* AMS Accounts are used by applications that have PCI data. If your teams need this, only **Read-Only** access should be requested.
* The dropdowns bellow contain the available roles for the different AMS accounts

<div class="wrap-collabsible">
    <input id="collapsible100" class="toggle" type="checkbox" style="display:none">
    <label for="collapsible100" class="lbl-toggle">Non-Prod Non-PCI</label>
    <div class="collapsible-content">
        <div class="content-inner">
            <table>
                <tbody>
                    <tr>
                        <td>Role Name</td>
                        <td>AD Group</td>
                    </tr>
                    <tr>
                        <td>Read Only</td>
                        <td>NW-AMS-ReadOnly-AWS_985610176151</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="wrap-collabsible">
    <input id="collapsible101" class="toggle" type="checkbox" style="display:none">
    <label for="collapsible101" class="lbl-toggle">Prod Non-PCI</label>
    <div class="collapsible-content">
        <div class="content-inner">
            <table>
                <tbody>
                    <tr>
                        <td>Role Name</td>
                        <td>AD Group</td>
                    </tr>
                    <tr>
                        <td>Read Only</td>
                        <td>NW-AMS-ReadOnly-AWS_150031793327</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="wrap-collabsible">
    <input id="collapsible102" class="toggle" type="checkbox" style="display:none">
    <label for="collapsible102" class="lbl-toggle">Non-Prod PCI</label>
    <div class="collapsible-content">
        <div class="content-inner">
            <table>
                <tbody>
                    <tr>
                        <td>Role Name</td>
                        <td>AD Group</td>
                    </tr>
                    <tr>
                        <td>Read Only</td>
                        <td>NW-AMS-ReadOnly-AWS_250055497373</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="wrap-collabsible">
    <input id="collapsible103" class="toggle" type="checkbox" style="display:none">
    <label for="collapsible103" class="lbl-toggle">Prod PCI</label>
    <div class="collapsible-content">
        <div class="content-inner">
            <table>
                <tbody>
                    <tr>
                        <td>Role Name</td>
                        <td>AD Group</td>
                    </tr>
                    <tr>
                        <td>Read Only</td>
                        <td>NW-AMS-ReadOnly-AWS_609756673462</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>


**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

**[Previous - Getting Started with AWS](/docs/aws/getting-started-with-aws/)**/**[Next - Login into AWS](/docs/aws/getting-started-with-aws/login-into-aws/)**
