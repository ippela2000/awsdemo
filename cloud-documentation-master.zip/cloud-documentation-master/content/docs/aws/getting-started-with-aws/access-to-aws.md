---
title: Access to AWS
menu: docs
category: aws
description: Access to AWS is provided by joining the AWS Active Directory Group associated with your AWS BSA Account.
weight: 1
---

**A SecondaryID is no longer needed to access AWS you can use your primary nwie id**

## AWS Active Directory Groups

   * Access to AWS is provided by joining the AWS Active Directory Group associated with your AWS BSA Account. This is now done in [IIQ](https://iiq.nwie.net/identityiq/home.jsf)

   * Before you submit a request you need to know which AD groups to request access to. Read below to identify the groups.

### Type of Access

*  Full-Console Access
   * Full Console access can be requested in Development & Sandbox environments only. This is the **CUSTOMADMIN** access.
   * This is usually requested by developers    
    
* Read-Only Access
   * You can **only** request **READONLY** access to Test and Production environments. With this acces you can view but not create anything in the Console    
   * Non-developers can request **READONLY** access to all environments
   
* Team-Role Access
   * To get additional access to your resources in these higher environments - Test/Production, a role with specific permission to the resource can be created.
   * If you need team role access follow the instructions under [Federated Application Team Roles](/docs/aws/getting-started-with-aws/howto_federatedappteamroles/)   
    
### AD Group Name

   * The format of the AD group for AWS access is 
        ```
        Template
            (<environment><BSA>)-(RoleType)-(AWS)_(aws-account#)        
        e.g.
            DevIO02-CUSTOMADMIN-AWS_542948635112
            TestIO02-READONLY-AWS_445709204409
            ProdIO02-READONLY-AWS_114597825358        
        ```
            
   * Go to the [AWS Accounts Page](/docs/aws/getting-started-with-aws/aws-account-numbers/) to get a BSA for **xxx** and  Account number for **############**
   * The table below has a list of access typically requested by a developer.
     
   | Environment | Access | Type of access |
   |---|---|---|
   | Development | DEVXXX-CUSTOMADMIN-AWS_############ | Full Console Access to Make Changes |
   | Production | PRODXXX-READONLY-AWS_############ | Viewing AWS Resources in the Console |
   | Test | TESTXXX-READONLY-AWS_############ | Viewing AWS Resources in the Console |
   | Sandbox | SANDBOXXXX-CUSTOMADMIN-AWS_############ | Full Console Access to Make Changes |
   | Tools | ToolsXXXX-CODEPIPELINE-AWS_############ | Order and View New Pipelines |
   | InfraServices Prod | InfraSvcsProd-CODEPIPELINE-AWS_679177070049 | Order Data Products and View Legacy Pipelines |


## Joining Active Directory Groups

   * Login to [IIQ](https://iiq.nwie.net/identityiq/home.jsf)

   * Click on the **Menu Icon**. Note:If IIQ.nwie.net is not added to your list of trusted websites, the menu lines will not show up

     <img class="img-responsive w-25" src="/docs/aws/images/iiq-menu.jpg">
     

   * Click on  **Manage Access** -> **Manage User Access**
   
     <img class="img-responsive d-flex w-25" src="/docs/aws/images/iiq_manage-user-access.jpg">


   * Search for the user using the nwieid e.g. **KALURK2** and select it. 
   
     <img class="img-responsive w-50" src="/docs/aws/images/iiq_search_user.jpg">


   * You can search and select multiple users.
   
     <img class="img-responsive w-50" src="/docs/aws/images/iiq_multiple_user.jpg">
     

   * Next, click on **Manage Access** tab -> **Add Access** tab -> Search for the AD group you want to be added to add. You can add multiple AD groups in the same request.
     ```
        e.g.
            * DEVIO02-CUSTOMADMIN-AWS_542948635112
            * SamuraiCats-TeamRole-AWS_416350540093
     ```           
     <img class="img-responsive w-75" src="/docs/aws/images/iiq_aws_ad_group.jpg">
    
    
   * Next click on the **Review** tab and click the **Submit** button at the end of the page     
     <img class="img-responsive w-75" src="/docs/aws/images/iiq_aws_review_submit.jpg">
    
    
   * You will receive an email when your UserID has been added to the appropriate groups. This process could take anywhere from 1-2 weeks.

   * You can also check the status of your request in the IIQ home page under **Track My Requests**
    <img class="img-responsive w-100" src="/docs/aws/images/iiq_track_requests.jpg">


## Common Issues

   * If you cannot find the AD group in IIQ, you can request the group to be added by following the instructions at [Adding missing AD group to IIQ](https://nwproduction.service-now.com/ess/?id=sc_cat_item&sys_id=5a41a00ddbf71bc0a6225d104b9619cc)
   
        * Select **Request Type:** Create Active Directory Group
        * **Preferred Group Name:** Enter the missing AD group
        * **Group Description:** This group already exists in Active Directory but is is not requestable in IIQ. Please make this group requestable
        * **Group Owner ID:** Your own name
        * **Group Access Level:** Read
        * **Group Access Type:** Application
        * **Please select 2 users to approve this request:** Add your name and your managers name
        
        * Final page will look like below :
        <img class="img-responsive w-100" src="/docs/aws/images/servicenow_add_actv_dir_group_to_iiq.jpg">
        
        * **Add to cart** and submit it

**[Questions?](https://rocketchat.nwie.net/channel/AWS)**

**[Previous - Getting Started with AWS](/docs/aws/getting-started-with-aws/)** / **[Next - Login into AWS](/docs/aws/getting-started-with-aws/login-into-aws/)**
