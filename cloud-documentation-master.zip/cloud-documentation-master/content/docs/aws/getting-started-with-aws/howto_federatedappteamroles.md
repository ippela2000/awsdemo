---
title: Federated Application Team Roles
menu: docs
category: aws
weight: 3
---

## Why do you need a Federated Role

Currently in the Test and Prod AWS accounts, READONLY is the only role allowed. 
To get additional access to your resources in these higher environments - Test/Production, a role with specific permission to the resource can be created.

A mechanism has been created to enable creation of a role that gives access to resources based on tags. 
Details are below on creating these roles. They will give you access to start/stop EC2, access to your S3 buckets, etc. in the higher environments. 
You will only have access to resources tagged with the 'Team' tag and a value matching the Team input requested when creating the role.

These roles also inherently get the required access to use AWS Athena.

**Role Types:**
 * TeamRole: Grants access to your resources but does not include the ability to interact with RDS instances.
 * RDS-POWER-AWS: Grants access to interact with your **RDS database(s)** and secrets manager, does not include any other access (EC2, S3, etc.)

**As of version 4.0 the Service Catalog product now handles AD group creation and group assignment, the AD group creation and udpate steps through Service Now are no longer required.**
**Exsting federated team role provisioned products of 3.0 or higher should be able [to update](https://docs.aws.amazon.com/servicecatalog/latest/userguide/enduser-update.html) to 4.0 without issue, ealier than 3.0 has not been confirmed.**

~~There are 3 steps in setting up these roles~~
 ~~1. Creating the roles in AWS Account - In this step we create the role in AWS using Service Catalog~~
 ~~2. Request a new AD Group in ServiceNow - In this step you request a new AD group which matches the name of the role created in AWS, the AD group is linked to the AWS role created.~~
 ~~3. Adding users to the new AD Group - Add users that need access. If new AD group, this can be combined with the ServiceNow request from Step 2.~~
 <br /><br />

## Ordering a Federated Team Role
To get an App Team role, you will need to order them out of Service Catalog in your BSA Tools account or InfraSvcsProd(legacy) account.

  * Log into the **your BSA Tools account or InfraSvcsProd(legacy)** account with your **-CodePipeline-** role
  * Under **Find Services** search for 'Service Catalog'
  * Click on **Service Catalog**
  * In the **Service Catalog** Service, click on 'Products'
  * Search for 'Other-FederatedTeamRole' and select it.
  * Click on **Launch Product**
  * Populate a name (this is not the team name yet), and select the latest version.
  * Select the 'pBusinessUnit' from the drop-down, this will determine which accounts the roles are created in
  * Select the 'pRoleType' drop-down menu - **'Teamrole'** or **'RDS Power User'**
  * Enter the 'pTeamName' value (with no underscores "_")  Your team name can be anything you like.  i.e.  'Tigers', 'Rockets', 'SamuraiCats'
  * Populate a list of NWIE users you want to be added to the AD group, separated by comma. i.e. 'johnd1,janed1'
  * Click next till you get to the **Review** page.
  * Review and click on **Launch**
  * This will create 5 roles: 1 in Dev, 1 in Test, 1 in Prod, 1 in Tools, and 1 in InfraSvcsProd.  With the name e.g
       -   **SamuraiCats-RDS-POWER-AWS** (If you requested PowerUser)
       -   **SamuraiCats-TeamRole-AWS**  (If you requested TeamRole)
  *  This will also create 5 AD groups: 1 in Dev, 1 in Test, 1 in Prod, 1 in Tools, and 1 in InfraSvcsProd.  With the name e.g 
      
      * Template:             
          - **(teamrolename)-TeamRole-AWS_(account#)**         
          - **(rdspowerusername)-RDS-POWER-AWS_(account#)**
        
      * Example for TeamRole:    
       
           -   **SamuraiCats-TeamRole-AWS_416350540093  (Dev)**
           -   **SamuraiCats-TeamRole-AWS_019695954516  (Test)**
           -   **SamuraiCats-TeamRole-AWS_139604990815  (Prod)**
           -   **SamuraiCats-TeamRole-AWS_715705998750 (Tools)**
           -   **SamuraiCats-TeamRole-AWS_679177070049 (InfraSrvcsProd)**
          
      * Example for RDS-POWER Role:        
         -   **SamuraiCats-RDS-POWER-AWS_416350540093  (Dev)**
         -   **SamuraiCats-RDS-POWER-AWS_019695954516  (Test)**
         -   **SamuraiCats-RDS-POWER-AWS_139604990815  (Prod)**
         -   **SamuraiCats-RDS-POWER-AWS_715705998750 (Tools)**
         -   **SamuraiCats-RDS-POWER-AWS_679177070049 (InfraSrvcsProd)**
          
  * This is the AD group you will need to request access to, when you want to [add more users to your TeamRole](/docs/aws/getting-started-with-aws/access-to-aws/#joining-active-directory-groups)
        

## Allowing the Team Role To Access Your Resources

To know how to give your role resources access to your resources refer to [How-to-give-teamrole-access-to-resources](/docs/aws/iam/howto-give-teamrole-access-to-resources)


**[Previous - Login into AWS](/docs/aws/getting-started-with-aws/login-into-aws/)**/**[Next - Additional Access](/docs/aws/getting-started-with-aws/additional-access/)**
