---
title: AWS Account Structure
draft: false
menu: docs
category: aws
weight: 4
---

### AWS Account Structure at Nationwide

![AWS Account Structure](/docs/aws/images/AccountStructure.png)

### VPC in Nationwide AWS Accounts

[What is VPC Peering?](https://docs.aws.amazon.com/vpc/latest/peering/what-is-vpc-peering.html)

![VpcPeering](/docs/aws/images/VpcPeering.png)



[Next - Getting Started with AWS](/docs/aws/getting-started-with-aws/)
