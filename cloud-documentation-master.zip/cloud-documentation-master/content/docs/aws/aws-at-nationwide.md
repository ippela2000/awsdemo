---
title: AWS at Nationwide
draft: false
menu: docs
category: aws
weight: 2
---

### What to do in Nationwide AWS?

* You are accountable for everything created within your space.
* Use the AWS region US-East-1 (N. Virginia).
* Use of native AWS capabilities/services is preferred.
* Use [AWS Tags.](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/Using_Tags.html)
* Use [Security Group(s)](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_SecurityGroups.html) for your application.
* Use [Amazon Machine Image (AMI)](https://docs.aws.amazon.com/general/latest/gr/glos-chap.html) for server builds
* Use up-to-date applications with the latest AMI.
* Use [Elastic Load Balancer (ELB)  / Application Load Balancer (ALB)](https://aws.amazon.com/elasticloadbalancing/)  for load balancing needs.
* Use [Amazon CloudFormation](https://aws.amazon.com/cloudformation/) for creation of templates and grouping of services.
* A code deployment process has been developed.
* Build everything as code, and use github.nwie.net to securely store it.
* Use [AWS Data At Rest Encryption](https://aws.amazon.com/blogs/security/tag/ec2-instance-store-encryption/) by default (block level).
* Shutdown the infrastructure when not in use.
* Try to start with smaller instances, wherever possible, and change to bigger ones, if you need them.
* Refer to the [Approved Product and Service page](/docs/aws/products/) to get a full list of all approved AWS services that can be used at NW.

### What not to do in Nationwide AWS?

* Do NOT use, consume or interact with any of the following data types without APPROVAL:
  * Social Security Number (SSN)
  * Credit Card Number (CCN), Financial Account Number
  * Policy Number
  * Health Information
  * Driver’s License Number
  * Identity Credentials (User Name, Password, Private Keys)
  * Internal Business Process Information
  * Non-Public Nationwide Programs or Strategy Information
  * Information about business partners or acquisitions that are not ready to be publicly shared
  * Customer Data that has not been vetted
  * Do NOT create additional User IDs or implement things that could put Nationwide at risk*
  * Do NOT create or implement [Security Groups](https://docs.aws.amazon.com/AmazonVPC/latest/UserGuide/VPC_SecurityGroups.html) that permit access from anywhere
    * Be specific and only provide the minimum access required to function (least privilege)


### NW AWS Responsibility Matrix

![AWS Resp Matrix](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/NationwideAWSRespMatrix.png)


### NW AWS Responsibility Matrix

![AWS Resp Matrix](https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/gh-pages/Image/NationwideAWSRespMatrix.png)


[Next - AWS Account Structure at Nationwide](/docs/aws/aws-account-structure/)
