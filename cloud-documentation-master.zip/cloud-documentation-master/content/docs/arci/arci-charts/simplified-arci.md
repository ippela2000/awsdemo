---
title: "Simplified NGI ARCI chart"
menu: docs 
category: arci
---
Select your role below to view its high-level responsibilities. For a more in-depth look at all recorded roles and responsibilities for NGI Cloud, refer to the [main NGI ARCI chart](/docs/arci/arci-charts/ngi-arci-chart/).  
 

<details>
    <summary>
        L4 CTO
    </summary>
    <section id="l4cto" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Continuity Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Application Dev Team/BSA
    </summary>
    <section id="appdev" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Architecture</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Development</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Asset Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Availability Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Pre-Prod</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Prod</i>
              </td>
              <td>
                R,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                C,A,R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Continuity Management</i>
              </td>
              <td>
                R,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                R,I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                I,C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: EC2 Config</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Event Management</i>
              </td>
              <td>
                I,C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                A,R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: OS Patching-Pets</i>
              </td>
              <td>
                I,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                C,A,R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                A,C,R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Reporting/Monitoring</i>
              </td>
              <td>
                A,R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                R,C,I,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Infrastructure Architect
    </summary>
    <section id="infratect" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Architecture</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Development</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Pre-Prod</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                A,R,C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Application Monitoring
    </summary>
    <section id="appmonitor" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                I,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Event Management</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Reporting/Monitoring</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Middleware
    </summary>
    <section id="middleware" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Architecture</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Development</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Asset Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Availability Management</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Pre-Prod</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Prod</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: OS Patching-Pets</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Database
    </summary>
    <section id="database" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: OS Patching-Pets</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Server
    </summary>
    <section id="server" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: EC2 Config</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: OS Patching-Pets</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Reporting/Monitoring</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Storage
    </summary>
    <section id="storage" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                I,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Network
    </summary>
    <section id="network" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        IT Operations (ECC)
    </summary>
    <section id="itopecc" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Availability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Continuity Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Event Management</i>
              </td>
              <td>
                A,R,C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                R,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                R,C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                R,I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Reporting/Monitoring</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        IT Operations (Process)
    </summary>
    <section id="itopprocess" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Knowledge Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Event Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: OS Patching-Pets</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                R,A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Configuration Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Level Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                A
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Capacity and Consumption Management
    </summary>
    <section id="ccm" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                R,A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Infrastructure Delivery Analytics Reporting
    </summary>
    <section id="idar" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Supplier Management
    </summary>
    <section id="suppliermgmt" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        I&O Finance
    </summary>
    <section id="iofinance" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                R,A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                R,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Reporting/Monitoring</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Cloud Operations/CSE
    </summary>
    <section id="cse" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I,R,C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                R,A
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Cloud Operations/CIE
    </summary>
    <section id="cie" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                I,A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Application Development</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Asset Management</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Pre-Prod</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: CloudFormation Template: Prod</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Continuity Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,R,C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Capacity Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Economics</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: EC2 Config</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                A,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Problem Management</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Release Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Reporting/Monitoring</i>
              </td>
              <td>
                R,A,C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: IAM User Configuration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I,R,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Configuration Management</i>
              </td>
              <td>
                A,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Service Request Fulfillment</i>
              </td>
              <td>
                R
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC I&O Front Office
    </summary>
    <section id="csociofo" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        IRM BSA Front Office
    </summary>
    <section id="irmbsafo" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                I,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        Cloud Application Security Engineering
    </summary>
    <section id="case" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: IAM User Configuration</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC DFI
    </summary>
    <section id="CSOCdfi" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC Incident Response
    </summary>
    <section id="csocir" markdown="1">
        <table>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Incident Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,A,I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC Defense Optimization
    </summary>
    <section id="csocdo" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: IAM User Configuration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,R,I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC Strategy and Guidance
    </summary>
    <section id="csocsg" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC Vulnerability Scanning
    </summary>
    <section id="CSOCvs" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,I,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC Vulnerability Response
    </summary>
    <section id="CSOCvr" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Vulnerability Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        CSOC Attack and Penetration
    </summary>
    <section id="CSOCattack" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I,C,A
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        IRM Capability Leads
    </summary>
    <section id="irmcapability" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Build Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                C,A
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                A
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                R
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: System Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: IAM User Configuration</i>
              </td>
              <td>
                C,A,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                C,I,A
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        IRM Continuity Management
    </summary>
    <section id="irmcontinuity" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Governance/People Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Operational Support</i>
              </td>
              <td>
                I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I
              </td>
            </tr>
        </table>
    </section>
</details>
<details>
    <summary>
        IRM Security Architecture
    </summary>
    <section id="irmsa" markdown="1">
        <table>
            <tr>
              <td><b>Activity Grouping</b></td>
              <td><b>A-R-C-I Designations</b></td>
            </tr>
            <tr>
              <td>
                <i>Application Administration/Middleware</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: General</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Foundational AMI Creation (OS Only)</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Functional AMI Creation</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Network Administration</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Build: Storage Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Business Office/Management</i>
              </td>
              <td>
                A,C
              </td>
            </tr>
            <tr>
              <td>
                <i>Change Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Cloud Architecture</i>
              </td>
              <td>
                C,R
              </td>
            </tr>
            <tr>
              <td>
                <i>Integration Management</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Operations: Database Administration</i>
              </td>
              <td>
                C
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: IAM User Configuration</i>
              </td>
              <td>
                C,I
              </td>
            </tr>
            <tr>
              <td>
                <i>Security: Management</i>
              </td>
              <td>
                I,A,R,C
              </td>
            </tr>
        </table>
    </section>
</details>
