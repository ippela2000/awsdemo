---
title: "Main NGI ARCI chart"
menu: docs
category: arci
---

Tap the image below to view the current NGI ARCI chart. For a more high-level view, refer to the [simplified ARCI](/docs/arci/arci-charts/simplified-arci/).  
_last updated: August, 2020_  

<a href="/docs/arci/documents/NGI_ARCI.xlsm"><img src="/docs/arci/images/ARCI_Main.png" alt="NGI ARCI snapshot" class="w-50" /></a>
