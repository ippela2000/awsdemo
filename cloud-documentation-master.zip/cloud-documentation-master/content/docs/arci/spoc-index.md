---
title: SPOC Index
menu: docs 
category: arci
---
## Single Points of Contact (SPOCs)
| Team | SPOC |
| ----- | ----- |
| ARCI Owner | Todd Kasper |
| Application Dev Team (BSA) | Daniel P Kelley, CLT Application Architect |
| Infrastructure Architecture | Ed Lyshe, Director |
| Application Monitoring | Phani Adabal, Manager |
| Middleware | Bob Ziegler, Product Manager; Jason Cartee, Product Owner |
| Database | Ken Hagy, Director |
| Server | Shishir Naik, Linux Product Manager; Theresa Jarrell, Windows Product Manager |
| Storage | Cam Salloum, Product Manager |
| Network | Mike Leuzinger, AVP |
| IT Operations (ECC) | Adam Grube, Director  |
| IT Operations (Process) | Adam Grube, Director |
| Capacity and Consumption Management | Joseph Daly, Director |
| Infrastructure Delivery Analytics Reporting | Joseph Daly, Director |
| SMS/Supply Management | Jeff Johnson, Strategic Sourcing Consultant |
| I&O Finance | Brian Reynolds, Financial Business Advisor |
| Cloud Operations/CSE | Vikas Chopra, Manager |
| Cloud Operations/CIE | Jeordy Rebbereh, CIE; Taraneh Parvaresh, Azure |
| IRM | Mike Leyh, Vulnerability Capability Owner |

