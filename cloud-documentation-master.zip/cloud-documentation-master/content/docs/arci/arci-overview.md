---
title: "ARCI Overview"
menu: docs
category: arci
---
## What is the ARCI?
The ARCI defines the roles and responsibilities across Nationwide's cloud environment. Each team refers to and updates their own column and tab within the ARCI spreadsheet. The ARCI matrix tab provides a high-level snapshot the entire spreadsheet.  
[![NGI ARCI snapshot](../images/ARCI_Main.png)](/docs/arci/arci-charts/ngi-arci-chart/)  
### Navigating the ARCI
* Select your role's tab along the bottom of the spreadsheet. 
  * This will open your role's ARCI activities. 
* Locate your role's column in Row 1.
* Compare how other roles interact with your role in similar activities.  
### ARCI chart color coding
The colors used in the ARCI chart help users distinguish between Activity and Role Groupings.  
### A-R-C-I definitions
| A-R-C-I | Description |
| ------- | ------- |
| **A**ccountable | This role is accountable for ensuring that the appropriate entities within their team perform their activity or procedure. |
| **R**esponsible | This role performs the activity or procedure. |
| **C**onsulted | This role provides input on the activity or procedure. |
| **I**nformed | This role receives information and communications on this activity or procedure. |  
## Updates to the ARCI
ARCI updates occur *annually during August* to maintain currency. On this annual schedule, the single points-of-contact (SPOC) for each role represented in the ARCI collaborate and drive updates to their team’s A-R-C-I designations. [Get in touch with your team's SPOC.](https://gocloud.nwie.net/docs/arci/spoc-index/)  
SPOCs wanting to update role responsibilities in the ARCI must reach out to the project manager driving the ARCI/audit updates for the process documentation.
