---
title: "Test Data Management"
draft: false
menu: solutions
category: data-movement
weight: 5
---


### Test Data Management (TDM)
* TDM is a Shared Services organization of IT experts focused on the provisioning of masked and synthetically generated data.
* Data can be generated for both Mainframe, Distributed and Cloud platforms to meet the needs of our Test, Development, and QA Teams throughout Nationwide IT with appropriate governance and industry best practices.
* Reach out to the <a href="mailto:RSD_Test_Environment_and_Data_Services_Projects@nationwide.com">TEDS TDM team</a> to get you data masked 
* For more information, reference to the [guidelines for data masking](https://onyourside.sharepoint.com/sites/IRM/SecurityStandardsPortal/IT%20Security%20Guidance/Nationwide%20Guidelines%20for%20Static%20Data%20Masking.pdf?csf=1&amp;e=6acLsx&amp;cid=c6ea17cf-b921-4578-9056-eb84c2124d37) or the [Data Guide](https://inside.nwie.net/media/ptn_securing_confidential_data_guide.pdf) to secure sensitive data

