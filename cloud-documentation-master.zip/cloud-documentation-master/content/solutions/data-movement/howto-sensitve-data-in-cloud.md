---
title: Sensitive Data in the Cloud
menu: solutions
category: data-movement
weight: 1
---

Today we work in a very heavily data driven society, and it is up to all of us to ensure that Nationwide members and company sensitive data is protected from accidental or intentional security threats.

In Q1 2019, the Enterprise Data Office (EDO) updated the <a href="https://onyourside.sharepoint.com/:b:/r/sites/edo/datagovernance/Data%20Governance%20Document%20Library/Nationwide%20EDO%20Data%20Classification%20Standard.pdf?csf=1&e=3BRubS">Data Classification Standards</a> that Nationwide will be moving forward with. Some of these terms and definitions are new and others are updates to existing information.

Here we will be highlighting core information needed for application teams to get started moving their sensitive data to the cloud. To get more information or more clarity, you and your team members can review the information on the [Data Governance SharePoint Site](https://onyourside.sharepoint.com/sites/edo/datagovernance/SitePages/Home.aspx).

### What is Sensitive Data?

Sensitive Data is data whose unauthorized disclosure or access could result in a severe adverse impact to Nationwide.

#### Examples:

Business information related to internal processes, technology strategies, business partners or acquisitions, etc.

Contracts and their contractual terms

Payment card information

Government-issued identifiers or information that directly identifies a person, including:

1. Social Security number
2. Driver’s license number
3. Passport number

Information linked to a person that can identify that person, either on its own or in combination with other information, including:

1. Financial account numbers or information
2. Medical information
3. Employment information (e.g. disciplinary actions, performance ratings, etc.)
4. Date of birth
5. Authenticators such as passwords, password reset questions, and biometrics

Have questions? Please review this [quick video](https://videospace.nationwide.com/media/DG+Two+Minute+Tuesday+-+Classification+FAQs%21/1_anq1xexw/92968121). To get more information, reference the [Data Classification Standard document](https://onyourside.sharepoint.com/sites/edo/datagovernance/Data%20Governance%20Document%20Library/Forms/Standards.aspx?id=%2Fsites%2Fedo%2Fdatagovernance%2FData%20Governance%20Document%20Library%2FNationwide%20EDO%20Data%20Classification%20Standard%2Epdf&parent=%2Fsites%2Fedo%2Fdatagovernance%2FData%20Governance%20Document%20Library) on the Data Governance SharePoint site.


### Ownership

* As we continue our journey moving to the cloud it is even more critical that we keep a close eye on sensitive data in all environments (i.e. non-production and production). 
* Protecting our sensitive data with data masking or encryption, removal, or by limiting the amount of sensitive data to only that which is required, are few ways that we can do our part in keeping our customers trust in us to maintain and protect their privacy.
* It is applications teams responsibility to understand what data you are migrating into your non-production environments (i.e. dev and test). 
* Sensitive data is **ONLY ALLOWED IN PRODUCTION**. 
* If you are unsure if there is sensitive data in the data set you wish to migrate, contact IRM to have your data scanned. 
* Reference to the [Security Guidelines](https://onyourside.sharepoint.com/sites/IRM/SecurityStandardsPortal/IT%20Security%20Guidance/Nationwide%20Guidelines%20for%20Static%20Data%20Masking.pdf?csf=1&e=LYss1E&cid=8fd87d40-0f2b-4c1c-b419-5fba584af387/)  is a list of data types that IRM will be identifying during the scan. 
* [Request a scan of you data](/solutions/data-movement/howto-sensitve-data-scan/) as soon as you can in your migration process; this could potentially take weeks or months to complete, if mitigation steps are necessary. 


### Data Scanning in AWS account

 * Scans are done weekly in the non-production environments. 
 * If sensitive data is found in non-production environments during this scan, access to data will be revoked until [remediation/mitigation](https://pages.github.nwie.net/Nationwide/Next-Gen-Infra/pages/Howto-RemediateData/) steps are taken.


#### Keep in mind that Regulated Data (i.e. PCI, PHI, HIPPA, Federal, State, Sarbanes-Oxley, etc.) could potentially affect the remediation/mitigation steps you and your team will have to take to use your data in the cloud environments! Please work with your [IRM representative](http://idl.nwie.net/irm.html) to get more information.

Below is information that walks through step by step of the options to protect application data that you may have responsibility for.

Please ensure that data being migrated to non-production environments (i.e. development and test) follows one of the following guidelines:

1.	Sensitive data is removed
2.	Sensitive data is masked
3.	IRM Exception in place


### Sensitive Data Remediation/Mitigation Process in Non-Production Environments

* Sensitive data is **NOT ALLOWED** in the lower environments.
* If sensitive data is found the scan of you lower environments you need to take steps to remediate it](). 

