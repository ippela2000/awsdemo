---
title: "Data Movement"
draft: false
menu: solutions
category: data-movement
---

In order to help facilitate a successful and productive migration to the cloud, it is time you think about the most important aspect of your application ... the **DATA**. 

Here at Nationwide, especially in Cloud Solutions, we aim to make "Data A First Class Citizen," and in order to do that we need to pause for a moment and ask some fundamental questions.

* In this publication we are going to break down items/tasks into three different sections:
   -  Must Do
   -  Need To Do
   -  Probably Should Be Doing
* We are also going to outline what happens when you **cannot** migrate your data store(s) to the cloud when your application migrates
   * Data Inertia

---

## Must Do

* Our **MUST DO** section, highlights those activities you must do prior to going to cloud, well for any matter...it is good to do even when you are in cloud.
* We have a **Top 3** that must get done, no matter the situation or case, and those include
  * Data Classification
  * Compliance And Regulation
  * Data Asset Inventory

* **Data Classification**
  * [Sensitive Data Scan Process](/solutions/data-movement/howto-sensitve-data-in-cloud/)
    * Has your relational data stores been scanned and classified?
    * Has your non-relational data stores been scanned and classified?
  * I have read the [EDO Classification Standard](https://onyourside.sharepoint.com/sites/edo/datagovernance/Data%20Governance%20Document%20Library/Nationwide%20EDO%20Data%20Classification%20Standard.pdf)
* **Compliance And Regulation**
  * Is any of your data under the follow:
    * Federal compliance or regulation
    * State compliance or regulation
    * FCRA compliance or regulation
    * The [Sarbanes-Oxley Act](http://www.soxlaw.com/)
   - Understand the [IRM IT Security Standards](https://onyourside.sharepoint.com/sites/IRM/SecurityStandardsPortal/IRMSecurityStandards/Forms/Stds%20%20Controls.aspx)
* **Data Asset Inventory**
  * My data sets have been inventoried in one or both of the following systems:
    * The Data Marketplace [data.nationwide.com]
      * [Adding A Data Set](https://pages.github.nwie.net/Nationwide/data-marketplace/documentation/publishing/#adding-a-new-dataset)
     * Nationwide Governance Catalog [NGC]
       * [Scan Request](https://onyourside.sharepoint.com/sites/edo/applications/ngc/SitePages/Home.aspx) ... then click "Scan Request"
* **IRM Representation**
    - I have identified my overall-general IRM representative
    - I have identified my IRM Front Office Representative
    - I know my IRM escalation path
* **Domain Experts**
     - Who are your data experts:
       - architects
       - engineers
       - scientists
       - analysts
* **Data Breach**
   - In the unlikely event of a data breach
     - Have identified a leadership path of escalation
     - Have identified a legal path of escalation
     - Have identified a technical path of escalation
       - Technical resources have a playbook and checklist established
         - The playbook and checklist has been communicated to all team members
* **Understand the recommended data movement options**
    - [Review the data movement alternatives from I&O Architecture](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-specs/data-movement-guide.html) and work with your architects to determine the most appropriate options.

----

## Need to Do


 - **Successful Completion**
   - Who defines success?
   - What do the components of success look like?
     - Is there a dashboard to track the components?
 - **Understanding Your Data Features**
    - How is your data consumed?
    - What are the Use Cases?
    - What is the data workload (requires micro-second latency, high throughput, etc.)?
    - Is your data read-only?
    - If your data is NOT read-only, you need to understand data-integrity requirements
 - **Understanding The Source System**
   - How much content do you need to migrate?
   - What format is your content in?
     - Relational DataStores
     - NoSQL DataStores
     - Flat files
     - Streaming
   - How much of it is duplicate content?
   - What attributes do the flat files have?
     - What is the average of these flat files?
 - **External Systems**
     - Are there other systems involved
 - **Test Data Management**
     - In DEV/TEST all confidential [PII, PCI, PHI, HIPPA] data is masked or obfuscated
     - My team has a test data management playbook that has been vetted and communicated to all team members?
 - **Meta Data Management**
     - What is your strategy around meta data management?
     - How to you intend to tactically implement the strategy?
 - **Deployment**
     - Is this a continuous process or a one-off?
     - Who will run the data movement, and how?
     - Does it plug into a workflow engine, for example?
 - **Access Issues**
    - Accessing the source and target systems
  - **On-Prem Decommission**
    - I have identified all my On-Prem DataStores slated for decommission
    - I have completed all the proper paperwork for my On-Prem decommission


----

## Probably Should be Doing


 - **Data Quality**
   -  Are there requirements for cleansing data, running rules against the source data or against the data once loaded into the target
 - **Data Testing**
     - Unit
     - System
     - Integration
 - **Performance**
   - I have identified all the standard performance metrics
   - I have worked with my domain experts and identified "exotic" metrics
   - I have established data SLI(s) [Service Level Indicators]
   - I have established data SLO(s) [Service Level Objectives]
   - All of my metrics are located in a playbook
     - That playbook has been communicated to all team members
 - **Data API Strategy**
   - Can this app's data be exposed via an API?
     - If yes, what is the strategy/plan?

----

## Data Inertia


If there is disinclination to move your data store(s) with your application, there are some questions that we need to address. If you taking part in a cloud migration party, please work **Cloud Data Services** or a **SRE** to complete this part of the question-answer form. If you are on an "unassisted" cloud migration journey, please work with your **APM/IPL/Architect/Tech Lead** to complete this form. Either way this form must be completed and returned back to **Cloud Data Services** if your application's data stores are not migrating to the cloud at the same time as your application

You can email the completed question-answer form to: CloudDataServices@nationwide.com or open [Auxiliary Service Request](https://nwproduction.service-now.com/com.glideapp.servicecatalog_cat_item_view.do?v=1&sysparm_id=1a9708690f465a00085d6509b1050ed5) with the Target Group: CLOUD-SOLUTIONS-DATASERVICES.

 - **What data stores are not migrating to cloud?**
   -  Relational databases
   -  Non-relational databases [NoSQL]
   -  Hadoop environments
   -  Data lakes
   -  NAS Shares
   -  30 Day backups
   -  Long-term cold storage archives
 - **Why are the data stores not migrating to the cloud?**
   -  Blockers
   -  Data store dependencies
   -  Technical difficulties
 - **What are the timelines for migrating these the data stores?**
   -  Year
   -  Quarter
   -  Month
   -  Day
 - **Do you need additional folks or resources in order to help migrate the data stores?**
   -  Cloud Solutions folks [Infra, Cloud Data Services, SRE, Security, Containers]
   -  EDO Architectural guidance/advice
   -  I&O Architectural guidance/advice
   -  Program level funding or monetary assistance

