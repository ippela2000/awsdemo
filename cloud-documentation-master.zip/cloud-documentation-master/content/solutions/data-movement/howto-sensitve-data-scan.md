---
title: Sensitive Data Scan
menu: solutions
category: data-movement
weight: 2
---

### Sensitive Data Scan Process 

If you do not know whether your application contains [sensitive data](/solutions/data-movement/howto-sensitve-data-in-cloud/), please validate this by following the submissions guidelines below for your data to be scanned by IRM before migrating to the cloud.

#### Structured Data Process

* IRM has the capability to scan Oracle and MSSQL databases to determine if sensitive data exists. 
* Refer to the [list of PII data types](https://onyourside.sharepoint.com/:b:/r/sites/IRM/SecurityStandardsPortal/IT%20Security%20Guidance/Nationwide%20Guidelines%20for%20Static%20Data%20Masking.pdf?csf=1&e=LYss1E) that IRM Information Protection will be focused on.
* If you are migrating data from another database type (not Oracle or MSSQL), work with [IRM](https://idl.nwie.net/irm.html) to complete a manual review of the data.
* Use the process below to request IRM to scan your databases; the SLA for scans to be completed is 10 business days.
    * Identify On-prem database connectivity information.
    * Submit an Auxiliary Service Request in ServiceNow using the information in the table below.
    * If sensitive data is found then the Information Protection team will contact the [IRM Front Office Representative](/solutions/security/aws_account_to_bsa_to_front_office_rep_070302019.xlsx) who will contact the BSA. 
    * The BSA team will then follow the [Remediation/Mitigation process for Sensitive Data](/solutions/data-movement/howto-sensitive-data-remediation/) .


<table>
<thead>
<tr>
<th>Field</th>
<th>Value</th>
</tr>
</thead>
<tbody>
<tr>
<td>Group</td>
<td>NSC-SCC-InfoProtection</td>
</tr>
<tr>
<td>CI Name</td>
<td>GUARDIUM</td>
</tr>
<tr>
<td>Description</td>
<td>“This request is for a Guardium SIF scan. Scan results also requires Data classification.&quot;</td>
</tr>
<tr>
<td>Database Name</td>
<td>Your Database Name</td>
</tr>
<tr>
<td>Schema</td>
<td>Your Database Schema Name</td>
</tr>
<tr>
<td>Database Type</td>
<td>Oracle, SQL, or DB2</td>
</tr>
<tr>
<td>Service Name</td>
<td>Your database's service name (Oracle only)</td>
</tr>
<tr>
<td>Host Name</td>
<td>The server where your database resides</td>
</tr>
<tr>
<td>Cluster Name</td>
<td>The cluster where your database resides</td>
</tr>
<tr>
<td>Port Number</td>
<td>The port number your database is listening on</td>
</tr>
</tbody>
</table>

#### Unstructured Data Scans
* IRM has the capability to scan Windows File Shares (NAS) to determine if sensitive data exists. 
* Refer to the [list of PII data types](https://onyourside.sharepoint.com/:b:/r/sites/IRM/SecurityStandardsPortal/IT%20Security%20Guidance/Nationwide%20Guidelines%20for%20Static%20Data%20Masking.pdf?csf=1&e=LYss1E) that IRM Information Protection will be focused on.
* Follow the process below to request IRM to scan your NAS file shares. The SLA for scans to be completed is 10 business days.

<ol>
<li><p>Identify Windows File Share names (e.g. \\ohnalnas0170\foldername)</p>
</li>
<li><p>Submit <strong><a href="https://nwproduction.service-now.com/nav_to.do?uri=%2Fcom.glideapp.servicecatalog_cat_item_view.do%3Fv%3D1%26sysparm_id%3D1a9708690f465a00085d6509b1050ed5">ServiceNow</a></strong> request to IRM Information Protection (NCS-SCC-InfoProtection) using the information in the table below. </p>
</li>
<li>If sensitive data is found then the Information Protection team will contact the appropriate <a href="/solutions/security/aws_account_to_bsa_to_front_office_rep_070302019.xlsx">IRM Front Office Representative</a> who will then contact the BSA's. The BSA team will then follow <a href="/solutions/data-movement/howto-sensitive-data-remediation/">Remediation/Mitigation process for Sensitive Data</a>. </li>
</ol>
<table>
<thead>
<tr>
<th>Field</th>
<th>Value</th>
</tr>
</thead>
<tbody>
<tr>
<td>Target Group</td>
<td>NSC-SCC-InfoProtection</td>
</tr>
<tr>
<td>CI Name</td>
<td>Symantec DLP</td>
</tr>
<tr>
<td>Description</td>
<td>“This request is for a Symantec DLP scan. Scan results also requires Data classification.&quot;</td>
</tr>
<tr>
<td>File Share Name</td>
<td>Your File Share Name(s)</td>
</tr>
</tbody>
</table>


