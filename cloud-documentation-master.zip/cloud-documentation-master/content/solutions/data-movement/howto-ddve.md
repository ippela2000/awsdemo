---
title: EMC DataDomain Virtual Edition
menu: solutions
category: data-movement
weight: 6
---

## EMC DataDomain Virtual Edition (DDVE) [1-Way]

DDVE is a data deduplication device that can be used for transferring large amounts of data into AWS over the IP network. The DDVE supports up to 96 TB of actual backend storage (S3 or EBS). This can translate into as much as half a petabyte of actual data stored and replicated to AWS given a 5 to 1 deduplication ration. Multiple DDVE's can be used in the case where a customer has a need for more storage than this limitation. Deduplication ratios can vary depending on the type of data being transmitted.

The current Cloud Data Services offering for DDVE will be limited to a [ 1-Way ] migration of data into AWS and manually configured. To access the DDVE customers are provided NFS or CIFS share which is mounted on the customer’s EC2 instance in AWS. Data is then copied by the customer from the share to the final landing spot for their data. This can be EBS, EFS, or S3. Once the cutover has occurred the data must be deleted from the share in order to reclaim the storage in use. This use case scenario is expected to not last more then a few weeks to months. If a customer has a need to keep the data domain for a more permanent scenario we are looking into the necessary billing to accomplish that in a future version of this offering.

### Ideal candidates for using DDVE [ 1-Way ]

1. Customers looking to migrate their entire app into AWS.
2. Migrations with a definite end date established.
3. Data sets that will deduplicate well.(video and audio files do not deduplicate well)
4. Data sets where the majority of the data is not compressed or encrypted.

### DDVE Costs?

In this initial offering of DDVE [ 1-Way ] the customer will be paying for the cost of the storage and EC2 instance setup in their AWS account to support the DDVE AMI being installed. This setup typically uses an m4.large linux ec2 instance with approximately 2 to X number of Terabytes of EBS storage. The amount of storage depends on how much data is being migrated at once and how well it deduplicates.

### How to request use of DDVE?

Please fill out the DDVE request template found on the Cloud Data Services page found here:
"https://github.nwie.net/Nationwide/AWS-CloudDataServices/issues/new?template=ddve_request.md"

Please label the request with "EPIC - DDVE".

Please assign the request to the "Cloud Solutions - Cloud Data Services" project.

Please assign the card to the following assignees "@painej1 @mahender"
