---
title: Remediate Sensitive Data
menu: solutions
category: data-movement
weight: 3
---

## Data Scanning

* It is recommended that you have your [data scanned by IRM](/solutions/data-movement/howto-sensitve-data-scan/) prior to migrating any data to the cloud. 
* Refer to the [list of PII data types](https://onyourside.sharepoint.com/:b:/r/sites/IRM/SecurityStandardsPortal/IT%20Security%20Guidance/Nationwide%20Guidelines%20for%20Static%20Data%20Masking.pdf?csf=1&e=LYss1E) that IRM scanning team will be focused.
* If [sensitive data](/solutions/data-movement/howto-sensitve-data-in-cloud/) is found then the Vulnerability Management team will contact the [IRM Front Office Representative](/solutions/security/aws_account_to_bsa_to_front_office_rep_070302019.xlsx) who will contact the BSA. 


## Remediation/Mitigation Process in Non-Production Environments

 * **Remove data**: If the sensitive data is not required in the non-prod environment, then delete it. If you can't delete the sensitive data, consider removing as much of the data as possible. An [exception](https://fulcrum.apps.nwie.net/fulcrum/#!/#!%2F) is requred if not all sensitive data can be removed.

 * **Mask/Mock data**: If the sensitive data needs to exist in non-prod environment, then mask the sensitive data by engaging [TEDS TDM team](/solutions/data-movement/test-data-management/).

 * **Get an exception**: If sensitive data cannot be masked, then work with [IRM](https://idl.nwie.net/irm.html) to obtain an [exception](https://fulcrum.apps.nwie.net/fulcrum/#!/#!%2F).

<h3>The Key</h3>

 The key here is to have a written plan in place with timelines and deadlines. This written plan must be available for review and must be provided to your IRM Front Office representative. If an asset in the cloud has had the access removed, having this written plan in place will enable the IRM Front Office rep to attest to the plan and submit a request to have the access restored.

