---
title: Pets vs Cattle Guide
menu: docs
category: Pets-vs-cattle
---

# Operational Maturity and Disambiguation of Pet vs. Cattle


## Summary
During a recent Open Forum in July, Doug Galuzny, Cloud Architect with I&O team, and Eric Zielinski, Director of CSE, discussed the concept behind Pets vs. Cattle.  

Pets vs. Cattle is an industry term and concept that Nationwide has been attempting to define for over a year. We had some issues with vulnerability management, and we decided to embark on an effort to put more rigor around the concept.  

In 2019, Cloud Migration established and distributed an accountability model where we gave the application teams infrastructure-as-code and automation tools to manage their cloud applications. This enabled them to deploy and manage their instances themselves, adjust configurations, and so forth.  

Cloud consumers were given SSH and RDP access. That combination of privileged access and the automation gaps that resulted in some of the applications not addressing vulnerabilities created some compliance issues with our vulnerability management patching of those and centralized in our I&O teams.  

Some applications are currently out of compliance due to the tagging and self-tagging of Pets v. Cattle done by the application teams. In an effort to remediate this noncompliance, we are introducing different tagging, and thus clearing up misunderstanding surrounding the definitions of Pets and Cattle.  

Originally, we identified whether an instance in the cloud was a Pet or Cattle via a tag called “Patch”. The application teams would tag whether they wanted I&O to patch, by clearly using “true” (“yes, I want to patch”) or “false” (“no, I do not want to patch”) in that tag. This method caused some confusion around how we managed our fleet and our asset inventory. For example, when it came time for patching, we assumed that teams who had tagged their instances as “false” were patching on their own.  

Learn more on how we addressed these behaviors: [watch the Open Forum broadcast](https://videospace.nationwide.com/media/1_mxxmgf2r) and [view the full PowerPoint presentation](https://teams.microsoft.com/l/file/6862F544-D0D9-4AA2-A6F4-A501484A4BCF?tenantId=22140e4c-d390-45c2-b297-a26c516dc461&fileType=pptx&objectUrl=https%3A%2F%2Fonyourside.sharepoint.com%2Fsites%2FCloudVulnerabilityManagement%2FShared%20Documents%2FGeneral%2FPets%20vs.%20Cattle%20Open%20Forum.pptx&baseUrl=https%3A%2F%2Fonyourside.sharepoint.com%2Fsites%2FCloudVulnerabilityManagement&serviceName=teams&threadId=19:88f50d9e6e3c4b57a5540ebcf8c3b74b@thread.tacv2&groupId=4626c66a-e863-4646-9f75-abb99a92d796) 

## Pets vs Cattle Background
### Problem Statement
The 2019 Cloud Migration established a distributed accountability model and provided application teams infrastructure-as-code, pipelines, and automation tools to manage their cloud applications with totally automated methods. Some application teams leveraged that automation for infrastructure setup but continued to deploy and manage middleware and applications configurations as they did on premise. Cloud consumers were also given SSH and RDP access to instances they created. The combination of privileged access and automation gaps has resulted in some applications not addressing the vulnerabilities in compliance with IRM requirements. I&O teams have centralized patching of vulnerabilities. The ambiguity between fully automated workloads and those managed manually is best described with the industry metaphor of Pet vs. Cattle. There should be clarity in which workloads are managed as Pets and those as Cattle.
### Key Findings
* EC2 instances labeled as Cattle by application teams thus not being patched for vulnerabilities
* Patching tags are not clearly understood among application teams
* Changes being made to EC2 instances outside automated pipelines
* SSH is being used for some patching including secure copy and gzip tunneling
* SSH is allowed to some containers
* Long running containers go far beyond the desired 28 day age
## Pets vs Cattle Definition
> ### Pets
> Pet is any compute instance (not container) where the user community has a specific relationship with individual nodes rather than the service they provide. This relationship can include patching, remote connectivity, manual upgrades and installations, hardcoded pointers to specific names or IPs that create tight coupling. Service is based on a specific node and its configuration.​  
> ### Cattle
> Cattle are not patched or managed through remote connection, rather software currency, configuration and vulnerability remediation is handled via redeployment from automation pipelines. Any connectivity to Cattle is unaware of the specifics of the node serving the transaction.  
### MEASURE TO BE IDENTIFIED AS CATTLE  
EC2 Cattle = Pipeline & ASG & (Image Age <60 days) [& meet VM SLAs]​  
Container Cattle = Pipeline & Instance Age <60 days & Image Age < 60 days [& meet VM SLAs]​  
#### *Assumptions*
1. Tags are *programmatically defined* and *read only*
2. All virtual instances (EC2) *default* to Pets until their *behavior* meets definition of Cattle
3. All containers are required to operate as Cattle or eventually get turned off
4. EC2 instances identified as Cattle but failing to maintain requirements follow a demotion process
## Pets vs Cattle EC2 Tag Breakdown
### Self Tagging by App Teams
<img src="../images/self-tagging-by-app-teams.png" alt="Self tagging by app teams" class="w-50" />  

This graph represents a high percentage of EC2 tagged as cattle manually by App teams.  
### Tagging Based on Behavior
<img src="../images/tagging-based-on-behavior.png" alt="Tagging based on behavior" class="w-50" />  

This graph represents a high percentage of EC2 not deploying from pipeline or auto scaling groups.
## Pets vs Cattle Target Operating Model
|  | Pet | CATTLE | CATTLE |
| ----- | ----- | ----- | ----- |
| **Resource Type** | **Virtual Instance** | **Virtual Instance** | **Container** |
| **Max Image Age** | None | 60 days (N-1) | 60 days (N-1) |
| **Max Instance Age** | None | 60 days | 60 days |
| **OS Patching** | Scripted patching by Hosting Team | Redeployment by App Team | Rebuild with current packages |
| **Middleware Patching** | Redeployment by App Team | Redeployment by App Team | Rebuild with current packages |
| **Database Patching** | Patched by Database Team | Redeployment by Database Team | Redeployment by App Team |
| **SSH/RDP Access (Test & Prod)^-a** | None - Firecall Only | None - Firecall Only via AWS SSM | None - Firecall Only |
| **Change Method** | Deploy or Change | Deploy Only | Deploy Only |
| **Auto-Scaling/Disposability** | Recommended | Required | Required |
| **Secure Config** | Same as on-prem | Controlled before deployment | Controlled before deployment |
| **Tagging Method (read only)** | Operating Model = Pet | Operating Model = CATTLE | Operating Model = CATTLE |  
## Pets vs Cattle Governance Model
<img src="../images/governance-model.png" alt="Governance Model" class="w-100" />  

## Pets vs Cattle Modifications of SSH/RDP
### Virtual Instance (EC2)
|  | Current Model | Future Model |
| --- | --- | --- |
| **Remote Shell**  _Linux_ | Direct SSH access with root credentials and anonymity | Connection through Firecall process only |
| **Remote Desktop**  _Windows_ | Direct RDP access with admin credentials and anonymity | Connection through Firecall process only |
| **File Copy**  _SSH_ | Executes secure copy from shell of target system while connected via SSH | Executes secure copy from shell of target system while connected via session manager |
| **File Copy**  _Integrated_ | Automation scripts utilizing secure copy move files to target system | No change. Direction changing to utilize S3 as intermediary rather than direct secure copy |
## Pets vs Cattle Firecall Access
> Definition  
> Any method established to provide emergency access to a secure information system. In the event of a critical error or abnormal end, unprivileged users can gain access to key systems to correct the problem. When a Firecall is used, there is usually a review process to ensure that the access was used properly to correct a problem. These methods generally either provide a one-time use User ID and password OR temporarily granted access to user for a short window of time (i.e. up to 24 hours)  
<img src="../images/firecall-access-definition.png" alt="Firecall Access Icons" class="w-75" />  

## Pets vs Cattle FAQs
### What are the implications of being converted to a Pet?
If your EC2 instance becomes a Pet, the Sustaining Team will add it to the Nationwide patching cycle, and receive monthly patches as released. Operating as a Pet increases cost due to more labor needed to support, patch, and maintain a healthy vulnerability posture. If the instances don’t receive patches, they have risk of becoming vulnerable to various breaches discovered through bugs, security holes, as well as potentially experience performance degradation due to unresolved memory and resource allocation issues from potentially poorly written code.  
Receiving patches in an automated redeployment scenario such as an Auto Scaling Group could potentially cause instability to the app, and wastes resources that could redeploy and maintain the software currency through those methods.  
### Why is SSH/RDP console access affected in these changes?
In an effort to drive more cattle-like behavior in our environment, we are encouraging app teams to utilize automation to make their changes and code updates. We are discouraging manual changes, which create unique instances and break the cycle of the instance updating via automated processes and pipelines.  
To curb this, we are _disabling_ native SSH and RDP session availability in a phased approach across the Nationwide compute environments.  
We realize there will still be occasions and justified reasons for needs console access to both Linux and Windows instance. We are deploying AWS SSM agent across the environment to enable SSH-like and RDP-like sessions to Linux and Windows instances.  
More questions and answers in [Pets vs Cattle FAQs](solutions/Pets-vs-cattle/Pets-vs-cattle-faqs.md).