---
title: Pets vs Cattle FAQs
menu: solutions
category: Pets-vs-Cattle 
---

## What is the difference between pets and cattle?

>### Pets
>Pets are any compute instance (that is not a container) where the user community has a specific relationship with individual nodes rather than the service they provide. This relationship includes patching, remote connectivity, manual upgrades and installations, and hard-coded pointers to specific names or IPs that create tight coupling. A specific node and its configuration is the foundation for the pets service.  
>### Cattle
>Cattle are not patched or managed through a remote connection. It handles the software currency, configuration, and vulnerability remediation through redeployment from automation pipelines. So, any connectivity to cattle is unaware of the specifics of the node serving the transaction. 

### Why is Nationwide making operational changes on how to identify pets and cattle?
In 2019, Nationwide cloud migration established a distributed accountability model to provide application teams with infrastructure-as-code, pipelines, and automation tools to manage their cloud applications using automated methods.  

Some application teams leveraged the automation for their infrastructure setup, but continued to deploy and manage middleware and application configurations as they did on-prem. Nationwide cloud migration gave cloud consumers access to SSH and RDP, so they could access the instances they created. This combination of privileged access and automation gaps has resulted in some applications not addressing the vulnerabilities in compliance with IRM requirements.

I&O teams have centralized patching vulnerabilities. The industry metaphor, pet vs cattle, is the best way to identify the difference between automated workloads (cattle) and manual workloads (pets).

### What happens if my instance gets flagged as a pet?
This applies to EC2 only.  
1.	Upon discovery on Day 1, the CSE team assigns a ticket to the app team for the new instance identified as a pet. 
2.	The App team should attempt to remediate this behavior by redeploying their instance with the latest code updates, including OS, middleware, and application.
3.	If after 7 days, the instance continues to flag as a pet, the CSE team sends a notification to leadership.  
4.	If after 14 days, the instance continues to flag as a pet, the CSE team retags the instance as a pet, and adds it to the Nationwide patching cycle.  
5.	At this point, the pet instance will receive patches until it redeploys with OS, middleware, and App code that does not violate Vulnerability Management SLAs.

### How can I get my instance to become cattle?
If your EC2 instance is currently tagged as a pet, the best way to get it tagged as cattle is to:  
* Maintain a image age of less than 60 days, and  
* Ensure that there are no violations with Vulnerability Management SLAs.  
  * If these two items remain true, then the automation for tagging relabels this as cattle.  
**Note:** I&O considers all on-prem instances as pets. Due to the lack of automation, anything on-prem cannot become cattle.

### What are the implications of becoming a pet?  
If your EC2 instance becomes a pet, the biggest implication is that the Sustaining team will add it to the Nationwide patching cycle, and it will receive monthly patches as released.  

Operating as a pet increases the cost for labor needed over the course of a year to support, patch, and maintain a healthy vulnerability posture. If instances do not receive patches, they are vulnerable to various breaches discovered through bugs and security holes, and could experience performance degradation from unresolved memory, and resource allocation issues from coding errors.  

Nationwide patches and maintains software versions to prevent these occurrences. Receiving patches in an automated redeployment scenario such as an Auto Scaling Group, could cause instability to the app, and wastes resources that could redeploy and maintain the software currency through those methods.

## Remote connectivity – Linux
### Why is SSH console access affected in these changes?
As part of the effort to drive more cattle-like behavior in our environment, Nationwide is encouraging app teams to use automation to make their changes and code updates.

The CSE team is discouraging manual changes, which create unique instances and break the cycle of the instance updating via automated processes and pipelines. The CSE team is using a phased approach to disable the native SSH and RDP session availability, both on-prem and in the cloud.  

We realize that there may still be occasions and valid reasons for needing console access to both Linux and Windows instance. We are deploying AWS SSM agent across the environment to enable SSH-like and RDP-like sessions to Linux and Windows instances.  

The benefits of using this rather than native SSH/RDP:
1.	You need to request access with: a reason why you need access, who needs access, responsible manager, instance name, and duration (hrs) for this access.  
2.	Nationwide will log all activity within the session to assess the work accomplishments. This activity log will help the app team find ways to mature the process and increase automation.  
3.	Nationwide is reducing remote connectivity, and requiring elevation to improve our vulnerability posture. This will make it less likely to execute commands that could pose risk.  
4.	While immutable infrastructure is a desired goal for many reasons, it may be necessary to access or alter systems running live. The AWS Systems Manager, Session Manager allows this capability without the need to add firewall ingress or bastion hosts.

### What if I still need SSH access to my instance?
A Firecall access request is available for Nationwide associates to submit a request for temporary access to designated EC2 and on-prem instances. Remote console access is going to remain, with modifications to the methods used to gain access to these remote sessions. This includes tracking and logging the work performed in the sessions. 

### How can I connect to my instance to execute commands from troubleshooting or verification of automation, etc.?
#### Connecting through AWS console:
1. Go to Systems Manager service  
<img src="../images/aws_SSM_search.jpg" alt="AWS SSM search" class="w-50" />  

2. Go to Session Manager on the left-hand menu.  
<img src="../images/aws_menu.jpg" alt="AWS menu" class="w-25" />  

3. Select the instance that you are trying to connect to, and click Start Session.  
<img src="../images/aws_SSM_select_service.jpg" alt="Select AWS SSM Service" class="w-100" />  

#### To connect to your instance using AWS CLI:
1. Please run [your federator](https://gocloud.nwie.net/docs/aws/management-and-governance/aws-cli/howto_tools/) 
2. Run the following command using your profile and region:
`aws ssm start-session --target <ec2-instanceid> --profile <your profile> --region`

### Does SSM limit executing any commands in the session?
No, and Nationwide configuration does not impose this type of limit.  Nationwide is replacing SSH with SSM for better accountability and visibility into what executes in our environment.

### Does SSM provide an ability to control secure configuration of an instance?
SSM has a component called *State Manager* that offers the ability to enforce specific configurations within an instance. It also has a component called *App Config* for controlling the application settings and configurations within the instance.

### How is Nationwide disabling native SSH?
The CSE team is redirecting SSH to a new component, *RSSH,* which enables the CSE team to limit the access to the native connection method by the group.  

On a per node basis, the CSE team can configure the RSSH component to allow native access for issues with SSM connectivity, or for issues with an app-to-app integration not functioning with the SSM connection.

### Does a user have to authenticate to the instance once they establish a session?
Upon initial connection, a user is connecting with a federated IAM role, and the instance is unaware of their specific user ID. The system knows them as SSMUser at that point. To connect to their user specific rights, they would have to `su` to their user credentials.

### If I run a batch process on my instance through an SSM provided session, and my time allotment expires for which I have access to the instance, what happens to my running process?
Like SSH, a user that needs to run a long running process should execute it with the screen function, so that it runs as a background process. In that case, the process will continue to run even if the app team terminates the user’s session.  

## Remote connectivity – Windows
### Does a user have to authenticate to the instance once they establish a session?
Yes, the SSM RDP session is like the native RDP session, in that it uses the native RDP client tunneled through the SSM agent connection. Once the user establishes a session, they need to logon using the credentials that have access to that server.

### Does SSM use native RDP client, or does it present a web browser emulation of an RDP session?
RDP does executes using the native RDP client. It tunnels through the SSM agent without using a browser or emulation.
 
## File transfer
### If I cannot use native SSH, how can I get files to my instance?
SCP will still be available through the SSM agent connection. As an alternative, users can also use the AWSCLI on the origin machine to upload files to Amazon S3 storage, connect to the destination machine, and then use the AWSCLI again from the destination to pull the files down to that target box.

### What if my instance has app-to-app integrations that requires native SCP for file transfers between applications?
An exception process is being designed for app-to-app connections so that those can continue using native SSH/RSSH where applicable. It is best to consider removing the file transfer requirements if possible, and convert to API calls for integration rather than sending flat files to servers.