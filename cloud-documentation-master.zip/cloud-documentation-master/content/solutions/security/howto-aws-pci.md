---
title: AWS PCI Info
menu: docs
category: general
weight: 6
---
###   AWS PCI Info <br><br>
<br>


#####  PCI Compliance

As you are well aware, maintaining Payment Card Industry (PCI) Compliance is a top priority for Nationwide and at this time, the Nationwide Amazon Web Service environment is not
certified to host “in scope” PCI assets. Efforts are under way to provide an environment that will both satisfy a cloud deployment strategy and maintain PCI Compliance for the
Enterprise. If you act as a point of contact for an information technology asset that is currently considered “in scope” for PCI requirements please reach out to
Jeff Bonifant (jeff.bonifant@nationwide.com) for more information.

PCI compliant cloud solutions are currently being reviewed and once a solution is designed / selected you will be informed of the direction for your PCI asset. Please be aware,
there is a possibility of impact to your cloud migration schedule, depending upon the timelines that have been identified for your asset.

My Asset is not located within the PCI Cage
Any application that transmits, processes, or stores credit card information is considered in scope for PCI compliance. In some cases, “in scope” applications are not located
within the PCI cages of the datacenter networks. In these cases, the asset still adheres to PCI Requirements through technology and process governance that is associated with
normal operations of the datacenter environment and these same controls need to be facilitated in a cloud environment. Any asset that contains actual credit card numbers,
not test numbers, should be considered in scope and this data cannot be utilized outside of a production PCI environment.

How do I prepare?
Do not stop your preparations for a cloud migration, as a final landing spot for PCI assets will likely be within AWS. Any learning and preparatory work that you are accomplishing
today will likely translate to the new environment. Many teams are being encouraged to explore containerization of their assets, and education and exploration of container
technologies can be valuable in the future, however, there is no current PCI compliant container solution within the Nationwide AWS environment or the datacenter at this time.
Efforts are under way to unable this capability and maintain PCI compliance.

Who do I contact with questions or updated information?
Reach out to Jeff Bonifant (jeff.bonifant@nationwide.com) for more information




