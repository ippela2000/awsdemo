---
title: RedLock Information Page
permalink: /docs/aws-docs/howtoredlock
---
<br>

##### Contents:
1. How to request access



##### How to request RedLock access:
1. Email cse@nationwide.com
2. The Cloud Security Engineering Team will add your userID to the RedLock readonly group.
3. Go to the following link:<br>
    https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fapp.redlock.io%2F%3Fcustomer%3De431c31e84f11c19a9ada0a6691e6123 <br>
4. If the the login page errors out, simply refresh or close the browser and retry it.


#### Links
* RedLock loging [RedLock Login](https://identity.nationwide.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fapp.redlock.io%2F%3Fcustomer%3De431c31e84f11c19a9ada0a6691e6123)

<br>


![alt text](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/gh-pages/Image/redlockimage.GIF "RedLock Screenshot")
