---
title: AWS Cloud TSB Information
description: "Listed below are the TSB exceptions filed for the Services in AWS"
draft: false
category: security
weight: 3
---

**Note:** These TSBs have been submitted via I&O. If you and your application would like to utilize any of these technologies, the Cloud Teams stress that you must work with your application architects. 

### AWS Lambda
* TSB0012149
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### Amazon Lex
* TSB0011994
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### Amazon Polly
* TSB0011995
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### Amazon S3 Glacier
* TSB0011997
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### AWS Storage Gateway
* TSB0011998
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### Amazon Athena
* TSB0011999
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### Amazon EMR
* TSB0012000
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### Amazon Kinesis
* TSB0012001
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:   
    * Per Technology, "For IoT or Edge cases only. Core Business should utilize our Kafka instances already deployed in AWS."

### AWS Snowball
* TSB0012002
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### AWS Lake Formation
* TSB0012003
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None

### AWS Step Functions
* TSB0012013
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None  

### Amazon Simple Queue Service (SQS)
* TSB0012130
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None  

### Amazon Simple Notification Service (SNS)
* TSB0012131
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:   
    * Per Technology, "SNS will not be the standard for Pub/Sub messaging for Core Business Events. That is Kafka. For smaller workloads (limited through-put) a combo of SQS/SNS may work. Also, if an application on AWS is fully native to AWS the linkage may be easier with an SNS/SQS solution. These will be addressed on a case-to-case basis."

### Amazon Elastic File System (EFS)
 * TSB0012132
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
 * Rationale for Approve/Deny
   * This production exception is approved with the following stipulations:   
     * Per IRM, "It requires an exception when used in a non-production environment because EFS cannot be scanned by our DLP tools." 

### AWS Snowmobile
 * TSB0012151
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
 * Rationale for Approve/Deny
   * This production exception is approved with the following stipulations:   
     * Per LOB, "This product should not be enabled by default in every account, only shared services providers (EDO, I&O etc.)."
     
### Amazon Database Migration Service (DMS)
* TSB0012133
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None  

### AWS Data Pipeline
* TSB0012005
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:  None  
  
### Amazon CloudSearch
* TSB0012012
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:
    * Per Legal, "Needs to go through AWS vetting. Cloud Team will schedule."
      * As of November 5, 2019 [11/5/19] this technology has **NOT** been vetted
      
### AWS FSx
* TSB0012481
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:   
	   * Per IRM, "Recommend approval of this Production Request with the stipulation that you adhere to "Production Only" caution specified in RFI 27943."
	   * Per LOB, "Need for SMB/NFS file sharing/mounts. We need prescriptive guidance for user patterns (source/target - Windows/Linux etc.) and those varioations may require more choices but lets nail down those patterns and ensure that we are using a consistent toolset to meet each pattern. I see several ways to create network shares and that could create complexity and debt if not goverened. Consider this approval supportive of using this technology to nail down those patterns. Meaning, I am interested in approving the use cases/patterns - not just the technology for broader use."
    
### AWS Glue
* TSB0012469
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:   
	   * Per IRM, "Recommend approval of this Production Request with the stipulation specified in RFI27942 re: Informatica for ETL."
	   * Per LOB, It is clear that Glue is an essential part of our evolving data pipeline in AWS and therefor needs to be a standard. The complication is that this request presents Glue as a standard technology. This does not satisfy the need for prescriptive guidance for its usage (which is wider than a single use case). For example, as an ETL tool, our teams (both data and BSA) have found that it is lacking in areas where our existing tools are used. The lessons learned are not making their way back to areas that perhaps could benefit from other's outcomes. I suggest that we decompose Glue to use cases/fit for purpose and prescribe those clearly in GoCloud. Additional guidance is needed for Glue Catalog and how it services a larger metadata management strategy/architecture. Definitely needed, but so to is the guidance for proper usage."

### AWS API Gateway
* TSB0012269
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny
  * This production exception is approved with the following stipulations:   
	   * Per LOB, "when using native amazon services, API Gateway is a natural integration technology that should be available for speed and lower levels of complexity. When leveraging API Gateway there will need to be associated (approved) patterns for tech teams to leverage that not only identify the components and where they fit by use case, but clearly state the pros and cons (lock-in) of the pattern. We feel that the technology is a vital component on our cloud migration journey but does not take the place of some critical components already in the ecosystem like Apigee."
	   * Per Technology, "I recommend approving this Production exception with the following stipulations: For internal services only that are not business to business calls."

### Amazon AppStream 2.0
* TSB0012011
* Requester: <a href = "mailto:hainem1@nationwide.com">Matthew Haines</a>
* Rationale for Approve/Deny:
  * Per Technology, "The team must ensure someone from Mark Gibson's EUSG is involved in managing any desktop published applications.  The EUSG should ensure the products are fully managed through their entire lifecycle (acquisition, allocation, license compliance, currency, vulnerability remediation, upgrades/replacements, retirement, license reclamation/reuse, etc.)  This group is the subject matter experts at performing this work end-to-end for desktop apps."
