---
title: Configuring SSO and the Ping Request
draft: false
category: security
---




### To configure Ping SSO for your application on tomcat, follow the instructions [here](https://github.nwie.net/Nationwide/mw-apache-httpd/wiki) to install apache first, and then be sure to read through the following.

#### The Ping team will need to protect the URLs for your application so you can enable single sign on. However, you only get _one option_ in the apache configuration for all environments in your 'install_tomcat.sh' file.

To enable all three environments with one option, we recommend requesting your application URLS with an asterisk representing the environment in front of the application as follows. Note that you will need to request both the application URL and the healthcheck header URL as shown.

### Dev Environment Ping Request:

    *.myapplicationname.aws.e1.nwie.net
    hc.*.myapplicationname.aws.e1.nwie.net

### Test (and any other lower) Environment Ping Request (yes, exactly as the Dev):

    *.myapplicationname.aws.e1.nwie.net
    hc.*.myapplicationname.aws.e1.nwie.net

### Prod Environment Ping Request (no asterisk):

    myapplicationname.aws.e1.nwie.net
    hc.myapplicationname.aws.e1.nwie.net

#### In the install_tomcat.sh file, for the apache configuration, add your application name without any other configuration:

    myapplicationname

#### For each environment, your **DNS names (pCertName in json)** should look like this:

**Dev:**

    dev.myapplicationname.aws.e1.nwie.net

**Test:**

    test.myapplicationname.aws.e1.nwie.net

**Prod:**

    myapplicationname.aws.e1.nwie.net
