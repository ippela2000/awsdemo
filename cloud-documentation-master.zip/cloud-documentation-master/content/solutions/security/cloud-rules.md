---
title: Guardrails in Natiowide AWS Cloud accounts
description: "Description of Cloud Rules that apply to the resources you create in AWS at Nationwide"
draft: false
category: security
weight: 1
---

## Overview
Nationwide has a number of Cloud Rules that apply to the resources you create in AWS. The reason Nationwide has chosen to enforce it's own custom rules is to provide a higher level of security and protection to our members in the public cloud space as well as help optimize our use of the cloud.

This page will now review different AWS services, what rules apply and how they are enforced.

### Notifications
When cloud rules are enforced, an email is sent to the user specified in the ResourceOwner tag on the resource. Thus it is important to make sure that tag has a valid NWIE id or distribution group. A message will also be posted to the #AWS-Notifications rocket chat channel.

EC2 instances that are shut down will receive a tag "LastAutomatedShutdown" with the reason for the shutdown.

EC2 instances that are violating a rule but are not shutdown because they are in a lower environment will receive a tag "RuleViolation".

### Exceptions to rules
[Please see here](/solutions/security/howto-ruleexception/)

## THE RULES

| AWS Service | Rule | What | Enforcement | Why | Additional Info |
|---|---|---|---|---|---|
|EC2-Instance| Tagging | Instances must be tagged | EC2 Instance Shut Down| Tagging helps identify who/what app owns resources | [Check Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement)
|EC2-Instance| Machine Images (AMIs) | EC2 instances must use Approved Nationwide AMIs | EC2 Instance Shut Down in Test/Prod, Warning  in Dev & Sandbox | Nationwide has decided to force everyone to use the same base images to build their application images from. This is so we can ensure the correct security software is installed and so we can patch vulnerabilities in a centralized and automated fashion. | [AWS Golden AMI process](https://aws.amazon.com/blogs/awsmarketplace/announcing-the-golden-ami-pipeline/)  
|EC2-Instance| Subnets | EC2 instances cannot be directly in public subnets |EC2 Instance Shut Down in Prod, Test & Dev | EC2 instances cannot directly reside in public subnets to be accessible directly from the Internet. All internet facing EC2 instances must be behind Load Balancers with a Web Application Firewall (WAF) attached. This is to provide better security and stability of our servers.  | [AWS WAF info](https://aws.amazon.com/blogs/aws/aws-web-application-firewall-waf-for-application-load-balancers/) Also note: when creating an ec2 instance in the Console, AWS might default to a public subnet so you will need to change it.
|EC2-Security Groups| Security Groups | The security group used by the instance will be reviewed. The ToolsAccess security group is also automatically attached to your instance. | Warning Only | Your security group will be reviewed and an email sent to the ResourceOwner with suggestions to make it more secure/less open. The resource will also be tagged with this information. This is to drive better behavior and to strengthen our security posture. The ToolsAccess group will allow I/O administrators and scanning tools access to your server | 
|EC2-AMI| Public AMIs | AMIs are not allowed to be set to "public" | AMIs will be set to "private" automatically | Public AMIs can be seen by other users of AWS outside of Nationwide.  This rule is to prevent our data and proprietary knowledge from falling into the wrong hands. |
|S3-Bucket| Public Bucket | S3 buckets or objects cannot be publicly accessible | Buckets are blocked from being set to public automatically |  Public buckets and objects can be seen by anyone on the internet.  This rule is to prevent our data and proprietary knowledge from falling into the wrong hands. |
|S3-Bucket| Bucket Encryption | S3 buckets cannot be unencrypted | Unencrypted buckets will have encryption turned on automatically | Encrypted data at rest is a best security practice. This rule is to prevent our data and proprietary knowledge from falling into the wrong hands |
|S3-Bucket| Default Bucket Policies | S3 buckets receive default bucket policies | The bucket policies are added automatically | The default bucket policies prevent objects and buckets from being made public |
|KMS-Key| Key Rotation | All KMS keys must have key rotation enabled | KMS key rotation will be enabled automatically | This is a security best practice | [AWS KMS Key rotation guide](https://docs.aws.amazon.com/kms/latest/developerguide/rotate-keys.html)
|ECR| Public Repository | Elastic Container Repositories (ECRs) cannot be "public" | Repositories will be set to "private" |Public ECRs can be seen by other users of AWS outside of Nationwide.  This rule is to prevent our data and proprietary knowledge from falling into the wrong hands. |
|IAM-User| No IAM Users | IAM Local users are not allowed to be created | The CreateUser command is blocked by for whole enterprise | Nationwide has decided to forbid the use of local aws users so we are able to leverage expiring federated roles connected to our existing NWIE AD.
|IAM-Role|IAM Deny on Roles | Any role created in AWS will automatically receive a IAMDeny policy that blocks certain actions | Policy is automatically applied | This is to prevent users from being able to create roles that have the ability to break critical security controls in AWS.
|Redshift| Public Clusters | Clusters are not allowed to be set to "public" | Clusters will be set to "private" automatically | Public Redshift Clusters can be seen by other users of AWS outside of Nationwide.  This rule is to prevent our data and proprietary knowledge from falling into the wrong hands.
|Redshift| Unencrypted Clusters | Clusters are not allowed to be unencrypted | Clusters WILL BE DELETED. Once a cluster is created unencrypted, it cannot be set to encrypted. The only way to enforce this rule is to delete. | Encrypted data at rest is a best security practice. This rule is to prevent our data and proprietary knowledge from falling into the wrong hands.
|RDS| Public Instances | RDS Instances are not allowed to be set to "public" | RDS Instances will be set to "private" automatically | Public RDS Instances can be seen by other users of AWS outside of Nationwide.  This rule is to prevent our data and proprietary knowledge from falling into the wrong hands.
|RDS| Unencrypted Instances | RDS Instances are not allowed to be unencrypted | RDS Instances will be shut down. Once a instance is created unencrypted, it cannot be set to encrypted. The only way to enforce this rule is to shut down. | Encrypted data at rest is a best security practice. This rule is to prevent our data and proprietary knowledge from falling into the wrong hands.
|RDS| Tagging | Instances must be tagged | RDS Instance Shut Down | Tagging helps identify who/what app owns resources | [Check Required Tags for Services at Nationwide](/docs/aws/cost/tagging-requirement)
|RDS| Engin Type |RDS Engin Type | RDS Instance Shut Down in Prod & Test | Supported RDS Engin type |'sqlserver-se','sqlserver-ee','aurora-postgresql','oracle-ee','oracle-ee2','oracle-se1','oracle-se'
|ElastiCache| Encryption | Encryption at-rest and in-transit | ElastiCache Cluster or Resource Group will be deleted. | Encrypted data at rest and in transit is a best security practice. This rule is to prevent our data and proprietary knowledge from falling into the wrong hands. |
