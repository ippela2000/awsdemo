---
title: How to Request a Cloud Rule Exception
description: "Cloud rule exceptions are often needed to meet the needs the application requirements"
draft: false
category: security
weight: 2
---


##### To request a new rule exception or marketplace access please submit a Github bug report [here](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=exception_request.md)

### Cloud Rule Examples

Below are some common cloud rules that could require an exception and the reasoning for them being in place.

  - **IAM Role Policies:** IAM roles are not unique to each user, these roles are applied across accounts so any changes made to them apply everywhere.
  - **S3 Guardrails:** S3 buckets, while not public by default, can easily be made public by AWS design. Nationwide has designed and engineered policies enforcing that S3 buckets are not made public and must be encrypted to protect Nationwide data.
  - **Nationwide Approved Amazon Machine Images (AMIs):** EC2 instances may only used Nationwide approved AMIs. This is because of the monitoring and security tools that are needed to be installed on the instances.

## The Vetting Committee

- **What is the vetting committee?**
  * The vetting committee is designed to enable the timely vetting of all things AWS, whether it be a new AWS service, a MarketPlace AMI, a 3rd Party AMI, or perhaps even a new process or method pertaining to 'how' cloud is done
- **Who are the standing members of the vetting committee?**
  - The vetting committee is comprised of individuals from the following organizations:
     - Legal-OPTICS
     - Security Architecture
     - IRM
     - Cloud Solutions
     - I&O Architecture
  - Individuals from various organizations can and will be called upon depending on the given topic(s) at hand
- **When do I as a developer or architect need to engage the vetting committee?**
  * As a developer or architect you will need to engage the vetting committee whenever you need an exception to a cloud rule or the approval of a 3rd Party AMI or the approval and use of an AWS MarketPlace offering. Perhaps you are looking at the [Platforms, Products and Services](https://pages.github.nwie.net/Nationwide/NW-Cloud-Docs/docs/aws-docs/0-Platform-Product-Services/) page and you do not see an AWS service that you would like to utilize, this is when you would engage the the vetting committee.
- **How do I engage the vetting committee?**
  * A great way to engage the committee is to request an exception by filling out [this Github card request](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=exception_request.md).
- **Who schedules and organizes the vetting committee and determines what topics are discussed?** 
  * The Cloud Product Manager
    * Ryan Mainwaring: mainwr1@nationwide.com
- **Once a decision is made, what is next? What about TSB?**
  * After the vetting committee had made a ruling on a particular item, process or technology a couple things happen:
    * The item or technology is enabled in the development account unless it's a AWS Marketplace item. See below for that process
    * Paperwork is submitted to the TSB, having already been vetted, as required for audits
    * Cloud Solutions engagement can further take place with various BSA teams
  
### AWS Marketplace

### Please remember: No Nationwide data can be used as part of these test and learn situations

#### For your Consideration
Using a 3rd Party AWS MarketPlace image can speed up your development cycles and there is no doubt that the Cloud Delivery Team [CDT] and the various tech consultants share in the goal of speed to market. Before starting the journey to utilize a 3rd Party AWS MarketPlace image there are tactics we ask you to consider. Nationwide is only as agile as the vendors we choose to utilize for our 3rd Party AWS MarketPlace images. Bearing that in mind, CDT recommends the following approaches to be completely exhausted prior to the use of a 3rd Party AWS MarketPlace image.

**Questions To Ask To Your Teams: Before clicking**
* Is this AMI critical to your business?
  * If “yes” why?
* Is vendor support absolutely required?
  * If “yes” why?
* If there is an existing relationship with the AMI provider, is there a contract in place?
  * If “yes” please provide
  * If “no” an Enterprise contract will be needed so please plan to engage Procurement.
* Have you worked with your IRM and Legal OPTICS teams in regard to using a 3rd Party AWS MarketPlace image (“AMI”)?
* Is the use/purchase of this 3rd Party AWS MarketPlace image in alignment with architectural standards?
  * Engage with your Solution/System/App architects
* Since this is a 3rd Party Image [app] have you established a support and maintenance structure around the use of this image in production?

After going through the initial internal discussions with IRM, Legal OPTICS, and Architecture the following steps are required:available

#### Step 1
* Beginning Point: Sandbox account
* Receive approval from Legal OPTICS, and your AVP
  * Submit request for your AMI to the [Github Issues](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=exception_request.md)
     * The name of the AVP or higher that has approved this spend and can accept any identified risks
     * Name of the application and link to any license agreement
     * Business unit and anticipated goal for Sandbox Access
     * Price estimate
* Provide answers to the short intake form provided
  * Legal OPTICS will review the request, End User License Agreement, and provide legal guidance to the AVP identified on the intake form for the AVP to approve its use in Sandbox.  The legal review SLA is 10 business days or sooner.
* After approval is received, the CDT will grant selected parties the proper access to retrieve the 3rd Party AMI and place it the Sandbox Account
  * The individual downloading will be given the correct permissions for exactly 24 hours after which the permissions will be removed
* After downloading you will be given 15 days to evaluate the AMI
* After the time frame has expired the AMI will be removed from the Sandbox account

After completing **Step 1** you will be able to move to **Step 2**

#### Step 2
* Beginning Point: Dev account
  * Only available after completing **Step 1**
* If you have gone through the first approach and believe that the AMI needs to be promoted to the Dev/Test/Prod environments the following actions will be required
  1. Review and approval from IRM, Legal OPTICS, and Architecture [written or email] plus any officer approvals
  2. The execution of an Enterprise Contract or utilization of an existing contract.  The Procurement area should be engaged via your normal processes
  3. After the approvals the Service Vetting Team will review all the collected documentation and approvals for a “final” review
  4. The individual downloading will be given the correct permissions for exactly 24 hours after which the permissions will be removed

