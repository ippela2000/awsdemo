---
title: Resiliency(DR) Directives
draft: false
category: security
---

- **Directive**:  All **Critical** applications must be configured in a resilient manner to take advantage of the fault tolerance capabilities of the cloud environment, and must be deployed across at least two availability zones.  Refer to the available [Resiliency patterns](/solutions/architecture/create-app-infra-resiliency/).
		- **Justification**:  This provides an alternative environment that can be used in the event of disruption to the primary production configuration. 
- **Directive**:  All **Critical** applications must be coded in a fault tolerant manner to take advantage of the inherent resiliency of the cloud environment.  Each application layer must automatically auto-scale and move from one zone to another.    - **Justification**:  This allows for uninterrupted processing in the event of infrastructure failure.
-  **Directive**:  All **Critical** applications must be designed to be unaffected by faults experienced by dependencies, to include third party, on-premises, cloud-to-cloud, and up- or downstream applications or data.
		- **Justification**:  This insulates the application from extraneous disruptions.
- **Directive**: All **Critical** applications must be correctly modeled in the Abacus tool. You can get in touch with the team [here](https://onyourside.sharepoint.com/sites/EnterpriseArchitecture/SitePages/Enterprise%20Architecture%20Core%20Team.aspx). 
		- **Justification**: This provides understanding of application dependencies from both a business and infrastructure resiliency standpoint.
- **Directive**: All application recovery plans must be correctly documented in the resiliency plan tool (Assurance) to include RTO, RPO, and any connectivity requirements from Nationwide facilities. 
		- **Justification**: This complies with enterprise and regulatory requirements, and allows for proper assessment to certify the infrastructure meets the recovery time and data loss needs.
- **Directive**: Determine whether the critical application lies on the Critical Business Process critical path, using the CBP mapping function within the Enterprise Architecture tool. 
		- **Justification**: Critical path applications are vital to the resiliency of the business process, such that if they become unavailable the business process will not function. These applications may have additional stringent resiliency requirements that must be satisfied.
- **Directive**: All applications must be registered in ServiceNow. 
		- **Justification**: This allows for proper application assessment and tracking.
- **Directive**: All Critical applications must undergo a resiliency test prior to “going live” in production to validate resiliency capability according to the enterprise recovery standard.  The directive of the CDT is to utilize blue green deployment practices. To become familiar with this, reference this [tutorial](https://github.nwie.net/Nationwide/AWS-PipelineFactory/blob/master/src/Git/code/add_templates/README/Linux/BlueGreen-Readme.md).  All cloud-based application layers must prove resilient prior to going live in production.  A Recovery Test Report should be completed and submitted to the IRM Continuity Management professional to receive proper test credit.   
		- **Justification**: This allows for discovery of resiliency issues and provides assurance that in the event of a disruption the application can continue to function as designed.
