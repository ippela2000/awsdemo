---
title: I&O Architecture
menu: solutions
category: architecture
draft: false
---

- [Highlevel Architecture Documentation](https://onyourside.sharepoint.com/sites/NGI/Published/ArchitectureRepository/Forms/ArchHighLevel.aspx)
- [Solution Architecture](https://onyourside.sharepoint.com/sites/NGI/Published/ArchitectureRepository/Forms/ArchSolutions.aspx)
- [Architectural Decisions](https://onyourside.sharepoint.com/sites/NGI/Published/ADRepository/Forms/AllItems.aspx)
- [Architecture Guidance](https://onyourside.sharepoint.com/sites/NGI/Published/ArchitectureRepository/Forms/ArchGuidance.aspx)
- [Architecture Standards](https://onyourside.sharepoint.com/sites/NGI/Published/ArchitectureRepository/Forms/ArchStds.aspx)
- [Misc Documentation](https://onyourside.sharepoint.com/sites/NGI/Published/ArchitectureRepository/Forms/ArchMisc.aspx)
- [Architectural Document Report](https://tab.nwie.net/t/IOPM/views/NGI-SharedFiles/DocLibrary?:embed=y&:refresh=y#1)
