---
title: Architectural Best Practices
menu: solutions
category: architecture
draft: false
weight: 3
---


## Leverage Scalability in the Cloud

>Systems that are expected to grow over time need to be built on top of a scalable architecture. Such an architecture can support growth in users, traffic, or data size with no drop in performance.  Infrastructure should not be left at the "high-water mark" at all times, and should be able to scale up or down based on the current usage of the underlying resources.  Our bias is to prefer architectures that favor Horizontal Scalability

- Associated Concepts:
  - [Scaling Horizontally](#scaling-horizontally)
  - [Scaling Vertically](#scaling-vertically)

## Think Disposable Resources Instead of Fixed servers

>In a traditional infrastructure environment, you have to work with fixed resources due to the upfront cost and lead time of introducing new hardware. This drives practices like manually logging in to servers to configure software or fix issues, hardcoding IP addresses, running tests or processing jobs sequentially etc. That old mindset needs changed to take advantage of the dynamically provisioned nature of cloud computing. We must think of servers and other components as temporary resources.

- Associated Concepts:
  - [Asynchronous Integration](#asynchronous-integration)
  - [Infrastructure as Code](#infrastructure-as-code)
  - [Immutable Infrastructure](#immutable-infrastructure)

## Keep Data Sources with Applications When Possible

>In the cloud, it is a best practice, when possible, to move the data source with the application as they migrate to the cloud - same region, same cloud provider preference. However, applications often have connections to data sources which are ultimately shared with other applications. In this case, it is often hard to insist all applications using the shared data source also move.  This is where more modern data sharing and streaming practices, api strategies, and the guidance provided in [Nationwide's Integration SOD](#link-to-be-added) & [Nationwide's API SOD](https://pages.github.nwie.net/Nationwide/Architecture-Standards/sod/sod-api.html) help mitigate this risk.

## Infrastructure is Turned Off When Not in Use

>In our traditional IT Infrastructure, we were not able to consume and bill resources through a usage based billing model, in the cloud, this efficiency becomes a new tool in our toolchest.  Since we embody an Infrastructure as Code (IaC) strategy, infrastructure can be restored by redeploying the templates which created the infrastructure, often in a matter of a few minutes.

## Resiliency over Disaster Recovery

>In a traditional IT infrastructure, you would often have to manually react to a variety of events. In the cloud, infrastructure and applications should react automatically to incidents within the environment and either degrade gracefully or recover fully.

- Read more: [Building Fault Tolerant Applications](https://d0.awsstatic.com/whitepapers/aws-building-fault-tolerant-applications.pdf)
- Read more: [AWS Cloud Best Practices](https://d1.awsstatic.com/whitepapers/AWS_Cloud_Best_Practices.pdf)

## Loose Coupling, It's Not Just for Applications. Decouple your Apps from the Infrastructure

>As application complexity increases, a desirable attribute of an IT system is that it can be broken into smaller, loosely coupled components. This means that IT systems should be designed in a way that reduces interdependencies—a change or a failure in one component should not cascade to other components.

- Associated Concepts:
  - [Loose Coupling](#loose-coupling)
  - [Service Discovery](#service-discovery)

## Think Services, Not Servers

>Developing, managing, and operating applications—especially at scale—requires a wide variety of underlying technology components. In our traditional systems, Nationwide would have to build and operate all those components, which is why our bias is to use native services found in our cloud providers over building and managing services ourselves.

## Embrace Polyglot Data Stores

>With traditional IT infrastructure, organizations were often limited to the database and storage technologies they could use. There could be constraints based on licensing costs and the ability to support diverse database engines. With cloud solutions, these constraints are great lessened by leveraging cloud native solutions. As a result, it is not uncommon for applications to run on top of a polyglot data layer choosing the right technology for each workload.

## Remove Single Points of Failure

>Production systems typically come with defined or implicit objectives in terms of uptime. A system is highly available when it can withstand the failure of an individual or multiple components (e.g. , hard disks, servers, network links etc. ). We must think about ways to automate recovery and reduce disruption at every layer of our architectures.

- Read more: [Building Fault Tolerant Applications](https://d0.awsstatic.com/whitepapers/aws-building-fault-tolerant-applications.pdf)

## The Price to Experiment is Greatly Lessened. So, Experiment First

>In our traditional delivery process, we often were charged with designing systems that we might not be to able to fully research or utilize until we purchased a license or a new physical asset. Additionally, sourcing these assets often took time, and making even an educated guess would be costly. In using cloud services, the price for experimentation is greatly lessened due to consumption based usage, leaving opportunities to quickly test-and-learn the efficacy of a new service.

## Optimize for Cost... Eventually

>Cloud Services often bring a plethora of configurations with their services.  The temptation is to optimize immediately. In some cases, _you should select_ the cheapest type that suits your workload’s requirements up front. In _other cases_, using fewer instances of a larger instance type might result in lower total cost or better performance. The real optimizations and insights come via benchmarking and then selecting the right configurations depending on how your workload utilizes CPU, RAM, network, storage size, and I/O.

- Read more: [Monitoring Your Usage and Costs](http://docs.aws.amazon.com/awsaccountbilling/latest/aboutv2/monitoring-costs.html)

## Leverage Security as Code

>Traditional security frameworks, regulations, and organizational policies define security requirements related to things such as firewall rules, network access controls, internal/external subnets, and operating system hardening. You can implement these in cloud environments as well, but with it comes the opportunity to capture them all in a script that defines a “Golden Environment.” Security best practices can now be reused among multiple projects and become part of your continuous integration pipeline. You can perform security testing as part of your release cycle, and automatically discover application gaps that drift from your security policy.

- Read More: [Security at scale: Governance in AWS](https://d0.awsstatic.com/whitepapers/compliance/AWS_Security_at_Scale_Governance_in_AWS_Whitepaper.pdf)
- Read More: [AWS Security Best Practices](https://d0.awsstatic.com/whitepapers/aws-security-best-practices.pdf)

## Let IT Assets Become Programmable Resources

>On cloud platforms, IT assets are programmable, you can apply techniques, practices, and tools from software development to make your whole infrastructure reusable, maintainable, extensible, and testable. Code that is used to build infrastructure can live with your application code in your version control repository, allowing architectures to be reused and production environments to be reliably cloned for testing.

- Read more: [AWS Cloud Best Practices](https://d1.awsstatic.com/whitepapers/AWS_Cloud_Best_Practices.pdf)

## Deployments Should Seek to be Blue / Green

>Blue/green deployment is a technique for releasing applications by shifting traffic between two identical environments running different versions of the application. Blue/green deployments can mitigate common risks associated with deploying software, such as downtime and rollback capability.

## All Things Considered, Prefer Stateless Architectures

>In practice, most applications need to maintain some kind of state information. For example, web applications need to track whether a user is signed in, or else they might present personalized content based on previous actions. An automated multi-step process will also need to track previous activity to decide what its next action should be. You can still make a portion of these architectures stateless by not storing anything in the local file system that needs to persist for more than a single request.  Applications can work to become more stateless following the guidance provided in the App & Platform SoD.

> Inevitably, there will be layers of your architecture that you won’t turn into stateless components. First, by definition, databases are stateful. (They will be covered separately in the Databases section.) In addition, many legacy applications were designed to run on a single server by relying on local compute resources. Other use cases might require client devices to maintain a connection to a specific server for prolonged periods of time. For example, real-time multiplayer gaming must offer multiple players a consistent view of the game world with very low latency. This is much simpler to achieve in a non-distributed implementation where participants are connected to the same server.

- Associated Concepts:
  - [Loose Coupling](#loose-coupling)
  - [Service Discovery](#service-discovery)
  - [Stateful Components](#stateful-components)
  - [Stateless Applications](#stateless-applications)

## In the Cloud Automate Everything

>In a traditional IT infrastructure, you would often have to manually react to a variety of events. When deploying on a cloud platform, there is increased opportunity for automation.  All path-to-product environments require Infrastructure as Code, which can improve both your system’s stability and the efficiency of your organization. It is recommended that you take the time to create this automated deployment process early in the migration process.

## Applications Must Be Able to Automate Their Configurations

>Automating your infrastructure and build is not enough to seek the full benefits of cloud. In order for an application to be truly resilient and portable, it must be able to be turned on and be fully aware of its configuration, i.e. environment and dependencies.  The guidance in the App & Platform SoD as well as [12-factor App](https://12factor.net/config) is a great way to begin.

- Associated Concepts:
  - [Service Discovery](#service-discovery)

## Monitor Everything

>Having a comprehensive monitoring strategy in place will ensure you include every detail when it comes to ensuring robust architectures for your applications. Having data-driven insights into how your environment is performing will empower you to make smart business decisions when considering tradeoffs between performance and costs. It's a requirement in the Nationwide cloud environments to make data transparent to asset owners and decisions makers around the cost and performance of cloud resources.

---

## Additional Resources

- [Nationwide Cloud SOD](https://pages.github.nwie.net/Nationwide/Architecture-Standards/sod/sod-cloud.html)
- [Nationwide App & Platform SOD](https://pages.github.nwie.net/Nationwide/Architecture-Standards/sod/sod-app-platform.html)
- [Nationwide Cloud Native Platform Reference Architecture](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-arch/ra-cnp.html)
- [AWS Cloud Best Practices](https://d1.awsstatic.com/whitepapers/AWS_Cloud_Best_Practices.pdf)
- [Serverless Multi-Tier Architectures](https://d0.awsstatic.com/whitepapers/AWS_Serverless_Multi-Tier_Archiectures.pdf)
- [AWS Architecture Center](https://aws.amazon.com/architecture)
- [AWS Well Architected Framework](http://d0.awsstatic.com/whitepapers/architecture/AWS_Well-Architected_Framework.pdf)
  - [AWS Well-Architected Framework - Cost Optimization Pillar](https://d1.awsstatic.com/whitepapers/architecture/AWS-Cost-Optimization-Pillar.pdf)
  - [AWS Well-Architected Framework - Operational Excellence Pillar](https://d1.awsstatic.com/whitepapers/architecture/AWS-Operational-Excellence-Pillar.pdf)
  - [AWS Well-Architected Framework - Performance Efficiency Pillar](https://d1.awsstatic.com/whitepapers/architecture/AWS-Performance-Efficiency-Pillar.pdf)
  - [AWS Well-Architected Framework - Reliability Pillar](https://d1.awsstatic.com/whitepapers/architecture/AWS-Reliability-Pillar.pdf)
  - [AWS Well-Architected Framework - Security Pillar](https://d1.awsstatic.com/whitepapers/architecture/AWS-Security-Pillar.pdf)
- [AWS Operational Checklist](http://media.amazonwebservices.com/AWS_Operational_Checklists.pdf)
- [AWS Whitepapers](https://aws.amazon.com/whitepapers/)
- [Infrastructure as Code](https://d1.awsstatic.com/whitepapers/DevOps/infrastructure-as-code.pdf)
- [Architecting for the Cloud](https://d1.awsstatic.com/whitepapers/AWS_Cloud_Best_Practices.pdf)
- [Building Secure AWS AMIs](https://d1.awsstatic.com/whitepapers/aws-building-ami-factory-process-using-ec2-ssm-marketplace-and-service-catalog.pdf)
- [Multiple AZ's](https://aws.amazon.com/rds/details/multi-az/)
- [EC2](https://github.com/open-guides/og-aws/blob/master/README.md)
- [Cloudwatch Alerts](https://github.com/open-guides/og-aws/blob/master/README.md)
- [GIT](https://pages.github.nwie.net/Nationwide/nw-dev-portal/content/cross-cutting/source-control/git/index.html)

---

## Definitions

### Asynchronous Integration

Asynchronous integration is another form of loose coupling between services. This model is suitable for any interaction that does not need an immediate response and where an acknowledgement that a request has been registered will suffice. It involves one component that generates events and another that consumes them. The two components do not integrate through direct point-to- point interaction but usually through an intermediate durable storage layer, i.e. a queue, a notification system, or a streaming data platform.

### Blue / Green Deployments

Blue/green deployment is a technique for releasing applications by shifting traffic between two identical environments running different versions of the application. Blue/green deployments can mitigate common risks associated with deploying software, such as downtime and rollback capability.

### Bootstrapping

When you launch any resource, you start with a default configuration.  While this does not replace proper image management practices, there are times when you must execute automated bootstrapping actions. That is, scripts that install software or copy data to bring that resource to a particular state. You can parameterize configuration details that vary between different environments (e.g., production, test, etc.) so that the same scripts can be reused without modifications.  A downside is this adds to the time needed for a newly provisioned resource to be operational.  A balance is needed between number of image permutations needing support and excessive bootstrapping.

### Golden Images

Certain resource types, especially VM IaaS services like (Azure Virtual Machines and AWS EC2), can be launched from a golden image.  A golden image is the concept of: a snapshot of a particular state of that resource. When compared to the bootstrapping approach, a golden image results in faster start times and removes dependencies to configuration services or third-party repositories. This is important in auto-scaled environments and is our "all-things-considered" preferred approach.

### Graceful Failure

Another way to increase loose coupling is to build applications in such a way that they handle component failure in a graceful manner. You can identify ways to reduce the impact to your end users and increase your ability to make progress on your offline procedures, even in the event of some component failure.  Additional Guidance on this is provided in the Cloud SoD as well as the App & Platform SoD.

### Immutable Infrastructure

Infrastructure that is never intentionally changed once provisioned. If changes are required, those changes are made to the scripts and the resources are redeployed. The application of the principles we have discussed does not have to be limited to the individual resource level. Since cloud assets are programmable, you can apply techniques, practices, and tools from software development to make your whole infrastructure reusable, maintainable, extensible, and testable.

### Infrastructure as Code

Infrastructure as Code (IaC) is the process of managing and provisioning server infrastructure (usually virtual) through machine-readable definition files or scripts rather than though physical hardware configuration or interactive configuration tools.

### Loose Coupling

As application complexity increases, a desirable attribute of an IT system is that it can be broken into smaller, loosely coupled components. This means that IT systems should be designed in a way that reduces interdependencies—a change or a failure in one component should not cascade to other components.

### Reduce Privileged Access

When you treat servers as programmable resources, you can capitalize on that for benefits in the security space as well. When you can change your servers whenever you need to you can eliminate the need for guest operating system access to production environments. If an instance experiences an issue you can automatically or manually terminate and replace it. However, before you replace instances you should collect and centrally store logs on your instances that can help you recreate issues in your development environment and deploy them as fixes through your continuous deployment process. This is particularly important in an elastic compute environment where servers are temporary. Where you don’t have access to data, consider asking for an API to the underlying data source rather than requesting direct access to data-stores.

### Right Sizing

The cloud offers a broad range of resource types and configurations to suit a plethora of use cases. For example, many cloud providers offer choices of instance types. In some cases, you should select the cheapest type that suits your workload’s requirements. In other cases, using fewer instances of a larger instance type might result in lower total cost or better performance. You should benchmark and select the right instance type depending on how your workload utilizes CPU, RAM, network, storage size, and I/O.

### Scaling Vertically

Scaling vertically takes place through an increase in the specifications of an individual resource (e.g., upgrading a server with a larger hard drive or a faster CPU). This way of scaling can eventually hit a limit and it is not always a cost efficient or highly available approach. However, it is very easy to implement and can be sufficient for many use cases especially in the short term.

### Scaling Horizontally

Scaling horizontally takes place through an increase in the number of resources (e.g., adding more hard drives to a storage array or adding more servers to support an application). This is the preferred way to build Internet-scale applications that leverage the elasticity of cloud computing.

### Serverless Architectures

Another approach that can reduce the operational complexity of running applications is that of the serverless architectures. It is possible to build both event-driven and synchronous services for mobile, web, analytics, and the Internet of Things (IoT) without managing any server infrastructure. These architectures can reduce costs because you are not paying for underutilized servers, nor are you provisioning redundant infrastructure to implement high availability.

### Service Discovery

Applications that are deployed as a set of smaller services will depend on the ability of those services to interact with each other. Because each of those services could be running across multiple compute resources there needs to be a way for each service to be addressed. For example, in a traditional infrastructure if your front end web service needed to connect with your back end web service, you could hardcode the IP address of the compute resource where this service was running. Although this approach can still work on cloud computing, if those if those services are meant to be loosely coupled, they should be able to be consumed without prior knowledge of their network topology details. Apart from hiding complexity, this also allows infrastructure details to change at any time. Loose coupling is a crucial element if you want to take advantage of the elasticity of cloud computing where new resources can be launched or terminated at any point in time. In order to achieve that you will need some way of implementing service discovery.

### Stateless Applications

When users or services interact with an application they will often perform a series of interactions that form a session. A stateless application is an application that needs no knowledge of previous interactions and stores no session information. Such an example could be an application that, given the same input, provides the same response to any end user. A stateless application can scale horizontally since any request can be serviced by any of the available compute resources (e.g., an EC2 instances or AWS Lambda functions). With no session data to be shared, you can simply add more compute resources as needed. When that capacity is no longer required, any individual resource can be safely terminated (after running tasks have been drained). Those resources do not need to be aware of the presence of their peers – all that is required is a way to distribute the workload to them.

### Stateful Components

Inevitably, there will be layers of your architecture that you won’t turn into stateless components. First, by definition, databases are stateful. (They will be covered separately in the Databases section.) In addition, many legacy applications were designed to run on a single server by relying on local compute resources. Other use cases might require client devices to maintain a connection to a specific server for prolonged periods of time. For example, real-time multiplayer gaming must offer multiple players a consistent view of the game world with very low latency. This is much simpler to achieve in a non-distributed implementation where participants are connected to the same server.

### Stateless Components

In practice, most applications need to maintain some kind of state information. For example, web applications need to track whether a user is signed in, or else they might present personalized content based on previous actions. An automated multi-step process will also need to track previous activity to decide what its next action should be. You can still make a portion of these architectures stateless by not storing anything in the local file system that needs to persist for more than a single request.

### Well-Defined Interfaces

A way to reduce interdependencies in a system is to allow the various components to interact with each other only through specific, technology-agnostic interfaces (e.g., RESTful APIs). In that way, technical implementation detail is hidden so that teams can modify the underlying implementation without affecting other components. As long as those interfaces maintain backwards compatibility, deployments of difference components are decoupled.

## Infrastructure Guiding Principles
* Be mindful that AWS security contexts do not necessarily map to Nationwide security contexts.
* Use of AWS Tags is required.
* Use Amazon Machine Image (AMI) for server builds.
* Use Elastic Load Balancer (ELB) / Application Load Balancer (ALB) for load balancing needs.
* When Internet facing application is required use AWS WAF.
* Use of Security Group(s) is required.
* Do NOT create or implement Security Groups that permit access from anywhere.
* Be specific and only provide the minimum access required to function (least privilege).
* Ingress only control is preferred.
* Use up-to-date applications and patch appropriately.
* Rip and replace methodology should be preferred.
* Whenever possible do not implement inline network protections.
* Implement security control as close to the resource as possible.
* Could include OS based agents or AWS Services.
* Session Key management is important and must be addressed appropriately.

![Infrastructure Security to Nationwide Connectivity](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/production%20account%20to%20nationwide%20connectivity.PNG)



![Infrastructure Security to Nationwide Connectivity](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/AWS%20test%20account%20nationwide%20connectivity.PNG)



![Infrastructure Security to Nationwide Connectivity](https://github.nwie.net/Nationwide/Next-Gen-Infra/blob/master/Image/Development%20account%20nationwide%20connectivity.PNG)


![Infrastructure Security to Nationwide Connectivity](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Infrastructure%20security%20to%20nationwide%20connectivity.PNG)




## Default Communication between VPCs


![Default Communication between VPCs](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Security.PNG)

## Elastic Load Balancing
The AWS version of a load balancer. This can be any load balancer. It can be in front of a web server or application server.  It automatically distributes incoming application traffic across multiple targets and multiple availability zones.

![Elastic Load Balancer](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Elastic%20Load%20Balancer.PNG)

There are three types of  Load Balancers:

### Application Load Balancer

Application Load Balancer is best suited for load balancing of HTTP and HTTPS traffic and provides advanced request routing targeted at the delivery of modern application architectures, including microservices and containers. Operating at the individual request level (Layer 7), Application Load Balancer routes traffic to targets within Amazon Virtual Private Cloud (Amazon VPC) based on the content of the request.

Application Load Balancer operates at the request level (layer 7), routing traffic to targets - EC2 instances, containers and IP addresses based on the content of the request. Ideal for advanced load balancing of HTTP and HTTPS traffic, Application Load Balancer provides advanced request routing targeted at delivery of modern application architectures, including microservices and container-based applications. Application Load Balancer simplifies and improves the security of your application, by ensuring that the latest SSL/TLS ciphers and protocols are used at all times.

### Network Load Balancer

Network Load Balancer is best suited for load balancing of TCP traffic where extreme performance is required. Operating at the connection level (Layer 4), Network Load Balancer routes traffic to targets within Amazon Virtual Private Cloud (Amazon VPC) and is capable of handling millions of requests per second while maintaining ultra-low latencies. Network Load Balancer is also optimized to handle sudden and volatile traffic patterns.

Network Load Balancer operates at the connection level (Layer 4), routing connections to targets - Amazon EC2 instances, containers and IP addresses based on IP protocol data. Ideal for load balancing of TCP traffic, Network Load Balancer is capable of handling millions of requests per second while maintaining ultra-low latencies. Network Load Balancer is optimized to handle sudden and volatile traffic patterns while using a single static IP address per Availability Zone. It is integrated with other popular AWS services such as Auto Scaling, Amazon EC2 Container Service (ECS), and Amazon CloudFormation.

### Classic Load Balancer

Classic Load Balancer provides basic load balancing across multiple Amazon EC2 instances and operates at both the request level and connection level. Classic Load Balancer is intended for applications that were built within the EC2-Classic network.

Classic Load Balancer provides basic load balancing across multiple Amazon EC2 instances and operates at both the request level and connection level. Classic Load Balancer is intended for applications that were built within the EC2-Classic network. We recommend Application Load Balancer for Layer 7 and Network Load Balancer for Layer 4 when using Virtual Private Cloud (VPC).

 **Benefits of Elastic Load Balancing **
* Highly Availability
* Secure
* Elastic
* Flexible
* Robust Monitoring and Auditing
* Hybrid Load Balancing

![Standard and Guideline for ELB](https://github.nwie.net/Nationwide/Next-Gen-Infra/blob/master/Image/ELB%20Standards%201a.PNG)

![Security ELB](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/ELB%20Standards%201b.PNG)

## What is Splunk?

Splunk is designed to forward the logs that are generated and temporarily stored by hardware and software components across the enterprise, to a central solution where it can be indexed, searched, correlated, visualized, and retained.

Why Splunk?

 It is primarily used for operational purposes, in support of processes such as problem analysis, incident management, root cause analysis, forensic analysis, and application defect analysis.

   Logs are critical for a variety of IT processes, namely problem analysis, security incident detection, forensics, legal, and regulatory compliance. Today, there are two key on-prem capabilities & tools:

![Splunk1](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Splunk%201.PNG)

  * **Log Management:** Aggregation, retention, search, analysis, and visualization of our app/infra/security logs. Part of DevOps toolchain.
     * Splunk Enterprise (standard), logs ~1,7TB daily.
  * **Security Information & Event Management(SIEM):** Analyze logs and events to detect security incidents and issues
     * IBM QRadar is the NW SIEM solution, ~80% of data ingest is identical to Splunk.

![Splunk2](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Splunk%202.PNG)

Log sources include but are not limited to:

* Application Logs: custom application logs (e.g. homegrown Java, Cobol, etc,), as well as third-party logs such as Guidewire.
* Infrastructure Logs: server, network, storage, middleware such as application server platforms and databases, and other infrastructure technologies.
* Security logs: security logs of infrastructure (e.g. operating systems) and applications, as well as proprietary security tools such as McAfee Web Gateway.
 Guiding principles include:

•Non-functional requirements (NFRs), such as retention and recoverability, are primarily driven by Nationwide's security & compliance policy. It’s recognized that cost, existing (QRadar) risk, and other factors may preclude the solution from meeting or exceeding policy. These items will be captured as technical risks for visibility and sign-off.
•The default posture for log access/visibility is that all authenticated users will have access to all logs except where restricted by security, legal, or compliance.

## IDENTITY ACCESS MANAGEMENT
* IAM affects everything. It is FOUNDATIONAL.
* PING Federation will be used for User and Non-Interactive access to AWS IAM (of the cloud).
* NWIE Authentication Services will be used to manage IAM for NWIE devices (in the cloud).
* User AWS IAM Authentication will require use of a NWIE Privileged ID and MFA.
* Non-Interactive AWS IAM Authentication will require use of a NWIE managed ID and MFA.
* AWS Role will be based on job tower requirements at this time; aggregation will occur with maturity.
* AWS Role Policy will be based on the least privilege principal for each AWS role.
* Users can have multiple AWS IAM roles but can only assume a single role at a time.
* Local AWS ID should not be created unless a federated ID is not feasible.

Graphic

![Cloud Access Level](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Cloud%20Access%20Level.PNG)

* User Access from Nationwide includes AWS Console, API/CLI.
* System Access from Nationwide includes AWS Console, API/CLI.
* CICD Access from Nationwide is API/CLI Only.
* Break Glass/Break Fix scenarios will be Full Access.
* Connectivity to Nationwide Data is access from AWS to Nationwide Data Repositories
* Nationwide Data access is dependent upon Data Classification.
* Test versus Production Data.
* Connectivity to Internet is used for accessing AWS services and select Internet-based services.
* Connectivity from the Internet provides public access to applications that reside in AWS.

[AWS Account Structure](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/Account%20Structure.png)

## AWS Simple Storage Solution (S3)

S3 is an object storage service where you can create a bucket and store objects (files) with virtually no limitation on number of objects.  Size of each object should be < 5TB.

It is paramount that data stored in an S3 bucket is protected appropriately.  Decisions such Data at Rest Encryption using AWS KMS for key management and Data in Motion.  Encryption are examples of protections that must be used with S3.

!!Below is REQUIRED for S3 Usage!!

![Security Controls S3](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/s3%20security%20controls.PNG)
![Security Controls S3](https://raw.github.nwie.net/Nationwide/Next-Gen-Infra/master/Image/S3%20diagram.PNG)

