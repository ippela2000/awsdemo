---
title: Tactical Preparation for the Cloud
menu: solutions
category: architecture
draft: false
weight: 2
---

## Preparing for The Cloud

## Section I: Overriding Principles

* Refactor the application off propriety platforms
  * **OS Platform**
    * Linux: move from RHEL to CentOS
  * **Database Platform**
    * Relational DBs [Oracle and MSSQL] - Refactor to less proprietary alternatives, if POSSIBLE
    * Take advantage of Nonrelational Database Systems where appropriate.  Such as:
      * DynamoDB
  * **Middleware Platform**
    * Proprietary Middleware platforms [IHS, WebSphere] - Refactor to alternatives such as:
      * Tomcat
      * Node.JS
      * Amazon API Gateway
* Decompose Monoliths
  * This is the practice of taking a large application and breaking it out into a network of smaller services
    * each adhering to 12 factor principles
    * each with a minimalistic set of responsibilities
* Cloud applications are best deployed as a collection of services or APIs
  * [Loosely Coupled](https://pages.github.nwie.net/Nationwide/Next-Gen-Infra/pages/arch3-BestPractices/#loose-coupling-its-not-just-for-applications-decouple-your-apps-from-the-infrastructure)
* Make security systemic within the application
  * Involve auditors up front in the design and requirements process
  * Be fully transparent with auditors around development process
  * Follow these [guidelines](https://docs.google.com/document/d/e/2PACX-1vSt_-UG47Y4RXHImzZ38IYaZ_2IWFbXA4HTXm17SL39xsL3N6c4JChYzpj52wc4QVuj4VgQkZnIoKxB/pub) to the extent possible
* All data must be classified prior to entry into the cloud

----
----

## Section II: High Level Principles

* Applications should use the highest level of abstraction that solves the business case
  * Doing a lift and shift does not fundamentally transform the application or how the application operates
* Focus on technologies that remove as much management overhead as possible because none of that provides business value
* Look for places to shed common responsibilities
  * Use hosted services for things that are not core to the value you want to deliver

----
----

## Section III: 12 Factor At Nationwide

* The cloud requires a new way of developing and deploying apps
* Use a [SOLID](https://en.wikipedia.org/wiki/SOLID_(object-oriented_design)) methodology for building in the cloud
  * Use [declarative](https://en.wikipedia.org/wiki/Comparison_of_programming_paradigms) formats for setup automation
  * Maximize portability between execution environments
  * Keep environments consistent by continuous deployment
  * Scale with few changes to tooling/architecture
* Utilize the [12 Factor App](https://12factor.net/) approach

----


* First we need to review the foundational principles of 12 Factor

  1. _Codebase_

     * One codebase tracked in version control, many deploys

  2. _Dependencies_

     * Explicitly declare and isolate dependencies

  3. _Config_

     * Store config in the environment

  4. _Backing services_

     * Treat backing services as attached resources

  5. _Build, Release, Run_

     * Strictly separate build and run stages

  6. _Processes_

     * Execute the app as one or more stateless processes

  7. _Port Binding_

     * Export services via port binding

  8. _Concurrency_

     * Scale out via the process model

  9. _Disposability_

     * Maximize robustness with fast startup and graceful shutdown

  10. _Dev/Prod Parity_

      * Keep development, staging, and production as similar as possible

  11. _Logs_

      * Treat logs as event streams

  12. _Admin Processes_

      * Run admin/management tasks as one-off processes

### Must Do "Factors"

  1. [Codebase](#codebase)
  2. [Dependencies](#dependencies)
  3. [Backing Services](#backing-services)

----

#### Codebase

* Put all application source code into source control
  * At Nationwide, the Enterprise standard is GitHub Enterprise
* There is only **ONE** codebase with many deploys
  * This means that the app is deployed to "staging" or "dev/test" using the same codebase but might be in a different state (possibly via configuration transformation during deploy)
* **Importance**: _Necessary Requirement_
* Reference: [Codebase](https://12factor.net/codebase)

#### Dependencies

* Never let your application assume dependencies [database, image processing libraries, command-line-tools, external packages/libraries, etc..] will be in place on a given machine/VM
  * The application must declare all dependencies and their correct versions
  * Ensure it by "baking" those dependencies into the software Systems
* Most languages and frameworks provide a natural method to this issue
* A developer will list all the libraries they expect to have in place and when the code is deployed a command is executed and the dependencies are downloaded.
* **Importance**: _High_
  * Without this, resiliency, scalability, and self-healing of application becomes mostly impossible and an undue burden on development teams.
* Reference: [Dependencies](https://12factor.net/dependencies)

```
Ruby Gemfile, e.g `bundle install —path=vendor/bundle`
Debian/RPM
npm install
```

#### Backing Services

* The application will talk to many "backing services" such as databases, caching services, email services, queuing services, etc. All these should be referenced by a simple endpoint.
* These "backing services" may be on different systems, different datacenters, or even managed by a SaaS company. The point is your code should not know the difference
* This allows for great flexibility, so a team member could become able to replace a local database system, such as Redis, with one serviced by Amazon and the code base does not change
* This is a case where defining application dependencies cleanly keeps the system flexible as dependencies are abstracted from the dependent systems
* **Importance**: _High_
  * Given the availability of options in binding to services, this is a common practice with little developer overhead
* Reference: [Backing Services](https://12factor.net/backing-services)

#### Config

* Configuration is anything that may vary between environments, while code is all the stuff that does not differ
* The code that talks to your database does not differ only the location [where the database is running]
* Usernames and passwords for various systems and servers also count as configuration and should **NEVER** be stored in code
    1) You do not want sensitive information like database credentials or API keys to be committed into the repository to prevent security leaks
    2) Your configuration varies per environment. For example, you might want to enable debugging on your local environment while this would be overkill on production
* All configuration code will be stored outside of the code base and read in by the code at runtime
  * Instead of hardcoding this information, rely on environment variables to handle this information
* **Importance**: _Medium_
* Reference: [Config](https://12factor.net/config)



#### Build, Release, Run

* Build: The process of turning the code into a bundled set of scripts, assets, and binaries
  * This stage is fully controlled by the developer
    * In this phase a developer tags new releases and fixes bugs
* Release: Taking the code bundle from the Build Execution Phase and preparing for execution in a target environment
  * In this stage the developer executes tests to verify and validate that the code and configurations behave as intended
* Run: This stage executes the code without any human intervention
* The idea is that the build stage does all the "heavy lifting" and developers manage that phase
* **Importance**: _High_
* Reference: [Build,Release,Run](https://12factor.net/build-release-run)

#### Processes

* Stateless applications are designed to degrade gracefully
* This means that if the application stack fails, the application itself does not become a failure
* Essentially the state of your application should be completely defined and contained in your databases and shared storage
  * Data must be stored to a stateful backing service such as a database
* **Importance**: _Medium_
  * Not only is a stateless app more robust, but it’s easier to manage, and generally incurs fewer bugs, and scales better
  * It is not likely that all applications will be able to move to a stateless posture, however it is greatly encouraged for new application design
* Reference: [Processes](https://12factor.net/processes)


#### Port Binding

* The application is completely self-contained and does not require runtime injection of a web server into the execution environment
* The application should expose any HTTP as a service and bind to that port to expose its services
* **Importance**: _Medium_
  * Most runtime frameworks provide this as part of their framework with no developer intervention
* Reference: [Port Binding](https://12factor.net/port-binding)



#### Concurrency

* Every process inside your application should be treated as a first-class citizen
  * This means that every process should be able to scale, restart, or clone itself when needed
* Think about using OS process managers such as Upstart or Nomad to manage processes and output streams
* **Importance**: _Low_
  * Do not worry about this factor too much until your application is deep into scaling considerations... think Netflix
* Reference: [Concurrency](https://12factor.net/concurrency)

#### Disposability

* When new code is deployed, the developer wants that version of code to start up right-away and be able to deal with incoming requests
* This principle is a natural outcome of _Backing Services_ and _Concurrency_
  * If the application crashes from a new deployment the application will have everything it needs waiting in a database or cache ... therefore code reloads should only be seconds
  * The SpringBoot Framework has a module called 'Actuator' which allows the application to shutdown gracefully
* **Importance**: _Medium_
* Reference: [Disposability](https://12factor.net/disposability)

#### Dev/Prod Parity

* In order to achieve continuous deployment the gap between development-test-production must be made as small as possible
  * Your development environment(s) should resemble production as close as possible
* **Importance**: _Low_
  * However, don't underestimate the value of examining the delivery pipeline as a first step.  It forces developers to look at the app with new eyes, considering releases and delivery from a different point of view.  Also, if one or more "lower" environments can be eliminated up front, refactoring the app often gets considerably easier.
* Reference: [Dev/Prod Parity](https://12factor.net/dev-prod-parity)

#### Logs

* Logging is important for debugging and checking up on the general health of applications
* Applications should not be concerned with the storage and management of these logs
* Log entries should instead be treated as an event stream that is routed to a separate service for archival and analysis
    * Examples: New Relic, Splunk and Logentries
* **Importance**: _Low_
  * This is often a relatively simple change, as its impacts are usually minor.  As such, it may be a good place to start or experiment.
* Reference: [Logs](https://12factor.net/logs)

#### Admin Processes

* One-off admin processes are long-running processes that should be run in an identical environment as the regular long-running processes of the app
* They run against the same live release, using the same codebase, configuration and database
* The SpringBoot Framework has a module called 'Actuator' which allows for remote execution of management tasks such as health, restart, shutdown, etc..
* **Importance**: _Low_
* Reference: [Admin Processes](https://12factor.net/admin-processes)
* Examples
  * Running database migrations (e.g. manage.py migrate in Django, rake db:migrate in Rails)
  * Running a console (also known as a REPL shell) to run arbitrary code or inspect the app’s models against the live database. Most languages provide a REPL by running the interpreter without any arguments (e.g. python or Perl) or in some cases have a separate command (e.g. irb for Ruby, rails console for Rails)
  * Running one-time scripts committed into the app’s repo (e.g. php scripts/fix_bad_records.php)

#### Summary

* Some of these factors may seem esoteric, as they are fully rooted in fundamental system design, however, at the heart of any system is an architecture that is robust and reliable
* The "12 Factors" are being adopted across the industry and by major software platforms and frameworks
* The "Logs" and "Dev/Prod Parity" factors provide a low-risk space to experiment and to:
  * Get a better handle on scope and approach to refactoring existing apps
  * Get developers thinking through the change in mindset

----
----

## Section IV: Tech Maturity

#### Code

|Title|Level 1|Level 2|Level 3|Level 4|Cloud Native Minimum|
|-------------|-------------|-----|-----|-----|-----|
|**Code Commenting Strategy**|**No or inconsistent** code comments that do not tend to follow any defined standards, comments cannot be used to generate documentation|**All new code** is self-documenting and comments are suitable for documentation generation tools|**Most code** is self-documenting and **existing comments** are suitable for documentation generation tools|**All code** is self-documenting and comments are consistently suitable for documentation generation tools|na|
|**Code management strategy**|Code is in SCM (e.g. git) and used for release, but there is **little to no documented or agreed strategy** of how to branch, merge, or release code|Develop on **version branches**. Every deployment can be tracked back to understand all changes which went into it by anyone in the team|Develop on **feature branches** that are short-lived (i.e. less than two weeks) and **release from merged master**|**Develop and release from master** with at least **daily code check-ins** using a process allowing traceability to the requested feature|1|
|**Test suite**|**No or some** unit tests, functional tests, critical path tests, and performance tests|**Some** unit tests, functional tests, critical path tests, performance tests **with all of them passing successfully**|Actively builds and maintains unit tests, functional tests, critical path tests, performance tests with all of them successfully passing for **positive flows**|Actively builds and maintains unit tests, functional tests, critical path tests, performance tests with all of them successfully passing for **positive and negative flows** maintaining **100% critical path coverage**|3|
|**Logging & telemetry**|**Default** or customized logging and **no telemetry**|**Rudimentary** logging and telemetry in place|**Adherence to established logging & telemetry standards** Suitable information available in logs and telemetry for **troubleshooting common issues**|Adherence to established logging & telemetry standards **Most** issues can be diagnosed through logs and telemetry|2|
|**Backward/forward compatibility**|**Breaking changes** (i.e. tested locally)|Changes are **regressed by users** of the product prior to release|Coding practices supports **forward** compatibility|Coding practices support **backward and forward** compatibility|2|
|**Monitoring & alerting**|Logs have enough data to set up monitoring and alerts on|**Some monitoring** and **some alerting** is prioritized in the work queue|**Prioritization** of monitoring and alerting as part of the **acceptance criteria for all work** Access to **log archives** and telemetry is available for troubleshooting|Prioritization of monitoring, alerting, and **validation of triggers (e.g. SLAs)** as part of the acceptance criteria for all work Logs are **indexed** and telemetry is **readily** available for troubleshooting|1|
|**Quality engineering model**|Contributors have separate roles (i.e. only code or test)|**Some** contributors can **both code and test**|**Most** contributors both code and test|**All** contributors both code and test|na|
|**Code reuse**|Contributors usually code what they need|Contributors can highlight where they have **reused open source** or code from other projects|Contributors **aim to reuse** vs rebuild while coding and **actively evangelize** to maximize code reuse by others|Contributors seek to reuse vs rebuild as part of the **planning process**, actively evangelize to maximize code reuse by others, and **actively contributes to other code**|na|
|**Build for availability**|Product is not tested for extreme failures (e.g. a node/instance becoming unavailable)|Product is **manually tested** for extreme failures and automatically tested for error use cases|**Automated resilience testing framework (e.g. Chaos Monkey)** runs rampant on the product in a **staging** environment without failures|Automated resilience testing framework (e.g. Chaos Monkey) runs rampant on the product in a **staging and production** environment without failures and **all errors (e.g. code, web server, OS, etc...) are caught and escalated**|2|
|**Incremental coding (prototyping)**|Contributors do not use prototyping to estimate or validate any features|Contributors **sometimes** use prototyping to **estimate** larger features more confidently|Contributors **often** use prototyping to **validate** features with users before completion|Contributors **always** use prototyping to validate features with users before completion|na|
|**Feedback & requirements**|Contributors start coding before requirements are fully understood|Contributors code from wireframes/design comps and **understand the requirements and business** value before building the feature|Contributors code from wireframes/design comps, and understand **how the feature interacts within the ecosystem** before building the feature|Contributors code from **clickable** wireframes / design comps that were **validated by users** and understand how the feature interacts within the ecosystem before building the feature|na|
|**Behavior driven development (bdd)**|Contributors do not have an understanding of BDD methodology|Contributors understand BDD methodology, and practice it on some features|Contributors understand BDD methodology, and practice it on **most** features|BDD methodology is **how things get done**|na|

#### Build & Test

|Title|Level 1|Level 2|Level 3|Level 4|Cloud Native Minimum|
|-------------|-------------|-----|-----|-----|-----|
|**Definition of done completeness**|Contributors do not follow any documented or agreed upon definition of "done"|Contributors **mostly follow** a defined definition of "done"|Contributors **always follow** definition of "done" as a **gate to making a release**|Contributors actively update definition of "done" to improve quality and prevent issues from reoccurring|na|
|**Code quality**|Code coverage is unknown or out of date|Code coverage is **actively tracked**|**80%+** code coverage is maintained|**90%+** code coverage is maintained or **less than 20% of build rejections by regression test coverage**|na|
|**Security code analysis**|Code has never been scanned with a web application security scanner|Code has been **previously** scanned with a security scanner|Code is **regularly scanned** with a security scanner|Code is **automatically scanned** with a security scanner and **defects are prioritized into active workload**|2|
|**Automated testing**|No defined acceptance tests|**Some** existing acceptance tests, but **little to no automation**|**Most** existing tests are automated, but **all new acceptance tests are fully automated**|**Acceptance tests are actively built and maintained** with full automation for every build|2|
|**Continuous integration**|No automated build pipeline Code is **manually compiled** and may not always compile successfully|Build pipeline **contains manual steps** but the build is never left in a failed state Some failures may be missed|Build pipeline **requires automated tests to pass** before feature is considered "complete"|Build pipeline requires automated tests to pass and **failures are actively monitored and a process for handling failures is in place**|3|
|**Performance testing & capacity planning**|The operational capacity of the production software is not clearly understood|Performance is **manually tested** during the release process using load scripts of common scenarios Contributors understand the algorithmic complexity of the software|Performance is **automatically tracked** in a **staging** environment to gauge changes in application performance Contributors **understand the optimal load** that each instance can handle, and there is a **process in place** to make release decisions based on acceptance of new SLAs Capacity provisioning and scaling up & down **requires manual steps**|Performance is automatically tracked in **both staging and production** with a full understanding of the application performance characteristics. Contributors **actively collaborate** with the business to **determine acceptance of new SLAs* based on actual production traffic and predications** created by load testing. Capacity provisioning and scaling up & down is **fully automated**|2|
|**Configuration file management**|Manual configurations|Each environment has predefined configurations|Sensitive data has been **abstracted**, and configurations are **human readable**|Sensitive data has been abstracted, and configurations are human readable All configurations are **automated** with tools that support **monitoring & alerting** with minimal environment-specific data|3|
|**Service consumer tests**|No or some tests simulating a consuming application or service|**Manual** tests are executed to simulate a consuming application or service|**Automated** tests of main use cases from a consuming application or service are **integrated** into the build pipeline|Automated tests from a consuming application or service are **triggered** by the build pipeline, and **cause the build to fail** if there are errors|2|

#### Release

|Title|Level 1|Level 2|Level 3|Level 4|Cloud Native Minimum|
|-------------|-------------|-----|-----|-----|-----|
|**Deployment strategy**|Contributors do not follow a documented or consistent deployment strategy|Contributors follow a defined deployment strategy|Contributors follow a defined deployment strategy that includes automated rollbacks, regression tests, configs, and tracking|Contributors follow a defined deployment strategy that is fully automated and includes regression tests, configs, tracking, and database releases|2|
|**Release frequency**|Releases take longer than a cycle (iteration/sprint)|1 release every cycle (sprint/iteration)|Multiple releases every cycle (sprint/iteration)|Code is released to production on every successful build|na|
|**Feature flags**|No feature flagging|Some feature flagging|Feature flags adhere to an established standard, allow for run-time based configuration, and are consistently maintained as the product evolves|Feature flags adhere to an established standard, allow for run-time based configuration, are consistently maintained as the product evolves, and different categories of feature-flags are controlled by different stakeholders|na|
|**Build pipeline traceability**|Code can be built correctly - manually or via a build pipeline|There is a build pipeline with a visual representation and contributors are automatically alerted when a build fails|Build is triggered by source control check-in or is scheduled, with alerts being sent out on failures|Build is triggered by source control check-in or a build of its dependent services, with alerts being sent out on failures, and if successful the build is pushed across environments to production|1|
|**Modular releases**|	Entire product is a single deployable unit|Some of the product is separated into different deployable units|Most of the product is separated into many deployable units|Pieces of product/service is independently deployable and the lifecycle of change for different parts of the product is well understood and taken into account for the deployment architecture|na|
|**Continuous delivery**|Manual deployment and testing are performed in staging|Manual deployment, and automatic testing are performed in staging|Automated deployment and tests are performed in staging|Automated deployment and tests are performed in production when code is checked in as "zero touch" continuous deployments|2|
|**Deployment methodology**|Able to automatically or manually deploy a new release to a single server/cluster before rolling to the next|Able to manually determine the impact of a partial (canary) deployment|Able to automatically determine the impact of a partial (canary) deployment|Zero downtime, fully automated blue-green or red-black deployments spin up and validate a canary instance in production with the ability to segment a group or percentage of traffic, switch traffic over, and shut down the previous version once successful|na|
|**Dependency management**|Dependencies are uncertain|Manual dependency management|Automatic dependency management|Contributors follow a defined strategy to regularly update dependencies to newer versions|1|
|**Push button releases**|Releases require more than one contributor to deploy|Releases require manual intervention|Code can be deployed via a push button release, but not the environment|Production-like environments can be prepared through version controlled scripts and run via push button deployments|na|
|**Scriptable db releases**|Database specialist makes schema/migrations on behalf of the contributors|Contributors create scripts to perform schema changes and migrations, but database specialist executes them|DB schema changes and migrations are made directly from version control as a manual set during release|DB schema changes and migrations are made directly from version control and consistent across all environments, including production|na|

#### Operate

|Title|Level 1|Level 2|Level 3|Level 4|Cloud Native Minimum|
|-------------|-------------|-----|-----|-----|-----|
|**Devops practice**|Environments in production and staging are not controlled by contributors building the product|Environments in staging are controlled and partially managed by the contributors building the product and receive issues escalations for that environment|Environments in production are owned by the contributors building the product, but controlled by someone else. Staging is fully owned and controlled.|DevOps model is followed - environments in production and staging are fully controlled and owned by the contributors building the product, including alerts and issue escalations|na|
|**Runbook adoption**|No triage runbook has been created|Contributors have created a triage runbook, but is it not actively used|Contributors have created a triage runbook, and it is integrated into the alerting infrastructure for easy reference|Contributors have created a useful triage runbook that is actively maintained and integrated into the alerting infrastructure for easy reference|na|
|**Monitoring & alerting**|SLAs havn't been defined or if SLAs are monitored and alerts are set up, they mostly just encompass the standard cases|SLAs are monitored and some alerts are sent when thresholds are not met, healthchecks are monitored, and alerts are configured for many standard error conditions|SLAs in staging and production are consistently being met and alerted on when thresholds are not met, and healthchecks are monitored Alerts are configured for a majority of error conditions|SLAs in staging and production are consistently being met, and a business disruption alert is escalated when thresholds are not met or a healthcheck fails Non-standard HTTP responses trigger an alert Alerts are triggered for main use cases when expected results are not met (i.e. lower than normal conversion rate)|2|
|**On-call strategy**|Others know how to escalate to the team|Contributors follow a defined on-call strategy|On-call strategy is efficient as evidenced by consistently low MTTD and MTTR but sometimes requires more than one party to resolve|Contributor who is on-call is usually the resolver for all issues within their product as evidenced by a consistently low MTTD and MTTR|2|
|**Risk management**|Contributors do not fully own risk management or mitigation of the product. Disaster recovery is normally defined and/or managed by someone else who has full ownership|Contributors think about disaster recovery plans while the code is built and released, but requires the involvement from many other parties|There is an established disaster recovery plan (DRP) and business continuity program (BCP)|There is an established disaster recovery plan (DRP) and business continuity program (BCP) which has been tested within the past 6 months|2|
|**Synthetic monitoring**|No synthetic monitoring is in place|Synthetic monitoring is used in staging and production with some alerting|Synthetic monitoring is used in staging and production for major use cases, with escalation alerts for failures|Synthetic monitoring is used in staging and production for both positive and negative use cases, with escalation alerts for failures|2|
|**Log management strategy**|All logs, all the time!|Log rotation is based off a default template|Log rotation takes into account available disk space Logs are archived for retention|There is an effectively defined log rotation strategy including timing of business activities like periods of high demand Logs are retained according to business and legal requirements|2|
|**Business dashboard**|Some business metrics are tracked in a dashboard, and / or some metrics are still mined manually, but these may not be visible or accessible to all contributors|Business metrics are tracked in a dashboard that illustrates product performance, and is constantly referenced by others to quantify how the product performs All contributors have access and regular consistent visibility of the dashboard|Business metrics are tracked in a dashboard that illustrates product performance, is constantly referenced by others to quantify how the product performs, and used to measure the success of new feature rollouts The dashboard is clearly visible at all times to all contributors|Business metrics are tracked in a dashboard that illustrates product performance, is constantly referenced by others to quantify how the product performs, and used to measure the success of new feature rollouts Main use cases trigger alerts to stakeholders when business metrics do not match expected values (e.g. lower than expected conversion rates)|na|
|**Vulnerability  management**|Application team addresses library vulnerabilities when notified|Active vulnerability scanning of libraries in place and remediated by the team|Regular scanning of libraries and infrastructure components in place and the team managed within a defined SLA|Active scanning of all components with a roll forward strategy|na|

#### Optimize

|Title|Level 1|Level 2|Level 3|Level 4|Cloud Native Minimum|
|-------------|-------------|-----|-----|-----|-----|
|**Continuous process improvement**|Few processes are defined and contributors rely on tribal knowledge to succeed|Processes are documented and can be repeated by any contributor|Contributors simplify / automate processes whenever possible and documentation is maintained by as they evolve|Contributors are actively focused on continuous process improvement by identifying and enhancing processes; performance is predictable, and quality is consistently high|na|
|**Tech debt management**|Contributors do not track debt in any consistent way|Contributors can track debt via a defined process|Contributors avoid taking on any new debt by actively tracking and managing it|Contributors actively prioritize and reduce all debt|na|
|**Root cause prevention**|Production issues happen and sometimes it's known why, but it is mostly difficult to find the underlying cause|Contributors follow a defined process for determining the root cause of issues|Contributors follow a defined and accepted process for determining the root cause of issues, and major issues are prioritized and corrected|Contributors follow a defined and accepted process for root cause analysis which includes consistently preventing future issues by: 1) putting the issue into the work queue 2) prioritizing and correcting the issue, and 3) adding monitoring / alerting to detect such issues|2|
|**Data-driven metrics**|It takes a lot of time to gather metrics and sometimes it's too late to get the data after the fact|Metrics can be pulled after an issue happens to determine why|Metrics illustrate the product health, and action (e.g. product decisions) is taken based on the metrics|Metrics illustrate the product health, predictive rules create alerts, and action (e.g. product decisions) is taken based on the metrics|na|

#### Readiness

|Title|Level 1|Level 2|Level 3|Level 4|Cloud Native Minimum|
|-------------|-------------|-----|-----|-----|-----|
|**Cloud knowledge & experience**|Little team member experience in cloud services, few to none certifications, no production experience|Team trained, basic certifications, no experience yet|Abundant and advanced certifications, experience in lower environments|Well experienced and currently managing other applications in the cloud with a track record of success|na|
|**Migration commitment**|No dedicated team members or only a single role represented, business partners unaware or unconvinced of the benefits|Small cross functional team aligned|A cross functional team is dedicated|A cross functional team including business partners, developers, testers, and architecture is dedicated|3|

----
----

## Section V: Associated Github Issues

#### Issues

* [Issue 971](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/971) [Storyboard - Prepare Applications for The Cloud]
* [Issue 903](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/903) [Prepare Applications For The Cloud Document]


----
----

### Contributions

* Craig Chakford
* Tyler Napierkowski
* Matthew Keck
* Michael Frayer
* Matthew Haines
* Drake Pocsatko
