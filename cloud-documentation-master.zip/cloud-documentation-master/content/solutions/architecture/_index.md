---
title: Architecture
description: "This section has all the Architectural documentation to accelerate your cloud journey"
menu: solutions
category: architecture
---

## Architectural Statement

* Architecture would not decide which products are valuable to you or your business. 
* As such, we want to keep product offerings as open as possible and would actively seek to not limit or describe individual products an end-user might want to use.
* The individual ability of a product to be leveraged in our environments, may however, be limited based on the maturity of foundational capabilities, i.e. data protection. 
* Since we don't wish to limit users choices, we also cannot protect users from making what some might view as a poor configuration choice or an expensive solution as we don't want to denote intent. 
* As a result, individual self-service offerings might choose to implement limitations around products, cost and availability, based on the consumers of those systems only.
* However, this logic should only be enforced in that individual self-service option and not in all options. 
* Foundational controls may exist within the orchestration layers, in a given infrastructure disposition, to prevent conflicts with existing foundational infrastructure or violates necessary security constructs.

## Self Service Options
* Cloud Service Provider GUI Portal (Sandbox(s) only)
* API / Service Interface (e.g. Cloud Formations, Azure Automations, etc.) (All Environments)
* CLI (All Environments) (Sandbox(s) only for user identity, service accounts for path-to-prod environments)
* CI/CD Pipeline (All Environments)
* SDK (e.g. Azure PowerShell, AWS PowerShell SDK) (Sandbox(s) only for user identity, service accounts for path-to-prod environments)
* Enterprise Portal (Product: ServiceNow) (All Environments)
* Specialized Portal (e.g. Nitro) (Limited, to specific infrastructure dispositions)

## Personas
* Devoloper
* I&O Associate
* Admin Support

## Infrastructure Dispositions Available
* Innovation Sandbox
* Sandbox
* Non-Prod
* Prod

## Questions
### Who you are?
* Architectural stance listed in the Personas section

### What can you provision?
* Architectural stance listed in the Statement section

### Who approves what you can provision?
* Architecture has no formal stance on who should approve the provisioning of infrastructure outside of existing processes and mechanisms

### Where should the bill go?
* Architectural stance is bill should go to the appropriate person

### Architectural Contributions
* Matthew Keck
* Michael Smolak
* Danny Baker
* Scott Matelski
* Matthew Haines

[Next - Architectural Statements of Direction](/solutions/architecture/arch-statementofdirection)
