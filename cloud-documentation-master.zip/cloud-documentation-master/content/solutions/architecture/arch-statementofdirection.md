---
title: Architectural Statements of Direction
menu: solutions
category: architecture
draft: false
weight: 1
---

## Cloud Statement of Direction:
* [Cloud Statement of Direction](https://pages.github.nwie.net/Nationwide/Architecture-Standards/sod/sod-cloud.html)

## Application and Platform Statement of Direction:
* [Application and Platform Statement of Direction](https://pages.github.nwie.net/Nationwide/Architecture-Standards/sod/sod-app-platform.html)
* [Oracle to Postgres Statement of Direction](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-specs/oracle-postgresql.html)

## Architecture Reference Specifications
* [Data Movement Guide](https://pages.github.nwie.net/Nationwide/Architecture-Standards/ref-specs/data-movement-guide.html)

