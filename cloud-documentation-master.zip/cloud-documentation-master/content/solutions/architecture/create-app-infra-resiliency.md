---
title: Creating Application Infrastructure Resiliency
permalink: /docs/aws-docs/create-app-infra-resiliency/
---

**IT RESILIENCY REQUIREMENTS BY ENVIRONMENT**

Environment resiliency is the capacity of an IT environment to continue the availability of resources to hosted objects during environment infrastructure component outages.   **Environment** resiliency is a component of **application** resiliency.  Application resiliency is the capacity of an application to perform built-in action(s) and remain functional when one or more of the application&#39;s components fail. [You can review further detail for resiliency requirements for various AWS services here.](https://onyourside.sharepoint.com/sites/YouaretheFirstLineofDefense/Shared%20Documents/Forms/AllItems.aspx?id=%2Fsites%2FYouaretheFirstLineofDefense%2FShared%20Documents%2FCM%20Cloud%20Resiliency%20Matrix%5FApril%202020%2Epdf&parent=%2Fsites%2FYouaretheFirstLineofDefense%2FShared%20Documents)

The following can be used as a checklist to configure robust application and/or infrastructure resiliency.  These requirements apply to an application deploying to a **single Cloud Service Provider\* (CSP)**, **multiple CSPs\*** , **Nitro\*\*** , or **on-prem environment\*\*\*** :

- Deployed in a minimum of 2 physical and/or virtual sites
    - Examples:
      - primary/secondary site setup
      - load-balanced across sites
      - Data Center East and CSP

- Connectivity from secondary site back to primary site for any layer in a secondary site
  - Example:  database failover must be able to connect back to the web/app layers
- Automated, automatic failover from all production app layers to a secondary alternate physical/virtual site
  - Example:  the entire application must be capable of seamless failover
- Connectivity between all layers in secondary sites (recovery)
  - Example:  web/app and data layers failed to the recovery site must be able to connect to each other
- Connectivity from all layers failed to a secondary site to external dependencies
  - Example:  database failed over must be able to connect to other databases wherever they are located
- Capability to circumvent missing dependencies and to tolerate errors when detected
- Point-in-time data layer replication/backup
- Primary and secondary connectivity to 3rd party vendor
- Code that builds the infrastructure is stored in a resilient manner that meets the application&#39;s availability requirements

**NOTE:**  The use of cloud services in lieu of on-premise infrastructure carries the same resiliency requirements that apply to on-premise infrastructure

**\*** A Cloud Service Provider offers network services, infrastructure, or business applications in the cloud. The cloud services are hosted in a data center that can be accessed by companies or individuals using network connectivity.  A single cloud service provider is an individual cloud vendor, such as AWS or Azure.   An application deploying to multiple cloud service providers would need to ensure connectivity between them.  For example, an application could deploy to both AWS and Azure, and would need connectivity to each cloud zone

**\*\*** Nitro is the Nationwide on-premise cloud service

**\*\*\*** On-premise environment covers any Nationwide data center
