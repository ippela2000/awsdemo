---
title: Serverless Architecture
menu: solutions
category: architecture
draft: false
weight: 4
---

# Unofficial Communication -- Conceptual

## AWS Serverless Platform

#### Compute

* AWS Lambda lets you run code without provisioning or managing servers
* You pay only for the compute time you consume - there is no charge when your code is not running
* Just upload your code and Lambda takes care of everything required to run and scale your code with high availability
* Lambdas are stateless, meaning the whole concept of writing server-side code needs to be learned all over again

#### API Proxy

* Amazon API Gateway is a fully managed service that makes it easy for developers to create, publish, maintain, monitor, and secure APIs at any scale
* Amazon API Gateway allows you to process hundreds of thousands of concurrent API calls and handles traffic management, authorization and access control, monitoring, and API version management

#### Storage

* Amazon Simple Storage Service (Amazon S3), provides developers and IT teams with secure, durable, highly-scalable object storage
* Amazon S3 is easy to use, with a simple web service interface to store and retrieve any amount of data from anywhere on the web

#### Data Stores

* Amazon DynamoDB is a fast and flexible NoSQL database service for all applications that need consistent, single-digit millisecond latency at any scale
* It is a fully managed cloud database and supports both document and key-value store models

#### Interprocess Messaging

* Amazon SNS is a fully managed pub/sub messaging service that makes it easy to decouple and scale microservices, distributed systems, and serverless applications
* Amazon SQS is a fully managed message queuing service that makes it easy to decouple and scale microservices, distributed systems, and serverless applications

#### Orchestration

* AWS Step Functions makes it easy to coordinate the components of distributed applications and microservices using visual workflows
* Building applications from individual components that each perform a discrete function lets you scale and change applications quickly
* Step Functions is a reliable way to coordinate components and step through the functions of your application

#### Analytics

* Amazon Kinesis is a platform for streaming data on AWS, offering powerful services to make it easy to load and analyze streaming data, and also providing the ability for you to build custom streaming data applications for specialized needs
* Amazon Athena is an interactive query service that makes it easy to analyze data in Amazon S3 using standard SQL. Athena is serverless, so there is no infrastructure to manage, and you pay only for the queries that you run

### Serverless Concepts
* Serverless is conceived as always up because organizations or departments do not really have to manage anything.
  * There is no need to worry about 'up-time'
  * It scales automatically ... check best practices

# Blueprints

<details><summary>Type 1: RESTful Microservices</summary><p>

<h2 id="type1restfulmicroservices">Type 1: RESTful Microservices</h2>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want a secure, easy-to-operate framework that is simple to replicate and has high levels of resiliency and availability</li>

<li>You want to log utilization and access patterns to continually improve your backend to support customer usage</li>

<li>You are seeking to leverage managed services as much as possible for your platforms, which reduces the heavy lifting associated with managing common platforms including security and scalability</li>
</ul>

<h3 id="designconceptsofmicroservices">Design Concepts of Microservices</h3>

<ul>
<li>Multiple components</li>

<li>Built for business needs</li>

<li>Has simple routing</li>

<li>Is decentralized</li>

<li>Fault tolerant</li>

<li>Evolutionary</li>
</ul>

<h3 id="blueprintforrestfulmicroservices">Blueprint for RESTful microservices</h3>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T1.PNG" alt="RESTful microservices" /></p>

<ul>
<li>(1) Customers: leverage your microservices by making API (that is, HTTP) calls. Ideally, your consumers should have a tightly bound service contract to your API in order to achieve consistent expectations of service levels and change control</li>

<li>(2) API Gateway: hosts RESTful HTTP requests and responses to customers. In this scenario, API Gateway provides built-in authorization, throttling, security, fault tolerance, request/response mapping, and performance optimizations</li>

<li>(3) Lambda: contains the business logic to process incoming API calls and leverage DynamoDB as a persistent storage</li>

<li>(4) DynamoDB: persistently stores microservices data and scales based on demand. Since microservices are often designed to do one thing really well, a schemaless NoSQL data store is regularly incorporated</li>
</ul>

<h3 id="configurationnotes">Configuration Notes</h3>

<p>Leverage API Gateway logging to understand visibility of microservices consumer access behaviors. This information is visible in Amazon CloudWatch Logs and can be quickly viewed through Log Pivots or fed into other searchable engines such as Amazon ES or Amazon S3 (with Amazon Athena). The information delivered gives key visibility, such as:</p>

<ul>
<li>Understanding common customer locations, which may change geographically based on the proximity of your backend</li>

<li>Understanding how customer input requests may have an impact on how you partition your database</li>

<li>Understanding the semantics of abnormal behavior, which can be a security flag</li>

<li>Understanding errors, latency, and cache hits/misses to optimize configuration</li>
</ul>
</p></details>

<details><summary>Type 2: Stream Processing</summary><p>

<h2 id="type2streamprocessing">Type 2: Stream Processing</h2>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want to create a complete serverless architecture without managing any instance or server for processing streaming data</li>

<li>You want to use the Kinesis Producer Library (KPL) to take care of data ingestion from a data producer-perspective</li>
</ul>

<h3 id="blueprintforstreamprocessing">Blueprint for stream processing</h3>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T2.PNG" alt="Stream Processing" /></p>

<ul>
<li>(1) Data producers: use the Amazon Kinesis Producer Library (KPL) to send social media streaming data to a Kinesis stream. Amazon Kinesis Agent and custom data producers that leverage the Kinesis API can also be used</li>

<li>(2) Kinesis: stream collects, processes, and analyzes real-time streaming data produced by data producers. Data ingested into the stream can be processed by a consumer, which, in this case, is Lambda</li>

<li>(3) Lambda: acts as a consumer of the stream that receives an array of the ingested data as a single event/invocation. Further processing is carried out by the Lambda function. The transformed data is then stored in a persistent storage, which, in this case, is DynamoDB</li>

<li>(4) DynamoDB: provides a fast and flexible NoSQL database service including triggers that can integrate with AWS Lambda to make such data available elsewhere</li>

<li>(5) Business users: leverage a reporting interface on top of DynamoDB to gather insights out of social media trend data</li>
</ul>

<h3 id="configurationnotes">Configuration notes</h3>

<ul>
<li>Follow best practices when re-sharding Kinesis streams in order to accommodate a higher ingestion rate. Concurrency for stream processing is dictated by the number of shards. Therefore, adjust it according to your throughput requirements</li>

<li>Consider reviewing the Streaming Data Solutions whitepaper for batch processing, analytics on streams, and other useful patterns</li>

<li>When not using KPL, make certain to take into account partial failures for non-atomic operations such as PutRecords since the Kinesis API returns both successfully and unsuccessfully processed records upon ingestion time</li>

<li>Duplicated records may occur, and you must leverage both retries and idempotency within your application – both consumers and producers</li>

<li>Consider using Kinesis Firehose over Lambda when ingested data needs to be continuously loaded into Amazon S3, Amazon Redshift, or Amazon ES</li>

<li>Consider using Kinesis Analytics over Lambda when standard SQL could be used to query streaming data, and load only its results into Amazon S3, Amazon Redshift, Amazon ES, or Kinesis Streams</li>

<li>Follow best practices for AWS Lambda stream-based invocation since that covers the effects on batch size, concurrency per shard, and monitoring stream processing in more detail</li>
</ul>

</p></details>

<details><summary>Type 3: Web Application</summary><p>

<h2 id="type3webapplication">Type 3: Web Application</h2>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want a scalable web application that can go global in minutes with high levels of resiliency and availability.</li>

<li>You want a consistent user experience with adequate response times.</li>

<li>You are seeking to leverage managed services as much as possible for your platforms in order to limit the heavy lifting associated with managing common platforms.</li>

<li>You want to optimize your costs based upon actual user demand versus paying for idle resources.</li>

<li>You want to create a framework that is easy to set up and operate, and that you can extend with limited impact later.</li>
</ul>

<h3 id="blueprintforwebapplication">Blueprint for web application</h3>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T3.PNG" alt="Web Application" /></p>

<ul>
<li>(1) Consumers: of this web application may be geographically concentrated or worldwide. Leveraging Amazon CloudFront not only provides a better performance experience for these consumers through caching and optimal origin routing, but limits redundant calls to your backend</li>

<li>(2) S3: hosts web application static assets and is securely served through CloudFront.</li>

<li>(3) Cognito: user pool provides user management and identity provider feature for your web application</li>

<li>(4) As static content served by Amazon S3 is downloaded by the consumer, in many scenarios, dynamic content needs to be sent to or received by your application. For example, when a user submits data through a form, Amazon API Gateway serves as the secure endpoint to make these calls and return responses displayed through your web application</li>

<li>(5) Lambda: function provides Create, Read, Update, Delete (CRUD) operations on top of DynamoDB for your web application</li>

<li>(6) DynamoDB: can provide the backend NoSQL data store to elastically scale with the traffic of your web application</li>
</ul>
</p></details>

<details><summary>Type 4: Mobile backend</summary><p>

<h2 id="type4mobilebackend">Type 4: Mobile Backend</h2>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want to create a complete serverless architecture without managing any instance and/or server</li>

<li>You want your business logic to be decoupled from your mobile application as much as possible</li>

<li>You are looking to provide business functionalities as an API to optimize development across multiple platforms</li>
</ul>

<h3 id="blueprintforamobilebackend">Blueprint for a mobile backend</h3>

<ul>
<li>Here is a scenario for a common mobile backend, which does not take into consideration real-time/streaming use cases</li>
</ul>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T4.PNG" alt="Mobile Backend" /></p>

<ul>
<li>(1)  Mobile users: interact with the mobile application backend by performing API calls against API Gateway and AWS service APIs (for example, Amazon S3 and Amazon Cognito).</li>

<li>(2)  API Gateway: hosts RESTful HTTP requests and responses to mobile users. In this scenario, API Gateway provides the exact same feature set as described in the RESTful microservices scenario.</li>

<li>(3)  Amazon Cognito: is used for user management and as an identity provider for your mobile application. Additionally, it allows mobile users to leverage existing social identities such as Facebook, Twitter, Google+,Amazon to sign in.</li>

<li>(4)  API Gateway Cache: is used to avoid unnecessary Lambda executions by caching the content or previous calls within the service and delivering it at a higher performance rate.</li>

<li>(5)  A Lambda: function manages both POST and GET requests to either retrieve or update the data store.</li>

<li>(6)  A Lambda: function handles search and queries to Amazon ES. These requests map with specific API methods and resources from the API Gateway.</li>

<li>(7)  A Lambda: function implements the business logic of deciding when to send push notifications to the end user.</li>

<li>(8)  Amazon SNS: delivers push notifications requested by the previous Lambda function.</li>

<li>(9)  DAX DynamoDB Cache: provides in-memory acceleration for DynamoDB tables, and it significantly improves the overall performance of this application including the heavy lifting of cache invalidation and cluster management.</li>

<li>(10) DynamoDB: provides persistent storage for your mobile application, including mechanisms to expire unwanted data from inactive mobile users through a Time To Live (TTL) feature.</li>

<li>(11) DynamoDB Streams: captures item-level changes and enables a Lambda function to update additional data sources.</li>

<li>(12) A Lambda: function acts as a consumer of DynamoDB Streams to update Amazon ES indexes allowing for analytics and additional richer queries such as full-text search for our mobile users.</li>

<li>(13) Amazon ES: acts as a main search engine for your mobile application as well as analytics.</li>

<li>(14) CloudFront: provides a CDN that serves content faster to geographically-distributed mobile users and includes security mechanisms to static assets in Amazon S3.</li>

<li>(15) Amazon S3: stores mobile application static assets including certain mobile user data</li>
</ul>

<h3 id="configurationnotes">Configuration notes</h3>

<ul>
<li>Validate request payloads by using the API Gateway request validation feature. Secure coding best practices such as input validation/sanitization still apply within your serverless application. OWASP documentation is a great starting point.</li>

<li>Performance test your Lambda functions with different memory and timeout settings to ensure that you’re using the most appropriate resources for the job</li>

<li>Follow best practices when creating your DynamoDB tables. Make certain to calculate your read/write capacity and table partitioning to ensure reasonable response times</li>

<li>Follow best practices when managing Amazon ES Domains. Additionally, Amazon ES provides an extensive guide7 on designing concerning sharding and access patterns that also apply here</li>

<li>Reduce unnecessary Lambda function invocations by leveraging caching when possible at the API level</li>

<li>Leverage DAX for caching to significantly increase response times and reduce the number of calls to your DynamoDB table</li>

<li>For low-latency requirements where near-to-none business logic is required, Amazon Cognito Federated Identity can provide scoped credentials so that your mobile application can talk directly to an AWS service, for example, when uploading a user’s profile picture, retrieve metadata files from Amazon S3 scoped to a user, etc</li>
</ul>

</p></details>


<details><summary>Type 5: Serverless Alerting</summary><p>

<h2 id="type5serverlessalerting">Type 5: Serverless Alerting</h2>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want to create a complete serverless architecture without managing any instance and/or server</li>

<li>You want your alerting logic to be decoupled from the application platform and infrastructure as much as possible</li>

<li>You want a consistent user experience with adequate response times for alerts</li>

<li>You are seeking to leverage managed services as much as possible for your platforms in order to limit the heavy lifting associated with managing common platforms</li>
</ul>

<h3 id="blueprintsforserverlessalerting">Blueprints for serverless alerting</h3>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T5.PNG" alt="Serverless Alerting" /></p>

<ul>
<li>(1) A Cloudwatch metric: represents a time-ordered set of data points that are published to Cloudwatch. Think of a metric as a variable to monitor, and the data points represent the values of that variable over time</li>

<li>(2) A Cloudwatch alarm: is triggered by a Cloudwatch metric moving outside of the desired state for that metric</li>

<li>(3) The SNS topic: receives the Cloudwatch alarm data</li>

<li>(4) A Lambda: function is triggered by the SNS topic </li>

<li>(5) The Lambda function processes the alert data from the SNS topic and pushes data to:


<ul>
<li>an email</li>

<li>a mobile SMS</li>

<li>a persistent chat platform</li>

<li>a SNS topic, for further downstream consumption</li></ul>
</li>

<li>(6) A ticket system, ServiceNow for example, watches a given SNS topic and subscribes to a topic</li>
</ul>
</p></details>


<details><summary>Type 6: Serverless Chatbot</summary><p>

<h2 id="type6serverlesschatbot">Type 6: Serverless Chatbot</h2>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want to create a complete serverless architecture without managing any instances and/or servers</li>

<li>You are seeking to leverage managed services as much as possible for your platforms in order to limit the heavy lifting associated with managing common platforms</li>

<li>You want a secure, easy-to-operate framework that is simple to replicate and has high levels of resiliency and availability</li>
</ul>

<h3 id="blueprintsforserverlesschatbot">Blueprints for serverless chatbot</h3>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T6.PNG" alt="Serverless Chatbot" /></p>

<ul>
<li>(1) A user posts a message containing an image to a chat app channel that is monitored by a chatbot</li>

<li>(2) The chat app posts the event to the API Gateway API for the chatbot</li>

<li>(3) The chatbot validates the event. The event triggers a Lambda function that downloads the image</li>

<li>(4) Amazon Rekognition's image recognition feature checks the images for suggestive or explicit content</li>

<li>(5) The chat app API deletes any image containing explicit or suggestive content from the chat channel</li>

<li>(6) The chatbot uses the chat app API to post a message to the chat channel detailing the deletion of the image</li>
</ul>
</p></details>


<details><summary>Type 7: IoT Backend</summary><p>

<h2 id="type7iotbackend">Type 7: IoT Backend</h2>

<h3>This blueprint is highly conceptual and subject to change</h3>

<h3 id="characteristics">Characteristics</h3>

<ul>
<li>You want to create a complete serverless architecture without managing any instances and/or servers</li>

<li>You want a cost-efficient application for processing IoT data</li>

<li>You require massive scaling</li>
</ul>

<h3 id="blueprintsforiotbackend">Blueprints for IoT Backend</h3>

<p><img src="https://github.nwie.net/Nationwide/Next-Gen-Infra/raw/master/Architecture/Documents/images/T7.PNG" alt="IoT Backend" /></p>

<ul>
<li>(1) Devices send events with data to Amazon Kinesis, which provides large scale durable storage of the events for 24 hours and allows multiple AWS Lambda functions to process the same events</li>

<li>(2) In AWS Lambda, Lambda Function 1 processes the incoming events and stores the event data in a table in Amazon DynamoDB for low-latency access. DynamoDB allows the needed capacity of the table to be provisioned just by changing a configuration value. The Lambda function also sends the values to AWS CloudWatch for simple monitoring of aggregate metrics</li>

<li>(3) Lambda Function 2 processes the same events as Function 1 but stores the incoming events in Amazon S3 for cost effective long-term durable archival. Storing data in S3 makes it easily accessible for analytics processing with Amazon Elastic MapReduce (Amazon EMR) and Amazon Redshift</li>

<li>(4) Lambda Function 3 provides a synchronous interface that devices call directly to retrieve data from DynamoDB. This can, for instance, be used to retrieve configuration information or historical event data that the devices need</li>

<li>(5) To lower cost, event data stored in Amazon S3 that is no longer needed online is automatically migrated to Amazon Glacier or deleted after a certain retention period using S3 object lifecycle management</li>

<li>(6) Amazon EMR runs jobs that read and write directly to DynamoDB and S3 to analyze the data, generate aggregates, and create billing reports from the large set of events gathered from the device. Event data from S3 is loaded into Amazon Redshift to allow interactive exploration and analysis of the data using standard SQL queries</li>
</ul>
</p></details>
