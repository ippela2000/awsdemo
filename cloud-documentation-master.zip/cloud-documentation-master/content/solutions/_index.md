---
title: "Solutions"
description: "Here there are resources to help you start and accelerate your cloud migration, architectural statement of direction and patterns for new cloud development."
menu: main
category: cloud
weight: 3
---

Browse the different section under [Architecture](/solutions/architecture), [DataMovement](/solutions/data-movement/), [Application Migration](/docs/general/), [Security](/solutions/security/) for more details.

