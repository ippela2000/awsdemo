---
title: Application Migration
menu: solutions
category: migration
---


### This page provides a list of everything needed before you start to migrate your application to the cloud

1. Before you start your Application migration look at the [Cloud-accelerators](/solutions/migration/cloud-accelerators) to check if there are any existing patterrns that can help accelerate you cloud journey

2. Next review the [Self-Service Diagnostic page](/solutions/migration/self-service-diagnostics/). You will need the following to use this page
   - Your Application's Cloud Architecture
   - Operational Plans
   - Estimate of the effort to migrate to the cloud

3. Make sure your BSA's account stack is stood up in AWS. If not, you can [open a request](https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/new?template=new_account_stack.md) in the Next-Gen-Infra repo.
      * To complete this form, have:
          * BSA Disbursement code
          * BSA Resource owner name
          * BSA unit name
      * You can find the list of default disbursement codes on the [Cloud Optimization Team Sharepoint](https://onyourside.sharepoint.com/sites/CloudOptimizationServiceTeam)
      * The [AWS account page](/docs/aws/getting-started-with-aws/aws-account-numbers) has the list of current BSA stacks

4. Have **[access](/docs/aws/getting-started-with-aws/getting-secondary-id/)** to Nationwide's AWS accounts.
      * **Be sure you are using region US-East-1 (N. Virginia) or you will experience permissions issues.**
      * **EC2 instances MUST be of size medium or above or you will experience permissions issues**

5. **[Create](https://help.github.com/articles/creating-a-new-repository/)** a **[GitHub](https://github.nwie.net)** repository for your application.

6. Before you can start migrating you application to the cloud you should be comfortable with self-service infrastructure provisioning. 
You should also have a good understanding of the services you will be using and how to deploy and migrate application in the Cloud. Look through the learning section to get familiar with the services you will be using.   

7. Take ownership of your application's infrastructure.
   - Identifying connections up-front will help with getting the required approvals
     - Outbound [things my application reaches out to on the internet]
     - Inbound  [connections coming in from the internet]
   - Working with an individual from Cloud Solutions on the [Data Checklist](/solutions/data-movement/)

8. Register your application in **[ServiceNow](https://nwproduction.service-now.com/nav_to.do?uri=%2Fu_enterprise_applications_list.do%3Fsysparm_userpref_module%3D50399bb2db608890a6225d104b961938%26sysparm_query%3Du_status!%3DDeleted%5EEQ%26sysparm_clear_stack%3Dtrue)** for new app.

9. It is **your** responsibility to understand what data you are migrating into your non-production environments (i.e. dev and test). [Sensitive data](https://onyourside.sharepoint.com/:w:/r/sites/IRM/_layouts/15/Doc.aspx?sourcedoc=%7B4EACEB7D-E1E8-4C7D-8B2D-D9F08E24750B%7D&file=Protect%20Sensitive%20Data%20in%20Non-Production%20Environments%20(Distributed%20Database)%20-%20Knowledge%20Sheet.docx&action=default&mobileredirect=true&DefaultItemOpen=1) is not allowed in the lower environments. If you are unsure if there is sensitive data in the data set you wish to migrate, contact IRM to have your data scanned. You can also reference the [Nationwide's Guidelines for Static Data Masking](https://onyourside.sharepoint.com/:b:/r/sites/IRM/SecurityStandardsPortal/IT%20Security%20Guidance/Nationwide%20Guidelines%20for%20Static%20Data%20Masking.pdf?csf=1&e=LYss1E) document.  It is a list of data types that IRM will be identifying during the scan. Submit a [request](/solutions/data-movement/howto-sensitve-data-in-cloud/) as soon as you can in your migration process; this could potentially take weeks or months to complete, if mitigation steps are necessary. 

**Note: (Someone/Something) runs weekly scans in the non-production environments. If (Someone/Something) finds sensitive data in non-production environments, then (Someone/Something) will revoke access to the data until you take [remediation/mitigation steps](/solutions/data-movement/howto-sensitive-data-remediation/)** 


10. Other things to consider 
  - [Resiliency/Disaster Recovery(DR) directives](/solutions/architecture/howto-resiliency-directives/) 
  - [Resiliency Testing](/solutions/migration/application-resiliency)   
  - [Production Ready Review](/solutions/migration/production-ready-review)
