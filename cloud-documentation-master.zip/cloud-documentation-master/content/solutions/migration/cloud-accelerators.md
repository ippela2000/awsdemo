---
title: "Cloud Accelerators"
description: "New to your cloud journey? Start off on the right foot by viewing our getting started guide to get set up with access, tutorials, and more!"
menu: solutions
category: cloud
weight: 1
---


The content on this page centers on the key information needed to accelerate your cloud migrations. The Cloud defaults section lists out the defaults agreed upon by ITLT. The Cloud accelerators will give advice on common architecture and insights. And, the Cloud migration resources give project managers and developers tools to help drive cloud migrations forward from a planning perspective.

## Cloud defaults

- In reference to a recent announcement from the IT Leadership Team (ITLT), in partnership with architecture, Nationwide has reached a set of defaults for Cloud Migrations.
- Refer to the Approved products [page](/docs/aws/products/_index) for the latest approved AWS products to use with these accelerators. 
- The following represents our initial list of core cloud technologies.  **As we move forward, we expect this list to grow as we learn and adjust based on both experience and need.**

| **TECHNOLOGY PURPOSE** | **EXISTING STANDARD** | **CLOUD DEFAULT** |
| --- | --- | --- |
| JAVA EXECUTION | WebSphere | **→**  Tomcat or Spring Boot |
| OPERATIONAL DATA STORE | Oracle, MS SQL | **→**  PostgreSQL |
| COMPUTE VIRTUALIZATION | VMWare | **→**  Docker Containers |
| CONTAINER ORCHESTRATION | n/a | **→**  Kubernetes |
| DATA WAREHOUSE | Teradata | **→**  IntelliCloud |
| DATA WAREHOUSE | Netezza | **→**  TBD (Targeting Q3) |
| EVENT STREAMING | n/a | **→**  Kafka |
| ETL | Informatica PWC | **→**  Informatica PWC |

**For those applications with the cloud migration path of Replatforming or re-architecting, these core technologies should be the target.**  For those applications with a cloud migration path of re-hosting, migrating to these technologies  **should**  occur in a subsequent phase.

## Cloud accelerators

These documents are meant to be used as an accelerator for your application's cloud migration. They are meant to be a common set of advice that we hope will work for most applications of a given architecture.

- [Framework: Using the Accelerators](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/using-the-accelerators.pdf?csf=1&amp;e=Lmwzr5)
- [Microservices App](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/microservices-app.pdf?csf=1&amp;e=K55GWj)
- [Static Front-End App](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/static-frontend-app.pdf?csf=1&amp;e=WfRJZK)
- [Traditional N-Tier App (NCP)](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/traditional-n-tier-app-ncp.pdf?csf=1&amp;e=rxo8XR)
- [Traditional N-Tier App (VMs)](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/traditional-n-tier-app-vm.pdf?csf=1&amp;e=Bq9lBa)
- [Workload Automation ESP Edition](https://onyourside.sharepoint.com/:b:/r/sites/ECTO/Shared%20Documents/2016-2018%20past%20docs/Enterprise%20Cloud%20Accelerators/workload-management-esp-edition.pdf?csf=1&amp;e=Re5jLJ)
- [Cloud File Movement](https://onyourside.sharepoint.com/:w:/s/iCTOArchitecture/EbnV4N3gEARAp4xK0QaEex4BB1SiLNcY3r-MiPZ014Pjag?e=wpvl0P)
- [Tealeaf Cloud Migration](https://onyourside.sharepoint.com/:b:/s/wd/TeaLeaf/ER071bOwcgBNjz6txhivbGUBtRWvghlfgNt8bMldp78F5Q)
- [Oracle to Postgres Migration How-To](/docs/aws/database/rds/oracle2postgres/)
- [GangPlank documentation](https://github.nwie.net/Nationwide/gangplank)
    - Gangplank is designed to quickly onboard applications from Nationwide's existing Java Platforms to kubernetes. 
    - Gangplank is designed with multi-tier java applications in mind. It is not intended for use with new micro service focused applications.
    - Application teams should still learn kubernetes and understand what gangplank is doing to support their applications over their life cycle however gangplank can get you up and running quickly.


## Migration resources

These resources are here to help teams plan and execute their cloud migrations. Below you will find definitions, templates, tool kits, and more. Application teams and their management do not have to use any of these resources; they are options.




