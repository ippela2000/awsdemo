---
title: Production Ready Review
menu: solutions
category: architecture
weight: 5
---

## General

### Legal

- [ ] Licenses of my application's 3rd-party dependencies are not violated?
- [ ] My application does not violate cryptography policies and laws?
- [ ] My app is compliant according to the organizational standards?

### Design

- [ ] My application has sufficient diagrams provided by my architects, engineers, or developers to understand overall design?
- [ ] I have diagrams detailing programmatic client requests?
- [ ] My team knows where the diagrams are located?
- [ ] I understand the implications of license agreements of services my application will use in the cloud?
- [ ] I have a mechanism or game-plan for evaluating and leveraging new features, instance types, configurations, and service become available in the cloud?

### Tagging Strategy

- [ ] I can pass and leverage all the appropriate minimal required tags for all of my resources?
     - [ ] Alert
     - [ ] AutoShutDown8pm
     - [ ] DisbursementCode
     - [ ] ResourceOwner
     - [ ] APRMID
     - [ ] DataClassification
     - [ ] ResourceName
     - [ ] Patch

----

## Security Pillar

### General

- [ ] I have reviewed the [AWS Security Pillar Document](https://d1.awsstatic.com/whitepapers/architecture/AWS-Security-Pillar.pdf)

### Data Protection

- [ ] I am able to protect my data at rest?
- [ ] I am able to protect my data in transit?
- [ ] I am aware of the data classification status of my data?
- [ ] I can audit my application against [OWASP](https://www.owasp.org/index.php/Category:OWASP_Top_Ten_Project) Top 10 Vulnerabilities?

### Privilege Management

- [ ] I am able to limit automated access (such as from applications, scripts, or third-party tools or services) to my AWS resources?
- [ ] I am able to manage credentials?
- [ ] I am able to manage keys?

### Detective Controls

- [ ] I am able to capture my application logs in Splunk Cloud and analyze them?

### Security Architecture

- [ ] My team and I have gone through a security architectural review at least once?

----

## Reliability Pillar

### General

- [ ] I have reviewed the [AWS Reliability Pillar Document](https://d1.awsstatic.com/whitepapers/architecture/AWS-Reliability-Pillar.pdf)


### Foundations

- [ ] I am able to plan and model my network topology on AWS?
- [ ] I have a path for technical escalation?
- [ ] I can run my services in different independent availability zones?
- [ ] I have designed components in my application to be as [loosely coupled](/solutions/architecture/arch-bestpractices/#loose-coupling-its-not-just-for-applications-decouple-your-apps-from-the-infrastructure) as possible?

### Change Management

- [ ] My application has the ability to adapt to changes?
- [ ] I am able to monitor my AWS resources for changes?
- [ ] I am able to perform change management on my production resources?

### Resiliency

- [ ] My application can retain reasonable functionality in isolation?
- [ ] My application can recover from being under heavy load?
- [ ] My application can reestablish all lost connections?
- [ ] My application can [manage sessions](https://aws.amazon.com/caching/session-management/) properly in the event of node failure and seamlessly transition users between nodes?
- [ ] My application can not cause cascading failures to propagate through the system?

### Load balancing

- [ ] My application can run behind a load balancer?
- [ ] I can add a new node without system downtime?

### Failure Management

- [ ] I have a documented plan in place for performing and auditing backups of my critical resources?
- [ ] My application is able to withstand [component failures](/solutions/architecture/arch-bestpractices//#resiliency-over-disaster-recovery)?
- [ ] I have a documented plan in place for recovery?
- [ ] I have tested my recovery plan at least once prior to going to prod?

### General Availability

- [ ] My application avoids any [single points of failure](/solutions/architecture/arch-bestpractices//#remove-single-points-of-failure)?
- [ ] I have decomposed my workloads by [service-level objective](https://en.wikipedia.org/wiki/Service_level_objective)?
- [ ] I have designed tasks and messages to be idempotent where possible (An idempotent operation completes no more than one time.)?
- [ ] I have designed my application to [gracefully degrade](/solutions/architecture/arch-bestpractices//#graceful-failure)?

### Data Management Availability

- [ ] I can geo-replicate my application's data where necessary?
- [ ] I can geo-replicate my application's databases where necessary?
- [ ] I can use optimistic concurrency and eventual consistency for my transactions?

----

## Performance Efficiency Pillar

### General

- [ ] I have reviewed the [AWS Performance Efficiency Pillar Document](https://d1.awsstatic.com/whitepapers/architecture/AWS-Performance-Efficiency-Pillar.pdf)

### Compute

- [ ] I can properly select the correct instance type for my application?
- [ ] I can monitor my application's instances post Go-Live to ensure they are performing as expected?
- [ ] I can ensure that the quantity of my application's instances matches demand?
- [ ] I have a path for technical escalation for any compute issues?

### Storage

- [ ] I can properly select the appropriate storage solution for my application?
- [ ] I can monitor my storage solution to ensure it is performing as expected?
- [ ] I can ensure that the capacity and throughput of my storage solutions matches demand?
- [ ] I have a path for technical escalation for any storage issues?

### Database

- [ ] I can select the appropriate database solution for my application?
- [ ] I can monitor my database(s) to ensure performance is as expected?
- [ ] I can ensure the capacity and throughput of my database(s) matches demand?
- [ ] I have a path for technical escalation for any database issues?

### Testing

- [ ] I have performed stress tests on my application?
- [ ] I have performed network partitioning tests for my application?
- [ ] I know the location of the results from the differing tests performed on my application?

----

## Cost Optimization Pillar

### General

- [ ] I have reviewed the [AWS Cost Optimization Pillar Document](https://d1.awsstatic.com/whitepapers/architecture/AWS-Cost-Optimization-Pillar.pdf)

### General Cost Questions

- [ ] My team and I have a basic understanding of how resources in AWS are billed?
- [ ] My project/product team is aware of the billing and chargeback model that Nationwide is utilizing for AWS costs?
- [ ] My team and I have an escalation path for any billing issues that might arise?

### Matched Supply and Demand

- [ ] I can make sure my capacity matches but does not substantially exceed what my application needs?
- [ ] I can optimize my usage of AWS usage?

### Cost-effective Resources

- [ ] I have selected the appropriate resource types to meet my cost targets?
- [ ] I have selected the appropriate pricing model to meet my cost targets?
- [ ] I have selected the appropriate managed services (higher level services than EC2, EBS and S3) that can increase my ROI?

### Expenditure Awareness

- [ ] I have controls and procedures in place to govern AWS costs?
- [ ] I have used mechanisms like the AWS cost calculator to get a general idea of my application costs in the cloud?
- [ ] I have the ability to monitoring usage and spending?
- [ ] I have the ability and procedures in place to decommission resources that I no longer need, or stop resources that are temporarily not needed?
- [ ] I considered data-transfer charges when designing my architecture?

### Optimizing Over Time

- [ ] I have the ability to manage and/or consider the adoption of new services?

----

## Operational Excellence Pillar

### Preparation

- [ ] I am following cloud best practices and I have documented those best practices?
- [ ] I am doing configuration management for my workloads?

### Operations

- [ ] My workloads are able to evolve while minimizing the impact of changes?
- [ ] I can monitor my workload to ensure it is operating as expected?

### Playbooks

- [ ] I have a documented playbook that is readily available to all members on my team?
- [ ] I have reviewed my playbook at least once with all members of my team?
- [ ] My playbooks have standard operating procedures for my application as well as other services my application might utilize?

### Responses

- [ ] I have the ability to respond to unplanned events?
- [ ] I have an escalation path for responding to unplanned events?
