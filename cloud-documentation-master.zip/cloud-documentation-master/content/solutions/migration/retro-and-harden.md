---
title: Retro and Harden
menu: solutions
category: migration
weight: 4
---


## Overview:  

![reto-harden-pyramid.jpg](/solutions/images/reto-harden-pyramid.jpg)

**Looking for ways to realize additional cloud benefits for your application that’s already in Cloud?  Here’s how we can help you** 

*	The Cloud Enablement program has created a Retro & Harden survey to look-back on the applications already running in the cloud. The objective of the Retro & Harden survey is to drive a minimum acceptable level of maturity by leveraging the diagnostic framework and evaluating the current level of maturity of Nationwide’s cloud applications in the following domains: Architecture, Security, Economics and Operations.
*	 The outcomes of this survey will aid application owners in identifying and addressing opportunities to realize additional savings or identify possible Architectural, Operational, or Security risks.  
*	 To maintain  Nationwide’s standards of best practice and continue our commitment to operating in a secure and optimized state, **this  model must  be followed  after the application has been migrated to the cloud.**
*    It will take only 5-7 minutes to respond to the survey and the typical turnaround time is <5 business days for receiving a response (everything meets nationwide standards or a follow-up conversation)
*   At the end of the process, application teams will have a list of Required and Recommended opportunities for further hardening of their application in cloud.
*   The Cloud team will provide consultation to the application team for remediating the opportunities (gaps) based on agreed upon timeline. 

_**Note:** Applications that have completed either a Full-Service Diagnostic OR a Self-Service Diagnostic model do NOT need to go through Retro and Hardening process.  In addtion, the program will not fund for the remainder of 2020 the application teams for Retro & Harden remediations, or dedicated delivery resources, including Dojos. Funding must be provided by the application team or BSA._

## The Retro & Harden Model
 
![retro-harden-process-flow.jpg](/solutions/images/retro-harden-process-flow.png) 
 

## Getting Started

*   Respond to the [Retro & Harden survey](https://forms.office.com/Pages/ResponsePage.aspx?id=TA4UIpDTwkWyl6JsUW3EYW7iJcuyG2BHiGMwCYtl3apUQ0c2QkJXMElWQjlUQjdXVEMzRkFIVU9NOSQlQCN0PWcu)
*   If you have questions, reach out to the Cloud Enablement program team on our dedicated [Retro & Harden Team](https://teams.microsoft.com/l/team/19%3a29a40053ab954301a5647af701c70104%40thread.tacv2/conversations?groupId=6c8bdd20-6064-4afb-81d1-82658765a3c2&tenantId=22140e4c-d390-45c2-b297-a26c516dc461).

Thank you for your continued support of the Cloud Enablement Program.


