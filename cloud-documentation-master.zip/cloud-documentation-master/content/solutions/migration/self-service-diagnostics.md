---
title: Self Service Diagnostics
menu: solutions
category: migration
weight: 2
---


## Overview 

**Planning to  migrate  your application  to the  cloud?  Here's what you need to know before you  do**

* The  Cloud Enablement  program's migration approach for 2020 is focused on identifying  financially impactful  application suites that would benefit  most from migrating to the cloud. 

* To accomplish this, a full-service diagnostic process was implemented, enabling us to uniformly evaluate four key domain  areas  for cloud readiness: architecture, security, operating model and economics.  

* Based on  the  high  demand for a self-service capability and  learnings from the diagnostic  process, the program  team has created  a  lean, self-service diagnostic model that will aid  application owners  in  effectively  communicating the  migration  benefits to their  Business Solution Area (BSA) leaders  and  business partners. 

* To maintain  Nationwide’s standards of best practice and continue our commitment to operating in a  secure and optimized state, **you must follow this model from the beginning of an application’s journey to the cloud.**

* Any member of the application or architecture team can submit the diagnostic survey. In order to respond effectively, we recommend you have the following information and perhaps teammates handy:
    1. Proposed initial cloud design -- (primary role accountability: Product Architect, Solution Architect)
    2. Operational plans -- (primary role accountability: APM, Tech Lead)
    3. Estimate of effort required to complete the migration project {hours, dollars - +/- 50%] -- (primary role accountability: APM)

* It will take only 5-7 minutes to respond to the survey and the typical turnaround time is <5 business days for receiving a response (approval to migrate or a follow-up conversation)



## The self-service model 

![self-service-model](/solutions/images/self-service-model.jpg)

   

## Getting started 
 
* Respond to the [Self-Service Diagnostic survey](https://forms.office.com/Pages/ResponsePage.aspx?id=TA4UIpDTwkWyl6JsUW3EYbxVaQEGF9dOmhEpCjC-2p9URDcwTTkyNDdHQzAyTzNYT1pTN0ZTTzFGMiQlQCN0PWcu)
* If you have questions, reach out to the Cloud Enablement program team on our dedicated [Cloud Diagnostics Teams channel](https://teams.microsoft.com/_?tenantId=22140e4c-d390-45c2-b297-a26c516dc461#/l/team/19:707c3330fe5e4effb966dc80d054f056@thread.tacv2/conversations?groupId=016955bc-1706-4ed7-9a11-290a30beda9f&tenantId=22140e4c-d390-45c2-b297-a26c516dc461&deeplinkId=2fb4af3f-c091-485b-c978-1b0fff63a2ae)

Thank you for your continued support of the Cloud Enablement Program.


   
