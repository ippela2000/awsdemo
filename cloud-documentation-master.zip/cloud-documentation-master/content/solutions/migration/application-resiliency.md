---
title: Application Resiliency
menu: solutions
category: migration
weight: 3
---

******** 

## Overview 
All Applications deploying to Nationwide Cloud are expected to be Reliable and Resilient. Nationwide Continuity Management Team requires resiliency testing of all business-critical applications to make sure Applications are configured to meet High Availability and Resiliency requirements. It is expected that the application can automatically fail-over within its availability zone and can recover across availability zones. The HA/Resiliency team will provide consultation and support to application teams in order to assist with testing the application to see if the Application Infrastructure configuration matches the Reliability and Resiliency requirements of the application



## Introduction
Please refer the Nationwide Cloud Application's Resiliency requirements and [Guidelines](https://gocloud.nwie.net/solutions/architecture/howto-resiliency-directives/) for Applications. 


## Scope 

 The scope of the Resiliency Testing is limited to the Production environment.  Application teams may choose to extend the testing to Test environments.


 
## Prerequisites 
Resiliency Testing will be conducted to all Nationwide Cloud applications.  Before conducting the Resiliency Test, please make sure your applications implemented  the following requirements

- Application is deployed to the BSA's AWS PROD accounts or Cloud Native Platform (CNP) PROD account successfully.
- Application APRM details are available in ServiceNow ([ServiceNow](https://nwproduction.service-now.com/nav_to.do?uri=%2Fu_enterprise_applications_list.do%3Fsysparm_userpref_module3D50399bb2db608890a6225d104b961938%26sysparm_query%3Du_status%2521%253DDeleted%255EEQ%26sysparm_clear_stack%3Dtrue))
- Application Logging is configured ([Logging](https://gocloud.nwie.net/docs/general/monitoring-alterting/howto_monitor-alert/))
- Application monitoring is  in place ([Monitoring](https://gocloud.nwie.net/docs/general/monitoring-alterting/howto_monitor-alert/))
- Application alerting for PROD support is in place ([Alerting](https://gocloud.nwie.net/docs/general/monitoring-alterting/howto_monitor-alert/))
- Security Scans are  complete ([Vulnerability Scanning](https://gocloud.nwie.net/docs/cnp/security/image-vulnerability-scanning/)) 
- Production Readiness review is completed ([Production Review](https://gocloud.nwie.net/solutions/migration/production-ready-review/))



## Resiliency Testing Process

 Before the application going live, application teams are expected to perform a Resiliency test.  The test shall cover individual components failing over with in the availability zone and across the availability zones.  Test results can be shared with the Continuity team to get credit for the activity

- **Validate Application Infrastructure configurations:** Please make sure your cloud application is configured based on NW CDT best practices.  Please refer the configuration/deployments are created based on the Cloud best [practices](https://gocloud.nwie.net/support/sre/design-recommendations/)
- **Schedule the Resiliency Test:**  Submit an email request to  John Draper (**john.draper@nationwide.com**) with your application APRM ID, App Technical contact details and the planned Go-live date. Resiliency test should be conducted 2-3 weeks before going live.  This will allow for necessary preparation, testing, validation and configuration updates as necessary.  
- **Conduct the Resiliency Test:**.  Perform the Resiliency test.  
- **Validate the results:**  Ensure the application and its components (web, app, database etc) are failed over to the other availability zone and
continue  accessible. The Application logs/Splunk/Cloudwatch/Kubernetes logs should indicate that the application is running on the other availability zone

- **Document the results:** Capture the screen shots, log snippets of the test.
- **Submit the results to the Continuity Management team:**  Please email the results to  **john.draper@nationwide.com**
- **Receive credit for the Test:** Continuity Management team will review the test results and will document the results. This will ensure that your application is completed the required Resiliency test requirement.



## Resiliency Configuration 

 The following sections covers the resiliency setup, configuration and validation requirements for each of the cloud components.  Based on your application components, please review the individual sections below and ensure your application infrastructure/deployment
 configurations are updated as needed



###	Docker/Kubernetes Container based Applications
 
 Docker/Kubernetes based applications can leverage the resiliency capabilities offered by the CNP platform. 
 Please ensure your Kubernetes deployment yaml configuration includes the required Request limits, Pod disruption budget, Node affinity and Anti affinity specifications.
 Refer the [CNP Resiliency specifications](https://gocloud.nwie.net/docs/cnp/architecture/application-resiliency/) and update your Kubernetes deployment scripts accordingly.
 
 **Reference configuration**: Please refer the following Kubernetes [configuration](https://github.nwie.net/Nationwide/nationwide-dot-com/blob/aws_migration/iac/PT/deployment.yaml) as a general reference for the deployment configuration 
    
 **Resiliency Testing, Validation and Results documentation**: Please refer the following general reference [documentation](https://onyourside.sharepoint.com/:x:/r/sites/EDS/EDS-INTERSTELLAR/_layouts/15/Doc.aspx?sourcedoc=%7B816f6c14-803c-49b0-a7bb-83ad7927a13f%7D&action=edit&activeCell=%27nwdotcom-static%20(DEV)%27!E4&wdInitialSession=957c0cbd-abef-401d-a366-ad494aa0541e&wdRldC=1&cid=7af527b4-b4bc-43d9-b40b-e19568ba593b) for documenting the fail-over testing results
   
   
    
###	AWS EC2 based Applications
 AWS EC2 server based applications can leverage the Auto Scaling and Availability Zone fail-over features offered by AWS. EC2 servers deployed using the Nationwide CDT Service Catalog/Code pipeline can leverage the Blue/Green deployment and auto scaling 
 features included in the Pipeline.  Please ensure your pipeline is deployed using the latest pipeline version and has the fail over capabilities. Please refer the CDT Pipeline [documentation](https://gocloud.nwie.net/docs/aws/management-and-governance/service-catalog/pipeline-server-bluegreen-quickdeploy/) to ensure your pipeline is configured accordingly.
 
 **Automated Resiliency Testing - Chaos Workshop**: Cloud SRE team  recommends using the Chaos Workshop Toolkit for automating the Resiliency testing of the AWS resources.  The ChaosWorkshop provides Test framework to Resiliency testing of AWS resources including EC2, ASG etc.  
 
 Please refer the documentation [here](https://github.nwie.net/Nationwide/ChaosWorkshop).  Application team can leverage this framework as suitable for their application specific needs and CI/CD capabilities.
 
 
### Azure Cloud based Applications
  Azure Cloud based Applications can leverage the Auto-scale and Availability Zone fail-over features offered by Azure.  Before going live, please review your application's Resiliency posture with the Azure Infrastructure Team. You can reach the  Azure Infrastructure team at **Azure_Infrastructure_Engineers@nationwide.com**.  The Resiliency testing will be a co-ordinated effort with Application, Azure Infrastructure and Continuity teams.
 

### Databases
 * **Oracle on EC2 Servers**: Oracle database platform uses Dataguard technology for replication and also leverages the underlying EC2 capabilities for fail-over and Resiliency. 
 
 * **Oracle/MS SQL/PostgresSQL RDS**: These databases will leverage the AWS RDS capabilities for replication, fail-over and resiliency.   
 
 * **SQL on EC2 Servers**: MS SQL database platform uses SQL Always On feature for replication and resiliency.  
 
 
 BSA's can co-ordinate with I&O DBA team to request the resiliency Test.  The testing shall including failing over the database across availability zones,  validate the database is up and application can continue access data data.  
 
Please refer the  [Database Services](https://onyourside.sharepoint.com/sites/RDDS/SitePages/DB-as-a-Service---Product-Offerings.aspx) page for all product offerings and capabilities.

  
### Kafka components 


The Kafka integration component is offered as a Service by the I&O Event Streaming team.  The Kafka platform is running on AWS Cloud environment with Kafka Brokers distributed across three availability zones. The Kafka platform leverages the Kafka Broker setup and the underlying AWS EC2 resiliency features to provide a high availability and resiliency posture for an application's topics.

The BSA application topics are distributed among the shared Kafka Brokers.  As this is a shared environment for all BSA applications, individual Kafka topic fail-over across availability zones cannot be tested per application. If any application requires resiliency testing, they will need to co-ordinate with the I&O Event Streaming team.  Please plan and schedule the testing well ahead.

Please contact the I&O Event Streaming team via [GitHub request](https://github.nwie.net/Nationwide/mw-aws-confluent-kafka-dev) to review, validate and test your resiliency requirements.

  
## Questions
 For any general questions related to Resiliency Testing, please reach out to John Draper (john.draper@nationwide.com)



## Additional Information
 - Continuity Management and the Resiliency Testing [process](https://onyourside.sharepoint.com/sites/IRM/CM/SitePages/Continuity-Management-Home.aspx)
-  [Resiliency Directives (DR)](https://gocloud.nwie.net/solutions/architecture/howto-resiliency-directives/)
- Resiliency Guidelines from Continuity Management Team can be found [here](https://gocloud.nwie.net/solutions/architecture/create-app-infra-resiliency/)
