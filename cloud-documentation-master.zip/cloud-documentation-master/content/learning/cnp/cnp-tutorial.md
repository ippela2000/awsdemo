---
category: "cnp"
description: "Get hands-on experience with Docker and Kubernetes in this Tutorial from the CNP team, recommended for any team looking to migrate their application to the Cloud Native Platform"
draft: false
difficulty: 0
title: "CNP Tutorial"
hoursEstimate: 5
contentType: technical

---

Get hands-on experience with Docker and Kubernetes in this Tutorial from the CNP team, recommended for any team looking to migrate their application to the Cloud Native Platform

* [Introduction](/docs/cnp/tutorial)
* [Intro to Docker](/docs/cnp/tutorial/01-intro-to-docker)
* [Installing Docker](/docs/cnp/tutorial/02-installing-docker)
* [Pulling Docker Images](/docs/cnp/tutorial/03-pulling-docker-images)
* [Building Docker Images](/docs/cnp/tutorial/04-building-docker-images)
* [Pushing Docker Images](/docs/cnp/tutorial/05-pushing-docker-images)
* [Running Docker Images](/docs/cnp/tutorial/06-running-docker-containers)
* [Intro to Kubernetes](/docs/cnp/tutorial/07-intro-to-kubernetes)
* [Installing Kubernetes](/docs/cnp/tutorial/08-installing-kubernetes)
* [Working with Kubernetes](/docs/cnp/tutorial/09-working-with-kubernetes)
* [Working with CNP Kubernetes](/docs/cnp/tutorial/10-working-with-cnp-kubernetes)
* [Using Helm](/docs/cnp/tutorial/11-using-helm)
* [Multi-Pod Example](/docs/cnp/tutorial/12-multi-pod-example)
* [Final Thought](/docs/cnp/tutorial/13-final-thoughts)