---
category: "cnp"
description: "This course provides a deeper look of Container technologies and is recommended for all users."
draft: false
difficulty: 2
title: "Intermediate Container Learning"
hoursEstimate: 17
contentType: technical
---




<details>
   <summary>Container Focused Training </summary>
   <p>
   <table>
      <thead>
         <tr>
            <th style="text-align:center">Course Name</th>
            <th style="text-align:center">Method</th>
            <th style="text-align:center">Training  Available</th>
            <th style="text-align:center">Cost</th>
            <th style="text-align:center">Description</th>
         </tr>
      </thead>
      <tbody>
         <tr>
            <td style="text-align:center">Docker in Production</td>
            <td style="text-align:center">E-Learning: Self Paced <br> 10 Hours</td>
            <td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/docker-production-using-amazon-web-services/table-of-contents">Docker in Production</a></td>
            <td style="text-align:center">Free</td>
            <td style="text-align:center">Learn how to use Docker and AWS to test, build and deploy applications.</td>
         </tr>
         <tr>
            <td style="text-align:center">Docker Deep Dive</td>
            <td style="text-align:center">E-Learning: Self Paced <br> 6 Hours</td>
            <td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/docker-deep-dive/table-of-contents">Docker in Production</a></td>
            <td style="text-align:center">Free</td>
            <td style="text-align:center">Learn how to use Docker for Enterprise.</td>
         </tr>
         <tr>
            <td style="text-align:center">Kubernetes Deep Dive</td>
            <td style="text-align:center">E-Learning: Self Paced <br> 4 Hours</td>
            <td style="text-align:center"><a href="https://acloud.guru/learn/kubernetes-deep-dive">Kubernetes Deep Dive</a></td>
            <td style="text-align:center">Pay</td>
            <td style="text-align:center">Learn how Kubernetes works.</td>
         </tr>
         <tr>
            <td style="text-align:center">Containerizing a Software Application with Docker</td>
            <td style="text-align:center">E-learning: Self Paced <br> 2.5 Hours</td>
            <td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/containerizing-software-application-docker/table-of-contents">Containerizing a Software</a></td>
            <td style="text-align:center">Free</td>
            <td style="text-align:center">Learn how to containerize an application using Docker.</td>
         </tr>
         <tr>
            <td style="text-align:center">Monitoring Containerized Application Health with Docker</td>
            <td style="text-align:center">E-learning: Self Paced <br> 2.75 Hours</td>
            <td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/monitoring-containerized-app-health-docker/table-of-contents">Monitoring Containerized Applications</a></td>
            <td style="text-align:center">Free</td>
            <td style="text-align:center">Learning how to monitor your application health in Docker.</td>
         </tr>
         <tr>
            <td style="text-align:center">Using Docker with AWS Elastic Beanstalk</td>
            <td style="text-align:center">E-Learning: Self Paced <br> 1 Hour</td>
            <td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/docker-aws-elastic-beanstalk/table-of-contents">Docker with AWS Elastic Beanstalk</a></td>
            <td style="text-align:center">Free</td>
            <td style="text-align:center">Learn how to use AWS Elastic Beanstalk to manage deploying Docker containers.</td>
         </tr>
      </tbody>
   </table>
   </p>
</details>
