---
category: "cnp"
description: "These courses are designed for anyone who is looking to get started with Containers and Kubernetes"
draft: false
difficulty: 0
title: "Getting started with Containers"
hoursEstimate: 4
contentType: technical

---


**Training**: Please review the following self-paced training videos before migration to the cloud. 
The goal of these videos is to have app teams prepared for migration .

*PluralSight is only free for Nationwide employees, login by selecting Login and then choose Login as School or Business, for contractors it is recommended working with your manager to obtain access to PluralSight*  <br>

<details><summary>Foundational training for Containers</summary>
By the end of this training you will have a basic understand of Docker and Kubernetes
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Docker &amp; Kubernetes: The Big Picture</td>
<td style="text-align:center">E-learning: Self Paced <br> 2 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/docker-kubernetes-big-picture/table-of-contents">The Big Picture</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">High level overview of Docker and Kubernetes.</td>
</tr>
<tr>
<td style="text-align:center">Getting Started with Kubernetes</td>
<td style="text-align:center">E-learning: Self Paced <br> 3 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/getting-started-kubernetes/table-of-contents">Getting Started with Kubernetes</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Introduction to Kubernetes</td>
</tr>
</tbody>
</table>
</p>
</details>
