---
category: "billing"
description: "This course provides a high-level overview of understanding cost and billing in AWS and is recommended for all users."
draft: false
tags: ["billing", "aws"]
difficulty: 0
title: "AWS Cost Training"
hoursEstimate: 14
contentType: "nonTechnical"
---


* **This Training is for APMs/Managers/ScrumMasters or anyone who wants to understand Cloud from a Product/Cost perspective.**



<details>
   <summary>AWS Cost Training</summary>
   <p>
   <table>
      <thead>
         <tr>
            <th>Name</th>
            <th>Method</th>
            <th>Training Available</th>
            <th style="text-align:center">Cost</th>
            <th>Description</th>
         </tr>
      </thead>
      <tbody>
         <tr>
            <td>AWS Cost Control</td>
            <td>E-Learning: Self Paced <br> 5 Hours</td>
            <td><a href="https://acloud.guru/learn/aws-cost-control">AWS Cost Control</a></td>
            <td style="text-align:center">Pay</td>
            <td>Provides an introduction on how to control costs in AWS.</td>
         </tr>
         <tr>
            <td>AWS Cloud Essentials: Pricing and Support</td>
            <td>E-Learning: Self Paced <br> 45 Minutes</td>
            <td><a href="https://www.aws.training/learningobject/wbc?id=16344">AWS Cloud Essentials: Pricing and Support</a></td>
            <td style="text-align:center">Pay</td>
            <td>Provides an overview of how AWS is supported and how products are priced.</td>
         </tr>
      </tbody>
   </table>
   </p>
</details>


<!-- ## Business

| Level | Training | Duration | Cost | Capstone Certification |
| ------------------------------ | -------------- |--|:--:|--|
| Beginner |[AWS Business Essentials](https://aws.amazon.com/training/course-descriptions/business-essentials/) | 1 Day|$|
| Beginner |[AWS Cost Control](https://acloud.guru/learn/aws-cost-control) |5 hours|$||
| Beginner |[AWS Cloud Practitioner Essentials](https://www.aws.training/learningobject/curriculum?id=16357) |7 hours|Free||
| Beginner |[AWS Pricing and Support](https://www.aws.training/learningobject/wbc?id=16344)|45 mins|Free||
| Beginner |[AWS Certified Cloud Practitioner](https://acloud.guru/learn/aws-certified-cloud-practitioner)|5 Hours|$| [AWS Certified Cloud Practitioner](https://aws.amazon.com/certification/certified-cloud-practitioner/)|
-->


