---
category: "billing"
description: "This page has training on Cloudability, which is used by Nationwide to manage cost and is recommended for all users."
draft: false
tags: ["billing", "aws"]
difficulty: 1
title: "Cloudability Learning"
hoursEstimate: 4+
contentType: "nonTechnical"
---

* **This Training is for APMs/Managers/ScrumMasters or anyone who wants to understand Cloud from a Product/Cost perspective.**

<details><summary>Cloudability Training</summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Cloudability Training</td>
<td style="text-align:center">E-Learning: Self Paced <br> 5+ Hours</td>
<td style="text-align:center"><a href="https://onyourside.sharepoint.com/sites/CloudOptimizationServiceTeam">Cloud Optimization Team Webpage</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">On the Cloud Optimization page scroll to the bottom to the section <strong>Guides, Tutorials, Videos, Instructionals</strong> .</td>
</tr>
</tbody>
</table>
</p>
</details>


