---
category: "architecture"
description: "This course provides Cloud Practitioner Essentials training for architecture and is recommended for all users."
draft: false
tags: ["aws", "architecture"]
difficulty: 1
title: "AWS Architecting Best Practices"
hoursEstimate: 0.75
contentType: architecture
---

<details><summary>AWS Architecting Best Practices Training</summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Cloud Practitioner Essentials: Architecting</td>
<td style="text-align:center">E-Learning: Self Paced <br> 45 Minutes</td>
<td style="text-align:center"><a href="https://www.aws.training/learningobject/wbc?id=16339">Cloud Practitioner Essentials: Architecting</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Introduction to the Well Architected Framework Fault Tolerance and High Availability, &amp; Web Hosting.</td>
</tr>
</tbody>
</table>
</p>
</details>


