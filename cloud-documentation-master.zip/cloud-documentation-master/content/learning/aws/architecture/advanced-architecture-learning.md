---
category: "architecture"
description: "This course provides a Architectural Overview of what is needed when migrating you application to the cloud."
draft: false
tags: ["aws", "architecture"]
difficulty: 3
title: "Advanced AWS Architectural Learning"
hoursEstimate: 13
contentType: architecture
---

<details><summary>AWS Architecting Best Practices Training</summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Migrating Your Applications to the Cloud</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-migrating-applications-cloud/table-of-contents">Migrating Your Application</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn about different migration strategies and how to make the most of AWS Cloud.</td>
</tr>
</tbody>
</table>
</p>
</details>


