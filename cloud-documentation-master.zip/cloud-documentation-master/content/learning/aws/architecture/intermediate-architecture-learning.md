---
category: "architecture"
description: "This course provides an training of how to architect for the cloud: for Security, reliability and is recommended for all users."
draft: false
tags: ["aws", "architecture", "security"]
difficulty: 2
title: "Architecting for Reliability and Security"
hoursEstimate: 13
contentType: architecture
---

<details><summary>AWS Architecting Training</summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Architecting for Reliability on AWS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-architecting-reliability/table-of-contents">Architecting for Reliability on AWS</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to implement a highly available &amp; reliable application architecture.</td>
</tr>
<tr>
<td style="text-align:center">Architecting for Security</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/architecting-security-aws/table-of-contents">Architecting for Security</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn to apply security at all layers of AWS including encrypting and protecting data at-rest.</td>
</tr>
<tr>
<td style="text-align:center">AWS Developer: Serverless Architecture &amp; Monitoring</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1.5 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-developer-serverless-architecture-monitoring">Serverless Architecture &amp; Monitoring</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn more around Serverless architecture and how monitoring works within it.</td>
</tr>
</tbody>
</table>
</p>
</details>


