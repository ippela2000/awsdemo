---
category: "security"
description: "These courses provide training any anyone looking to get advanced training in Security AWS."
tags: ["aws", "security"]
draft: false
difficulty: 4
title: "Security Focused Training"
hoursEstimate: 4
contentType: technical
---

<details><summary>Security Focused Training</summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Securing Managed Services</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-security-operations-managed-services">Securing Managed Services</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to utilize AWS managed security services and best practices.</td>
</tr>
<tr>
<td style="text-align:center">Securing Core AWS Infrastructure Services</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-security-operations-infrastructure-services">Securing Infrastructure Services</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to secure core AWS infrastructure services and best practices</td>
</tr>
<tr>
<td style="text-align:center">Securing Cloud DevOps in PaaS, Iass, &amp; SaaS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2.25 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/cloud-devops-securing-paas-iaas-saas">Securing Cloud DevOps</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn to secure cloud DevOps environments.</td>
</tr>
<tr>
<td style="text-align:center">Deployment and Security</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-deployment-security/table-of-contents">Deployment and Security</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Experience using the best methods of deployment and AWS security services.</td>
</tr>
<tr>
<td style="text-align:center">Implementing Amazon Inspector</td>
<td style="text-align:center">E-Learning: Self Paced <br> 41 Minutes</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/amazon-inspector-implementing">Amazon Inspector</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to implement automated auditing for your EC2 instances.</td>
</tr>
</tbody>
</table>
</p>
</details>
