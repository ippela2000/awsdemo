---
category: data
tags: ["aws", "data"]
description: "This course provides training on Data Virtualization tools in AWS."
draft: false
difficulty: 2
title: "Data Visualization Training"
hoursEstimate: 4
contentType: technical
---

<details><summary>AWS QuickSight</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">AWS QuickSight</td>
<td style="text-align:center">On-line class<br>4 hrs</td>
<td style="text-align:center"><a href="https://www.aws.training/learningobject/curriculum?id=35944">Visualizing with QuickSight</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>

<p>
</p>
<p>
</p>
