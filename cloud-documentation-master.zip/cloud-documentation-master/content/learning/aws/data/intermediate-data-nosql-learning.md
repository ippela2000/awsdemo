---
category: data
tags: ["aws", "data"]
description: "This course provides training of AWS cloud technologies for using interesting in using NOSQL."
draft: false
difficulty: 2
title: "NoSQL Training"
hoursEstimate: 12+
contentType: technical
---



<details><summary>Overview of DynamoDB</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">What is DynamoDB</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/Introduction.html">What is DynamoDB</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">How DynamoDB Works</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/HowItWorks.html">How DynamoDB Works</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Creating Tables and Loading Sample Data</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 - 4 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/SampleData.html">Creating Tables and Loading Sample Data</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">DynamoDB secondary indexes</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://linuxacademy.com/blog/amazon-web-services-2/a-quick-guide-to-dynamodb-secondary-indexes">DynamoDB secondary indexes</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Improving Data Access with Secondary Indexes</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/SecondaryIndexes.html">Improving Data Access with Secondary Indexes</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Best Practices for DynamoDB</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 days & ongoing</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/best-practices.html">Best Practices for DynamoDB</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Choosing the Right DynamoDB Partition Key</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/choosing-the-right-dynamodb-partition-key">Choosing the Right DynamoDB Partition Key</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Partitions and Data Distribution</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/amazondynamodb/latest/developerguide/HowItWorks.Partitions.html">Partitions and Data Distribution</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>
