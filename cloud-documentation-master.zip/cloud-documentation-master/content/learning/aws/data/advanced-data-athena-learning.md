---
category: data
tags: ["data", "aws"]
description: "This course provides training on Amazon Athena."
draft: false
difficulty: 7
title: "Understanding Athena"
hoursEstimate: 4
contentType: technical
---


<details><summary>Overview of Amazon Athena</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">What is Amazon Athena</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/athena/latest/ug/what-is.html">What is Amazon Athena?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">How Amazon Athena works</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/athena/latest/ug/getting-started.html">Getting started</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Best practices for Amazon Athena</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=JIviltfpul0">Deep Dive and Best Practices for Amazon Athena</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Integration with AWS Glue</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/athena/latest/ug/glue-athena.html">Integration with AWS Glue</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Amazon Glue for ETL in data processing</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://www.accenture.com/us-en/blogs/blogs-kalyani-sayyed-amazon-glue-etl">Applying Amazon Glue for ETL in data processing</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>
