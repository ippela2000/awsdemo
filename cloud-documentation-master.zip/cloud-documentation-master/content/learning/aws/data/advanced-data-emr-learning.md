---
category: data
tags: ["data", "aws"]
description: "This course provides training on EMR/Hadoop"
draft: false
difficulty: 3
title: "Understanding EMR/Hadoop"
hoursEstimate: 34
contentType: technical
---

<details><summary>Overview of EMR/Hadoop</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">What is Hadoop</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://www.sas.com/en_us/insights/big-data/hadoop.html">What is Hadoop</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">What is Hadoop</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://hortonworks.com/apache/hadoop/">Apache Hadoop</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Introduction to HDFS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://www.ibm.com/developerworks/library/wa-introhdfs/index.html">HDFS</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">The Hadoop Distributed Filesystem (Chapter 3)</td>
<td style="text-align:center">e-Book: Self Paced <br> 8 hrs</td>
<td style="text-align:center"><a href="https://www.isical.ac.in/~acmsc/WBDA2015/slides/hg/Oreilly.Hadoop.The.Definitive.Guide.3rd.Edition.Jan.2012.pdf">PDF</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">How Mapreduce works (Chapter 6)</td>
<td style="text-align:center">e-Book: Self Paced <br> 8 hrs</td>
<td style="text-align:center"><a href="https://www.isical.ac.in/~acmsc/WBDA2015/slides/hg/Oreilly.Hadoop.The.Definitive.Guide.3rd.Edition.Jan.2012.pdf">PDF</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Hadoop 2 Architecture</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=4Y4XST3ZBcs&feature=youtu.be&t=1m28s">Understanding Hadoop 2 0 Architecture</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Configuring EMR</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/emr/latest/ManagementGuide/emr-plan-vpc-subnet.html">EMR Networking</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Accessing EMR Web Interfaces</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/emr/latest/ManagementGuide/emr-web-interfaces.html">View Web Interfaces Hosted on Amazon EMR Clusters</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Work with Steps using the CLI and console</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/emr/latest/ManagementGuide/emr-work-with-steps.html">Work with Steps Using the CLI and Console</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">S3distcp</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/emr/latest/ReleaseGuide/UsingEMR_s3distcp.html">S3DistCp (s3-dist-cp)</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Working with Hive</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=tKNGB5IZPFE">Hive Tutorial 1 | Hive Tutorial for Beginners | Understanding Hive In Depth</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Hive Architecture</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://www.guru99.com/introduction-hive.html">What is Hive? Architecture & Modes</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Hive UDFs</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://www.guru99.com/hive-user-defined-functions.html">Hive Function: Built-in & UDF (User Defined Functions)</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Working with spark</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=9CVzod-z1u4">Crash Introduction to Apache Spark by Paco Nathan</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Introduction to Apache Spark</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://www.toptal.com/spark/introduction-to-apache-spark">Introduction to Apache Spark with Examples and Use Cases</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Configuring Spark In EMR</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/emr/latest/ReleaseGuide/emr-spark-configure.html">Configure Spark</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Best Practices for Apache spark on Amazon EMR</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=KfgCJufxI0M">AWS re:Invent 2016: Best Practices for Apache Spark on Amazon EMR</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Submitting User applications with spark submit and tuning</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://aws.amazon.com/blogs/big-data/submitting-user-applications-with-spark-submit/">Submitting User Applications with spark-submit</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>


<p>
</p>
