---
category: data
tags: ["data", "aws"]
description: "This course provides training on Elasticsearch."
draft: false
difficulty: 3
title: "Learning AWS Elastic Search"
hoursEstimate: 15
contentType: technical
---

<details><summary>Overview of Elasticsearch</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">Elasticsearch Service</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/elasticsearch-service/latest/developerguide/what-is-amazon-elasticsearch-service.html">What Is Amazon Elasticsearch Service?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Elasticsearch cluster creation</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/elasticsearch-service/latest/developerguide/es-createupdatedomains.html#es-createdomain-configure-access-policies">Elasticsearch cluster creation</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Elasticsearch snapshots</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/elasticsearch-service/latest/developerguide/es-managedomains-snapshots.html">Working with Amazon Elasticsearch Service Index Snapshots</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Loading Sample Data</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://www.elastic.co/guide/en/kibana/current/tutorial-load-dataset.html">Loading Sample Data</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Kibana & Logstash</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/elasticsearch-service/latest/developerguide/es-kibana.html">Kibana and Logstash</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Elasticsearch service Best practices</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/elasticsearch-service/latest/developerguide/aes-bp.html">Amazon Elasticsearch Service Best Practices</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>

