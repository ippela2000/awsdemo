---
category: data
tags: ["aws", "data"]
description: "This course provides a high-level introduction of data in Cloud Data technologies and is recommended for all users."
draft: false
difficulty: 1
title: "Beginners Introduction to Data"
hoursEstimate: 8
contentType: technical
---

<details><summary>General Data Services Training</summary>

<p>
<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
  <tr>
    <td>AWS Database Services Overview</td>
    <td style="text-align:center">On-line class<br> 10 mins</td>
    <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=16205">AWS Database Services Overview</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Introduction to Amazon Relational Database Service (RDS)</td>
    <td style="text-align:center">On-line class<br> 10 mins</td>
    <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=16449">Introduction to Amazon Relational Database Service (RDS)</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Introduction to Amazon Athena</td>
    <td style="text-align:center">On-line class<br> 10 mins</td>
    <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=15885">Introduction to Amazon Athena</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td style="text-align:center">Getting Started with AWS Athena</td>
    <td style="text-align:center">E-Learning: Self Paced <br> 2.25 Hours</td>
    <td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-athena-get-started">AWS Athena</a></td>
    <td style="text-align:center">Free</td>
</tr>
  <tr>
    <td>Introduction to Amazon Redshift</td>
    <td style="text-align:center">On-line class<br> 10 mins</td>
    <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=16514">Introduction to Amazon Redshift</a></td>
    <td style="text-align:center">Free</td>
  </tr>
 <tr>
    <td style="text-align:center">Data Warehousing with AWS Redshift</td>
    <td style="text-align:center">E-Learning: Self Paced <br> 2.5 Hours</td>
    <td style="text-align:center"><a href="https://www.pluralsight.com/courses/amazon-redshift-high-performance-data-warehousing">Data Warehousing with AWS Redshift</a></td>
    <td style="text-align:center">Free</td>
</tr>
  <tr>
    <td>Introduction to Amazon DynamoDB</td>
    <td style="text-align:center">On-line class<br> 10 mins</td>
    <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=16021">Introduction to Amazon DynamoDB</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>AWS re:Invent 2018</td>
    <td style="text-align:center">Video<br> 45 mins</td>
    <td style="text-align:center"><a href="https://www.youtube.com/watch?v=-pb-DkD6cWg&feature=youtu.be">The Right Tool for the Right Job</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>AWS re:Invent 2018</td>
    <td style="text-align:center">Video<br> 45 mins</td>
    <td style="text-align:center"><a href="https://www.youtube.com/watch?v=tVVMffvJPUw&feature=youtu.be">AWS Database and Analytics</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>AWS re:Invent 2018</td>
    <td style="text-align:center">Video<br> 45 mins</td>
    <td style="text-align:center"><a href="https://www.youtube.com/watch?v=hwnNbLXN4vA&feature=youtu.be">Match Your Workload to the Right Database</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>AWS re:Invent 2018</td>
    <td style="text-align:center">Video<br> 45 mins</td>
    <td style="text-align:center"><a href="https://www.youtube.com/watch?v=valsEK5mIQI&feature=youtu.be">Netflix: Iterating on Stateful Services in the Cloud</a></td>
    <td style="text-align:center">Free</td>
  </tr>
</table>
</p>
</details>
