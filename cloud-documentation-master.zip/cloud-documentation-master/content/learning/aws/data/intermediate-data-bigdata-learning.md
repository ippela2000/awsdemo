---
category: data
tags: ["aws", "data"]
description: "This course provides training of cloud technologies for working with Big Data"
draft: false
difficulty: 2
title: "Big Data Training"
hoursEstimate: 4
contentType: technical
---



<details><summary>Overview of Big Data</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">Introduction to Hadoop and Mapreduce</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=DEQNknALf_8&feature=youtu.be&list=PLSv8gI5gDyOS_amomc3MejmNs7ZOqQwBj">Introduction to Hadoop and Mapreduce</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Big Data Overview</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://aws.amazon.com/big-data/what-is-big-data">Big Data Overview</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">NoSQL Overview</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://aws.amazon.com/nosql">NoSQL Overview</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Streaming Overview</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://aws.amazon.com/streaming-data">Streaming Overview</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>
