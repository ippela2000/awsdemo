---
category: data
tags: ["aws", "data"]
description: "This course provides a high-level overview of database migration to cloud technologies and is recommended for all users."
draft: false
difficulty: 1
title: "Database Migration"
hoursEstimate: 4
contentType: technical
---

<details><summary>Database Migration</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
  <tr>
    <td>AWS Database Migration ServiceBest Practices</td>
    <td style="text-align:center">Whitepaper<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://d1.awsstatic.com/whitepapers/RDS/AWS_Database_Migration_Service_Best_Practices.pdf">Database Migration Service Best Practices</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Strategies for Migrating Oracle Databases to AWS</td>
    <td style="text-align:center">Whitepaper<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://d1.awsstatic.com/whitepapers/strategies-for-migrating-oracle-database-to-aws.pdf">Migrating Oracle Databases to AWS</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Migrating Oracle Autonomous Transactions to PostgreSQL</td>
    <td style="text-align:center">Blog<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/migrating-oracle-autonomous-transactions-to-postgresql/">Migrating Oracle Autonomous Transactions to PostgreSQL</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Common challenges faced while migrating from Oracle to PostgreSQL</td>
    <td style="text-align:center">Blog<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/how-to-solve-some-common-challenges-faced-while-migrating-from-oracle-to-postgresql/">How to solve some common challenges faced while migrating from Oracle to PostgreSQL</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>AWS re:Invent 2018</td>
    <td style="text-align:center">Video<br>45 mins</td>
    <td style="text-align:center"><a href="https://www.youtube.com/watch?v=11IHvxjy4hw&feature=youtu.be">Migrating Databases to the Cloud with AWS Database Migration Service</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Best Practices For migrating an Oracle database to Amazon RDS PostgreSQL</td>
    <td style="text-align:center">Blog<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/best-practices-for-migrating-an-oracle-database-to-amazon-rds-postgresql-or-amazon-aurora-postgresql-target-database-considerations-for-the-postgresql-environment/">Target database considerations for the PostgreSQL environment</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Best Practices For migrating an Oracle database to Amazon RDS PostgreSQL</td>
    <td style="text-align:center">Blog<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/best-practices-for-migrating-an-oracle-database-to-amazon-rds-postgresql-or-amazon-aurora-postgresql-source-database-considerations-for-the-oracle-and-aws-dms-cdc-environment/">Source database considerations for the Oracle and AWS DMS CDC environment</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Best Practices For migrating an Oracle database to Amazon RDS PostgreSQL</td>
    <td style="text-align:center">Blog<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/best-practices-for-migrating-an-oracle-database-to-amazon-rds-postgresql-or-amazon-aurora-postgresql-migration-process-and-infrastructure-considerations/">Migration process and infrastructure considerations</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Tactical Oracle To PostgreSQL Migration</td>
    <td style="text-align:center">PDF<br>1 hr</td>
    <td style="text-align:center"><a href="https://github.nwie.net/Nationwide/NW-Cloud-Docs/blob/master/docs/_docs/Image/Oracle-To-PostgreSQL-Migration.pdf">Oracle To PostgreSQL Migration</a></td>
    <td style="text-align:center">Free</td>
  </tr>
 
</table>
</p>
</details>
