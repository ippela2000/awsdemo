---
category: data
tags: ["aws", "data"]
description: "This course provides training on Database Operations"
draft: false
difficulty: 1
title: "Database Operations"
hoursEstimate: 4
contentType: technical
---



<details><summary>Operations</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
  <tr>
    <td>Maintaining a DB Instance</td>
    <td style="text-align:center">Documentation<br>2-3 hrs</td>
    <td style="text-align:center"><a href="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_UpgradeDBInstance.Maintenance.html">Maintaining a DB Instance</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>Performance Insights</td>
    <td style="text-align:center">Blog<br>1 hr</td>
    <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/set-alarms-on-performance-insights-metrics-using-amazon-cloudwatch/">Set alarms on Performance Insights metrics using Amazon CloudWatch</a></td>
    <td style="text-align:center">Free</td>
  </tr>
  <tr>
    <td>AWS re:Invent 2018</td>
    <td style="text-align:center">Video<br>45 mins</td>
    <td style="text-align:center"><a href="https://www.youtube.com/watch?v=RyX9tPxffmw&feature=youtu.be">Using Performance Insights to Optimize Database Performance</a></td>
    <td style="text-align:center">Free</td>
  </tr>
</table>
</p>
</details>

