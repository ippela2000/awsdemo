---
category: data
tags: ["data", "aws"]
description: "This course provides training on Kinesis"
draft: false
difficulty: 3
title: "Overview of Kinesis"
hoursEstimate: 20
contentType: technical
---
<details><summary>Overview of Kinesis</summary>
<p>
<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">Kinesis Streams</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/streams/latest/dev/introduction.html">What Is Amazon Kinesis Data Streams?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Kinesis Data Streams Key Concepts</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/streams/latest/dev/key-concepts.html">Amazon Kinesis Data Streams Terminology and Concepts</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Kinesis Firehose</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/firehose/latest/dev/what-is-this-service.html">What Is Amazon Kinesis Data Firehose?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Kinesis Analytics</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/kinesisanalytics/latest/dev/what-is.html">What Is Amazon Kinesis Data Analytics for SQL Applications?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Pushing Data into Kinesis Streams</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://aws.amazon.com/kinesis/data-streams/getting-started">Pushing Data into Kinesis Streams</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Creating Firehose Delivery Stream</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/firehose/latest/dev/basic-create.html">Creating an Amazon Kinesis Data Firehose Delivery Stream</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Sending data to Firehose stream</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/firehose/latest/dev/basic-write.html">Sending Data to an Amazon Kinesis Data Firehose Delivery Stream</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">How to transform data in Firehose stream</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/firehose/latest/dev/data-transformation.html">Amazon Kinesis Data Firehose Data Transformation</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Firehose Data Transformation with Lambda</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://aws.amazon.com/blogs/compute/amazon-kinesis-firehose-data-transformation-with-aws-lambda">Amazon Kinesis Firehose Data Transformation with AWS Lambda</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>

<p>
</p>
