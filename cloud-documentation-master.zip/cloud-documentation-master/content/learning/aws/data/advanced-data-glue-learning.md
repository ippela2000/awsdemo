---
category: data
tags: ["data", "aws"]
description: "This course provides training on AWS Glue"
draft: false
difficulty: 3
title: "AWS Glue"
hoursEstimate: 24
contentType: technical
---


<details><summary>Overview of AWS Glue</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
<td style="text-align:center">What is AWS Glue</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/what-is-glue.html">What is AWS Glue?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">AWS Glue : How It Works</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/populate-data-catalog.html">How does AWS Glue work?</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Getting started with AWS Glue ETL</td>
<td style="text-align:center">E-Learning: Self Paced <br> 15 mins</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=z3HeHlWg88M">Getting Started with AWS Glue ETL</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Introduction to AWS Glue - Reinvent</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 mins</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=4N_ktE4NFIk">AWS re:Invent 2016: NEW LAUNCH! Introduction to AWS Glue: A Fully Managed ETL Service</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Populating AWS Glue Catalog</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/populate-data-catalog.html">Populating the AWS Glue Data Catalog</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">What are Glue jobs and Authoring Jobs In AWS Glue</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/author-job.html">Authoring Jobs in AWS Glue</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Running and Monitoring AWS Glue</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/monitor-glue.html">Running and Monitoring AWS Glue</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Triggering Jobs in AWS Glue</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/trigger-job.html">Triggering Jobs in AWS Glue</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Working with Job Bookmarks</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/monitor-continuations.html">Tracking Processed Data Using Job Bookmarks</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Using Dev end points for glue jobs/scripts development</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/dev-endpoint.html">Using Development Endpoints for Developing Scripts</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Environment setup for Dev end points</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/start-development-endpoint.html">Setting Up Your Environment for Development Endpoints</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Run ETL scripts from Apache Zeppelin notebook</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/dev-endpoint-tutorial-EC2-notebook.html">Tutorial: Set Up an Apache Zeppelin Notebook Server on Amazon EC2</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Python Samples</td>
<td style="text-align:center">E-Learning: Self Paced <br> 5 hrs</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/aws-glue-programming-python-samples.html">AWS Glue Python Code Samples</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">Best practices when using Athena and Glue</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/athena/latest/ug/glue-best-practices.html">Best Practices When Using Athena with AWS Glue</a></td>
<td style="text-align:center">Free</td>
</tr>
<tr>
<td style="text-align:center">AWS Glue troubleshooting</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hr</td>
<td style="text-align:center"><a href="https://docs.aws.amazon.com/glue/latest/dg/troubleshooting-glue.html">AWS Glue Troubleshooting</a></td>
<td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>

<p>
</p>

