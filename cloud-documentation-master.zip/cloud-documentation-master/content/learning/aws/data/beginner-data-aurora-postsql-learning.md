---
category: data
tags: ["aws", "data"]
description: "This course provides a high-level overview of Aurora/PostgreSQL and is recommended for all users."
draft: false
difficulty: 1
title: "Aurora/PostgreSQL"
hoursEstimate: 4
contentType: technical
---



<details><summary>Aurora/PostgreSQL</summary>

<p>

<table>
  <tr>
    <th>Course Name</th>
    <th>Method</th>
    <th>Training Available</th>
    <th>Cost</th>
  </tr>
<tr>
    <td>PostgreSQL Fundamentals</td>
    <td style="text-align:center">On-line class<br>20 mins</td>
    <td style="text-align:center"><a href="https://www.aws.training/learningobject/wbc?id=32439">PostgreSQL Fundamentals</a></td>
    <td style="text-align:center">Free</td>
  </tr>
<tr>
   <td>Introduction to Amazon Aurora</td>
   <td style="text-align:center">On-line class<br>10 mins</td>
   <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=15888">Introduction to Amazon Aurora</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Introduction to Amazon Aurora Serverless</td>
   <td style="text-align:center">On-line class<br>15 mins</td>
   <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=23327">Introduction to Amazon Aurora Serverless</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Amazon Aurora FAQs</td>
   <td style="text-align:center">FAQ<br>15 mins</td>
   <td style="text-align:center"><a href="https://aws.amazon.com/rds/aurora/faqs/">Amazon Aurora FAQs</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>AWS re:Invent 2018</td>
   <td style="text-align:center">Video<br>45 mins</td>
   <td style="text-align:center"><a href="https://www.youtube.com/watch?v=2WG01wJIGSQ&feature=youtu.be">What's New in Amazon Aurora</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Mapping a Few Core Oracle DB Concepts to Amazon RDS/Aurora PostgreSQL Concepts</td>
   <td style="text-align:center">On-line class<br>45 mins</td>
   <td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=26849">Mapping a Few Core Oracle DB Concepts to Amazon RDS/Aurora PostgreSQL Concepts</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Parallel Query for Amazon Aurora</td>
   <td style="text-align:center">Blog<br>1 hr</td>
   <td style="text-align:center"><a href="https://aws.amazon.com/blogs/aws/new-parallel-query-for-amazon-aurora/">Parallel Query for Amazon Aurora</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Managing PostgreSQL users and roles</td>
   <td style="text-align:center">Blog<br>2-3 hrs</td>
   <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/managing-postgresql-users-and-roles/">Managing PostgreSQL users and roles</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>AWS re:Invent 2018</td>
   <td style="text-align:center">Video<br>45 mins</td>
   <td style="text-align:center"><a href="https://www.youtube.com/watch?v=tJ0TWdIocz0&feature=youtu.be">Accelerate Database Development and Testing with Amazon Aurora</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>AWS re:Invent 2018</td>
   <td style="text-align:center">Video<br>45 mins</td>
   <td style="text-align:center"><a href="https://www.youtube.com/watch?v=3PshvYmTv9M&feature=youtu.be">Deep Dive on Amazon Aurora with PostgreSQL Compatibility</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Connecting to a DB Instance</td>
   <td style="text-align:center">Documentation<br>2-3 hrs</td>
   <td style="text-align:center"><a href="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/USER_ConnectToPostgreSQLInstance.html">Connecting to a DB Instance Running the PostgreSQL Database Engine</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Common DBA Tasks for PostgreSQL</td>
   <td style="text-align:center">Documentation<br>2-3 hrs</td>
   <td style="text-align:center"><a href="https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Appendix.PostgreSQL.CommonDBATasks.html">Common DBA Tasks for PostgreSQL</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Failover with Amazon Aurora PostgreSQL</td>
   <td style="text-align:center">Blog<br>1 hr</td>
   <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/failover-with-amazon-aurora-postgresql/">Failover with Amazon Aurora PostgreSQL</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>Single pgpool endpoint</td>
   <td style="text-align:center">Blog<br>1 hr</td>
   <td style="text-align:center"><a href="https://aws.amazon.com/blogs/database/a-single-pgpool-endpoint-for-reads-and-writes-with-amazon-aurora-postgresql/">How to set up a single pgpool endpoint for reads and writes with Amazon Aurora PostgreSQL</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>AWS re:Invent 2018</td>
   <td style="text-align:center">Video<br>55 mins</td>
   <td style="text-align:center"><a href="https://www.youtube.com/watch?v=4DqNk7ZTYjA&feature=youtu.be">Aurora Serverless: Scalable, Cost-Effective Application Deployment</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>PostgreSQL Performance</td>
   <td style="text-align:center">Documention<br>2-3 hrs</td>
   <td style="text-align:center"><a href="https://www.postgresql.org/docs/9.6/performance-tips.html">Performance Tips</a></td>
   <td style="text-align:center">Free</td>
</tr>
<tr>
   <td>AWS re:Invent 2018</td>
   <td style="text-align:center">Video<br>46 mins</td>
   <td style="text-align:center"><a href="https://www.youtube.com/watch?v=6YmcteXoBvU&feature=youtu.be">Deep Dive on PostgreSQL Databases on Amazon RDS</a></td>
   <td style="text-align:center">Free</td>
</tr>
</table>
</p>
</details>
