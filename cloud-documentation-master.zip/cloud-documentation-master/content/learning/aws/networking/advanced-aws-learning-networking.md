---
category: "aws"
description: "These courses provide training any anyone looking to get advanced training in Networking AWS."
tags: ["aws", "networking"]
draft: false
difficulty: 4
title: "Networking Focused Training"
hoursEstimate: 4
contentType: technical
---

<details><summary>Networking Focused Training </summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">AWS Networking: Deep Dive VPC</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-networking-deep-dive-vpc/table-of-contents">Deep Dive VPC</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to secure VPCs that can easily scale to accommodate workloads and connectivity.</td>
</tr>
<tr>
<td style="text-align:center">AWS Networking: Deep Dive ELB</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-networking-deep-dive-elb/table-of-contents">Deep Dive ELB</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn to securely configure load balancing for any internet facing or internal application.</td>
</tr>
<tr>
<td style="text-align:center">AWS Networking: Deep Dive Route 53 DNS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-networking-deep-dive-route-53-dns/table-of-contents">Deep Dive Route 53 DNS</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to configure Route 53 for any domain name and more.</td>
</tr>
</tbody>
</table>
</p>
</details>

