---
category: "aws"
description: "This course provides a foundational AWS training and reommended for anyone who is new to AWS and Cloud Technologies."
draft: false
difficulty: 0
title: "Foundational AWS Learning"
hoursEstimate: 4
contentType: technical
---
Training: Please review the following self paced PluralSight training videos before migration to the cloud. 
The goal of these videos are to have app teams prepared for migration by defining, at a high level, key AWS services that app teams may utilize during their migration. 
PluralSight is only free for Nationwide employees, login by selecting Login and then choose Login as School or Business, 
for contractors it is recommended working with your manager to obtain access to PluralSight


Foundational Courses

* **These training videos should be taken by anyone who is new to AWS - Technical (Developers/Tester etc) and Non-Technical (APMs/PPL etc)**

<details><summary>Foundational training for AWS</summary>
By the end of this training you will be able to do the following understand the basics of Cloud and the basic services in AWS
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Introduction to Cloud</td>
<td style="text-align:center">E-learning: Self Paced <br> 1 hour</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=usYySG1nbfI&amp;t=0s&amp;list=PL9ooVrP1hQOFWxRJcGdCot7AgJu29SVV3&amp;index=7">Introduction to Cloud</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides an introduction to cloud for beginners and is a good base for future learning.</td>
</tr>
<tr>
<td style="text-align:center">AWS in 10 Minutes</td>
<td style="text-align:center">E-Learning: Self Paced <br> 10 minutes</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=r4YIdn2eTm4">AWS in 10 Minutes</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Only have 10 minutes? This tutorial will give you a 50k foot view of what is AWS.</td>
</tr>
<tr>
<td style="text-align:center">Introduction to AWS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 hour</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=PW-V-72MJNY&amp;t=0s&amp;list=PL9ooVrP1hQOFWxRJcGdCot7AgJu29SVV3&amp;index=3">Intro to AWS</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides an introduction into AWS; a few steps further than the 10 minute overview.</td>
</tr>
<tr>
<td style="text-align:center">AWS Core Services</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 hours</td>
<td style="text-align:center"><a href="https://www.aws.training/learningobject/wbc?id=16332">AWS Core Services</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides an introduction to Amazon’s key services when it comes to the cloud.</td>
</tr>
<tr>
<td style="text-align:center">AWS Security Fundamentals</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4 hours</td>
<td style="text-align:center"><a href="https://aws.amazon.com/training/course-descriptions/security-fundamentals/">AWS Security Fundamentals</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides an introduction on security and how to it works in the cloud.</td>
</tr>
<tr>
<td style="text-align:center">AWS Database Services Overview</td>    
<td style="text-align:center">On-line class<br> 10 mins</td>
<td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=16205">AWS Database Services Overview</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides an introduction on Database Services in the cloud.</td>
</tr>
<tr>
<td>Introduction to Amazon Relational Database Service (RDS)</td>    
<td style="text-align:center">On-line class<br> 10 mins</td>
<td style="text-align:center"><a href="https://www.aws.training/learningobject/video?id=16449">Introduction to Amazon Relational Database Service (RDS)</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Introduction to RDS.</td>
</tr>
<tr>
<td style="text-align:center">AWS Cloud Practitioner Essentials</td>
<td style="text-align:center">E-Learning: Self Paced <br> 7 hours</td>
<td style="text-align:center"><a href="https://www.aws.training/learningobject/curriculum?id=16357">AWS Cloud Practitioner Essentials</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides the essentials for learning AWS cloud technology. <strong>Pre-req for Cloud Practitioner certification.</strong></td>
</tr>
</tbody>
</table>
</p>
</details>






