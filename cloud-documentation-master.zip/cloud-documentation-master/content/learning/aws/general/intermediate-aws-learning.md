---
category: "aws"
description: "These courses provide training with a developer focus for tools like AWS SDK, Cloud Formation, Code Pipeline, Systems Manager etc"
draft: false
difficulty: 2
title: "Developer focused AWS Learning"
hoursEstimate: 13
contentType: architecture
---

<details><summary>Developer Focused trainings</summary>
<p>

<h4 id="Intermediate-courses-recommended">Intermediate Courses Recommendations</h4>

<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Getting Started</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-getting-started/table-of-contents">Getting Started</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Provides an introduction to cloud and AWS from a developer point of view.</td>
</tr>
<tr>
<td style="text-align:center">Getting Started with AWS Developer Tools</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-tools-getting-started/table-of-contents">AWS Developer Tools</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Basics of using CodeCommit, CodeBuild, CodeDeploy, CodePipelines, and how to create a Continuous Deployment Pipeline.</td>
</tr>
<tr>
<td style="text-align:center">CloudFormation Demo</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 Hour</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=01hy48R9Kr8&amp;list=PLhr1KZpdzukf34vxrO18JKjMLT_5tGNJi&amp;index=22">Deep Dive on CloudFormation</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Demos showcase how developers can quickly edit, debug and deploy applications to the cloud.</td>
</tr>
<tr>
<td style="text-align:center">CodePipeline at Nationwide</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 Hour</td>
<td style="text-align:center"><a href="https://videospace.nationwide.com/playlist/dedicated/93125981/1_m0s3pf6v/1_isnxs1ai">Code Pipeline at Nationwide</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Demos showcase how developers can quickly deploy Code Pipeline at Nationwide.</td>
</tr>
<tr>
<td style="text-align:center">Monitoring with AWS CloudTrail</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 Hour</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/monitoring-aws-cloudtrail">AWS CLoudTrail</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn several techniques for monitoring with CloudTrail</td>
</tr>
<tr>
<td style="text-align:center">Amazon SDK with GO</td>
<td style="text-align:center">E-Learning: Self Paced <br> 5 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-sdk-go-building-web-applications">Amazon SDK with GO</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to build a full-feature web application written in GO.</td>
</tr>
<tr>
<td style="text-align:center">Node.js: Getting Started</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/nodejs-getting-started/table-of-contents">Node.js</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn the fundamentals and get comfortable writing code for Node.</td>
</tr>
<tr>
<td style="text-align:center">Using Serverless Framework with Node.js on AWS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 45 minutes</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-nodejs-serverless-framework-using/table-of-contents">Using Serverless Framework with Node.js</a>)</td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn the basics of the framework and how to use it to build event-driven apps.</td>
</tr>
<tr>
<td style="text-align:center">AWS Simple Systems Manager for EC2</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1.5 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-ssm-ec2-getting-started">AWS Simple Systems manager for EC2</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to use AWS Systems Manager for EC2 to manage virtual machines serverless.</td>
</tr>
<tr>
<td style="text-align:center">AWS Tools for Windows Powershell</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-tools-windows-powershell-automating-cloud-operations/table-of-contents">AWS Tools for Windows Powershell</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn to install secure tools, and master cmdlets beyond those used in the course.</td>
</tr>
<tr>
<td style="text-align:center">AWS Infrastructure: Connecting On-Premises</td>
<td style="text-align:center">E-Learning: Self Paced <br> 47 Minutes</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/on-prem-resources-aws-infrastructure/table-of-contents">Connecting On-Premises</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn best practices for connecting to local resources to your AWS infrastructure.</td>
</tr>
<tr>
<td style="text-align:center">Deploying Processing Apps with AWS Kinesis</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3.5 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-kinesis-processing-app">AWS Kinesis</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to build stream processing applications using AWS Kinesis.</td>
</tr>
</tbody>
</table>

