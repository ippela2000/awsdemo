---
category: "aws"
description: "These courses provide training for AWS certifications - Cloud Practitioner"
draft: false
difficulty: 0
title: "AWS Certified Cloud Practitioner"
hoursEstimate: 14
contentType: "nonTechnical"
---


* **This certification is for APMs/Managers/ScrumMasters or anyone who wants to understand Cloud from a Product/Cost perspective.**

<details>
   <summary>AWS Certification</summary>
   <p>
   <table>
      <thead>
         <tr>
            <th style="text-align:center">Course Name</th>
            <th style="text-align:center">Method</th>
            <th style="text-align:center">Training  Available</th>
            <th style="text-align:center">Cost</th>
            <th style="text-align:center">Description</th>
         </tr>
      </thead>
      <tbody>
         <tr>
            <td style="text-align:center">AWS Certified Cloud Practitioner</td>
            <td style="text-align:center">E-Learning: Self Paced <br> 5 Hours</td>
            <td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-cloud-practitioner">AWS Certified Cloud Practitioner</a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-cloud-practitioner/">AWS Certified Cloud Practitioner</a></td>
            <td style="text-align:center">Free and Pay</td>
            <td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
         </tr>
      </tbody>
   </table>
   </p>
</details>

<!-- ## Business

| Level | Training | Duration | Cost | Capstone Certification |
| ------------------------------ | -------------- |--|:--:|--|
| Beginner |[AWS Business Essentials](https://aws.amazon.com/training/course-descriptions/business-essentials/) | 1 Day|$|
| Beginner |[AWS Cost Control](https://acloud.guru/learn/aws-cost-control) |5 hours|$||
| Beginner |[AWS Cloud Practitioner Essentials](https://www.aws.training/learningobject/curriculum?id=16357) |7 hours|Free||
| Beginner |[AWS Pricing and Support](https://www.aws.training/learningobject/wbc?id=16344)|45 mins|Free||
| Beginner |[AWS Certified Cloud Practitioner](https://acloud.guru/learn/aws-certified-cloud-practitioner)|5 Hours|$| [AWS Certified Cloud Practitioner](https://aws.amazon.com/certification/certified-cloud-practitioner/)|
-->


