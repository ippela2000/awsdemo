---
category: "aws"
description: "This course provides a advanced training on cloud technologies for developers cloud technoliges like CLI, Lambda"
draft: false
difficulty: 4
title: "Deep Dive Developer focused AWS Learning"
hoursEstimate: 23
contentType: technical
---

<h4 id="Advanced-recommended">Advanced Courses Recommendations</h4>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">Designing and Developing</td>
<td style="text-align:center">E-Learning: Self Paced <br> 4.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-designing-developing/table-of-contents">Designing and Developing</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">How to use the AWS SDK to design and develope applications with AWS.</td>
</tr>
<tr>
<td style="text-align:center">Mastering AWS Command Line Interface Operations</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-command-line-interface-mastering-operations/table-of-contents">AWS Command Line Interface</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to master the AWS command line interface to do a variety of tasks.</td>
</tr>
<tr>
<td style="text-align:center">AWS Lambda Deep Dive</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-lambda-deep-dive/table-of-contents">Lambda Deep Dive</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to create, deploy, and manage event-driven serverless apps</td>
</tr>
<tr>
<td style="text-align:center">Securing Access to Object Storage</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2.25 Hours</td>
<td style="text-align:center"><a href="https://www.pluralsight.com/courses/aws-security-operations-object-storage">AWS Security Operations</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn about AWS security services and features.</td>
</tr>
<tr>
<td style="text-align:center">AWS CodeDeploy</td>
<td style="text-align:center">E-Learning: Self Paced <br> 9 Hours</td>
<td style="text-align:center"><a href="https://acloud.guru/learn/aws-codedeploy">AWS CodeDeploy</a></td>
<td style="text-align:center">Pay</td>
<td style="text-align:center">Learn how to automate code deployments and achieve zero-downtime patching.</td>
</tr>
<tr>
<td style="text-align:center">Automating with AWS CodePipeline</td>
<td style="text-align:center">E-learning: Self Paced <br> 1.5 Hours</td>
<td style="text-align:center"><a href="https://videospace.nationwide.com/playlist/dedicated/93125981/1_m0s3pf6v/1_isnxs1ai">AWS CodePipeline</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to manage Automate your IAC using code pipelines.</td>
</tr>
<tr>
<td style="text-align:center">Deep Dive on S3 and Glacier</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1 Hour</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=SUWqDOnXeDw&amp;index=2&amp;list=PLmHFYKpCjiBOZ93-qZlB_AeV8DqAwsKh1&amp;t=0s">Deep Dive on S3 and Glacier</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to use storage management tools for end to end management of storage.</td>
</tr>

</tbody>
</table>


</p>
</details>

