---
category: "aws"
description: "These courses provide training for AWS certifications"
tags: [ "aws", "certifications" ]
draft: false
difficulty: 2
title: "AWS Certifications"
hoursEstimate: 4
contentType: technical
---

Below are some Certifications you can consider taking.
<details><summary>Certification Trainings</summary>
<p>

<h4 id="services">Basic Certifications</h4>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">AWS Certified Cloud Practitioner</td>
<td style="text-align:center">E-Learning: Self Paced <br> 5 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-cloud-practitioner">AWS Certified Cloud Practitioner</a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-cloud-practitioner/">AWS Certified Cloud Practitioner</a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>

<tr>
<td style="text-align:center">AWS Certified Solution Architect - Associate</td>
<td style="text-align:center">E-Learning: Self Paced <br> 22 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-solutions-architect-associate">AWS Certified Solution Architect - Associate</a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-solutions-architect-associate/">AWS Certified Solution Architect - Associate</a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>
<tr>
<td style="text-align:center">AWS Certified Developer - Associate</td>
<td style="text-align:center">E-Learning: Self Paced <br> 17 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-developer-associate-june-2018">AWS Certified Developer - Associate (June 2018)</a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-developer-associate/">AWS Certified Developer - Associate (June 2018)</a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>
</tbody>
</table>


<h4 id="services">Advanced Certifications</h4>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">AWS Certified Solution Architect - Professional</td>
<td style="text-align:center">E-Learning: Self Paced <br> 12 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-solutions-architect-professional">AWS Certified Solution Architect - Professional</a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-solutions-architect-professional/">AWS Certified Solution Architect - Professional</a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>
<tr>
<td style="text-align:center">AWS Certified DevOps Engineer - Professional</td>
<td style="text-align:center">E-Learning: Self Paced <br> 6 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-devops-engineer-professional">AWS Certified DevOps Engineer - Professional</a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-devops-engineer-professional/">AWS Certified DevOps Engineer - Professional</a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>
</tbody>
</table>



<h4 id="services">Specialty Certification</h4>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">AWS Certified Security - Specialty</td>
<td style="text-align:center">E-Learning: Self Paced <br> 9 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-security-specialty">AWS Certified Security - Specialty </a> <br> <strong>Certification:</strong> <a href="https://aws.amazon.com/certification/certified-security-specialty/">AWS Certified Security - Specialty </a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>
<tr>
<td style="text-align:center">AWS Big Data Specialty</td>
<td style="text-align:center">E-Learning: Self Paced <br> 12 Hours</td>
<td style="text-align:center"><strong>Training:</strong> <a href="https://acloud.guru/learn/aws-certified-big-data-specialty">AWS Big Data Specialty</a></td>
<td style="text-align:center">Free and Pay</td>
<td style="text-align:center">Provides training on the certification exam. You must pay to take the exam certification.</td>
</tr>
</tbody>
</table>
</p>
</details>


## Additional Resources
- [AWS Open Guide ](https://github.com/open-guides/og-aws/blob/master/README.md) **Free**
- [Free AWS Labs](https://aws.amazon.com/training/intro-to-aws-labs/) **Free**

