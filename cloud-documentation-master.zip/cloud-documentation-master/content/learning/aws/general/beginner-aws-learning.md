---
category: "aws"
description: "This course provides a training on commonly used AWS training such as S3, EC2, IAM, CloudWatch, RDS, CloudFormation and Lambda"
draft: false
difficulty: 1
title: "Beginner AWS Learning"
hoursEstimate: 14
contentType: technical
---


* **After getting a foundational understanding of AWS, you can take training on the most commonly used Services in AWS**
* **By the end of this step you will be have a good understanding of the most commonly use AWS Services and how to use them**
* **These are basic trainings that should be taken by anyone who will be building/supporting applications in AWS** 
* **Start at the first training in the table and work your way to the bottom**

<details><summary>Most Commonly Used Services</summary>
<p>
<table>
<thead>
<tr>
<th style="text-align:center">Course Name</th>
<th style="text-align:center">Method</th>
<th style="text-align:center">Training  Available</th>
<th style="text-align:center">Cost</th>
<th style="text-align:center">Description</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center">S3 for Beginners</td>
<td style="text-align:center">E-Learning: Self Paced <br> 1.5 Hours</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=XGcoeEyt2UM&amp;t=0s&amp;list=PLEiEAq2VkUULlNtIFhEQHo8gacvme35rz&amp;index=10">S3 for Beginners</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Understand cloud storage and types, and what S3 is (Simple Storage Service).</td>
</tr>
<tr>
<td style="text-align:center">User Security and Identity and Access Management</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/player?course=managing-aws-security-identity&author=brian-eiler&name=managing-aws-security-identity-m2&clip=0&mode=live">IAM</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn about DynamoDB; how the service works, leverage it, and avoiding pitfalls.</td>
</tr>
<tr>
<td style="text-align:center">EC2 for Beginners</td>
<td style="text-align:center">E-Learning: Self Paced <br> 22 Minutes</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=8TlukLu11Yo&amp;t=0s&amp;list=PLEiEAq2VkUULlNtIFhEQHo8gacvme35rz&amp;index=9">EC2 for Beginners</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Understand what is EC2, are the steps to create an EC2 instance, what is SNS and how to use it.</td>
</tr>
<tr>
<td style="text-align:center">CloudWatch for Beginners</td>
<td style="text-align:center">E-Learning: Self Paced <br> 30 Minutes</td>
<td style="text-align:center"><a href="https://www.youtube.com/watch?v=_Tqce6pGb44">AWS CloudWatch</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">This video will help you understand what is CloudWatch and how to use it.</td>
</tr>
<tr>
<td style="text-align:center">AWS Lambda</td>
<td style="text-align:center">E-Learning: Self Paced <br> 2 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-developer-introduction-aws-lambda/table-of-contents">AWS Lambda</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to build, deploy and manage scalable cloud services.</td>
</tr>
<tr>
<td style="text-align:center">Amazon RDS</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/player?course=amazon-web-services-databases-in-depth&author=richard-seroter&name=amazon-web-services-databases-in-depth-m2&clip=0&mode=live">Amazon RDS</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn about DynamoDB; how the service works, leverage it, and avoiding pitfalls.</td>
</tr>
<tr>
<td style="text-align:center">Getting Started with DynamoDB</td>
<td style="text-align:center">E-Learning: Self Paced <br> 3 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-dynamodb-getting-started/table-of-contents">DynamoDB</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn about DynamoDB; how the service works, leverage it, and avoiding pitfalls.</td>
</tr>
<tr>
<td style="text-align:center">Automating with AWS CloudFormation</td>
<td style="text-align:center">E-learning: Self Paced <br> 1.5 Hours</td>
<td style="text-align:center"><a href="https://app.pluralsight.com/library/courses/aws-automating-cloudformation/table-of-contents">AWS CloudFormantion</a></td>
<td style="text-align:center">Free</td>
<td style="text-align:center">Learn how to manage your infrastructure as code with hands-on labs.</td>
</tr>
</tbody>
</table>
</p>
</details>


