---
title: "Automating Manual Troubleshooting Strategies"
menu: blog
blogPost: true
draft: false
description: A technical look at how SRE is automating toil 
tags: ["sre"]
---

## The Problem

Are there common "stop the bleeding" techniques your team resorts to when responding to specific production alerts? An example of this would be restarting an application instance as a known strategy to combat a P0 when a specific log message can be found - the equivalent of turning the lightswitch off and then on again when you see the lightswitch blinking.   

You are not alone! This is a common tactic when trying to quickly restore service of an application. There are two common issues with these behaviors:  
1. When service is restored, the underlying problem is often not investigated as the on call individual moves on to the next problem. 
2. There is added time to restore service since this workflow is reliant on an individual recieving a ticket, reading the associated information, determining that the "stop the bleeding" strategy can be used and implementing that strategy (and performing the associated post mortem). Additionally, this may cause a context switch for the on call individual, or even worse, this known incident may occur in the middle of the night, or during a birthday party.  

This blog post will deal with addressing issue 2: automating manual remediation tactics. Of course, the best course of action is to determine and resolve the underlying source of the incident, but automating these manual steps is often a quick and easy way to address a recurring incident until the underlying problem can be addressed. Please see [this post mortem reading](https://landing.google.com/sre/sre-book/chapters/postmortem-culture/) for further information on how to use post mortems to identify and resolve root causes of incidents. 

Below is an example of resolving an incident with a "stop the bleeding" technique through automation rather than manual intervention. The team in question is the iMedia operations team, who would first try restarting an application instance when recieving a Splunk alert that the following log message had been found: "UNAVAILABLE for connection (please try again)", indicated a DB connectivity issue.

## The Solution  
  
If the fix is the same everytime, why not take human intervention out of it? Even if it doesn't fix the problem, you can rule out a few issues even before on call has to intervene.

In this case, all we needed to do was write a bash script that restarts the instance everytime Splunk sends this alert. The hard part was going to be figuring out where to run this script and how to kick it off with the proper information about the instance to restart. 

Of note, this is just one example of how this framework can be used. It is flexible to many coding languages and scenarios. A basic diagram explanation is shown below.

![](RASimple.png)

## How it's implemented
Our solution has a few steps, first the Splunk alert sends an HTTP POST to a webhook, this webhook is connected to a Lambda function that parses the log event and then kicks off a CodeBuild job that runs the bash script to restart the instance. For all of this to work, we had to create an Application Load Balancer as a webhook. This Load Balancer, when hit, forwards the data onto the Lambda, which then calls Splunk to get all of instances that need to be restarted (more details about this in the Challenges section below). 

- Splunk Alert
    ```bash
    index=pcf cf_space_name=perf cf_app_name=*-ssc-web cf_org_name=iMedia "UNAVAILABLE for connection \(please try again\)" 
    ```
    This is the Splunk Query that the alert was created off of. This query is run every 15 minutes and if any results are returned, Splunk will POST to the custom webhook.

- Webhook Load Balancer  

    The CloudFormation for deploying the LoadBalancer that is acting as a webhook is given [here](https://github.nwie.net/Nationwide/SplunkAlertTestLambda/blob/master/serverless.yml#L26). A LoadBalancer, Certificate, CNAME, Security Group, and default HTTPListener are created in this file (currently using a Serverless deployment). 

- Lambda Function  

    In the same [file](https://github.nwie.net/Nationwide/SplunkAlertTestLambda/blob/master/serverless.yml#L287) the Lambda Function is also deployed. An important property of this is the alb event property. This allows you to specify the path on the ALB, that when hit, will kick off this Lambda. In this case, the path is /deleteInstance. 

    The lambda function runs this [code](https://github.nwie.net/Nationwide/SplunkAlertTestLambda/blob/master/Control/handler.py), but can be changed to do any necessary functionality. In our case, it queries and parses Splunk logs. The query is the same as the Splunk Alert and is given below.

    ```python
    service = client.connect(
        host=HOST,   # NHPLT0010.nwie.net
        port=PORT,   # 8089
        username=USERNAME,  # Shortname
        password=PASSWORD) # Password - this is retrieved from the AWS Parameter Store, this value should not be hardcoded


    kwargs_oneshot = {"earliest_time": "-15m",
                    "latest_time": "now",
                    "execmode": "normal", 
                    "count" : 10000}

    searchquery_oneshot = "search index=pcf cf_space_name=perf cf_app_name=*-ssc-web cf_org_name=iMedia \"UNAVAILABLE for connection \(please try again\)\""

    oneshotsearch_results = service.jobs.oneshot(searchquery_oneshot, **kwargs_oneshot)
    reader = results.ResultsReader(oneshotsearch_results)
    ```

    Once the returned results are parsed, the CodeBuild job is invoked and the data is passed over as an environment variable. 
    ```python
    cb = boto3.client( 'codebuild' )

    # Set the custom environment variable
    build = {
        'projectName': 'imediacbauto-IAS01-auto-us-east-1',
        'environmentVariablesOverride': [
            {
                'name': 'TEST_ARRAY',
                'value': json.dumps(items_to_restart)
            }
        ],
    }

    # Start codebuild job
    cb.start_build( **build )
    ```

- CodeBuild Job  

   The CodeBuild deployment is currently in a separate [CodePipeline](https://github.nwie.net/Nationwide/iMedia-automation-codebuild). The buildspec-codebuild.yaml is the important file because it contains the bash code that gets run when the CodeBuild job is started. First, it installs the CF CLI. The preferred way of installing the CF CLI is blocked in our AWS environment so our current workaround is to store the tar installer with the codebuild files. Next in the script, it logs into the CF CLI, and then goes through each item of the instance array passed over from lambda and restarts them one by one.
   ```yaml
   build:
    commands:
      #  Get password from parameter store
      - pass=$(aws ssm get-parameter --name iMediaSplunkPass --with-decryption | jq .Parameter.Value)
      # Parse out the cf space to log into from the Splunk data.
      - cf_space_name=$(echo "$TEST_ARRAY" | jq -c '.[0].cf_space_name')
      - echo $cf_space_name
      # Login CF
      - cf login -a https://api.sys.testpcf.nwie.net -u USERNAME -p $pass -s $cf_space_name         --skip-ssl-validation 
      # Go through each item from the Splunk data array
      - for row in $(echo "$TEST_ARRAY" | jq -c '.[]'); do
            cf_app_name=$(echo "$row" | jq -r '.cf_app_name');
            echo $cf_app_name;
            source_instance=$(echo "$row" | jq -r '.source_instance');
            echo $source_instance;
            # Restart the relevant instance
            cf restart-app-instance $cf_app_name $source_instance;
          done
      - echo "Done"
   ```

## Challenges
Originally, we used the Lambda function to parse the data Splunk sent over when it hit the webhook. We found that this only sent over the first log event of the error occuring, so we would be missing all other instances if there were multiple that were getting this error and needed to be restarted. To fix this, instead of parsing the data that Splunk sent over in the HTTP POST from hitting the webhook, the Lambda calls the Splunk API and gets all log events that occured in the past 15 minutes. This set of data will contain any instances that need to be restarted, so all that's left to do is parse out the instance IDs and send them over to the restart script. 

## Next steps
Currently, the automation steps are deployed in a combination of two pipelines, one using the Serverless framework and one using AWS CodePipeline, as well as a few manual steps. These two pipelines need to be combined and all manual deployment steps need to be automated. Once this is done, this automation framework can be reused by any application that has processes that can be automated in response to errors and alerts. 

Another nice thing to have moving forward would be generic ids for authenticating to Splunk and the CF CLI. This way there would be improved security and the calls would not be tied to a user. 

## Repos
- [ALB and Lambda using the Serverless Framework](https://github.nwie.net/Nationwide/SplunkAlertTestLambda)
- [CodePipeline CodeBuild deployment](https://github.nwie.net/Nationwide/iMedia-automation-codebuild)
