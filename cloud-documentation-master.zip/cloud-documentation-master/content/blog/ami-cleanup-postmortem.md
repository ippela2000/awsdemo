---
title: "Postmortem: Deletion of AMI's and Snapshots within InfraSvcsProd."
menu: blog
blogPost: true
draft: false
description: Postmortem outlining the details of the incidents involving the deletion of AMI's and Snapshots from the InfraSvcsProd account. Includes action items of what is being looked at to prevent this issue from happening going forward.
tags: ["sre", "postmortem", "AMI", "incident"]
---

# Deletion of AMI's and snapshots within InfraSvcsProd

## Date

August 12th, 2020

## Authors

Kevin Aprahamian

## Status

[In Progress](https://github.nwie.net/Nationwide/CloudSuccessTeam/issues/405)

## Summary

The cloud optimization team submitted a [support request](https://gocloud.nwie.net/support/cloud-support/guaranteed-support/#guaranteed-support) around cleaning up around 8,000 snapshots within the InfraSvcsProd account. To cleanup the snapshots, you need to also delete the AMIs (Amazon Machine Image) from the account that the snapshots are in if they belong to an AMI. When an automated script deleted the AMIs, this caused problems with currently running EC2s within other accounts that might have been dependent on those particular AMIs. A security responder was not being able to validate the AMI, so it stopped those EC2s.  Further, the responder prevented EC2s from starting after their nightly shutdown. Pipelines dependent on foundational AMIs also experienced redeployment issues because these AMIs no longer existed.

## Impact

* Pipelines that were dependent on those AMI's would fail based off of the AMI not existing
* Stopped EC2 instances were not able to start due to not seeing the AMI as approved to be used
* Autoscaling groups might not have been able to scale because the AMI was no longer approved or available.

## Contributing causes

* Foundational AMI's are not protected
* AMI's and Snapshots not validated if they were in use

## Trigger

* An automated cleanup of old AMI's and snapshots was ran against the InfraSvcsProd account to save on cost, and remove tech debt from within the account.
  * https://github.nwie.net/Nationwide/IO-Engagement/issues/416

## Resolution

* All of the Pet EC2 instances had to be added to an exception list by a member of Cloud Security Engineering
* Teams that could run their pipelines had to rerun and rebuild their instances

## Detection

* Teams noticed Instances not starting up after autoshutdown processes
  * Trying an to start an unapproved AMI
  * EC2 instance cannot find AMI information
* Teams running pipelines noticed failures based off of unapproved or nonexistent AMIs
* Affected areas directly notified Cloud team members


## Action items

| Action Item | Type |  Issue |
| ----------- | ---- | --- |
| Standardize Snapshot and AMI cleanup process | Process |  https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/4764 |
| Establish deletion process | Process/Prevention |  https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/4765 |
| Cleanup instance ID exceptions | Cleanup | https://github.nwie.net/Nationwide/Next-Gen-Infra/issues/4766  |

## Lessons learned

### What went well

* Process in place to add instance ID's as exceptions to mitigate the problems
* Database team has an inventory of all impacted EC2 instances

### What went wrong

* Validation of the AMI/Snapshot before deletion 
* Is an RFC for this process needed for these types of cleanups going forward


### Where we got lucky

* CSE looking into vulnerabilities and able to see the majority of affected EC2s
* The timing of this happening. Happened during the day and everyone was available
* Cleaned up InfraSvcsProd only and not Tools accounts

## Timeline

| Time  | Description |
| ----- | ----------- |
| July 23rd, 2020 | [Deletion Request Submitted](https://github.nwie.net/Nationwide/IO-Engagement/issues/416)  |
| August 4th, 2020 | Clean up process run against InfraSvcsProd account|
| August 5th, 2020| EC2 instances are not starting up properly due to not being an approved AMI|
| August 5th, 2020|  Pipelines fail to run based off of missing AMI's that are used |
| August 5th, 2020| CSE and Cloud Success team notified of issues with EC2 instances and pipelines|
| August 5th, 2020| CSE adds Instance IDs to exceptions so they can start up based off of CSE and Database teams data|

Timeline of events above should be correct, do not have specific times of when individual items happened.

## Supporting information

* https://onyourside.sharepoint.com/sites/ServiceManagementGovernance/SitePages/IT-Change-Management.aspx
* https://github.nwie.net/robeaj1/AMICleanup
