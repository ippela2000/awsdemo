---
title: "Using S3 Pre-Signed URLs"
menu: blog
blogPost: true
draft: false
description: Pre-Signed URLs give the ability to access, for a period of time specific content in a bucket without making the bucket public. 
tags: ["s3"]
---

## Why do we use Pre-Signed URLs

At Nationwide all S3 buckets are private. Using [Pre-Signed URLs](https://docs.aws.amazon.com/AmazonS3/latest/dev/ShareObjectPreSignedURL.html) gives the ability to access for a period of time specific content in a bucket without making the bucket public. 

## Prerequisite

* You have a [Nationwide AWS account](https://gocloud.nwie.net/docs/aws/getting-started-with-aws/access-to-aws/)
* You have the [Nationwide AWS federator](https://github.nwie.net/Nationwide/aws-federator/blob/master/README.md) to generate the credential
* You are familiar with IAM Roles and Policies and S3 service and permissions in S3
* You are familiar with [AWS SDK for Java](https://docs.aws.amazon.com/sdk-for-java/v2/developer-guide/welcome.html)


## Implementing Pre-Signed URLs

A POC was done with the eb2b team. There are many way to generate a pre-signed url, in the POC we used the AWS SDK for Java. 

[The eb2b cloud migration blog page](https://onyourside.sharepoint.com/sites/nfit-eb2b-suite/eB2B-Technical-Support/CloudMigBlog/Lists/Posts/Post.aspx?ID=53) has the details on the implementation.
