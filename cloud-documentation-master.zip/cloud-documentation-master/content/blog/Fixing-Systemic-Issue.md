---
title: "Fixing Systemic Issues Within an Application."
menu: blog
blogPost: true
draft: false
description: Why spending a couple of days fixing an applications underlying problems can create a more reliable application for our members, as well as reduce on-call toil for our Rapid Response and on-call associates.
tags: ["sre"]
---

## Backstory

On July 2nd, the Cloud Infrastructure Engineering team was paged out to help a team whose application (ESS UAC) had triggered a P0. The ESS UAC EC2 instance had terminated due to a failed health check. Because the team was using an Auto Scaling group, a new EC2 instance was created. Unfortunately, the new instance failed to start their application with the following error:

```text
[stdout]Jul 7, 2020 20:29:51 +0000 [2595 1] com.newrelic INFO: Using default collector host: collector.newrelic.com
[stdout]Jul 7, 2020 20:29:51 +0000 [2595 1] com.newrelic INFO: New Relic Agent: Writing to log file: /webdata/mwshared/probes/newrelic/install/logs/newrelic_agent.log
[stderr]Jul 07, 2020 8:30:06 PM org.apache.catalina.startup.Catalina stopServer
[stderr]SEVERE: Could not contact [localhost:8005] (base port [8005] and offset [0]). Tomcat may not be running.
[stderr]Jul 07, 2020 8:30:06 PM org.apache.catalina.startup.Catalina stopServer
[stderr]SEVERE: Error stopping Catalina
[stderr]java.net.ConnectException: Connection refused (Connection refused)
[stderr] at java.net.PlainSocketImpl.socketConnect(Native Method)
[stderr] at java.net.AbstractPlainSocketImpl.doConnect(AbstractPlainSocketImpl.java:350)
[stderr] at java.net.AbstractPlainSocketImpl.connectToAddress(AbstractPlainSocketImpl.java:206)
[stderr] at java.net.AbstractPlainSocketImpl.connect(AbstractPlainSocketImpl.java:188)
[stderr] at java.net.SocksSocketImpl.connect(SocksSocketImpl.java:392)
[stderr] at java.net.Socket.connect(Socket.java:607)
[stderr] at java.net.Socket.connect(Socket.java:556)
[stderr] at java.net.Socket.<init>(Socket.java:452)
[stderr] at java.net.Socket.<init>(Socket.java:229)
[stderr] at org.apache.catalina.startup.Catalina.stopServer(Catalina.java:513)
[stderr] at sun.reflect.NativeMethodAccessorImpl.invoke0(Native Method)
[stderr] at sun.reflect.NativeMethodAccessorImpl.invoke(NativeMethodAccessorImpl.java:62)
[stderr] at sun.reflect.DelegatingMethodAccessorImpl.invoke(DelegatingMethodAccessorImpl.java:43)
[stderr] at java.lang.reflect.Method.invoke(Method.java:498)
[stderr] at org.apache.catalina.startup.Bootstrap.stopServer(Bootstrap.java:389)
[stderr] at org.apache.catalina.startup.Bootstrap.main(Bootstrap.java:479)
[stderr]
[stderr]cp: target ‘/opt/mw/tomcat90/webapps/nes-login/WEB-INF/classes/’ is not a directory
```

The team solved their problem through rerunning their AWS CodePipeline. It seemed that the issue only occurred when the instance was terminated and recreated, and did not occur through a regular deployment via their pipeline. The deployment pipeline took about 90 minutes to resolve the problem because the pipeline required deployments to their Dev, Test and Prod environments. It should also be noted that the ESS UAC application is a gateway to several other (20+) applications, so these applications were also impacting and waiting for this issue to resolve. 

On July 7th, 2020 the same issue occurs. This time, the SRE team was brought in to help with this frequently recurring problem. 

## Troubleshooting

Based off of the log that is shown above, we could see a few things that were happening.

* As a part of their deployment script, they were initially stopping Tomcat
    * Tomcat is configured to startup on instance startup, so for their application they needed to stop Tomcat to apply their necessary configurations.
* After stopping Tomcat it would try and copy property files based off of environments to their respective folder in the /tomcat90/webapps location

So our assumption was that it was a timing issue where the initial deployment gives more time for the Auto Scaling group and instance to become available before their pipeline kicks off of the deployment process in CodeDeploy. This initial time isn't given when a new instance starts up as a part of a termination and scale up within the autoscaling group. 

A few ideas that were thrown around:

* Should we add a delay or wait to the Tomcat stop?
* Should we have just a while loop to check for when Tomcat is started and then when it is just execute a stop?

These would have probably fixed the problem, but one of the Site Reliability Engineers (Kim Boydstun) called out updating the way their application is deployed out to not need the property files to be copied to a directory in Tomcat.

This would take modifying their applications context.xml:

```XML
    <Resources className="org.apache.catalina.webresources.StandardRoot">
        <PreResources className="org.apache.catalina.webresources.DirResourceSet"
            base="{Path To Properties}"
            webAppMount="/WEB-INF/classes" />
    </Resources>
```

This allows their application to function without needing their war file to be unpacked beforehand, so as apart of their deployment instead of having the following:

1. Instance is started
    * Tomcat is started with the instance unpacking their war file
2. Stop Tomcat
3. Copy property files and set java options
4. Start Tomcat

It could be simplified to the following:

1. Configure Tomcat to not startup by default (one time change)
2. Set Java options
3. Start Tomcat

This solution removes the timing issue that was happening with Tomcat, cuts back on the need for starting and stopping Tomcat, as well as cuts back on the need of moving files between directories for their deployment.

These changes were added to their pipeline within AWS, tested and validated, and were deployed into their production environment on July 9th, 2020 - just two days after the last incident had occurred. This will allow the application to recover correctly from healthcheck failures through autoscaling and automated deployments in less than 5 minutes. This solves a systemic issue of the application that had happened multiple of times before, with 90+ minute outages.

## Going One Step Further

They brought up that as apart of their production deployment they had to normally restart a service manually after everything had been deployed out. As apart of that same July 9th release, we were able to provide a fix for them so that they would not need any manual intervention with their deployments or instances.

Documentation was created on how they can run and update their pipeline to only deploy to the production environment if they did need to do a full redeployment due to an issue. This will significantly cut down on the time that would be required (90 minutes down to less than 30 minutes).

The final piece was adding some monitoring for their environment. Since the application could potentially fix itself within a couple of minutes with the changes put in place they wanted to be notified with a lower priority ticket of an instance being terminated so they could go back and fix any issue that might of caused the termination to happen. This was accomplished by using Auto Scaling metrics, Cloudwatch alarms, and lambda function that translated the Cloudwatch Alarm to a ServiceNow incident.

As a part of their Auto Scaling group creation we enabled a metric to be collected every 1 minute for GroupTerminatingInstances. This metric shows how many instances were terminated in a given period.

```YAML
  rAutoScalingGroup:
    Type: AWS::AutoScaling::AutoScalingGroup
    Properties:
      VPCZoneIdentifier:
        - !ImportValue oPrivateSubnetA
        - !ImportValue oPrivateSubnetB
        - !ImportValue oPrivateSubnetC
      LaunchConfigurationName: !Ref rLaunchConfig
      DesiredCapacity: !Ref pDesiredCapacity
      MinSize: !Ref pMinInstances
      MaxSize: !Ref pMaxInstances
      HealthCheckGracePeriod: 300
      MetricsCollection:
        - Granularity: "1Minute"
          Metrics:
          - "GroupTerminatingInstances"
      TargetGroupARNs:
        - !Ref rTargetGroup
```

We can then setup a [Cloudwatch alarm to trigger an incident in ServiceNow](https://gocloud.nwie.net/docs/general/monitoring-alterting/howto_cloudwatch-to-snow/)

```YAML
  rCloudwatchAlarmTerminatedInstances:
    Type: AWS::CloudWatch::Alarm
    Properties:
      AlarmDescription: !Sub "${pCIName},${pTerminatedInstancesSeverity},${pTerminatedInstancesPriority},${pAssignmentGroup}"
      AlarmName: !Sub ${pTerminatedInstancesAlarm}
      AlarmActions:  
        - !Sub "arn:aws:sns:us-east-1:${AWS::AccountId}:${pSNSTopicName}"
      Namespace: AWS/AutoScaling
      MetricName: GroupTerminatingInstances
      Statistic: Sum
      Period: 60
      ComparisonOperator: GreaterThanThreshold
      EvaluationPeriods: 1
      Threshold: 0
      Dimensions:
      - Name: AutoScalingGroupName
        Value: !Ref rAutoScalingGroup
```

This alarm will check the number of instances terminated in a 1 minute period based off of their Auto Scaling group. If the count is ever above 0, this will cut a P2 ticket to their assignment group so that they can take a look to see why the instance was terminated. Note that the ticket didn't need to be a P0 or a P1 since it will fix itself, it is used to add an item to their queue to investigate.

## Shoutouts

I wanted to specifically call out the ESS UAC application area (Jason Dignan, Ouafae Kaddouri) and their leader, Sherilyn Janson, for being great collaborators through all of this. The Solutions Engineering team and specifically Craig Chakford. The Cloud Infrastructure Engineering team (Travis Ratcliff and Mike Jin). Also my fellow Site Reliability Engineers on this (Kim Boydstun, Jeff Robeano).
