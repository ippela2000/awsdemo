---
title: "Introducing Chaos Engineering at Nationwide!"
menu: blog
blogPost: true
draft: false
description: Introducing Chaos Engineering at Nationwide!
tags: ["sre"]
---

## Chaos Engineering

Chaos Engineering is the practice of experimentally injecting failure into live production systems to prove that the system is resilient to unexpected conditions and pertubations. It is especially useful for testing emergent behavior of complex systems under load, which can be difficult or impossible to test in pre-production environments.

Common experiments include terminating nodes, removing all nodes in an availability zone, injecting latency or errors, and artifically saturating server resources (e.g. CPU).

## Chaos Toolkit

Chaos Toolkit is an open source project for Chaos Engineering. The [core](https://github.com/chaostoolkit/chaostoolkit) module provides basic functionality to define experiments, while additional packages like [chaostoolkit-aws](chaostoolkit-aws) provide functionality for testing specific services.

Chaos experiments are defined in YAML or JSON. Every experiment begins by testing if the steady-state hypothesis is true, to ensure the system is in a known good state before conducting the experiment. Then, as the experiment steps are run, probes are used to validate that the system is still performing to expectations. Finally, an optional rollback step can restore the system to its original state.

## Example

Here is an example of a simple chaos experiment which removes all instances from an autoscaling group in a given availability zone, to verify that the application remains available and autonomously recovers from the failure.

``` YAML
title: 'What is the impact of removing an AZ from my autoscaling group?'
description: 'If an AZ is removed from my autoscaling group, traffic will be served from instances in other AZs.'
version: 1.0.0
configuration:
    aws_profile_name: default
    aws_region: us-east-1
steady-state-hypothesis:
    title: 'Application serves traffic from healthy instances.'
    probes:
        -
            type: probe
            name: we-can-access-application
            tolerance: 200
            provider:
                type: http
                timeout: 3
                verify_tls: false
                url: http://pwc-Chaos-Test-Alpha.aws.e1.nwie.net:6001
method:
    -
        name: remove-AZ
        provider:
            arguments:
                asg_names:
                  - pwc-chaos-test-WorkerScalingGroup-21T330YYFBQK
                  - pwc-chaos-test-GatewayScalingGroup-1IIQBBV8DZJFS
                  - pwc-chaos-test-MasterScalingGroup-UYUBOTZZAIJM
                subnets:
                  - subnet-04dd441cd6a9ef076 #These are the subenets we want to keep. Subnets not listed here will be the ones removed
                  - subnet-09758ab256d587157
            func: change_subnets
            module: chaosaws.asg.actions
            type: python
        pauses:
            after: 600
        type: action
rollbacks: #WARNING, rollback only occurs on a successful test completing.
           #If the Test fails and exits, then there are no automatic rollbacks to restore the subnets listed below.
    -
        name: restore-AZ
        provider:
            arguments:
                asg_names:
                  - pwc-chaos-test-WorkerScalingGroup-21T330YYFBQK
                  - pwc-chaos-test-GatewayScalingGroup-1IIQBBV8DZJFS
                  - pwc-chaos-test-MasterScalingGroup-UYUBOTZZAIJM
                subnets:
                  - subnet-0b51818318f5f5968
                  - subnet-04dd441cd6a9ef076
                  - subnet-09758ab256d587157 #bring back the subnet that was not listed above, and was removed during the test.
            func: change_subnets
            module: chaosaws.asg.actions
            type: python
        type: action
```

A successful test report looks like this:

```JSON
{
  "start": "2020-07-08T21:59:41.935233",
  "status": "completed",
  "deviated": false,
  "steady_states": {
    "before": {
      "steady_state_met": true,
      "probes": [
        {
          "activity": {
            "type": "probe",
            "name": "we-can-access-application",
            "tolerance": 200,
            "provider": {
              "type": "http",
              "timeout": 3,
              "verify_tls": false,
              "url": "http://pwc-Chaos-Test-Alpha.aws.e1.nwie.net:6001"
            }
          },
          "output": {
            "status": 200,
            "headers": {
              "Accept-Ranges": "bytes",
              "ETag": "W/\"107-1533328362000\"",
              "Last-Modified": "Fri, 03 Aug 2018 20:32:42 GMT",
              "Content-Type": "text/html",
              "Content-Length": "107",
              "Date": "Wed, 08 Jul 2020 21:59:42 GMT",
              "Server": "Informatica"
            },
            "body": "<html>\n\n<head>\n<meta http-equiv=\"refresh\" content=\"0; URL=/coreservices/\">\n</head>\n\n<body>\n</body>\n\n</html>"
          },
          "status": "succeeded",
          "start": "2020-07-08T21:59:41.937230",
          "end": "2020-07-08T21:59:42.224229",
          "duration": 0.286999,
          "tolerance_met": true
        }
      ]
    },
    "after": {
      "steady_state_met": true,
      "probes": [
        {
          "activity": {
            "type": "probe",
            "name": "we-can-access-application",
            "tolerance": 200,
            "provider": {
              "type": "http",
              "timeout": 3,
              "verify_tls": false,
              "url": "http://pwc-Chaos-Test-Alpha.aws.e1.nwie.net:6001"
            }
          },
          "output": {
            "status": 200,
            "headers": {
              "Accept-Ranges": "bytes",
              "ETag": "W/\"107-1533328362000\"",
              "Last-Modified": "Fri, 03 Aug 2018 20:32:42 GMT",
              "Content-Type": "text/html",
              "Content-Length": "107",
              "Date": "Wed, 08 Jul 2020 22:09:44 GMT",
              "Server": "Informatica"
            },
            "body": "<html>\n\n<head>\n<meta http-equiv=\"refresh\" content=\"0; URL=/coreservices/\">\n</head>\n\n<body>\n</body>\n\n</html>"
          },
          "status": "succeeded",
          "start": "2020-07-08T22:09:44.490081",
          "end": "2020-07-08T22:09:44.787070",
          "duration": 0.296989,
          "tolerance_met": true
        }
      ]
    }
  },
  "run": [
    {
      "activity": {
        "name": "remove-AZ",
        "provider": {
          "arguments": {
            "asg_names": [
              "pwc-chaos-test-WorkerScalingGroup-21T330YYFBQK",
              "pwc-chaos-test-GatewayScalingGroup-1IIQBBV8DZJFS",
              "pwc-chaos-test-MasterScalingGroup-UYUBOTZZAIJM"
            ],
            "subnets": [
              "subnet-04dd441cd6a9ef076",
              "subnet-09758ab256d587157"
            ]
          },
          "func": "change_subnets",
          "module": "chaosaws.asg.actions",
          "type": "python"
        },
        "pauses": {
          "after": 600
        },
        "type": "action"
      },
      "output": null,
      "status": "succeeded",
      "start": "2020-07-08T21:59:42.226241",
      "end": "2020-07-08T21:59:44.487505",
      "duration": 2.261264
    }
  ],
  "rollbacks": [
    {
      "activity": {
        "name": "restore-AZ",
        "provider": {
          "arguments": {
            "asg_names": [
              "pwc-chaos-test-WorkerScalingGroup-21T330YYFBQK",
              "pwc-chaos-test-GatewayScalingGroup-1IIQBBV8DZJFS",
              "pwc-chaos-test-MasterScalingGroup-UYUBOTZZAIJM"
            ],
            "subnets": [
              "subnet-0b51818318f5f5968",
              "subnet-04dd441cd6a9ef076",
              "subnet-09758ab256d587157"
            ]
          },
          "func": "change_subnets",
          "module": "chaosaws.asg.actions",
          "type": "python"
        },
        "type": "action"
      },
      "output": null,
      "status": "succeeded",
      "start": "2020-07-08T22:09:44.792099",
      "end": "2020-07-08T22:09:46.906975",
      "duration": 2.114876
    }
  ],
  "end": "2020-07-08T22:09:46.906975",
  "duration": 604.9737465381622
}
```

## Contributing

To get started with Chaos Engineering or to contribute your test scenarios, check out the [ChaosWorkshop](https://github.nwie.net/Nationwide/ChaosWorkshop) repository. Please create issues and pull requests with anything you would like to contribute!
