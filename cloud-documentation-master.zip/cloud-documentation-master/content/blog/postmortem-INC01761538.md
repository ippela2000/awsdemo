---
title: "Postmortem: IAM Authorization Center - MFA failed for RSC application"
menu: blog
blogPost: true
draft: false
description: Postmortem of an incident where some users were unable to receive an MFA challenge. This prevented them from logging in.
tags: ["sre", "postmortem"]
---

## Date

04/30/2020

## Author(s)

Andrew Seling

## Status

a Complete

## Summary

Some users are unable to receive an MFA challenge. This can prevent them from logging in.

The origin of the issue is unknown, but we believe there is a link to cookie handling between RSC and some browsers. As part of the login flow, RSC passes a `deviceToken` to IAM in multiple, sequential calls. With each call, IAM updates the `deviceToken` and returns the updated value for RSC to pass in the subsequent call.

LoginSubmitAction.java (i.e. clicking the log-in button) passes 'deviceToken' as a cookie  and ContactSelectionSubmitAction.java (i.e. requesting an MFA challenge token). In most instances, this operates as intended.

In some instances, we believe the `deviceToken` cookie is not updated in the browser during the execution of the login process. When the MFA challenge process retrieves this cookie and submits it to IAM to obtain a challenge code, IAM returns an error and the login process fails.

iMedia has opened defect (263820) to address this issue, possibly by refactoring the login/challenge flow to avoid using cookies to pass internal `deviceToken` values.

## Impact

Some users are unable to receive an MFA challenge. This can prevent them from logging in. Based on Splunk searches, this issue impacted approximately 500 unique users on May 19 2020. The issue impacted approximately 1,100 unique users between 5/10 and 5/17, and approximately 4000 unique users year to date.

## Contributing causes

1. As part of the login flow, RSC passes a `deviceToken` to IAM in multiple, sequential calls. With each call, IAM updates the `deviceToken` and returns the updated value, which RSC passes back to IAM in the subsequent call.

LoginSubmitAction.java (i.e. clicking the log-in button) passes 'deviceToken' as a cookie  and ContactSelectionSubmitAction.java (i.e. requesting an MFA challenge token). In most instances, this operates as intended.

    In some instances, we believe the `deviceToken` cookie is not updated in the browser during the execution of the login process. When the MFA challenge process retrieves this cookie and submits it to IAM to obtain a challenge code, IAM returns an error and the login process fails.

## Trigger

Unknown

## Resolution

Defect 263820 opened.

## Detection

Reported by [customer](https://www.opinionlab.com) via email using [fullstory](https://app.fullstory.com/ui/RK0FN/session/5577871114649600:5215138263351296:1588180288067:6501968552148992/).

## Action items

| Action Item | Type |  Issue |
| ----------- | ---- | --- |
| Investigate & Resolve Defect | Prevent | 263820 |
| Send error to New Relic when getConfirmationToken() fails to return a token | Detect | 263820 |
| Ensure SRE can build/run RSC on their laptops | Mitigate | [121](https://github.nwie.net/Nationwide/imedia-ops/issues/121) |
| Add Apigee to New Relic distributed tracing | Detect | [2131](https://github.nwie.net/Nationwide/Devopstronauts/issues/2131) |
| Investigate if SME team is seeing customer complaints from this issue| Detect | [122](https://github.nwie.net/Nationwide/imedia-ops/issues/122)
| Identify how IAM team was communicating to iMedia about expired tokens and if this needs enhanced | Detect | [123](https://github.nwie.net/Nationwide/imedia-ops/issues/123)

## Lessons learned

### What went well

1. Good collaboration between Nationwide Technology teams to investigate the issue.

### What went wrong

1. We were manually alerted by the customer, rather than by our monitoring.
2. SRE was not able to build and run RSC on their laptop, delaying confirmation of bug details until an iMedia resource was available to assist.
3. The issue had been impacting users for at least several months before detailed investigation began.
4. Distributed tracing for RSC terminates at the call to IAM-WS, requiring lots of manual correlation of logs between different systems to understand the full flow of the request.

### Where we got lucky

1. Customer reached out to notify us of the issue.

## Timeline

| Time  | Description |
| ----- | ----------- |
| 04/30/2020|         |
| 13:57 |User DONK3555 impacted|
| 14:51 |[INC01761538](https://nwproduction.service-now.com/nav_to.do?uri=%2Fincident.do%3Fsys_id%3D96c12d741b2c9c5085510d87cc4bcb80%26sysparm_view%3Dtext_search) created & assigned to EIM-DEVOPS|
|15:21|Transferred from EIM-DEVOPS to IAM-Support-Access|
|05/01/2020| |
|11:28|Transferred to NF-IMEDIA-WSPT with guidance from IAM-Support-Access|
|05/04/2020| |
|14:09|Possible bug identified by SRE & IAM-Support-Access|
|05/07/2020| |
|15:19| Probable bug isolated by SRE & iMedia|
|16:15| Requested creation of new defect |
|5/07/2020|  |
|15:45| Defect 263820 opened|
|5/11/2020|
|12:42| Incident resolved |

## Supporting information

[FullStory](https://fsty.io/v/SLdUtte) for DONK3555

[GitHub Issue](https://github.nwie.net/Nationwide/rsc-web/issues/1569)

Request flow for generating MFA token. The `deviceToken` cookie is set in **loginSubmitAction.jsp** and retrieved from the browser cookie store in [this call](https://github.nwie.net/Nationwide/rsc-web/blob/62b5763dcc8cf511e755ab5eba6dad2400236419/src/main/java/com/nationwide/nf/rscweb/user/access/challenge/ContactSelectionSubmitAction.java#L164). It is then submitted through the following flow. **If `deviceToken` has expired, an error will result, otherwise, the response will be successful.**

1. User selects device to send MFA challenge to from [ContactSelection.jsp](https://github.nwie.net/Nationwide/rsc-web/blob/f4d66d2a02f0a30384c4f84c11b0cad6bf780cbb/webapp/WEB-INF/icm/jspf/access/challenge/contactSelection.jsp)
2. Struts [routes](https://github.nwie.net/Nationwide/rsc-web/blob/d2cb36362adb601dcec8bcd247fdbf595643bbbb/src/main/resources/struts-config/plansponsor/ps-access-struts.xml#L91-L97) the request to [ContactSelectionSubmitAction.java](https://github.nwie.net/Nationwide/rsc-web/blob/62b5763dcc8cf511e755ab5eba6dad2400236419/src/main/java/com/nationwide/nf/rscweb/user/access/challenge/ContactSelectionSubmitAction.java#L88-L105).
3. In ContactSelectionSubmitAction.java, validate() calls getConfirmationCode().
4. getConfirmationCode() calls getMfaDeviceParameters() to obtain devicePrint or deviceToken, as well as IpAddress.
5. getMfaDeviceParameters() then calls IAM backend via [UserManagementService](https://github.nwie.net/Nationwide/rsc-web/blob/de3e845b0a2b631dd18a2dd66c5c38f648f3b71e/src/main/java/com/nationwide/nf/rscweb/user/access/UserManagementService.java), [IAMMultiFactorDeviceResult](https://github.nwie.net/Nationwide/iam-business-services/blob/4b91350aade6db9da89f5f5015d9cb840c6d94ec/src/main/java/com/nationwide/nf/iam/service/rest/IAMRestfulServiceAdapterImpl.java#L288-L293), [JSONUserRequest](https://github.nwie.net/Nationwide/iam-business-services/blob/4b91350aade6db9da89f5f5015d9cb840c6d94ec/src/main/java/com/nationwide/nf/iam/service/rest/IAMRequestFormatter.java#L389-L401), and iam-ws. RSC passes the return from IAM back up to the validate() function. The return values are then fed into execute(), which handles the actual call to OMS to send a token. A good response looks like this:

``` JSON
{
    "responseId": "20200502235958375",
    "operationResponse": {
        "returnCode": "0000",
        "returnMessage": "Successful"
    },
    "user": {
        "GUID": "05DD8D90E4C64385AAA06EF33883B59D",
        "userName": "albertocamacho1224",
        "firstName": "FIRST",
        "lastName": "LAST",
        "userAccountStatus": "ENABLED",
        "loginTime": "2020-04-30T12:52:54",
        "lastLoginTime": "2020-04-29T09:39:15",
        "accountCreationTime": "2019-07-19T14:54:32",
        "lockedByIntruder": "false",
        "userNameCompliance": "Y",
        "changeDate": "20190719185432Z",
        "applicationAccess": "RSC",
        "flaggedForDeletion": "false",
        "userMfaStatus": "VERIFIED",
        "startDate": "2019-0719T18:54:32Z"
    },
    "authenticationTokenId": null,
    "pingRefreshToken": null,
    "pingToken": null,
    "samlToken": null,
    "actionCode": null,
    "device": {
        "deviceToken": "obfuscated"
    }
}
```

whereas a bad response looks like:

```JSON
{
    "responseId": "20200429131317816",
    "operationResponse": {
        "returnCode": "2015",
        "returnMessage": "Adaptive Auth Service Session error: 1203"
    },
    "user": null,
    "authenticationTokenId": null,
    "pingRefreshToken": null,
    "pingToken": null,
    "samlToken": null,
    "actionCode": null,
    "device":null
}
```

Splunk query for failed response:

``` text
index="pcf" source="diego_cell" sourcetype="cf:logmessage" cf_space_name="prod" | where ('cf_app_name'="blue-rsc-web" OR 'cf_app_name'="green-rsc-web") | search "Adaptive Auth Service Session" NOT "ContentCacheBuster"
```

## Credits

Brian Lawler (iMedia), Sean Sexton (EIM), Allan Olweny (iMedia), and Harish Reddy (I&O) for debugging assistance.
