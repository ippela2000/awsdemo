## GoCloud documentation

### What is front matter? 
GoCloud documentation website is built on a web framework called Hugo. The main structure of the documentation itself is markdown, but there are properties that the site uses to display other content (also called metadata). For example, the title property is used for the title section of the document's page and the menu property tells the site what section of GoCloud the document lives. More information on front matter can be found on Hugo's [website](https://gohugo.io/content-management/front-matter/).

### How to add a document to GoCloud
First, you will need to either convert or write up your document in the markdown syntax, after that, add the following front matter to the top of your markdown document.

```
---
title: Tagging to Manage Costs //Title of Document, this will be show in the left nav
menu: docs //Section you put the document in. This is the first four folders: docs, learning, solutions, and support (minus the blog, which can be contributed to by following this guide: [Blog Front Matter](https://github.nwie.net/Nationwide/cloud-documentation/blob/master/BLOG_FRONT_MATTER.md))
category: aws //Relevant category name for your document, search part of the website uses this information
---
```

Once you add the properties above, wrapped in ---, your document is ready for release. Put in a Pull Request in github, and make sure you put the file whatever folder in content/ is relevant for the document, otherwise the pr will be rejected.

---

**Note on Images:** If your images are looking a bit to large, you can easily use bootstrap utilities to resize them, you will just need to change the image from markdown tag to an HTML tag.

Example: 

```
<img src="../images/firecall-access-definition.png" alt="Firecall Access Icons" class="w-50" />
```
w-25 = 25% width of actual image size
w-50 = 50% width of actual image size
w-75 = 75% width of actual image size
w-100 = 100% width of image size, which isn't needed for images that already look good, sizing wise.

---


For support, email: CloudSuccessTeam@nationwide.com with APRMID: 8353