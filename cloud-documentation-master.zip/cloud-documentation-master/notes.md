## Global Notification Banner Notes
---
- cannot pull content pages into partial for notification because there won't be an account /announcements category. The announcements will be a parital and simpliar to rocket chat, will use a yaml file for its data source