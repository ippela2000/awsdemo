/**
 * Client-side search functionality for the Cloud Documentation website.
 */


// Options for configuring the search behavior.
var searchOptions = {
  // Options for Fuse.js (https://fusejs.io).
  fuse: {
    distance: 100,
    includeMatches: true,
    keys: [
      {
        name: 'title',
        weight: 0.8
      },
      {
        name: 'contents',
        weight: 0.5
      },
      {
        name: 'tags',
        weight: 0.3
      },
      {
        name: 'categories',
        weight: 0.3
      }
    ],
    location: 0,
    maxPatternLength: 32,
    minMatchCharLength: 1,
    shouldSort: true,
    threshold: 0.0,
    tokenize: true
  },
  contentsSummaryLength: 60
};

// The search query.
var searchQuery = getSearchQuery('query');

// Do what we came here to do.
$(document).ready(function() {
  if (window.location.pathname.split('/')[1] == 'search') {
    setSearchQueryInputElementValue(searchQuery);

    if (searchQuery.trim() != '') {
      invokeSearch(searchQuery);
    } else {
      $('#search-results').append('<p class="search-result-empty">Please enter a valid search query above.</p>');
    }
  } else {
    setSearchQueryInputElementValue('');
  }
});


/**
 * Invoke a search from the given query.
 */
function invokeSearch(query) {
  $.getJSON( '/index.json', function(data) {
    var fuse = new Fuse(data, searchOptions.fuse);
    var results = fuse.search(query);

    if(results.length >= 1) {
      setSearchResults(results);
    } else {
      $('#search-results').append('<p class="search-result-empty">No matches found.</p>');
    }
  });
}


/**
 * Set the search results.
 */
function setSearchResults(results){
  $.each(results, function(resultKey, resultValue) {
    var contents = resultValue.item.contents;
    var contentsSummary = '';
    var contentsSummaryHighlights = [];

    if (searchOptions.fuse.tokenize) {
      contentsSummaryHighlights.push(searchQuery);
    } else {
      $.each(resultValue.matches, function(matchKey, matchValue) {
        if (matchValue.key == 'tags' || matchValue.key == 'categories') {
          contentsSummaryHighlights.push(matchValue.value);
        } else if (matchValue.key == 'contents') {
          var summaryStartIndex = matchValue.indices[0][0]-searchOptions.contentsSummaryLength>0?matchValue.indices[0][0]-searchOptions.contentsSummaryLength:0;
          var summaryEndIndex = matchValue.indices[0][1]+searchOptions.contentsSummaryLength<contents.length?matchValue.indices[0][1]+searchOptions.contentsSummaryLength:contents.length;
          contentsSummary += contents.substring(summaryStartIndex, summaryEndIndex);

          contentsSummaryHighlights.push(matchValue.value.substring(matchValue.indices[0][0], matchValue.indices[0][1]-matchValue. indices[0][0]+1));
        }
      });
    }

    if(contentsSummary.length < 1){
      contentsSummary += contents.substring(0, searchOptions.contentsSummaryLength*2);
    }

    // Get the search result template.
    var searchResultTemplate = $('#search-result-template').html();

    // Render the search result.
    var searchResult = renderSearchResult(
      searchResultTemplate,
      {
        key: resultKey,
        title: resultValue.item.title,
        link: resultValue.item.permalink,
        tags: resultValue.item.tags,
        categories: resultValue.item.categories,
        contentsSummary: contentsSummary
      }
    );

    // Append the search result.
    $('#search-results').append(searchResult);

    // Highlight the matches in each search result summary.
    $.each(contentsSummaryHighlights, function(summaryHighlightKey, summaryHighlightValue) {
      $('#search-result-' + resultKey).mark(summaryHighlightValue);
    });
  });
}


/**
 * Get the search query.
 */
function getSearchQuery(name) {
  return decodeURIComponent((location.search.split(name + '=')[1] || '').split('&')[0]).replace(/\+/g, ' ');
}


/**
 * Render a search result from the given search result template and search
 * result data.
 */
function renderSearchResult(template, data) {
  var conditionalMatches;
  var conditionalPattern = /\$\{\s*isset ([a-zA-Z]*) \s*\}(.*)\$\{\s*end\s*}/g;

  // Since the loop below depends on re.lastIndex, a copy of the template string
  // is used to capture any manipulations whilst inside the loop.
  var templateCopy = template;

  while ((conditionalMatches = conditionalPattern.exec(template)) !== null) {
    if(data[conditionalMatches[1]]){
      // This is a valid key, remove conditionals and leave contents.
      templateCopy = templateCopy.replace(conditionalMatches[0], conditionalMatches[2]);
    } else {
      // This is not a valid key, remove the entire section.
      templateCopy = templateCopy.replace(conditionalMatches[0],'');
    }
  }

  template = templateCopy;

  // Perform a simple substitution for any conditionals removed above.
  var key;
  var pattern;
  var regExp;
  for (key in data) {
    pattern = '\\$\\{\\s*' + key + '\\s*\\}';
    regExp = new RegExp(pattern, 'g');
    template = template.replace(regExp, data[key]);
  }

  return template;
}


/**
 * Set the value of the search query input element.
 */
function setSearchQueryInputElementValue(value) {
  $('#search-query').val(value);
}
