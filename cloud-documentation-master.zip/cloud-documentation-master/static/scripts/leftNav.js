$(document).ready(function () {
  //Hiding left nav not related to page
  let grabSection = window.location.pathname.split("/"),
    section = grabSection[1];

  $("header > ul > li> a").removeClass("active");
  $("body > header > ul > li:nth-child(2) > a").addClass("active");
  if (section == "docs") {
    $('nav > ul > li > a[href*="/learning/"]').parent().hide();
    $('nav > ul > li > a[href*="/solutions/"]').parent().hide();
    $('nav > ul > li > a[href*="/search/"]').parent().hide();
    $('nav > ul > li > a[href*="/support/"]').parent().hide();
    $('nav > ul > li > a[href*="/blog/"]').parent().hide();
  } else if (section == "solutions") {
    $('nav > ul > li > a[href*="/learning/"]').parent().hide();
    $('nav > ul > li > a[href*="/docs/"]').parent().hide();
    $('nav > ul > li > a[href*="/search/"]').parent().hide();
    $('nav > ul > li > a[href*="/support/"]').parent().hide();
    $('nav > ul > li > a[href*="/blog/"]').parent().hide();
  } else {
    $('nav > ul > li > a[href*="/learning/"]').parent().hide();
    $('nav > ul > li > a[href*="/docs/"]').parent().hide();
    $('nav > ul > li > a[href*="/blog/"]').parent().hide();
    $('nav > ul > li > a[href*="/search/"]').parent().hide();
    $('nav > ul > li > a[href*="/solutions/"]').parent().hide();
  }
  //

  //Hides section top level nest item (e.g. Docs, Solutions, etc)
  $("li.parent:first > a").hide();
  //

  // Checks clicks on left nav, if it reaches 5 then it highlights the search box
  let clickCount = 0;

  const clickHandler = () => {
    clickCount++;
    if (clickCount >= 5) {
      $("#search-tool-tip").addClass("visible");
    }
  };

  element = document.getElementById("slide-menu");
  element.addEventListener("click", clickHandler);

  $("#search-query").focusin(() => {
    $("#search-tool-tip").removeClass("visible");
  });

  //
});
