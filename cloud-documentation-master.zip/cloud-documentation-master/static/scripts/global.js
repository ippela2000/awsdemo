$(document).ready(function () { 
    //If you use a function more than once, throw it here (also some sensitive functions like tagging)

    // Google Tag Manager DO NOT TOUCH
    let script = document.createElement('script'),
    currentHost = window.location.host,
    urls = ["gocloud.nwie.net", "cloud-documentation.apps.aws.e1.nwie.net", "cnp.nwie.net", "cloud.nwie.net"];
    script.type = "text/javascript";

    if (urls.indexOf(currentHost) !== -1) {
        script.src = "//tags.nationwide.com/Bootstrap.js";
    } else {
        script.src = "//tags.nationwide.com/test/Bootstrap.js";
    }

    document.head.appendChild(script);
    //
});