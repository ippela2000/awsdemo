// This is for any code related to content pages (e.g. Docs, Support, etc)
$(document).ready(function () {
    //Adding or hiding todos depending on content size
    let tocItems = $("h2").length;
    if ((tocItems == 1) || (tocItems == 2)) {
        $("#TableOfContents").hide();
        $("#contentSection h2").hide();
    }

    //Building edit this page url
    const getGitHubPageUrl = () => {
        let noSlashPath,
            splitPath,
            pathName = window.location.pathname,
            baseUrl = "https://github.nwie.net/Nationwide/cloud-documentation/blob/master/content",
            activeLinkHasChild = $("li.active > a").has("span.mark").length //Checks if the active link has a span.mark (which means it has children links)

        noSlashPath = pathName.substring(0, pathName.length - 1);

        splitPath = noSlashPath.split("/");
        splitPath.shift();

        if (activeLinkHasChild == 1 || splitPath.length == 2 ) {
            let fullIndexUrl = baseUrl + noSlashPath + "/_index.md";
            $("#edit-this-page").attr("href", fullIndexUrl);
        } else {
            let fullUrl = baseUrl + noSlashPath + ".md";
            $("#edit-this-page").attr("href", fullUrl);
        }
    }

    getGitHubPageUrl();
});