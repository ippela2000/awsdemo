# Cloud Documentation
The one-stop shop for cloud documentation at Nationwide.

# Dependencies
- GIT
- Use Homebrew or Chocolatey, depending on platform to install hugo **extended** package
  - see [Hugo's Getting Started Gude](https://gohugo.io/getting-started/installing/)
- Node Package Manager (NPM)
  - see [Get npm!](https://www.npmjs.com/get-npm)

# Installation
```bash
git clone --recurse-submodules https://github.nwie.net/Nationwide/cloud-documentation.git
NODE_TLS_REJECT_UNAUTHORIZED=0 npm install
hugo server
```

## When Upgrading hugo-bluesky
Note that when the dependent theme hugo-bluesky is updated, those changes need to be pulled into this repo, and the submodule will need to be committed.

In the root of cloud-documentation:
```bash
git submodule update --init --recursive
git commit themes/hugo-bluesky -m "Updating hugo-bluesky"
git push
```

# Styles
This project uses the latest version of the [Bolt design toolkit](https://prototype1.apps.nwie.net/). Web Components are loaded through the javascript loader in layouts/default/baseof.html. Typography is set sitewide via the bolt-typography class.

Site-specific styles are loaded though main.css, which is compiled from src/scss/main.scss. SCSS architecture follows [Hugo Giraudel's architecture guidelines](https://sass-guidelin.es/#architecture). Individual component-level and layout-level SCSS files should use '@import 'node_modules/@nationwide-bolt/tokens/dist/scss/_tokens.scss';' to make use of Bolt design tokens such as color names.

# Reference
As Hugo is still in active development, often the best way to find out how something is done is to see it in use. Most themes written with Hugo are available on GitHub, and allow you to see side by side the code and the site it generates. A few good resources:

- [Hugo Ananke Theme](https://themes.gohugo.io/gohugo-theme-ananke/)
- [istio.io](https://github.com/istio/istio.io)

# Docker, K8s, CI/CD
To run the site locally for development, from the root of the repository, run:
```
docker-compose up
```

Please refer to the [ci-cd/README.md](ci-cd/README.md) for more information about the build and deployment processes.